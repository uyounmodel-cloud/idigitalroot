#!/usr/bin/env python3
"""Open the exact approved CMS in its local-only review environment."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,platform,posixpath,shutil,signal,socket,subprocess,sys,tarfile,tempfile,threading,time,urllib.request,uuid,zipfile
p=argparse.ArgumentParser();p.add_argument('--node');p.add_argument('--no-open',action='store_true');p.add_argument('--test-seconds',type=int);a=p.parse_args()
root=Path(__file__).resolve().parent
class VisibleLog:
 def __init__(self,console,log):self.console=console;self.log=log
 def write(self,value):self.console.write(value);self.console.flush();self.log.write(value);self.log.flush();return len(value)
 def flush(self):self.console.flush();self.log.flush()
 def isatty(self):return self.console.isatty()
launch_log=(root/'WINDOWS_CMS_LAUNCH.log').open('a',encoding='utf-8');sys.stdout=VisibleLog(sys.stdout,launch_log);sys.stderr=VisibleLog(sys.stderr,launch_log)
logs=root/'CMS_PREVIEW_LOGS';logs.mkdir(exist_ok=True);run=logs/(time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8]);run.mkdir()
meta=json.loads((root/'SOURCE_MANIFEST.json').read_text());stage=None;children=[];handles=[];stop=threading.Event();status='FAIL';port=4197;url=f'http://127.0.0.1:{port}'
def requested_stop(*_):stop.set()
for sig in [signal.SIGTERM,signal.SIGINT]+([signal.SIGHUP] if hasattr(signal,'SIGHUP') else []):signal.signal(sig,requested_stop)
def stop_child(child):
 if child.poll() is None:
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
 try:child.wait(timeout=5)
 except subprocess.TimeoutExpired:
  try:os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  child.wait()
def execute(name,cmd,cwd,env,timeout=60):
 print(name+'...',flush=True);start=time.monotonic();notice=start+15
 with (run/(name+'.log')).open('w') as f:
  child=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);children.append(child)
  while child.poll() is None:
   if stop.is_set():stop_child(child);raise RuntimeError('CMS preparation stopped')
   if time.monotonic()-start>=timeout:stop_child(child);raise RuntimeError(name+' timed out; logs preserved')
   if time.monotonic()>=notice:print(name+' is still running ('+str(int(time.monotonic()-start))+' seconds).',flush=True);notice=time.monotonic()+15
   stop.wait(.2)
  code=child.returncode;children.remove(child)
 if code:raise RuntimeError(name+' failed; logs preserved')
 print(name+' completed.',flush=True)
def pinned_node():
 print('Preparing the approved CMS runtime...',flush=True)
 candidates=[a.node] if a.node else [shutil.which('node')]
 if not a.node:
  for base in sorted(Path('/tmp').glob('idigitalroot-preview-*')):
   candidates.extend(str(x) for x in base.glob('node-v22.16.0-linux-*/bin/node'))
 for candidate in filter(None,candidates):
  try:
   if subprocess.check_output([candidate,'-p','process.versions.node'],text=True,timeout=10).strip()=='22.16.0':print('Reusing Node 22.16.0.',flush=True);return Path(candidate).resolve()
  except (OSError,subprocess.SubprocessError):pass
 if a.node:raise RuntimeError('The specified Node runtime does not match 22.16.0')
 arch={'x86_64':'x64','aarch64':'arm64'}.get(platform.machine())
 if not arch:raise RuntimeError('Unsupported Linux CPU architecture')
 name=f'node-v22.16.0-linux-{arch}.tar.xz';base='https://nodejs.org/dist/v22.16.0/'
 with urllib.request.urlopen(base+'SHASUMS256.txt',timeout=20) as r:sums=r.read().decode()
 expected=next(l.split()[0] for l in sums.splitlines() if l.endswith('  '+name));archive=stage/name
 print('Downloading the verified CMS runtime...',flush=True);start=time.monotonic();notice=start+10;size=0
 with urllib.request.urlopen(base+name,timeout=20) as r,archive.open('wb') as f:
  while True:
   if stop.is_set():raise RuntimeError('CMS runtime download stopped')
   if time.monotonic()-start>180:raise RuntimeError('CMS runtime download exceeded three minutes')
   chunk=r.read(262144)
   if not chunk:break
   f.write(chunk);size+=len(chunk)
   if time.monotonic()>=notice:print(str(size//1048576)+' MB downloaded.',flush=True);notice=time.monotonic()+10
 if hashlib.sha256(archive.read_bytes()).hexdigest()!=expected:raise RuntimeError('Official runtime checksum mismatch')
 with tarfile.open(archive) as t:
  if hasattr(tarfile,'data_filter'):t.extractall(stage,filter='data')
  else:
   for m in t.getmembers():
    n=PurePosixPath(m.name)
    if n.is_absolute() or '..' in n.parts or not (m.isfile() or m.isdir() or m.issym() or m.islnk()):raise RuntimeError('Unsafe runtime archive entry')
    if m.issym() or m.islnk():
     link=posixpath.normpath(posixpath.join(posixpath.dirname(m.name) if m.issym() else '',m.linkname))
     if link.startswith('/') or link=='..' or link.startswith('../'):raise RuntimeError('Unsafe runtime archive link')
   t.extractall(stage)
 return stage/name[:-len('.tar.xz')]/'bin/node'
try:
 print('Preparing the owner-approved Public Website CMS v1.5.3.',flush=True)
 archive=root/meta['source_file']
 if hashlib.sha256(archive.read_bytes()).hexdigest()!=meta['source_sha256']:raise RuntimeError('Approved CMS source checksum mismatch')
 with socket.socket() as s:
  s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
  try:s.bind(('127.0.0.1',port))
  except OSError:raise RuntimeError('CMS port 4197 is occupied. No existing application was stopped.')
 stage=Path(tempfile.mkdtemp(prefix='idigitalroot-cms-preview-',dir='/tmp'));source=stage/'source'
 with zipfile.ZipFile(archive) as z:
  if z.testzip() is not None:raise RuntimeError('CMS ZIP CRC failure')
  if len(z.namelist())!=len(set(z.namelist())):raise RuntimeError('Duplicate CMS archive path')
  for n in z.namelist():
   path=PurePosixPath(n)
   if path.is_absolute() or '..' in path.parts or '\\' in n:raise RuntimeError('Unsafe CMS archive path')
  z.extractall(source)
 execute('Checking approved source integrity',[sys.executable,'scripts/verify_package.py'],source,os.environ.copy())
 node=pinned_node();env={**os.environ,'PATH':str(node.parent)+os.pathsep+os.environ['PATH'],'CMS_LOCAL_PORT':str(port),'CMS_LOCAL_BIND_HOST':'127.0.0.1','TMPDIR':str(stage/'databases')};Path(env['TMPDIR']).mkdir()
 # The approved ZIP supplies the exact compiled server and its module graph. No npm install or source rebuild is needed.
 execute('Checking the CMS module graph',[str(node),'tests/ui-real-module-graph.test.mjs'],source,env)
 print('Starting the local CMS...',flush=True)
 log=(run/'cms-server.log').open('w');handles.append(log);child=subprocess.Popen([str(node),'scripts/local-server.mjs'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);children.append(child)
 deadline=time.monotonic()+45
 while time.monotonic()<deadline and not stop.is_set():
  if child.poll() is not None:raise RuntimeError('CMS server stopped during startup')
  try:
   with urllib.request.urlopen(url+'/',timeout=2) as r:assert r.status==200 and 'loginRoot' in r.read().decode()
   with urllib.request.urlopen(url+'/app.js',timeout=2) as r:assert r.status==200 and 'OWNER REVIEW BUILD v1.5.3' in r.read().decode()
   break
  except Exception:time.sleep(.2)
 else:raise RuntimeError('CMS did not become ready as approved build v1.5.3')
 status='PASS';(run/'READY.json').write_text(json.dumps({'status':'PASS','source_sha256':meta['source_sha256'],'source_modified':False,'local_review_only':True,'deployment_performed':False,'provider_mutation_performed':False,'launcher_pid':os.getpid()},indent=2)+'\n')
 print('CMS READY: '+url,flush=True);print('Click "Sign in for local owner review" in the browser. No password is required for this local fixture.',flush=True)
 print('Keep this window open. This CMS uses its own sample database.',flush=True)
 if not a.no_open:
  cmd=shutil.which('cmd.exe') or ('/mnt/c/Windows/System32/cmd.exe' if Path('/mnt/c/Windows/System32/cmd.exe').exists() else None)
  if cmd:
   try:
    opened=subprocess.run([cmd,'/c','start','',url],capture_output=True,timeout=15)
    if opened.returncode:print('Browser opening failed; enter the CMS address above. The CMS remains running.',flush=True)
   except (OSError,subprocess.TimeoutExpired):print('Browser opening did not complete; enter the CMS address above. The CMS remains running.',flush=True)
  else:print('Enter the CMS address above in your browser.',flush=True)
 print(f'CMS launcher PID: {os.getpid()}. Press Enter here to stop the CMS.',flush=True)
 if a.test_seconds is not None:stop.wait(a.test_seconds)
 else:
  def wait_for_enter():
   try:input();stop.set()
   except EOFError:pass
  threading.Thread(target=wait_for_enter,daemon=True).start()
  while not stop.wait(1):
   if child.poll() is not None:raise RuntimeError('CMS server stopped')
except Exception as e:
 status='FAIL';(run/'error.txt').write_text(str(e)+'\n');print('CMS could not start. Send CMS_PREVIEW_LOGS.zip so I can diagnose it.',flush=True)
finally:
 for child in reversed(children):stop_child(child)
 for f in handles:f.close()
 (run/'RESULT.json').write_text(json.dumps({'status':status,'source_sha256':meta['source_sha256'],'source_modified':False,'deployment_performed':False,'provider_mutation_performed':False},indent=2)+'\n')
 with zipfile.ZipFile(root/'CMS_PREVIEW_LOGS.zip','w',zipfile.ZIP_DEFLATED) as z:
  for f in run.rglob('*'):
   if f.is_file():z.write(f,f.relative_to(run))
 if stage:shutil.rmtree(stage)
 print('CMS stopped. Logs saved in CMS_PREVIEW_LOGS.zip.',flush=True)
sys.exit(0 if status=='PASS' else 1)
