import puppeteer from '/workspace/idigitalroot-work/public-web/node_modules/puppeteer-core/lib/puppeteer/puppeteer-core.js';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const checks=[],errors=[],responses=[],consoleErrors=[],httpErrors=[];
const browser=await puppeteer.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
try {
 const page=await browser.newPage();await page.setViewport({width:1440,height:1000});
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')consoleErrors.push({text:m.text(),location:m.location()})});
 page.on('response',r=>{if(r.url().includes('/api/'))responses.push({path:new URL(r.url()).pathname,status:r.status()});if(r.status()>=400)httpErrors.push({status:r.status(),url:r.url()})});
 const pass=(name,value=true)=>{assert.ok(value,name);checks.push(name);console.log('PASS '+name)};
 await page.goto('http://127.0.0.1:4197/',{waitUntil:'networkidle0'});
 await page.click('#loginButton');await page.waitForSelector('.review-build-marker');await page.waitForNetworkIdle();
 pass('Actual browser local login establishes the approved CMS session');
 pass('Approved v1.5.3 marker',await page.$eval('.review-build-marker',e=>e.textContent.includes('v1.5.3')));
 pass('English LTR',await page.evaluate(()=>document.documentElement.dir==='ltr'));
 await page.screenshot({path:'/workspace/idigitalroot-evidence/cms-dashboard-en.png',fullPage:true});
 const ids=await page.$$eval('.sidebar [data-go]',els=>els.map(e=>e.dataset.go));
 for(const id of ids){await page.click(`.sidebar [data-go="${id}"]`);await page.waitForNetworkIdle();pass('Connected workspace '+id,await page.$eval('#workspace',e=>e.innerText.trim().length>0));}
 await page.click('.sidebar [data-go="editor"]');await page.waitForNetworkIdle();await page.click('[data-preview-lang="ar"]');await page.waitForNetworkIdle();
 pass('English UI and Arabic preview are independent',await page.evaluate(()=>document.documentElement.dir==='ltr'&&document.querySelector('.site').dir==='rtl'));
 await page.click('[data-ui-lang="ar"]');await page.waitForNetworkIdle();
 pass('Arabic RTL with sidebar right',await page.evaluate(()=>document.documentElement.dir==='rtl'&&document.querySelector('.sidebar').getBoundingClientRect().left>innerWidth/2));
 pass('Arabic editor tree right, canvas center, inspector left',await page.evaluate(()=>{const t=document.querySelector('.tree').getBoundingClientRect(),i=document.querySelector('.inspector').getBoundingClientRect(),c=document.querySelector('.canvascard').getBoundingClientRect();return t.left>c.left&&i.left<c.left}));
 await page.screenshot({path:'/workspace/idigitalroot-evidence/cms-editor-ar.png',fullPage:true});
 await page.click('[data-ui-lang="en"]');await page.waitForNetworkIdle();pass('English switch restores LTR',await page.evaluate(()=>document.documentElement.dir==='ltr'));
 pass('Connected API responses successful',responses.length>10&&responses.every(r=>r.status<400));
 pass('No uncaught application exceptions',errors.length===0);
 pass('Only expected missing favicon HTTP/console diagnostic',httpErrors.every(e=>e.status===404&&e.url.endsWith('/favicon.ico'))&&consoleErrors.every(e=>e.location.url?.endsWith('/favicon.ico')));
 fs.writeFileSync('/workspace/idigitalroot-evidence/cms-preview-browser-result.json',JSON.stringify({status:'PASS_WITH_KNOWN_LOCAL_PREVIEW_DIAGNOSTIC',checks,check_count:checks.length,api_response_count:responses.length,api_responses:responses,errors,console_errors:consoleErrors,http_errors:httpErrors,known_limitation:'Unmodified approved local server returns 404 for favicon.ico, producing a browser console diagnostic.',browser:await browser.version(),source_sha256:'62f9e7441372b825d4e8535febdf7679d09d9a39464a8f63843f1eadd5c6d257',source_modified:false,actual_windows_launcher_verified:false,provider_mutation_performed:false},null,2)+'\n');
} finally {await browser.close()}
