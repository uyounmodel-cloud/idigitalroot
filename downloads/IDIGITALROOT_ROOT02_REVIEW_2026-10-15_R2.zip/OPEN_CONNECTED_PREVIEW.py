#!/usr/bin/env python3
"""Single local WSL review launcher; no deploy, login, provider mutation or production data."""
from pathlib import Path,PurePosixPath
from preview_dependencies import install_bundle,ready_install
from review_data import adopt_previous
import argparse,hashlib,json,os,platform,posixpath,shutil,signal,socket,subprocess,sys,tarfile,tempfile,threading,time,urllib.request,zipfile,uuid
p=argparse.ArgumentParser();p.add_argument('--frontend-node');p.add_argument('--backend-node');p.add_argument('--state-root');p.add_argument('--no-open',action='store_true');p.add_argument('--test-seconds',type=int);a=p.parse_args()
root=Path(__file__).resolve().parent;meta=json.loads((root/'OPERATOR_MANIFEST.json').read_text());archive=root/meta['source_file'];stop=threading.Event();child=None;status='FAIL'
run=root/'PREVIEW_LOGS'/(time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8]);run.mkdir(parents=True)
class Tee:
 def __init__(self,console,log):self.console=console;self.log=log
 def write(self,s):self.console.write(s);self.console.flush();self.log.write(s);self.log.flush();return len(s)
 def flush(self):self.console.flush();self.log.flush()
launch=(root/'WINDOWS_PREVIEW_LAUNCH.log').open('a',encoding='utf8');sys.stdout=Tee(sys.stdout,launch);sys.stderr=Tee(sys.stderr,launch)
def interrupted(*_):stop.set()
signal.signal(signal.SIGINT,interrupted);signal.signal(signal.SIGTERM,interrupted)
state=Path(a.state_root).resolve() if a.state_root else Path.home()/'.local/share/idigitalroot-connected-review';stage=state/'toolchains';stage.mkdir(parents=True,exist_ok=True)
def halt(proc):
 if proc and proc.poll() is None:
  if globals().get('ready') is not None and ready.is_set() and proc.stdin:
   try:proc.stdin.write('\n');proc.stdin.flush();proc.wait(timeout=25);return
   except (OSError,subprocess.TimeoutExpired):pass
  os.kill(proc.pid,signal.SIGINT)
  try:proc.wait(timeout=25)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=10)
def execute(name,cmd,cwd,env,timeout=420):
 print(name+'...',flush=True);begin=time.monotonic();notice=begin+15
 with (run/(name+'.log')).open('w') as log:
  proc=subprocess.Popen([str(x) for x in cmd],cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   while proc.poll() is None:
    if stop.is_set() or time.monotonic()-begin>timeout:raise RuntimeError(name+' stopped or timed out; diagnostic logs are saved')
    if time.monotonic()>=notice:print(name+' still running ('+str(int(time.monotonic()-begin))+' seconds)',flush=True);notice=time.monotonic()+15
    stop.wait(.2)
  finally:
   if proc.poll() is None:os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=10)
 if proc.returncode:raise RuntimeError(name+' failed; diagnostic logs are saved')
 print(name+' completed',flush=True)

def get_node(version,override=None):
    print('Preparing Node '+version+'...',flush=True)
    arch={'x86_64':'x64','aarch64':'arm64'}.get(platform.machine())
    cached=stage/f'node-v{version}-linux-{arch}'/'bin/node'
    existing=override or (str(cached) if cached.exists() else shutil.which('node'))
    if existing and subprocess.check_output([existing,'-p','process.versions.node'],text=True,stdin=subprocess.DEVNULL,timeout=10).strip()==version:
        print('Reusing existing Node '+version+'.',flush=True);return Path(existing).resolve()
    if override:raise RuntimeError('Specified Node runtime has the wrong version')
    arch={'x86_64':'x64','aarch64':'arm64'}.get(platform.machine())
    if not arch:raise RuntimeError('Unsupported Linux CPU architecture')
    name=f'node-v{version}-linux-{arch}.tar.xz';base=f'https://nodejs.org/dist/v{version}/'
    with urllib.request.urlopen(base+'SHASUMS256.txt',timeout=45) as r:sums=r.read().decode()
    expected=next(x.split()[0] for x in sums.splitlines() if x.endswith('  '+name))
    pinned=meta.get('nodeArchives',{}).get(name)
    if pinned and expected!=pinned:raise RuntimeError('Official runtime checksum differs from the pinned release')
    downloaded=stage/name
    print('Downloading verified Node '+version+' runtime...',flush=True)
    begin=time.monotonic();notice=begin+10;downloaded_bytes=0
    with urllib.request.urlopen(base+name,timeout=20) as r,downloaded.open('wb') as f:
        while True:
            if stop.is_set():raise RuntimeError('Runtime download stopped; logs are saved.')
            if time.monotonic()-begin>180:raise RuntimeError('Node runtime download exceeded three minutes; logs are saved.')
            chunk=r.read(256*1024)
            if not chunk:break
            f.write(chunk);downloaded_bytes+=len(chunk)
            if time.monotonic()>=notice:
                print('Node '+version+': '+str(downloaded_bytes//1048576)+' MB downloaded.',flush=True);notice=time.monotonic()+10
    if hashlib.sha256(downloaded.read_bytes()).hexdigest()!=expected:raise RuntimeError('Official Node download integrity mismatch')
    with tarfile.open(downloaded) as t:
        if hasattr(tarfile,'data_filter'):t.extractall(stage,filter='data')
        else:
            # Preserve safe extraction on the owner's older Ubuntu Python as well.
            for m in t.getmembers():
                n=PurePosixPath(m.name)
                if n.is_absolute() or '..' in n.parts or not (m.isfile() or m.isdir() or m.issym() or m.islnk()):raise RuntimeError('Unsafe Node archive entry')
                if m.issym() or m.islnk():
                    link=posixpath.normpath(posixpath.join(posixpath.dirname(m.name) if m.issym() else '',m.linkname))
                    if link.startswith('/') or link=='..' or link.startswith('../'):raise RuntimeError('Unsafe Node archive link')
            t.extractall(stage)
    return stage/name[:-len('.tar.xz')]/'bin/node'
try:
 print('ROOT 02 — Universal company website + Connected CMS. Progress appears below.',flush=True)
 if hashlib.sha256(archive.read_bytes()).hexdigest()!=meta['source_sha256']:raise RuntimeError('Source ZIP integrity check failed')
 source=state/meta['source_sha256'][:20]/'source';data=source.parent/'review-data';data.mkdir(parents=True,exist_ok=True)
 if not source.exists():
  with zipfile.ZipFile(archive) as z:
   if z.testzip():raise RuntimeError('Source ZIP CRC failed')
   if len(z.infolist())>5000 or sum(x.file_size for x in z.infolist())>100*1024*1024:raise RuntimeError('Source archive exceeds release limits')
   for info in z.infolist():
    q=PurePosixPath(info.filename)
    if q.is_absolute() or '..' in q.parts or '\\' in info.filename or ((info.external_attr>>16)&0o170000)==0o120000:raise RuntimeError('Unsafe source archive entry')
   source.mkdir(parents=True);z.extractall(source)
 for port in [4198,4400]:
  with socket.socket() as sock:
   if sock.connect_ex(('127.0.0.1',port))==0:raise RuntimeError(f'Local port {port} is occupied. Close your earlier preview window, then restart this launcher.')
 front=get_node('22.19.0',a.frontend_node);back=get_node('22.16.0',a.backend_node);npm=back.parent/'npm'
 env={**os.environ,'PATH':str(front.parent)+os.pathsep+os.environ['PATH'],'ASTRO_TELEMETRY_DISABLED':'1','WRANGLER_SEND_METRICS':'false','npm_config_cache':str(state/'npm-cache'),'npm_config_update_notifier':'false'}
 execute('Verifying sealed source',['sha256sum','--check','SHA256SUMS.txt'],source,env,120)
 print('ROOT 02 uses a separate new review dataset. Earlier candidate folders and drafts are preserved; no incompatible content is imported automatically.',flush=True)
 inheritance=adopt_previous(state,source,data,meta,lambda message:print(message,flush=True))
 (run/'review-data-inheritance.json').write_text(json.dumps(inheritance,indent=2)+'\n')
 lockhash=hashlib.sha256((source/'website/package-lock.json').read_bytes()).hexdigest();stamp=source.parent/'DEPENDENCIES.json'
 if not ready_install(source,lockhash):
  bundle=meta.get('offlineDependencies')
  if bundle and platform.system()=='Linux' and platform.machine()=='x86_64':
   result=install_bundle(root,source,meta,stop,lambda message:print(message,flush=True))
   (run/'dependency-installation.json').write_text(json.dumps(result,indent=2)+'\n')
  else:
   for attempt in range(2):
    label='Installing pinned dependencies attempt '+str(attempt+1)
    try:
     execute(label,[npm,'ci','--engine-strict','--no-audit','--no-fund','--strict-ssl=true','--prefer-offline','--registry=https://registry.npmjs.org','--maxsockets='+('4' if attempt==0 else '2'),'--fetch-retries=1','--fetch-retry-mintimeout=2000','--fetch-retry-maxtimeout=10000','--fetch-timeout=60000'],source/'website',env)
     break
    except RuntimeError:
     text=(run/(label+'.log')).read_text(errors='replace')
     if attempt or stop.is_set() or not any(code in text for code in ['EIDLETIMEOUT','ETIMEDOUT','ECONNRESET','EAI_AGAIN','ECONNREFUSED']):raise
     print('Dependency download was interrupted. Reusing cached packages and retrying with fewer connections.',flush=True)
   stamp.write_text(json.dumps({'lockSha256':lockhash,'npm':'10.9.2','strategy':'PINNED_NPM_CI'})+'\n')
 print('Checking your existing Cloudflare connection read-only (up to 45 seconds).',flush=True);connection='UNVERIFIED'
 try:
  r=subprocess.run([str(front),str(source/'website/node_modules/wrangler/bin/wrangler.js'),'whoami'],cwd=source/'website',env=env,stdin=subprocess.DEVNULL,capture_output=True,text=True,timeout=45);text=(r.stdout+r.stderr).lower();connection='UNAUTHENTICATED' if 'not authenticated' in text else 'AUTHENTICATED' if r.returncode==0 and ('logged in' in text or 'account name' in text) else 'UNVERIFIED'
 except (OSError,subprocess.TimeoutExpired):pass
 (run/'cloudflare-read-only-status.json').write_text(json.dumps({'status':connection,'loginPerformed':False,'providerMutation':False,'rawIdentitySaved':False},indent=2)+'\n')
 print('Read-only identity status: '+connection+'. Continuing with LOCAL Workers only.',flush=True)
 cmd=[sys.executable,'-u',str(source/'scripts/run-native.py'),'--frontend-node',str(front),'--backend-node',str(back),'--data-dir',str(data),'--evidence-dir',str(run/'native')]
 child=subprocess.Popen(cmd,cwd=source,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,stdin=subprocess.PIPE,text=True,bufsize=1,start_new_session=True)
 ready=threading.Event()
 def output():
  with (run/'native-launch.log').open('w') as f:
   for line in child.stdout:
    print(line.rstrip(),flush=True);f.write(line);f.flush()
    if 'INTEGRATED_NATIVE_READY' in line:ready.set()
 threading.Thread(target=output,daemon=True).start();begin=time.monotonic()
 while not ready.wait(.2):
  if child.poll() is not None:raise RuntimeError('Integrated preview could not start; diagnostic logs are saved')
  if stop.is_set() or time.monotonic()-begin>600:raise RuntimeError('Preparation stopped or exceeded ten minutes; diagnostic logs are saved')
 def local_clock():
  while not stop.wait(30):
   results=[]
   for path in ['/__local/cms-scheduled','/__local/analytics-scheduled']:
    try:
     req=urllib.request.Request('http://127.0.0.1:4198'+path,method='POST',headers={'origin':'http://127.0.0.1:4198','x-local-test-runner':'LOCAL_ACCEPTANCE_ONLY'})
     with urllib.request.urlopen(req,timeout=15) as result:results.append({'handler':path,'status':result.status})
    except Exception:results.append({'handler':path,'status':'UNAVAILABLE'})
   with (run/'local-clock.log').open('a') as log:log.write(json.dumps({'time':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'results':results})+'\n')
 threading.Thread(target=local_clock,daemon=True).start()
 status='PASS';print('ROOT 02 — source '+meta['source_sha256'][:12],flush=True);print('READY — Website: http://127.0.0.1:4400   CMS: http://127.0.0.1:4198',flush=True)
 print('Click “Sign in for local owner review” in the CMS. Review edits persist for this candidate.',flush=True)
 print('This uses sample LOCAL data. No Cloudflare deployment has occurred. See FEATURE_STATUS.md for release gates.',flush=True)
 if not a.no_open:
  win=shutil.which('cmd.exe') or ('/mnt/c/Windows/System32/cmd.exe' if Path('/mnt/c/Windows/System32/cmd.exe').exists() else None)
  if win:
   for url in ['http://127.0.0.1:4400','http://127.0.0.1:4198']:
    try:subprocess.run([win,'/c','start','',url],capture_output=True,timeout=15)
    except (OSError,subprocess.TimeoutExpired):print('Open the local addresses above in your browser.',flush=True)
 print('Keep this window open. Press Enter here when finished to stop both local applications.',flush=True)
 if a.test_seconds is not None:
  deadline=time.monotonic()+a.test_seconds
  while not stop.wait(.2) and time.monotonic()<deadline:
   if child.poll() is not None:raise RuntimeError('A local service stopped; diagnostic logs are saved')
 else:
  def wait_input():
   try:input();stop.set()
   except EOFError:pass
  threading.Thread(target=wait_input,daemon=True).start()
  while not stop.wait(1):
   if child.poll() is not None:raise RuntimeError('A local service stopped; diagnostic logs are saved')
except Exception as e:
 status='FAIL';(run/'error.txt').write_text(str(e)+'\n');print(str(e),flush=True);print('Send PREVIEW_LOGS.zip for diagnosis. You do not need to debug it.',flush=True)
finally:
 stop.set()
 halt(child)
 if child and child.returncode not in (None,0):
  status='FAIL';(run/'error.txt').write_text('Native launcher exited unexpectedly with code '+str(child.returncode)+'; see native-launch.log\n')
 (run/'RESULT.json').write_text(json.dumps({'status':status,'sourceSha256':meta['source_sha256'],'deployment':False,'providerMutation':False,'dataKept':True},indent=2)+'\n')
 with zipfile.ZipFile(root/'PREVIEW_LOGS.zip','w',zipfile.ZIP_DEFLATED) as z:
  for f in run.rglob('*'):
   if f.is_file() and f.suffix in ['.log','.json','.txt']:z.write(f,f.relative_to(run))
 print('Preview stopped. Your local review data is kept. Diagnostics: PREVIEW_LOGS.zip',flush=True)
sys.exit(0 if status=='PASS' else 1)
