# iDigitalRoot Website Studio review source

Owner-directed CMS UI rebuild and approved v4.3 public visual restoration. Start with docs/CMS_STUDIO_OWNER_GUIDE.md and docs/CMS_STUDIO_CHANGE_REPORT.md. Original authority is in docs/AUTHORITY_REGISTER.md.

This remains a Phase 1 candidate; not owner-approved, production-ready or deployed. Cloudflare Workers/D1/private R2, pinned toolchain and frozen Core0001–0016/Analytics0001–0002 remain. No provider resources changed. Use scripts/run-native.py with fresh isolated data for acceptance; see docs/REPRODUCTION.md.
