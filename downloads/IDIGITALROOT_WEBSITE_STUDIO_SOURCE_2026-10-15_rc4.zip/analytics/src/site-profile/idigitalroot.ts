export type PrivacyMode = 'OFF' | 'COOKIELESS' | 'CONSENTED';

export type PropertyRule =
  | { type: 'string'; maxLength: number; pattern?: RegExp; enum?: readonly string[] }
  | { type: 'number'; min?: number; max?: number }
  | { type: 'boolean' };

export interface EventDefinition {
  eventKey: string;
  schemaVersion: 1;
  eventClass: string;
  publicAllowed: boolean;
  allowedModes: readonly Exclude<PrivacyMode, 'OFF'>[];
  propertyRules: Readonly<Record<string, PropertyRule>>;
  rawExportAllowed: boolean;
}

const HEX64 = /^[a-f0-9]{64}$/;
const SAFE_CODE = /^[A-Za-z0-9_.:-]+$/;

export const IDIGITALROOT_ANALYTICS_PROFILE = {
  profileKey: 'idigitalroot-public',
  profileVersion: 'p1-an-01-v1',
  endpointPath: '/api/analytics/v1/events',
  maxBodyBytes: 65536,
  maxBatchEvents: 25,
  maxEventIdLength: 128,
  maxClockSkewSeconds: 900,
  maxDateRangeDays: 366,
  maxQueryPageSize: 100,
  maxExportRows: 1000,
  maxRollupEventsPerWindow: 5000,
  eventRegistryVersion: 'v1',
  eventDefinitions: {
    page_view: {
      eventKey: 'page_view', schemaVersion: 1, eventClass: 'NAVIGATION', publicAllowed: true,
      allowedModes: ['COOKIELESS', 'CONSENTED'], propertyRules: {}, rawExportAllowed: true,
    },
    component_interaction: {
      eventKey: 'component_interaction', schemaVersion: 1, eventClass: 'ENGAGEMENT', publicAllowed: true,
      allowedModes: ['COOKIELESS', 'CONSENTED'],
      propertyRules: { interaction_key: { type: 'string', maxLength: 64, pattern: SAFE_CODE } }, rawExportAllowed: true,
    },
    internal_search: {
      eventKey: 'internal_search', schemaVersion: 1, eventClass: 'SEARCH', publicAllowed: true,
      allowedModes: ['COOKIELESS', 'CONSENTED'],
      propertyRules: {
        result_count_class: { type: 'string', maxLength: 24, enum: ['ZERO','ONE','TWO_TO_FIVE','SIX_TO_TWENTY','TWENTY_PLUS','UNKNOWN'] },
        query_length_class: { type: 'string', maxLength: 16, enum: ['EMPTY','SHORT','MEDIUM','LONG','UNKNOWN'] },
        query_group_hash: { type: 'string', maxLength: 64, pattern: HEX64 },
      }, rawExportAllowed: false,
    },
    inquiry_funnel_step: {
      eventKey: 'inquiry_funnel_step', schemaVersion: 1, eventClass: 'FUNNEL', publicAllowed: true,
      allowedModes: ['COOKIELESS', 'CONSENTED'],
      propertyRules: {
        step_key: { type: 'string', maxLength: 32, pattern: SAFE_CODE },
        outcome: { type: 'string', maxLength: 16, enum: ['VIEW','COMPLETE','ERROR','SUBMIT_ATTEMPT'] },
      }, rawExportAllowed: true,
    },
    inquiry_accepted: {
      eventKey: 'inquiry_accepted', schemaVersion: 1, eventClass: 'FUNNEL', publicAllowed: false,
      allowedModes: ['COOKIELESS', 'CONSENTED'],
      propertyRules: { conversion_kind: { type: 'string', maxLength: 32, enum: ['inquiry_accepted'] } }, rawExportAllowed: true,
    },
    web_vital: {
      eventKey: 'web_vital', schemaVersion: 1, eventClass: 'PERFORMANCE', publicAllowed: true,
      allowedModes: ['COOKIELESS', 'CONSENTED'],
      propertyRules: {
        metric_key: { type: 'string', maxLength: 16, enum: ['LCP','INP','CLS','FCP','TTFB'] },
        value_bucket: { type: 'string', maxLength: 32, pattern: SAFE_CODE },
      }, rawExportAllowed: true,
    },
    runtime_error: {
      eventKey: 'runtime_error', schemaVersion: 1, eventClass: 'RUNTIME_HEALTH', publicAllowed: true,
      allowedModes: ['COOKIELESS', 'CONSENTED'],
      propertyRules: {
        error_code: { type: 'string', maxLength: 128, pattern: SAFE_CODE },
        build_id: { type: 'string', maxLength: 64, pattern: SAFE_CODE },
        stack_signature: { type: 'string', maxLength: 64, pattern: HEX64 },
      }, rawExportAllowed: false,
    },
    ingest_security: {
      eventKey: 'ingest_security', schemaVersion: 1, eventClass: 'BOT_SECURITY', publicAllowed: false,
      allowedModes: ['COOKIELESS', 'CONSENTED'], propertyRules: {}, rawExportAllowed: false,
    },
  } satisfies Record<string, EventDefinition>,
} as const;

export type SeededEventKey = keyof typeof IDIGITALROOT_ANALYTICS_PROFILE.eventDefinitions;
