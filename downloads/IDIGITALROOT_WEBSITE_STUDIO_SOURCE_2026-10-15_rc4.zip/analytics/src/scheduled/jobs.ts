import type { D1Database } from '../core/types.js';
import { REPORT_KEYS } from '../analytics/reports.js';
import { rollupWindow, analyticsHealth, type Granularity } from '../analytics/rollup.js';
import { replayConversionOutbox } from '../analytics/outbox.js';
export async function runClosedWindowRollups(analyticsDb:D1Database,granularity:Granularity,start:string,end:string){const results=[];for(const key of REPORT_KEYS)results.push(await rollupWindow(analyticsDb,key,granularity,start,end));return results}
export async function runScheduledAnalytics(analyticsDb:D1Database,coreDb:D1Database,start:string,end:string,granularity:Granularity='HOUR'){return {rollups:await runClosedWindowRollups(analyticsDb,granularity,start,end),outbox:await replayConversionOutbox(coreDb,analyticsDb,25),health:await analyticsHealth(analyticsDb)}}
