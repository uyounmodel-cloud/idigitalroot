import type { AnalyticsEnv } from './core/types.js';
import { AnalyticsError } from './core/errors.js';
import { ingestAnalytics, recordSecurityRejection } from './analytics/ingest.js';
import { IDIGITALROOT_ANALYTICS_PROFILE } from './site-profile/idigitalroot.js';
function json(status:number,body:Record<string,unknown>){return new Response(JSON.stringify(body),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}})}
export async function handleAnalyticsRequest(request:Request,env:AnalyticsEnv):Promise<Response>{
  const requestId=request.headers.get('x-request-id')?.slice(0,128)||crypto.randomUUID();
  try{
    const url=new URL(request.url); if(url.pathname!==IDIGITALROOT_ANALYTICS_PROFILE.endpointPath)return json(404,{ok:false,code:'NOT_FOUND',requestId});
    if(request.method!=='POST')return json(405,{ok:false,code:'METHOD_NOT_ALLOWED',requestId});
    const outcome=await ingestAnalytics(request,env); return json(202,{ok:true,accepted:outcome.accepted,duplicate:outcome.duplicate,ignoredOff:outcome.ignoredOff,requestId});
  }catch(error){
    const e=error instanceof AnalyticsError?error:new AnalyticsError(500,'INTERNAL_ERROR','Analytics request was not accepted.');
    await recordSecurityRejection(env.ANALYTICS_DB,e.code,request);
    return json(e.status,{ok:false,code:e.code,requestId});
  }
}
export default {fetch:handleAnalyticsRequest};
