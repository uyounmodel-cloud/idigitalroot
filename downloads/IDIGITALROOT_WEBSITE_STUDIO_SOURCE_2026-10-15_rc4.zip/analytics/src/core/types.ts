export type SqlValue = string | number | null | ArrayBuffer | Uint8Array;

export interface D1Result<T = Record<string, unknown>> {
  success: boolean;
  results?: T[];
  meta?: Record<string, unknown>;
}

export interface D1PreparedStatement {
  bind(...values: SqlValue[]): D1PreparedStatement;
  first<T = Record<string, unknown>>(column?: string): Promise<T | null>;
  all<T = Record<string, unknown>>(): Promise<D1Result<T>>;
  run<T = Record<string, unknown>>(): Promise<D1Result<T>>;
}

export interface D1Database {
  prepare(sql: string): D1PreparedStatement;
  batch<T = Record<string, unknown>>(statements: D1PreparedStatement[]): Promise<D1Result<T>[]>;
}

export interface RateLimitResult { success: boolean; }
export interface RateLimiter { limit(input: { key: string }): Promise<RateLimitResult>; }

export interface ProviderRequestMetadata {
  country?: unknown;
  continent?: unknown;
  city?: unknown;
  region?: unknown;
  regionCode?: unknown;
  postalCode?: unknown;
  latitude?: unknown;
  longitude?: unknown;
  timezone?: unknown;
  botManagement?: unknown;
}

export type AnalyticsPermission =
  | 'analytics.read.aggregate'
  | 'analytics.read.raw'
  | 'analytics.export'
  | 'analytics.config.manage';

export interface TrustedCmsContext {
  authenticated: boolean;
  actorId: string;
  sessionId: string;
  requestId: string;
  environmentKey: string;
}

export interface AuthorizationVerifier {
  permissions(context: TrustedCmsContext): Promise<ReadonlySet<AnalyticsPermission>>;
}

export interface Clock { now(): Date; }
export const SYSTEM_CLOCK: Clock = { now: () => new Date() };

export interface AnalyticsEnv {
  ANALYTICS_DB: D1Database;
  CORE_DB?: D1Database;
  ANALYTICS_RATE_LIMITER?: RateLimiter;
  PUBLIC_ORIGINS: readonly string[];
  VISITOR_HMAC_SECRET: string;
  SEARCH_HMAC_SECRET: string;
  ENVIRONMENT_KEY: string;
}
