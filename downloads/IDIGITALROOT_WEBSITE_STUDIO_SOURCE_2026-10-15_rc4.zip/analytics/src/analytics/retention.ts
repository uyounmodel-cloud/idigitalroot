import type { D1Database } from '../core/types.js';
import { utcSeconds } from '../core/stable.js';
type Row=Record<string,unknown>;
export interface SyntheticRetentionFixture { testOnlySyntheticDataset:true; status:'APPROVED'; categoryKey:string; policyVersionKey:string; durationSeconds:number; }
export interface RetentionResult { blocked:boolean; categoryKey:string; deleted:number; reason:string; }
const TARGETS:Record<string,{table:string;column:string;where?:string}>={
  'analytics.raw_events':{table:'analytics_events',column:'received_at'},
  'analytics.session_pseudonyms':{table:'analytics_sessions',column:'last_event_at'},
  'analytics.consent_receipts':{table:'analytics_consent_receipts',column:'captured_at'},
  'analytics.aggregate_rollups':{table:'analytics_rollups',column:'window_end'},
  'analytics.ingest_security':{table:'analytics_ingest_security_buckets',column:'bucket_start'},
};
export async function runRetentionGate(analyticsDb:D1Database,coreDb:D1Database,categoryKey:string,nowDate=new Date(),synthetic?:SyntheticRetentionFixture):Promise<RetentionResult>{
  const cat=await coreDb.prepare('SELECT retention_category_id,policy_gate_state FROM retention_categories WHERE category_key=?').bind(categoryKey).first<Row>();
  if(!cat)return {blocked:true,categoryKey,deleted:0,reason:'CATEGORY_UNKNOWN'};
  let duration:number|null=null;
  if(synthetic){
    if(!synthetic.testOnlySyntheticDataset||synthetic.status!=='APPROVED'||synthetic.categoryKey!==categoryKey||!synthetic.policyVersionKey||!Number.isInteger(synthetic.durationSeconds)||synthetic.durationSeconds<0)return {blocked:true,categoryKey,deleted:0,reason:'SYNTHETIC_FIXTURE_INVALID'};
    duration=synthetic.durationSeconds;
  } else {
    if(cat.policy_gate_state!=='APPROVED')return {blocked:true,categoryKey,deleted:0,reason:'POLICY_GATE_OPEN'};
    const p=await coreDb.prepare(`SELECT duration_seconds FROM retention_policy_versions WHERE retention_category_id=? AND status='APPROVED' AND duration_seconds IS NOT NULL AND effective_at IS NOT NULL AND effective_at<=? ORDER BY effective_at DESC LIMIT 1`).bind(cat.retention_category_id as string,utcSeconds(nowDate)).first<Row>();
    if(!p||!Number.isInteger(p.duration_seconds))return {blocked:true,categoryKey,deleted:0,reason:'NO_APPROVED_POLICY'};
    duration=Number(p.duration_seconds);
  }
  const target=TARGETS[categoryKey]; if(!target)return {blocked:true,categoryKey,deleted:0,reason:'NO_TECHNICAL_TARGET'};
  const cutoff=utcSeconds(new Date(nowDate.valueOf()-duration!*1000));
  const r=await analyticsDb.prepare(`DELETE FROM ${target.table} WHERE rowid IN (SELECT rowid FROM ${target.table} WHERE ${target.column}<? LIMIT 100)`).bind(cutoff).run<Row>();
  const changes=Number((r.meta as Record<string,unknown>|undefined)?.changes??0);
  return {blocked:false,categoryKey,deleted:changes,reason:synthetic?'SYNTHETIC_TEST_POLICY':'APPROVED_POLICY'};
}
