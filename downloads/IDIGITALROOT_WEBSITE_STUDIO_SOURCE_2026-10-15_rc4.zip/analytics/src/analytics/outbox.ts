import type { D1Database } from '../core/types.js';
import { stableJson, utcSeconds } from '../core/stable.js';

type Row=Record<string,unknown>;
export interface ReplayResult { selected:number; delivered:number; retryable:number; }
const FORBIDDEN=/(name|email|phone|answer|jwt|token|cookie|authorization)/i;
function safePayload(text:unknown):Record<string,unknown>{
  if(typeof text!=='string'||text.length>8192) throw new Error('OUTBOX_PAYLOAD_INVALID');
  let value:unknown; try{value=JSON.parse(text)}catch{throw new Error('OUTBOX_PAYLOAD_INVALID')}
  if(!value||typeof value!=='object'||Array.isArray(value))throw new Error('OUTBOX_PAYLOAD_INVALID');
  const out=value as Record<string,unknown>;
  for(const [k,v] of Object.entries(out)){
    if(FORBIDDEN.test(k)|| (typeof v==='string'&&FORBIDDEN.test(v)&&k!=='conversion_kind')) throw new Error('OUTBOX_FORBIDDEN_FIELD');
  }
  if(out.conversion_kind!=='inquiry_accepted')throw new Error('OUTBOX_CONVERSION_KIND');
  return out;
}
function bounded(x:unknown,n=128):string|null{return typeof x==='string'&&x.length>0&&x.length<=n?x:null}

async function persistConversion(analyticsDb:D1Database,row:Row,now:string):Promise<void>{
  const id=String(row.conversion_event_id); const payload=safePayload(row.sanitized_payload_json);
  const existing=await analyticsDb.prepare('SELECT event_id,event_key,properties_json FROM analytics_events WHERE event_id=?').bind(id).first<Row>();
  const properties=stableJson({conversion_kind:'inquiry_accepted'});
  if(existing){ if(existing.event_key!=='inquiry_accepted'||existing.properties_json!==properties)throw new Error('CONVERSION_EVENT_CONFLICT'); return; }
  let session:Row|null=null;
  const sid=bounded(row.analytics_session_id);
  if(sid) session=await analyticsDb.prepare(`SELECT session_id,visitor_key_hash,consent_mode,locale_code,browser_class,os_class,device_class,language_class,viewport_class,country_code,continent_code,bot_class FROM analytics_sessions WHERE session_id=?`).bind(sid).first<Row>();
  const route=bounded(payload.route_id); const locale=bounded(payload.locale_code,16) ?? (session?.locale_code as string|null) ?? null;
  await analyticsDb.prepare(`INSERT INTO analytics_events(event_id,event_key,schema_version,occurred_at,received_at,session_id,visitor_key_hash,route_id,entity_id,revision_id,section_instance_id,component_key,locale_code,consent_mode,browser_class,os_class,device_class,language_class,viewport_class,country_code,continent_code,bot_class,properties_json,ingest_batch_id)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(
    id,'inquiry_accepted',Number(row.event_schema_version),now,now,(session?.session_id as string|null|undefined)??null,(session?.visitor_key_hash as string|null|undefined)??null,route,null,null,null,null,locale,
    (session?.consent_mode as string|null|undefined)??'COOKIELESS',(session?.browser_class as string|null|undefined)??null,(session?.os_class as string|null|undefined)??null,(session?.device_class as string|null|undefined)??null,(session?.language_class as string|null|undefined)??null,(session?.viewport_class as string|null|undefined)??null,
    (session?.country_code as string|null|undefined)??null,(session?.continent_code as string|null|undefined)??null,(session?.bot_class as string|null|undefined)??'UNKNOWN',properties,`outbox:${String(row.outbox_id).slice(0,96)}`
  ).run();
}

export async function replayConversionOutbox(coreDb:D1Database,analyticsDb:D1Database,limit=25,nowDate=new Date()):Promise<ReplayResult>{
  if(!Number.isInteger(limit)||limit<1||limit>50)throw new Error('OUTBOX_LIMIT'); const now=utcSeconds(nowDate);
  const rows=await coreDb.prepare(`SELECT outbox_id,lead_id,conversion_event_id,analytics_session_id,event_schema_version,sanitized_payload_json,state,attempt_count,next_attempt_at
    FROM analytics_conversion_outbox WHERE state IN ('PENDING','FAILED') AND (next_attempt_at IS NULL OR next_attempt_at<=?) ORDER BY created_at ASC LIMIT ?`).bind(now,limit).all<Row>();
  let delivered=0,retryable=0;
  for(const row of rows.results??[]){
    try{
      await persistConversion(analyticsDb,row,now);
      await coreDb.prepare(`UPDATE analytics_conversion_outbox SET state='SENT',attempt_count=attempt_count+1,last_error_code=NULL,sent_at=?,row_version=row_version+1 WHERE outbox_id=? AND state<>'SENT'`).bind(now,row.outbox_id as string).run();
      delivered++;
    }catch{
      await coreDb.prepare(`UPDATE analytics_conversion_outbox SET state='PENDING',attempt_count=attempt_count+1,last_error_code='ANALYTICS_WRITE_FAILED',next_attempt_at=?,row_version=row_version+1 WHERE outbox_id=? AND state<>'SENT'`).bind(now,row.outbox_id as string).run();
      retryable++;
    }
  }
  return {selected:(rows.results??[]).length,delivered,retryable};
}
