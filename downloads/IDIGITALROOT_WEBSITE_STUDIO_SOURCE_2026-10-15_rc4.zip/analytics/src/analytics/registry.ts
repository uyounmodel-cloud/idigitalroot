import type { D1Database } from '../core/types.js';
import { AnalyticsError } from '../core/errors.js';
import { IDIGITALROOT_ANALYTICS_PROFILE, type EventDefinition, type PropertyRule, type SeededEventKey } from '../site-profile/idigitalroot.js';
import { stableJson, utf8Bytes } from '../core/stable.js';

type Row = Record<string, unknown>;

export interface RegistryRecord {
  definition: EventDefinition;
  enabled: boolean;
  allowedModes: readonly string[];
  dbRawExportAllowed: boolean;
}

export async function loadRegistryRecord(db: D1Database, eventKey: string, schemaVersion: number): Promise<RegistryRecord> {
  const code = (IDIGITALROOT_ANALYTICS_PROFILE.eventDefinitions as Record<string, EventDefinition>)[eventKey];
  if (!code) throw new AnalyticsError(422, 'UNKNOWN_EVENT', 'Event is not registered.');
  if (schemaVersion !== code.schemaVersion) throw new AnalyticsError(422, 'UNSUPPORTED_SCHEMA_VERSION', 'Event schema version is unsupported.');
  const row = await db.prepare(`SELECT event_key,event_class,schema_version,enabled,allowed_modes_json,property_schema_json,raw_export_allowed
    FROM analytics_event_registry WHERE event_key=? AND schema_version=?`).bind(eventKey, schemaVersion).first<Row>();
  if (!row) throw new AnalyticsError(422, 'UNKNOWN_EVENT', 'Event is not registered.');
  if (row.enabled !== 1) throw new AnalyticsError(422, 'EVENT_DISABLED', 'Event is disabled.');
  if (row.event_class !== code.eventClass) throw new AnalyticsError(503, 'REGISTRY_MISMATCH', 'Analytics registry is unavailable.');
  let allowedModes: string[] = [];
  let dbPropertySchema: Record<string, unknown> = {};
  try {
    allowedModes = JSON.parse(String(row.allowed_modes_json)) as string[];
    dbPropertySchema = JSON.parse(String(row.property_schema_json)) as Record<string, unknown>;
  } catch {
    throw new AnalyticsError(503, 'REGISTRY_MISMATCH', 'Analytics registry is unavailable.');
  }
  const codeAllowed = new Set(code.allowedModes);
  if (!allowedModes.every((m) => codeAllowed.has(m as never))) throw new AnalyticsError(503, 'REGISTRY_MISMATCH', 'Analytics registry is unavailable.');
  const dbAllowed = new Set(Array.isArray(dbPropertySchema.allowed) ? dbPropertySchema.allowed.map(String) : []);
  if (dbPropertySchema.additionalProperties === false && Object.keys(code.propertyRules).length !== 0) {
    throw new AnalyticsError(503, 'REGISTRY_MISMATCH', 'Analytics registry is unavailable.');
  }
  if (dbAllowed.size && Object.keys(code.propertyRules).some((k) => !dbAllowed.has(k))) {
    throw new AnalyticsError(503, 'REGISTRY_MISMATCH', 'Analytics registry is unavailable.');
  }
  return { definition: code, enabled: true, allowedModes, dbRawExportAllowed: row.raw_export_allowed === 1 };
}

function validateProperty(rule: PropertyRule, value: unknown, key: string): void {
  if (rule.type === 'string') {
    if (typeof value !== 'string') throw new AnalyticsError(422, 'INVALID_PROPERTY', `Invalid property: ${key}.`);
    if (value.length > rule.maxLength) throw new AnalyticsError(422, 'PROPERTY_LIMIT', `Invalid property: ${key}.`);
    if (rule.pattern && !rule.pattern.test(value)) throw new AnalyticsError(422, 'INVALID_PROPERTY', `Invalid property: ${key}.`);
    if (rule.enum && !rule.enum.includes(value)) throw new AnalyticsError(422, 'INVALID_PROPERTY', `Invalid property: ${key}.`);
    return;
  }
  if (rule.type === 'number') {
    if (typeof value !== 'number' || !Number.isFinite(value)) throw new AnalyticsError(422, 'INVALID_PROPERTY', `Invalid property: ${key}.`);
    if (rule.min != null && value < rule.min) throw new AnalyticsError(422, 'INVALID_PROPERTY', `Invalid property: ${key}.`);
    if (rule.max != null && value > rule.max) throw new AnalyticsError(422, 'INVALID_PROPERTY', `Invalid property: ${key}.`);
    return;
  }
  if (typeof value !== 'boolean') throw new AnalyticsError(422, 'INVALID_PROPERTY', `Invalid property: ${key}.`);
}

export function validateProperties(definition: EventDefinition, value: unknown): Record<string, unknown> {
  if (value == null) return {};
  if (typeof value !== 'object' || Array.isArray(value)) throw new AnalyticsError(422, 'INVALID_PROPERTIES', 'Properties must be an object.');
  const input = value as Record<string, unknown>;
  const rules = definition.propertyRules;
  const keys = Object.keys(input);
  if (keys.length > 16) throw new AnalyticsError(422, 'PROPERTY_LIMIT', 'Too many properties.');
  for (const key of keys) {
    const rule = rules[key];
    if (!rule) throw new AnalyticsError(422, 'UNKNOWN_PROPERTY', 'Event property is not registered.');
    validateProperty(rule, input[key], key);
  }
  const encoded = stableJson(input);
  if (utf8Bytes(encoded) > 8192) throw new AnalyticsError(422, 'PROPERTY_LIMIT', 'Properties are too large.');
  return JSON.parse(encoded) as Record<string, unknown>;
}

export function seededEventKeys(): SeededEventKey[] {
  return Object.keys(IDIGITALROOT_ANALYTICS_PROFILE.eventDefinitions) as SeededEventKey[];
}
