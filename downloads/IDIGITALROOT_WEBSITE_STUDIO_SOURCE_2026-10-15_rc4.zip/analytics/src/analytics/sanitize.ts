import { AnalyticsError } from '../core/errors.js';

const SECRETISH = /(authorization|bearer\s|access[_-]?token|refresh[_-]?token|api[_-]?key|password|passwd|secret|session[_-]?token|jwt)/i;
const JWTISH = /eyJ[a-zA-Z0-9_-]{8,}\.[a-zA-Z0-9_-]{8,}\.[a-zA-Z0-9_-]{8,}/;
const SAFE_CAMPAIGN = /^[\p{L}\p{N} ._~\-:/+]{0,240}$/u;

export interface AcquisitionInput {
  referrerUrl?: unknown;
  utmSource?: unknown;
  utmMedium?: unknown;
  utmCampaign?: unknown;
  utmContent?: unknown;
  utmTerm?: unknown;
}

export interface SanitizedAcquisition {
  referrerClass: string;
  referrerHost: string | null;
  utmSource: string | null;
  utmMedium: string | null;
  utmCampaign: string | null;
  utmContent: string | null;
  utmTerm: string | null;
}

function campaign(value: unknown, max: number): string | null {
  if (value == null || value === '') return null;
  if (typeof value !== 'string') throw new AnalyticsError(422, 'INVALID_ACQUISITION', 'Invalid acquisition value.');
  const v = value.replace(/[\u0000-\u001F\u007F]/g, '').trim();
  if (!v) return null;
  if (v.length > max || !SAFE_CAMPAIGN.test(v) || SECRETISH.test(v) || JWTISH.test(v)) {
    throw new AnalyticsError(422, 'UNSAFE_ACQUISITION_VALUE', 'Invalid acquisition value.');
  }
  return v;
}

function classifyReferrer(ref: string | null, publicOrigins: readonly string[], hasCampaign: boolean): { cls: string; host: string | null } {
  if (!ref) return { cls: hasCampaign ? 'CAMPAIGN' : 'DIRECT', host: null };
  let url: URL;
  try { url = new URL(ref); } catch { return { cls: 'UNKNOWN', host: null }; }
  if (!['http:', 'https:'].includes(url.protocol)) return { cls: 'UNKNOWN', host: null };
  const refOrigin = url.origin.toLowerCase();
  if (publicOrigins.some((o) => o.toLowerCase() === refOrigin)) return { cls: 'SAME_SITE', host: null };
  const host = url.hostname.toLowerCase().slice(0, 253);
  if (/(^|\.)(google|bing|yahoo|duckduckgo)\./.test(host)) return { cls: 'SEARCH', host };
  if (/(^|\.)(facebook|instagram|linkedin|x|twitter|tiktok)\./.test(host)) return { cls: 'SOCIAL', host };
  return { cls: hasCampaign ? 'CAMPAIGN' : 'REFERRAL', host };
}

export function sanitizeAcquisition(input: AcquisitionInput | undefined, publicOrigins: readonly string[]): SanitizedAcquisition {
  const utmSource = campaign(input?.utmSource, 160);
  const utmMedium = campaign(input?.utmMedium, 160);
  const utmCampaign = campaign(input?.utmCampaign, 240);
  const utmContent = campaign(input?.utmContent, 240);
  const utmTerm = campaign(input?.utmTerm, 240);
  const hasCampaign = Boolean(utmSource || utmMedium || utmCampaign || utmContent || utmTerm);
  const ref = input?.referrerUrl == null ? null : String(input.referrerUrl).slice(0, 2048);
  const { cls, host } = classifyReferrer(ref, publicOrigins, hasCampaign);
  return { referrerClass: cls, referrerHost: host, utmSource, utmMedium, utmCampaign, utmContent, utmTerm };
}
