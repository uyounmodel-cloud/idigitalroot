import type { ProviderRequestMetadata } from '../core/types.js';

export interface CoarseDimensions {
  browserClass: string;
  osClass: string;
  deviceClass: string;
  languageClass: string;
  viewportClass: string;
  countryCode: string | null;
  continentCode: string | null;
  botClass: 'HUMAN_LIKELY' | 'AUTOMATION_LIKELY' | 'VERIFIED_BOT' | 'UNKNOWN';
}

function upperCode(value: unknown, length: number): string | null {
  if (typeof value !== 'string') return null;
  const v = value.trim().toUpperCase();
  return new RegExp(`^[A-Z]{${length}}$`).test(v) ? v : null;
}

export function classifyBrowser(userAgent: string | null): string {
  const ua = (userAgent ?? '').toLowerCase();
  if (!ua) return 'UNKNOWN';
  if (ua.includes('edg/')) return 'EDGE';
  if (ua.includes('firefox/')) return 'FIREFOX';
  if (ua.includes('chrome/') || ua.includes('crios/')) return 'CHROME';
  if (ua.includes('safari/') && !ua.includes('chrome/') && !ua.includes('crios/')) return 'SAFARI';
  return 'OTHER';
}

export function classifyOs(userAgent: string | null): string {
  const ua = (userAgent ?? '').toLowerCase();
  if (!ua) return 'UNKNOWN';
  if (ua.includes('android')) return 'ANDROID';
  if (/(iphone|ipad|ipod)/.test(ua)) return 'IOS';
  if (ua.includes('windows')) return 'WINDOWS';
  if (ua.includes('mac os x') || ua.includes('macintosh')) return 'MACOS';
  if (ua.includes('linux')) return 'LINUX';
  return 'OTHER';
}

export function classifyDevice(userAgent: string | null): string {
  const ua = (userAgent ?? '').toLowerCase();
  if (!ua) return 'UNKNOWN';
  if (/(ipad|tablet)/.test(ua)) return 'TABLET';
  if (/(mobile|iphone|ipod|android)/.test(ua)) return 'MOBILE';
  if (/(windows|macintosh|linux|x11)/.test(ua)) return 'DESKTOP';
  return 'OTHER';
}

export function classifyLanguage(value: string | null): string {
  if (!value) return 'UNKNOWN';
  const first = value.split(',')[0]?.trim().toLowerCase() ?? '';
  if (first.startsWith('en')) return 'EN';
  if (first.startsWith('ar')) return 'AR';
  if (/^[a-z]{2,3}(?:-|$)/.test(first)) return 'OTHER';
  return 'UNKNOWN';
}

export function classifyViewport(width: unknown): string {
  if (typeof width !== 'number' || !Number.isFinite(width) || width <= 0 || width > 10000) return 'UNKNOWN';
  if (width < 600) return 'SMALL';
  if (width < 1024) return 'MEDIUM';
  if (width < 1440) return 'LARGE';
  return 'XL';
}

export function classifyBot(userAgent: string | null, cf?: ProviderRequestMetadata): CoarseDimensions['botClass'] {
  const bm = cf?.botManagement;
  if (bm && typeof bm === 'object' && (bm as Record<string, unknown>).verifiedBot === true) return 'VERIFIED_BOT';
  const ua = (userAgent ?? '').toLowerCase();
  if (!ua) return 'UNKNOWN';
  if (/(bot|crawler|spider|headless|curl\/|wget\/|python-requests|httpclient)/.test(ua)) return 'AUTOMATION_LIKELY';
  return 'HUMAN_LIKELY';
}

export function coarseDimensions(input: {
  userAgent: string | null;
  acceptLanguage: string | null;
  viewportWidth?: unknown;
  cf?: ProviderRequestMetadata;
}): CoarseDimensions {
  return {
    browserClass: classifyBrowser(input.userAgent),
    osClass: classifyOs(input.userAgent),
    deviceClass: classifyDevice(input.userAgent),
    languageClass: classifyLanguage(input.acceptLanguage),
    viewportClass: classifyViewport(input.viewportWidth),
    countryCode: upperCode(input.cf?.country, 2),
    continentCode: upperCode(input.cf?.continent, 2),
    botClass: classifyBot(input.userAgent, input.cf),
  };
}
