import type { AnalyticsPermission, AuthorizationVerifier, D1Database, TrustedCmsContext } from '../core/types.js';
import { IDIGITALROOT_ANALYTICS_PROFILE } from '../site-profile/idigitalroot.js';
import { requirePermission } from './auth.js';
import { stableJson, utcSeconds } from '../core/stable.js';

type Row = Record<string, unknown>;
export const REPORT_KEYS = [
  'overview','content_routes','acquisition','audience_technology','coarse_geography','engagement_custom',
  'internal_search','inquiry_funnel','performance_web_vitals','public_runtime_health','bot_abuse',
] as const;
export type ReportKey = typeof REPORT_KEYS[number];

export interface ReportDefinition {
  reportKey: ReportKey;
  eventKeys: readonly string[];
  allowedDimensions: readonly string[];
  allowedFilters: readonly string[];
  allowedSorts: readonly string[];
  rawAllowed: boolean;
}
const COMMON = ['locale_code','route_id','entity_id','country_code','continent_code','browser_class','os_class','device_class','language_class','viewport_class','bot_class'] as const;
export const REPORT_REGISTRY: Readonly<Record<ReportKey, ReportDefinition>> = {
  overview: { reportKey:'overview', eventKeys:['page_view','inquiry_accepted'], allowedDimensions:['locale_code','route_id'], allowedFilters:['locale_code','route_id'], allowedSorts:['window_start','metric_count'], rawAllowed:true },
  content_routes: { reportKey:'content_routes', eventKeys:['page_view','component_interaction'], allowedDimensions:['route_id','entity_id','section_instance_id','component_key','locale_code'], allowedFilters:['route_id','entity_id','locale_code'], allowedSorts:['window_start','metric_count'], rawAllowed:true },
  acquisition: { reportKey:'acquisition', eventKeys:['page_view'], allowedDimensions:['referrer_class','referrer_host','utm_source','utm_medium','utm_campaign','locale_code'], allowedFilters:['referrer_class','referrer_host','utm_source','utm_medium','utm_campaign','locale_code'], allowedSorts:['window_start','metric_count'], rawAllowed:false },
  audience_technology: { reportKey:'audience_technology', eventKeys:['page_view'], allowedDimensions:['browser_class','os_class','device_class','language_class','viewport_class'], allowedFilters:['browser_class','os_class','device_class','language_class','viewport_class'], allowedSorts:['window_start','metric_count'], rawAllowed:true },
  coarse_geography: { reportKey:'coarse_geography', eventKeys:['page_view'], allowedDimensions:['country_code','continent_code'], allowedFilters:['country_code','continent_code'], allowedSorts:['window_start','metric_count'], rawAllowed:true },
  engagement_custom: { reportKey:'engagement_custom', eventKeys:['component_interaction'], allowedDimensions:['component_key','section_instance_id','route_id'], allowedFilters:['component_key','route_id'], allowedSorts:['window_start','metric_count'], rawAllowed:true },
  internal_search: { reportKey:'internal_search', eventKeys:['internal_search'], allowedDimensions:['route_id','locale_code'], allowedFilters:['route_id','locale_code'], allowedSorts:['window_start','metric_count'], rawAllowed:false },
  inquiry_funnel: { reportKey:'inquiry_funnel', eventKeys:['inquiry_funnel_step','inquiry_accepted'], allowedDimensions:['route_id','locale_code'], allowedFilters:['route_id','locale_code'], allowedSorts:['window_start','metric_count'], rawAllowed:true },
  performance_web_vitals: { reportKey:'performance_web_vitals', eventKeys:['web_vital'], allowedDimensions:['route_id','device_class'], allowedFilters:['route_id','device_class'], allowedSorts:['window_start','metric_count'], rawAllowed:true },
  public_runtime_health: { reportKey:'public_runtime_health', eventKeys:['runtime_error'], allowedDimensions:['route_id'], allowedFilters:['route_id'], allowedSorts:['window_start','metric_count'], rawAllowed:false },
  bot_abuse: { reportKey:'bot_abuse', eventKeys:['ingest_security'], allowedDimensions:['bot_class','country_code'], allowedFilters:['bot_class','country_code'], allowedSorts:['window_start','metric_count'], rawAllowed:false },
};

const SAFE_FILTER_VALUE=/^[A-Za-z0-9._:@/~+-]{1,160}$/;
const SAFE_RAW_FIELDS = [
  'event_id','event_key','schema_version','occurred_at','received_at','route_id','entity_id','revision_id','section_instance_id','component_key',
  'locale_code','consent_mode','browser_class','os_class','device_class','language_class','viewport_class','country_code','continent_code','bot_class','properties_json',
] as const;

export interface QueryInput {
  reportKey: string;
  mode?: 'aggregate'|'raw';
  start: string; end: string;
  dimensions?: string[];
  filters?: Record<string,string>;
  sort?: string;
  pageSize?: number;
}
export interface QueryResult { reportKey: ReportKey; mode:'aggregate'|'raw'; rows: Row[]; }

function fail(code:string): never { throw Object.assign(new Error('Analytics report request denied.'), { code }); }
function reportOf(key:string): ReportDefinition { if (!(key in REPORT_REGISTRY)) fail('UNKNOWN_REPORT'); return REPORT_REGISTRY[key as ReportKey]; }
function validateInput(input:QueryInput, report:ReportDefinition, exportMode=false): { start:string; end:string; limit:number } {
  if (typeof input.start!=='string' || typeof input.end!=='string') fail('INVALID_RANGE');
  const start = new Date(input.start), end=new Date(input.end);
  if (!Number.isFinite(start.valueOf()) || !Number.isFinite(end.valueOf()) || start>=end) fail('INVALID_RANGE');
  if (end.valueOf()-start.valueOf()>IDIGITALROOT_ANALYTICS_PROFILE.maxDateRangeDays*86400000) fail('RANGE_LIMIT');
  const cap=exportMode?IDIGITALROOT_ANALYTICS_PROFILE.maxExportRows:IDIGITALROOT_ANALYTICS_PROFILE.maxQueryPageSize;
  const limit=input.pageSize??Math.min(50,cap);
  if (!Number.isInteger(limit) || limit<1 || limit>cap) fail('PAGE_LIMIT');
  for (const d of input.dimensions??[]) if (!report.allowedDimensions.includes(d)) fail('DIMENSION_DENIED');
  for (const [k,v] of Object.entries(input.filters??{})) if (!report.allowedFilters.includes(k) || !SAFE_FILTER_VALUE.test(v)) fail('FILTER_DENIED');
  if (input.sort && !report.allowedSorts.includes(input.sort)) fail('SORT_DENIED');
  return {start:start.toISOString(),end:end.toISOString(),limit};
}

function shapeAggregateRows(rows:Row[], input:QueryInput):Row[]{
  let out=rows.map((row)=>{
    let dims:Record<string,unknown>={}; try{dims=JSON.parse(String(row.dimensions_json??'{}')) as Record<string,unknown>}catch{}
    for(const [k,v] of Object.entries(input.filters??{})) if(String(dims[k]??'')!==v) return null;
    if(input.dimensions?.length){const projected=Object.fromEntries(input.dimensions.map((k)=>[k,dims[k]??null]));return {...row,dimensions_json:stableJson(projected)}}
    return row;
  }).filter((x):x is Row=>x!==null);
  if(input.sort==='metric_count') out=out.sort((a,b)=>Number(b.metric_count??0)-Number(a.metric_count??0));
  return out;
}
function shapeRawRows(rows:Row[],input:QueryInput):Row[]{
  let out=rows.filter((row)=>Object.entries(input.filters??{}).every(([k,v])=>String(row[k]??'')===v));
  if(input.sort==='metric_count') fail('SORT_DENIED');
  return out;
}

async function audit(coreDb:D1Database, ctx:TrustedCmsContext, action:string, reportKey:string, permission:AnalyticsPermission, outcome:'SUCCESS'|'DENIED'|'FAILED'='SUCCESS'):Promise<void> {
  await coreDb.prepare(`INSERT INTO audit_events(audit_event_id,actor_id,source_kind,action_key,target_type,target_id,environment_key,outcome,correlation_id,metadata_json,created_at,session_id,request_id,ray_or_correlation_id,permission_key,reason_code,before_reference_json,after_reference_json)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(
      crypto.randomUUID(),ctx.actorId,'CMS',action,'analytics_report',reportKey,ctx.environmentKey,outcome,ctx.requestId,'{}',utcSeconds(new Date()),ctx.sessionId,ctx.requestId,ctx.requestId,permission,null,null,null
    ).run();
}

export async function queryAnalytics(analyticsDb:D1Database, coreDb:D1Database, verifier:AuthorizationVerifier, ctx:TrustedCmsContext, input:QueryInput):Promise<QueryResult> {
  const report=reportOf(input.reportKey); const mode=input.mode??'aggregate';
  const v=validateInput(input,report,false);
  if (mode==='aggregate') {
    await requirePermission(verifier,ctx,'analytics.read.aggregate');
    const rows=await analyticsDb.prepare(`SELECT report_key,window_granularity,window_start,window_end,dimensions_json,metric_count,metric_sum,metric_min,metric_max,metrics_json
      FROM analytics_rollups WHERE report_key=? AND window_start>=? AND window_start<? ORDER BY window_start ASC LIMIT ?`).bind(report.reportKey,v.start,v.end,v.limit).all<Row>();
    return {reportKey:report.reportKey,mode,rows:shapeAggregateRows(rows.results??[],input)};
  }
  if (mode!=='raw' || !report.rawAllowed) fail('RAW_REPORT_DENIED');
  await requirePermission(verifier,ctx,'analytics.read.raw');
  const placeholders=report.eventKeys.map(()=>'?').join(',');
  const selected=SAFE_RAW_FIELDS.join(',e.');
  const statement=`SELECT e.${selected} FROM analytics_events e JOIN analytics_event_registry r ON r.event_key=e.event_key AND r.schema_version=e.schema_version
      WHERE e.event_key IN (${placeholders}) AND r.raw_export_allowed=1 AND e.received_at>=? AND e.received_at<? ORDER BY e.received_at ASC LIMIT ?`;
  const rows=await analyticsDb.prepare(statement).bind(...report.eventKeys,v.start,v.end,v.limit).all<Row>();
  await audit(coreDb,ctx,'analytics.raw.read',report.reportKey,'analytics.read.raw');
  return {reportKey:report.reportKey,mode,rows:shapeRawRows(rows.results??[],input)};
}

export async function exportAnalytics(analyticsDb:D1Database,coreDb:D1Database,verifier:AuthorizationVerifier,ctx:TrustedCmsContext,input:QueryInput):Promise<QueryResult> {
  await requirePermission(verifier,ctx,'analytics.export');
  const report=reportOf(input.reportKey);
  const v=validateInput(input,report,true);
  const mode=input.mode??'aggregate';
  let result:QueryResult;
  if(mode==='aggregate'){
    await requirePermission(verifier,ctx,'analytics.read.aggregate');
    const rows=await analyticsDb.prepare(`SELECT report_key,window_granularity,window_start,window_end,dimensions_json,metric_count,metric_sum,metric_min,metric_max,metrics_json
      FROM analytics_rollups WHERE report_key=? AND window_start>=? AND window_start<? ORDER BY window_start ASC LIMIT ?`).bind(report.reportKey,v.start,v.end,v.limit).all<Row>();
    result={reportKey:report.reportKey,mode,rows:shapeAggregateRows(rows.results??[],input)};
  }else{
    if(mode!=='raw'||!report.rawAllowed) fail('RAW_REPORT_DENIED');
    await requirePermission(verifier,ctx,'analytics.read.raw');
    const placeholders=report.eventKeys.map(()=>'?').join(',');
    const selected=SAFE_RAW_FIELDS.join(',e.');
    const rows=await analyticsDb.prepare(`SELECT e.${selected} FROM analytics_events e JOIN analytics_event_registry r ON r.event_key=e.event_key AND r.schema_version=e.schema_version
      WHERE e.event_key IN (${placeholders}) AND r.raw_export_allowed=1 AND e.received_at>=? AND e.received_at<? ORDER BY e.received_at ASC LIMIT ?`).bind(...report.eventKeys,v.start,v.end,v.limit).all<Row>();
    await audit(coreDb,ctx,'analytics.raw.read',report.reportKey,'analytics.read.raw');
    result={reportKey:report.reportKey,mode,rows:shapeRawRows(rows.results??[],input)};
  }
  await audit(coreDb,ctx,'analytics.export',report.reportKey,'analytics.export');
  return result;
}

export async function requireAnalyticsConfig(verifier:AuthorizationVerifier,ctx:TrustedCmsContext):Promise<void> {
  await requirePermission(verifier,ctx,'analytics.config.manage');
}

export function reportRegistryDigestInput():string { return stableJson(REPORT_REGISTRY); }
export const GENERIC_REPORT_DIMENSIONS = COMMON;
