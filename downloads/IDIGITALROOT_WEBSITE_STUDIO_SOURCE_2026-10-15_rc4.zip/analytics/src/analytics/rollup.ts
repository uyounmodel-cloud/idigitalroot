import type { D1Database } from '../core/types.js';
import { sha256Hex } from '../core/crypto.js';
import { stableJson, utcSeconds } from '../core/stable.js';
import { REPORT_REGISTRY, type ReportKey } from './reports.js';
import { IDIGITALROOT_ANALYTICS_PROFILE } from '../site-profile/idigitalroot.js';

type Row=Record<string,unknown>;
export type Granularity='HOUR'|'DAY';
export interface RollupResult{reportKey:ReportKey;granularity:Granularity;groups:number;events:number;skipped:boolean;}
function fail():never{throw new Error('ROLLUP_INVALID_WINDOW')}
function props(row:Row):Record<string,unknown>{try{return JSON.parse(String(row.properties_json??'{}')) as Record<string,unknown>}catch{return {}}}
function dimensionFor(reportKey:ReportKey,row:Row):Record<string,unknown>{
  const p=props(row);
  switch(reportKey){
    case 'content_routes': return {route_id:row.route_id??null,entity_id:row.entity_id??null,component_key:row.component_key??null,locale_code:row.locale_code??null};
    case 'acquisition': return {referrer_class:row.referrer_class??null,referrer_host:row.referrer_host??null,utm_source:row.utm_source??null,utm_medium:row.utm_medium??null,utm_campaign:row.utm_campaign??null,locale_code:row.locale_code??null};
    case 'audience_technology': return {browser_class:row.browser_class??null,os_class:row.os_class??null,device_class:row.device_class??null,language_class:row.language_class??null,viewport_class:row.viewport_class??null};
    case 'coarse_geography': return {country_code:row.country_code??null,continent_code:row.continent_code??null};
    case 'engagement_custom': return {route_id:row.route_id??null,component_key:row.component_key??null,interaction_key:p.interaction_key??null};
    case 'internal_search': return {route_id:row.route_id??null,result_count_class:p.result_count_class??null,query_length_class:p.query_length_class??null};
    case 'inquiry_funnel': return {event_key:row.event_key,step_key:p.step_key??null,outcome:p.outcome??null};
    case 'performance_web_vitals': return {route_id:row.route_id??null,metric_key:p.metric_key??null,value_bucket:p.value_bucket??null};
    case 'public_runtime_health': return {route_id:row.route_id??null,error_code:p.error_code??null,build_id:p.build_id??null};
    case 'bot_abuse': return {reason_code:row.reason_code??null,bot_class:row.bot_class??null,country_code:row.country_code??null};
    default:return {event_key:row.event_key,locale_code:row.locale_code??null};
  }
}
async function sourceRows(db:D1Database,reportKey:ReportKey,start:string,end:string):Promise<Row[]>{
  const cap=IDIGITALROOT_ANALYTICS_PROFILE.maxRollupEventsPerWindow+1;
  if(reportKey==='acquisition'){
    const r=await db.prepare(`SELECT session_id,started_at,locale_code,referrer_class,referrer_host,utm_source,utm_medium,utm_campaign,utm_content,utm_term FROM analytics_sessions WHERE started_at>=? AND started_at<? ORDER BY started_at,session_id LIMIT ?`).bind(start,end,cap).all<Row>();
    return (r.results??[]).map(x=>({...x,_weight:1,_source_id:x.session_id}));
  }
  if(reportKey==='bot_abuse'){
    const r=await db.prepare(`SELECT bucket_start,reason_code,bot_class,country_code,count_value FROM analytics_ingest_security_buckets WHERE bucket_start>=? AND bucket_start<? ORDER BY bucket_start,reason_code LIMIT ?`).bind(start,end,cap).all<Row>();
    return (r.results??[]).map(x=>({...x,_weight:Number(x.count_value??0),_source_id:null}));
  }
  const def=REPORT_REGISTRY[reportKey], placeholders=def.eventKeys.map(()=>'?').join(',');
  const r=await db.prepare(`SELECT event_id,event_key,received_at,route_id,entity_id,section_instance_id,component_key,locale_code,browser_class,os_class,device_class,language_class,viewport_class,country_code,continent_code,bot_class,properties_json FROM analytics_events WHERE event_key IN (${placeholders}) AND received_at>=? AND received_at<? ORDER BY received_at,event_id LIMIT ?`).bind(...def.eventKeys,start,end,cap).all<Row>();
  return (r.results??[]).map(x=>({...x,_weight:1,_source_id:x.event_id}));
}
export async function rollupWindow(db:D1Database,reportKey:ReportKey,granularity:Granularity,start:string,end:string,nowDate=new Date()):Promise<RollupResult>{
  if(!(reportKey in REPORT_REGISTRY)||(granularity!=='HOUR'&&granularity!=='DAY'))fail(); const s=new Date(start),e=new Date(end);
  const expected=granularity==='HOUR'?3600000:86400000; if(!Number.isFinite(s.valueOf())||!Number.isFinite(e.valueOf())||e.valueOf()-s.valueOf()!==expected)fail();
  const windowStart=utcSeconds(s),windowEnd=utcSeconds(e),cursorKey=`${reportKey}:${granularity}`;
  const cursor=await db.prepare('SELECT through_received_at,row_version FROM analytics_rollup_cursors WHERE report_key=?').bind(cursorKey).first<Row>();
  if(cursor&&typeof cursor.through_received_at==='string'&&cursor.through_received_at>=windowEnd)return {reportKey,granularity,groups:0,events:0,skipped:true};
  const rows=await sourceRows(db,reportKey,windowStart,windowEnd); if(rows.length>IDIGITALROOT_ANALYTICS_PROFILE.maxRollupEventsPerWindow)throw new Error('ROLLUP_WINDOW_CAP');
  const groups=new Map<string,{dims:Record<string,unknown>;count:number}>();
  for(const row of rows){const dims=dimensionFor(reportKey,row);const key=stableJson(dims);const g=groups.get(key)??{dims,count:0};g.count+=Number(row._weight??1);groups.set(key,g)}
  const now=utcSeconds(nowDate), statements=[]; let idx=0;
  for(const g of groups.values()){
    const dims=stableJson(g.dims),hash=await sha256Hex(dims),rollupId=`ru_${(await sha256Hex(`${cursorKey}|${windowStart}|${hash}`)).slice(0,40)}`;
    statements.push(db.prepare(`INSERT INTO analytics_rollups(rollup_id,report_key,window_granularity,window_start,window_end,dimension_hash,dimensions_json,metric_count,metric_sum,metric_min,metric_max,metrics_json,source_through_received_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(report_key,window_granularity,window_start,dimension_hash) DO UPDATE SET window_end=excluded.window_end,metric_count=excluded.metric_count,metrics_json=excluded.metrics_json,source_through_received_at=excluded.source_through_received_at,updated_at=excluded.updated_at`).bind(rollupId,reportKey,granularity,windowStart,windowEnd,hash,dims,g.count,null,null,null,'{}',windowEnd,now)); idx++;
  }
  statements.push(db.prepare(`INSERT INTO analytics_rollup_cursors(report_key,through_received_at,through_event_id,row_version,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(report_key) DO UPDATE SET through_received_at=excluded.through_received_at,through_event_id=excluded.through_event_id,row_version=analytics_rollup_cursors.row_version+1,updated_at=excluded.updated_at`).bind(cursorKey,windowEnd,(rows.at(-1)?._source_id as string|null|undefined)??null,1,now));
  await db.batch(statements); return {reportKey,granularity,groups:idx,events:rows.length,skipped:false};
}
export async function analyticsHealth(db:D1Database,nowDate=new Date()):Promise<Record<string,number|string|null>>{
  const e=await db.prepare('SELECT COUNT(*) c,MAX(received_at) latest FROM analytics_events').first<Row>();
  const r=await db.prepare('SELECT COUNT(*) c,MAX(updated_at) latest FROM analytics_rollups').first<Row>();
  const b=await db.prepare('SELECT COALESCE(SUM(count_value),0) c FROM analytics_ingest_security_buckets').first<Row>();
  const now=nowDate.valueOf(), latest=typeof e?.latest==='string'?new Date(e.latest).valueOf():NaN;
  return {event_count:Number(e?.c??0),rollup_count:Number(r?.c??0),security_rejection_count:Number(b?.c??0),latest_event_at:typeof e?.latest==='string'?e.latest:null,latest_rollup_at:typeof r?.latest==='string'?r.latest:null,event_lag_seconds:Number.isFinite(latest)?Math.max(0,Math.floor((now-latest)/1000)):null};
}
