import type { AnalyticsPermission, AuthorizationVerifier, D1Database, TrustedCmsContext } from '../core/types.js';

const ANALYTICS_KEYS = new Set<AnalyticsPermission>([
  'analytics.read.aggregate','analytics.read.raw','analytics.export','analytics.config.manage',
]);
type Row = Record<string, unknown>;

export class CoreAuthorizationVerifier implements AuthorizationVerifier {
  constructor(private readonly coreDb: D1Database, private readonly now: () => Date = () => new Date()) {}
  async permissions(context: TrustedCmsContext): Promise<ReadonlySet<AnalyticsPermission>> {
    if (!context.authenticated || !context.actorId || !context.sessionId) return new Set();
    const now = this.now().toISOString();
    const session = await this.coreDb.prepare(`SELECT s.session_id,s.actor_id,s.state,s.inactivity_expires_at,s.absolute_expires_at,
      a.status,ss.activation_state
      FROM cms_sessions s JOIN actors a ON a.actor_id=s.actor_id
      JOIN actor_security_state ss ON ss.actor_id=s.actor_id
      WHERE s.session_id=? AND s.actor_id=?`).bind(context.sessionId, context.actorId).first<Row>();
    if (!session || session.state !== 'ACTIVE' || session.status !== 'ACTIVE' || session.activation_state !== 'active') return new Set();
    for (const key of ['inactivity_expires_at','absolute_expires_at'] as const) {
      const value = session[key];
      if (typeof value === 'string' && value <= now) return new Set();
    }
    const rows = await this.coreDb.prepare(`SELECT DISTINCT p.permission_key
      FROM actor_roles ar
      JOIN actor_role_scopes ars ON ars.actor_id=ar.actor_id AND ars.role_id=ar.role_id AND ars.granted_at=ar.granted_at AND ars.scope_kind='global'
      JOIN roles r ON r.role_id=ar.role_id AND r.archived_at IS NULL
      JOIN role_permissions rp ON rp.role_id=r.role_id
      JOIN permissions p ON p.permission_id=rp.permission_id AND p.authorization_state='ACTIVE'
      WHERE ar.actor_id=? AND ar.revoked_at IS NULL`).bind(context.actorId).all<Row>();
    const out = new Set<AnalyticsPermission>();
    for (const row of rows.results ?? []) if (ANALYTICS_KEYS.has(row.permission_key as AnalyticsPermission)) out.add(row.permission_key as AnalyticsPermission);
    return out;
  }
}

export async function requirePermission(verifier: AuthorizationVerifier, context: TrustedCmsContext, permission: AnalyticsPermission): Promise<void> {
  if (!context.authenticated) throw Object.assign(new Error('CMS analytics authorization denied.'), { code: 'AUTH_REQUIRED' });
  const permissions = await verifier.permissions(context);
  if (!permissions.has(permission)) throw Object.assign(new Error('CMS analytics authorization denied.'), { code: 'PERMISSION_DENIED' });
}
