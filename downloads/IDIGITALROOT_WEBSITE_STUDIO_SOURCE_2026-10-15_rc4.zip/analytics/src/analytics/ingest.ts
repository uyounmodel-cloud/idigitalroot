import type { AnalyticsEnv, Clock, D1Database, D1PreparedStatement, ProviderRequestMetadata } from '../core/types.js';
import { SYSTEM_CLOCK } from '../core/types.js';
import { AnalyticsError } from '../core/errors.js';
import { hmacSha256Hex, sha256Hex } from '../core/crypto.js';
import { parseUtc, stableJson, utcSeconds, utf8Bytes } from '../core/stable.js';
import { IDIGITALROOT_ANALYTICS_PROFILE, type PrivacyMode } from '../site-profile/idigitalroot.js';
import { coarseDimensions, type CoarseDimensions } from './classification.js';
import { sanitizeAcquisition, type SanitizedAcquisition } from './sanitize.js';
import { loadRegistryRecord, validateProperties } from './registry.js';

type Row = Record<string, unknown>;
const SAFE_ID = /^[A-Za-z0-9._~-]+$/;
const TOP_LEVEL_KEYS = new Set(['events', 'consentReceipt']);
const EVENT_KEYS = new Set(['eventId','eventKey','schemaVersion','occurredAt','privacy','context','acquisition','properties']);
const PRIVACY_KEYS = new Set(['mode','visitorToken','sessionToken','policyVersionReference']);
const CONTEXT_KEYS = new Set(['routeId','entityId','revisionId','sectionInstanceId','componentKey','localeCode','viewportWidth']);
const ACQUISITION_KEYS = new Set(['referrerUrl','utmSource','utmMedium','utmCampaign','utmContent','utmTerm']);
const RECEIPT_KEYS = new Set(['receiptId','priorMode','newMode','policyVersionReference','visitorToken','sessionToken']);
const SECURITY_REASONS = new Set([
  'UNSUPPORTED_MEDIA_TYPE','MALFORMED_JSON','PAYLOAD_TOO_LARGE','BATCH_TOO_LARGE','BAD_ORIGIN','RATE_LIMITED',
  'INVALID_EVENT','UNKNOWN_EVENT','EVENT_DISABLED','UNSUPPORTED_SCHEMA_VERSION','UNKNOWN_PROPERTY','PROPERTY_LIMIT',
  'TIMESTAMP_SKEW','EVENT_ID_CONFLICT','PUBLIC_CONVERSION_FORBIDDEN','REGISTRY_MISMATCH','PERSISTENCE_UNAVAILABLE',
]);

export interface IngestOutcome {
  accepted: number;
  duplicate: number;
  ignoredOff: number;
  receiptStored: boolean;
  requestId: string;
}

interface RawEvent {
  eventId: string;
  eventKey: string;
  schemaVersion: number;
  occurredAt: string;
  privacy: { mode: PrivacyMode; visitorToken?: string; sessionToken?: string; policyVersionReference?: string };
  context?: { routeId?: string; entityId?: string; revisionId?: string; sectionInstanceId?: string; componentKey?: string; localeCode?: string; viewportWidth?: number };
  acquisition?: Record<string, unknown>;
  properties?: Record<string, unknown>;
}

interface PreparedEvent {
  raw: RawEvent;
  receivedAt: string;
  visitorKeyHash: string | null;
  sessionId: string | null;
  propertiesJson: string;
  coarse: CoarseDimensions;
  acquisition: SanitizedAcquisition;
  canonical: Record<string, unknown>;
  duplicate: boolean;
}

function ownObject(value: unknown, code = 'INVALID_EVENT'): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new AnalyticsError(422, code, 'Invalid analytics event.');
  return value as Record<string, unknown>;
}

function rejectUnknown(obj: Record<string, unknown>, allowed: ReadonlySet<string>, code: string): void {
  if (Object.keys(obj).some((k) => !allowed.has(k))) throw new AnalyticsError(422, code, 'Invalid analytics event.');
}

function boundedId(value: unknown, field: string, required = false, max = 128): string | null {
  if (value == null || value === '') {
    if (required) throw new AnalyticsError(422, 'INVALID_EVENT', `Invalid ${field}.`);
    return null;
  }
  if (typeof value !== 'string' || value.length > max || value.length < (required ? 1 : 0) || !SAFE_ID.test(value)) {
    throw new AnalyticsError(422, 'INVALID_EVENT', `Invalid ${field}.`);
  }
  return value;
}

function asMode(value: unknown): PrivacyMode {
  if (value === 'OFF' || value === 'COOKIELESS' || value === 'CONSENTED') return value;
  throw new AnalyticsError(422, 'INVALID_PRIVACY_MODE', 'Invalid analytics privacy mode.');
}

function validateRawEvent(value: unknown): RawEvent {
  const obj = ownObject(value);
  rejectUnknown(obj, EVENT_KEYS, 'INVALID_EVENT');
  const privacy = ownObject(obj.privacy, 'INVALID_PRIVACY_MODE');
  rejectUnknown(privacy, PRIVACY_KEYS, 'INVALID_PRIVACY_MODE');
  const context = obj.context == null ? {} : ownObject(obj.context);
  rejectUnknown(context, CONTEXT_KEYS, 'INVALID_EVENT');
  const acquisition = obj.acquisition == null ? {} : ownObject(obj.acquisition);
  rejectUnknown(acquisition, ACQUISITION_KEYS, 'INVALID_ACQUISITION');
  const eventId = boundedId(obj.eventId, 'eventId', true)!;
  if (eventId.length < 16) throw new AnalyticsError(422, 'INVALID_EVENT', 'Invalid eventId.');
  const eventKey = boundedId(obj.eventKey, 'eventKey', true, 80)!;
  const schemaVersion = obj.schemaVersion;
  if (!Number.isInteger(schemaVersion) || Number(schemaVersion) < 1 || Number(schemaVersion) > 1000) throw new AnalyticsError(422, 'UNSUPPORTED_SCHEMA_VERSION', 'Event schema version is unsupported.');
  if (typeof obj.occurredAt !== 'string' || !parseUtc(obj.occurredAt)) throw new AnalyticsError(422, 'INVALID_EVENT', 'Invalid occurredAt.');
  const mode = asMode(privacy.mode);
  const visitorToken = boundedId(privacy.visitorToken, 'visitorToken', false, 128) ?? undefined;
  const sessionToken = boundedId(privacy.sessionToken, 'sessionToken', false, 128) ?? undefined;
  const policyVersionReference = boundedId(privacy.policyVersionReference, 'policyVersionReference', false, 160) ?? undefined;
  if (mode === 'CONSENTED' && (!visitorToken || visitorToken.length < 16 || !sessionToken || sessionToken.length < 16)) {
    throw new AnalyticsError(422, 'INVALID_PRIVACY_MODE', 'Consented analytics requires bounded first-party tokens.');
  }
  if (mode === 'COOKIELESS' && (visitorToken || sessionToken)) {
    throw new AnalyticsError(422, 'INVALID_PRIVACY_MODE', 'Cookieless analytics cannot use durable visitor/session tokens.');
  }
  for (const key of ['routeId','entityId','revisionId','sectionInstanceId','componentKey'] as const) boundedId(context[key], key, false, 128);
  if (context.localeCode != null && (typeof context.localeCode !== 'string' || !/^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})?$/.test(context.localeCode) || context.localeCode.length > 16)) {
    throw new AnalyticsError(422, 'INVALID_EVENT', 'Invalid locale.');
  }
  if (context.viewportWidth != null && (typeof context.viewportWidth !== 'number' || !Number.isFinite(context.viewportWidth))) {
    throw new AnalyticsError(422, 'INVALID_EVENT', 'Invalid viewport.');
  }
  return {
    eventId, eventKey, schemaVersion: Number(schemaVersion), occurredAt: obj.occurredAt,
    privacy: { mode, visitorToken, sessionToken, policyVersionReference },
    context: context as RawEvent['context'], acquisition, properties: obj.properties as Record<string, unknown> | undefined,
  };
}

function canonicalRecord(ev: PreparedEvent): Record<string, unknown> {
  const c = ev.raw.context ?? {};
  return {
    event_key: ev.raw.eventKey,
    schema_version: ev.raw.schemaVersion,
    occurred_at: utcSeconds(new Date(ev.raw.occurredAt)),
    session_id: ev.sessionId,
    visitor_key_hash: ev.visitorKeyHash,
    route_id: c.routeId ?? null,
    entity_id: c.entityId ?? null,
    revision_id: c.revisionId ?? null,
    section_instance_id: c.sectionInstanceId ?? null,
    component_key: c.componentKey ?? null,
    locale_code: c.localeCode ?? null,
    consent_mode: ev.raw.privacy.mode,
    browser_class: ev.coarse.browserClass,
    os_class: ev.coarse.osClass,
    device_class: ev.coarse.deviceClass,
    language_class: ev.coarse.languageClass,
    viewport_class: ev.coarse.viewportClass,
    country_code: ev.coarse.countryCode,
    continent_code: ev.coarse.continentCode,
    bot_class: ev.coarse.botClass,
    properties_json: ev.propertiesJson,
  };
}

function dbCanonical(row: Row): Record<string, unknown> {
  const keys = ['event_key','schema_version','occurred_at','session_id','visitor_key_hash','route_id','entity_id','revision_id','section_instance_id','component_key','locale_code','consent_mode','browser_class','os_class','device_class','language_class','viewport_class','country_code','continent_code','bot_class','properties_json'];
  return Object.fromEntries(keys.map((k) => [k, row[k] ?? null]));
}

async function rateLimit(request: Request, parsedEvents: RawEvent[], env: AnalyticsEnv): Promise<void> {
  if (!env.ANALYTICS_RATE_LIMITER) return;
  const first = parsedEvents[0];
  const origin = request.headers.get('origin') ?? 'none';
  const transientIp = request.headers.get('cf-connecting-ip') ?? '';
  const identity = transientIp || first?.privacy.sessionToken || first?.privacy.visitorToken || 'anonymous';
  const key = await hmacSha256Hex(env.VISITOR_HMAC_SECRET, `${origin}|${first?.eventKey ?? 'empty'}|${identity}`);
  const result = await env.ANALYTICS_RATE_LIMITER.limit({ key: `analytics:${key}` });
  if (!result.success) throw new AnalyticsError(429, 'RATE_LIMITED', 'Analytics request was not accepted.');
}

async function parseBody(request: Request): Promise<Record<string, unknown>> {
  const type = request.headers.get('content-type')?.split(';')[0]?.trim().toLowerCase();
  if (type !== 'application/json') throw new AnalyticsError(415, 'UNSUPPORTED_MEDIA_TYPE', 'Analytics request was not accepted.');
  const declared = Number(request.headers.get('content-length') ?? '0');
  if (Number.isFinite(declared) && declared > IDIGITALROOT_ANALYTICS_PROFILE.maxBodyBytes) throw new AnalyticsError(413, 'PAYLOAD_TOO_LARGE', 'Analytics request was not accepted.');
  let text: string;
  try { text = await request.text(); } catch { throw new AnalyticsError(400, 'MALFORMED_JSON', 'Analytics request was not accepted.'); }
  if (utf8Bytes(text) > IDIGITALROOT_ANALYTICS_PROFILE.maxBodyBytes) throw new AnalyticsError(413, 'PAYLOAD_TOO_LARGE', 'Analytics request was not accepted.');
  try { return ownObject(JSON.parse(text), 'MALFORMED_JSON'); } catch (e) {
    if (e instanceof AnalyticsError) throw e;
    throw new AnalyticsError(400, 'MALFORMED_JSON', 'Analytics request was not accepted.');
  }
}

async function prepareEvent(raw: RawEvent, request: Request, env: AnalyticsEnv, now: Date, cf?: ProviderRequestMetadata): Promise<PreparedEvent> {
  const registry = await loadRegistryRecord(env.ANALYTICS_DB, raw.eventKey, raw.schemaVersion);
  if (!registry.definition.publicAllowed) {
    if (raw.eventKey === 'inquiry_accepted') throw new AnalyticsError(403, 'PUBLIC_CONVERSION_FORBIDDEN', 'Analytics request was not accepted.');
    throw new AnalyticsError(403, 'PUBLIC_EVENT_FORBIDDEN', 'Analytics request was not accepted.');
  }
  if (raw.privacy.mode !== 'OFF' && !registry.allowedModes.includes(raw.privacy.mode)) throw new AnalyticsError(422, 'INVALID_PRIVACY_MODE', 'Invalid analytics privacy mode.');
  const occurred = parseUtc(raw.occurredAt)!;
  if (Math.abs(now.getTime() - occurred.getTime()) / 1000 > IDIGITALROOT_ANALYTICS_PROFILE.maxClockSkewSeconds) {
    throw new AnalyticsError(422, 'TIMESTAMP_SKEW', 'Event timestamp is outside the accepted window.');
  }
  const properties = validateProperties(registry.definition, raw.properties);
  const propertiesJson = stableJson(properties);
  const visitorKeyHash = raw.privacy.mode === 'CONSENTED' ? await hmacSha256Hex(env.VISITOR_HMAC_SECRET, raw.privacy.visitorToken!) : null;
  const sessionId = raw.privacy.mode === 'CONSENTED' ? raw.privacy.sessionToken! : null;
  const coarse = coarseDimensions({
    userAgent: request.headers.get('user-agent'), acceptLanguage: request.headers.get('accept-language'),
    viewportWidth: raw.context?.viewportWidth, cf,
  });
  const acquisition = sanitizeAcquisition(raw.acquisition, env.PUBLIC_ORIGINS);
  const p: PreparedEvent = { raw, receivedAt: utcSeconds(now), visitorKeyHash, sessionId, propertiesJson, coarse, acquisition, canonical: {}, duplicate: false };
  p.canonical = canonicalRecord(p);
  return p;
}

async function verifyExistingSession(db: D1Database, ev: PreparedEvent): Promise<boolean> {
  if (!ev.sessionId) return false;
  const row = await db.prepare('SELECT session_id,visitor_key_hash,consent_mode FROM analytics_sessions WHERE session_id=?').bind(ev.sessionId).first<Row>();
  if (!row) return false;
  if (row.visitor_key_hash !== ev.visitorKeyHash || row.consent_mode !== 'CONSENTED') {
    throw new AnalyticsError(409, 'SESSION_ID_CONFLICT', 'Analytics request was not accepted.');
  }
  return true;
}

function sessionInsert(db: D1Database, ev: PreparedEvent): D1PreparedStatement {
  const c = ev.raw.context ?? {};
  const a = ev.acquisition;
  return db.prepare(`INSERT INTO analytics_sessions(
    session_id,visitor_key_hash,started_at,last_event_at,consent_mode,privacy_policy_version,locale_code,landing_route_id,landing_entity_id,
    referrer_class,referrer_host,utm_source,utm_medium,utm_campaign,utm_content,utm_term,
    browser_class,os_class,device_class,language_class,viewport_class,country_code,continent_code,bot_class,first_event_id
  ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(
    ev.sessionId!, ev.visitorKeyHash, ev.receivedAt, ev.receivedAt, 'CONSENTED', ev.raw.privacy.policyVersionReference ?? null,
    c.localeCode ?? null, c.routeId ?? null, c.entityId ?? null,
    a.referrerClass, a.referrerHost, a.utmSource, a.utmMedium, a.utmCampaign, a.utmContent, a.utmTerm,
    ev.coarse.browserClass, ev.coarse.osClass, ev.coarse.deviceClass, ev.coarse.languageClass, ev.coarse.viewportClass,
    ev.coarse.countryCode, ev.coarse.continentCode, ev.coarse.botClass, ev.raw.eventId,
  );
}

function eventInsert(db: D1Database, ev: PreparedEvent, batchId: string): D1PreparedStatement {
  const c = ev.raw.context ?? {};
  return db.prepare(`INSERT INTO analytics_events(
    event_id,event_key,schema_version,occurred_at,received_at,session_id,visitor_key_hash,route_id,entity_id,revision_id,section_instance_id,component_key,
    locale_code,consent_mode,browser_class,os_class,device_class,language_class,viewport_class,country_code,continent_code,bot_class,properties_json,ingest_batch_id
  ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(
    ev.raw.eventId, ev.raw.eventKey, ev.raw.schemaVersion, utcSeconds(new Date(ev.raw.occurredAt)), ev.receivedAt, ev.sessionId, ev.visitorKeyHash,
    c.routeId ?? null, c.entityId ?? null, c.revisionId ?? null, c.sectionInstanceId ?? null, c.componentKey ?? null, c.localeCode ?? null,
    ev.raw.privacy.mode, ev.coarse.browserClass, ev.coarse.osClass, ev.coarse.deviceClass, ev.coarse.languageClass, ev.coarse.viewportClass,
    ev.coarse.countryCode, ev.coarse.continentCode, ev.coarse.botClass, ev.propertiesJson, batchId,
  );
}

async function prepareReceipt(value: unknown, env: AnalyticsEnv): Promise<D1PreparedStatement | null> {
  if (value == null) return null;
  const r = ownObject(value, 'INVALID_CONSENT_RECEIPT');
  rejectUnknown(r, RECEIPT_KEYS, 'INVALID_CONSENT_RECEIPT');
  const receiptId = boundedId(r.receiptId, 'receiptId', true)!;
  const priorMode = asMode(r.priorMode);
  const newMode = asMode(r.newMode);
  const policy = boundedId(r.policyVersionReference, 'policyVersionReference', true, 160)!;
  const visitorToken = boundedId(r.visitorToken, 'visitorToken', false, 128);
  const sessionToken = boundedId(r.sessionToken, 'sessionToken', false, 128);
  let visitorHash: string | null = null;
  let sessionId: string | null = null;
  if (visitorToken) {
    if (visitorToken.length < 16) throw new AnalyticsError(422, 'INVALID_CONSENT_RECEIPT', 'Invalid consent receipt.');
    visitorHash = await hmacSha256Hex(env.VISITOR_HMAC_SECRET, visitorToken);
  }
  if (sessionToken) {
    if (sessionToken.length < 16) throw new AnalyticsError(422, 'INVALID_CONSENT_RECEIPT', 'Invalid consent receipt.');
    const exists = await env.ANALYTICS_DB.prepare('SELECT session_id FROM analytics_sessions WHERE session_id=?').bind(sessionToken).first<Row>();
    sessionId = exists ? sessionToken : null;
  }
  return env.ANALYTICS_DB.prepare(`INSERT INTO analytics_consent_receipts(receipt_id,session_id,visitor_key_hash,prior_mode,new_mode,policy_version_reference,captured_at)
    VALUES(?,?,?,?,?,?,?)`).bind(receiptId, sessionId, visitorHash, priorMode, newMode, policy, utcSeconds(new Date()));
}

export async function ingestAnalytics(request: Request, env: AnalyticsEnv, clock: Clock = SYSTEM_CLOCK): Promise<IngestOutcome> {
  if (request.method !== 'POST') throw new AnalyticsError(405, 'METHOD_NOT_ALLOWED', 'Analytics request was not accepted.');
  const origin = request.headers.get('origin');
  if (!origin || !env.PUBLIC_ORIGINS.includes(origin)) throw new AnalyticsError(403, 'BAD_ORIGIN', 'Analytics request was not accepted.');
  const body = await parseBody(request);
  rejectUnknown(body, TOP_LEVEL_KEYS, 'INVALID_EVENT');
  if (!Array.isArray(body.events)) throw new AnalyticsError(422, 'INVALID_EVENT', 'Analytics events must be an array.');
  if (body.events.length > IDIGITALROOT_ANALYTICS_PROFILE.maxBatchEvents) throw new AnalyticsError(413, 'BATCH_TOO_LARGE', 'Analytics request was not accepted.');
  const rawEvents = body.events.map(validateRawEvent);
  await rateLimit(request, rawEvents, env);
  const now = clock.now();
  const cf = (request as Request & { cf?: ProviderRequestMetadata }).cf;
  const prepared: PreparedEvent[] = [];
  let ignoredOff = 0;
  const inBatch = new Map<string, string>();
  for (const raw of rawEvents) {
    const ev = await prepareEvent(raw, request, env, now, cf);
    if (raw.privacy.mode === 'OFF') { ignoredOff++; continue; }
    const digest = await sha256Hex(stableJson(ev.canonical));
    const priorDigest = inBatch.get(raw.eventId);
    if (priorDigest && priorDigest !== digest) throw new AnalyticsError(409, 'EVENT_ID_CONFLICT', 'Analytics event ID conflict.');
    if (priorDigest === digest) continue;
    inBatch.set(raw.eventId, digest);
    prepared.push(ev);
  }

  for (const ev of prepared) {
    const existing = await env.ANALYTICS_DB.prepare(`SELECT event_key,schema_version,occurred_at,session_id,visitor_key_hash,route_id,entity_id,revision_id,section_instance_id,component_key,locale_code,consent_mode,browser_class,os_class,device_class,language_class,viewport_class,country_code,continent_code,bot_class,properties_json FROM analytics_events WHERE event_id=?`).bind(ev.raw.eventId).first<Row>();
    if (existing) {
      if (stableJson(dbCanonical(existing)) !== stableJson(ev.canonical)) throw new AnalyticsError(409, 'EVENT_ID_CONFLICT', 'Analytics event ID conflict.');
      ev.duplicate = true;
    }
  }

  const statements: D1PreparedStatement[] = [];
  const sessionSeen = new Set<string>();
  const existingSession = new Set<string>();
  for (const ev of prepared) {
    if (ev.duplicate || !ev.sessionId || sessionSeen.has(ev.sessionId)) continue;
    sessionSeen.add(ev.sessionId);
    if (await verifyExistingSession(env.ANALYTICS_DB, ev)) existingSession.add(ev.sessionId);
    else statements.push(sessionInsert(env.ANALYTICS_DB, ev));
  }
  for (const ev of prepared) {
    if (ev.duplicate) continue;
    statements.push(eventInsert(env.ANALYTICS_DB, ev, request.headers.get('x-analytics-batch-id')?.slice(0, 128) || crypto.randomUUID()));
  }
  for (const sid of existingSession) {
    statements.push(env.ANALYTICS_DB.prepare('UPDATE analytics_sessions SET last_event_at=? WHERE session_id=?').bind(utcSeconds(now), sid));
  }
  const receipt = await prepareReceipt(body.consentReceipt, env);
  if (receipt) statements.push(receipt);
  if (statements.length) {
    try { await env.ANALYTICS_DB.batch(statements); }
    catch { throw new AnalyticsError(503, 'PERSISTENCE_UNAVAILABLE', 'Analytics request could not be persisted.'); }
  }
  return {
    accepted: prepared.filter((e) => !e.duplicate).length,
    duplicate: prepared.filter((e) => e.duplicate).length,
    ignoredOff,
    receiptStored: Boolean(receipt),
    requestId: request.headers.get('x-request-id')?.slice(0, 128) || crypto.randomUUID(),
  };
}

export async function recordSecurityRejection(db: D1Database, code: string, request: Request, clock: Clock = SYSTEM_CLOCK): Promise<void> {
  const reason = SECURITY_REASONS.has(code) ? code : 'INVALID_EVENT';
  const cf = (request as Request & { cf?: ProviderRequestMetadata }).cf;
  const coarse = coarseDimensions({ userAgent: request.headers.get('user-agent'), acceptLanguage: request.headers.get('accept-language'), cf });
  const d = clock.now();
  d.setUTCMinutes(0, 0, 0);
  const bucket = utcSeconds(d);
  try {
    await db.prepare(`INSERT INTO analytics_ingest_security_buckets(bucket_start,reason_code,bot_class,country_code,count_value,updated_at)
      VALUES(?,?,?,?,1,?) ON CONFLICT(bucket_start,reason_code,bot_class,country_code) DO UPDATE SET count_value=count_value+1,updated_at=excluded.updated_at`)
      .bind(bucket, reason, coarse.botClass, coarse.countryCode ?? 'ZZ', utcSeconds(clock.now())).run();
  } catch { /* rejection accounting must not reveal or fail open */ }
}

export async function deriveInternalSearchGroup(rawNormalizedQuery: string, secret: string): Promise<string> {
  const normalized = rawNormalizedQuery.normalize('NFKC').trim().toLowerCase().replace(/\s+/g, ' ').slice(0, 256);
  return hmacSha256Hex(secret, normalized);
}
