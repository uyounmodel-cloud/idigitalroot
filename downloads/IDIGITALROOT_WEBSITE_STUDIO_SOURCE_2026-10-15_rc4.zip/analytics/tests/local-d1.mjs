import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

export class LocalStatement {
  constructor(owner, sql, values=[]) { this.owner=owner; this.sql=sql; this.values=values; }
  bind(...values){ return new LocalStatement(this.owner,this.sql,values); }
  first(column){ const row=this.owner.db.prepare(this.sql).get(...this.values); if(row==null)return null; const plain={...row}; return column==null?plain:(plain[column]??null); }
  all(){ const rows=this.owner.db.prepare(this.sql).all(...this.values).map(r=>({...r})); return {success:true,results:rows,meta:{}}; }
  run(){ const r=this.owner.db.prepare(this.sql).run(...this.values); return {success:true,results:[],meta:{changes:Number(r.changes),last_row_id:Number(r.lastInsertRowid)}}; }
}
export class LocalD1 {
  constructor(filename=':memory:'){ this.db=new DatabaseSync(filename); this.db.exec('PRAGMA foreign_keys=ON'); }
  prepare(sql){ return new LocalStatement(this,sql); }
  async batch(statements){ this.db.exec('BEGIN IMMEDIATE'); const out=[]; try{for(const s of statements)out.push(s.run());this.db.exec('COMMIT');return out}catch(e){try{this.db.exec('ROLLBACK')}catch{}throw e} }
  close(){this.db.close()}
  exec(sql){this.db.exec(sql)}
}
function sha(bytes){return crypto.createHash('sha256').update(bytes).digest('hex')}
export function applyMigrations(db, dir){
  db.exec(`CREATE TABLE IF NOT EXISTS _schema_migrations(migration_name TEXT PRIMARY KEY,sha256 TEXT NOT NULL,applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')))`);
  const files=fs.readdirSync(dir).filter(x=>x.endsWith('.sql')).sort(); let applied=0,skipped=0;
  for(const name of files){const bytes=fs.readFileSync(path.join(dir,name)); const digest=sha(bytes); const row=db.db.prepare('SELECT sha256 FROM _schema_migrations WHERE migration_name=?').get(name); if(row){if(row.sha256!==digest)throw new Error(`migration checksum mismatch ${name}`); skipped++;continue} db.exec('BEGIN IMMEDIATE');try{db.exec(bytes.toString('utf8'));db.db.prepare('INSERT INTO _schema_migrations(migration_name,sha256) VALUES(?,?)').run(name,digest);db.exec('COMMIT');applied++}catch(e){try{db.exec('ROLLBACK')}catch{}throw e}}
  return {applied,skipped};
}
export function loadFixture(db, filename){db.exec(fs.readFileSync(filename,'utf8'))}
