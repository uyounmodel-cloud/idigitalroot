#!/usr/bin/env python3
from __future__ import annotations
import hashlib, os, pathlib, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
EXPECTED_TOOLCHAIN={"node":"v22.16.0","npm":"10.9.2","tsc":"Version 5.8.3"}
EXPECTED_MIGRATIONS={
"schema/analytics/migrations/0001_analytics_schema.sql":"930f20b7a825d29cab6ceb3d45c8c70a75199d1f8222b38b498267cbb6aa74ee",
"schema/analytics/migrations/0002_analytics_registry_seed.sql":"478563180a82260093a4f9f10728bc77591d30c15aa345607c3041889226e852",
"schema/core/migrations/0001_core_registry.sql":"bbfeaca5a70d5ac5e13b5917f7de2a1eb6d857ad8e6b0c1debb36cd8be60315a",
"schema/core/migrations/0002_auth_rbac_seams.sql":"ccd4e878df1635b7756dc4b934871162a3b1509ce1fdd3ff0baa3baf0802bc87",
"schema/core/migrations/0003_routes_and_content_entities.sql":"416dce1173c103ea5f01efba9d225f9857ec5551bfc2759cacd6a722ee505647",
"schema/core/migrations/0004_content_revisions_and_sections.sql":"8afad9495802af85fc0312b17d57d6a66c9753a6878ac963a4055d90da129949",
"schema/core/migrations/0005_media_and_embed_registry.sql":"8daf78187c5f237111a7a1048ac6b1e80fc00e07b5c551b61b641cece9b72f4a",
"schema/core/migrations/0006_publication_schedule_idempotency.sql":"865a26138fc72ecb0cb9dca08ad24cf20d49815043d061c3f5224a1b691cdee3",
"schema/core/migrations/0007_inquiry_and_lead.sql":"5ea7c12cde8d20a6e3f52e5340abd9bf35f4ad50cf6086d5ad30c88d306b11cf",
"schema/core/migrations/0008_retention_policy_and_audit.sql":"3b75ceb8b0c4259c7757758779bba57bd8e52c8c9f9766520754b68e729cdae8",
"schema/core/migrations/0009_integrity_triggers.sql":"134226ff1a4fe6d7d608d8237626e0c9ff0f53a95dddc7f589d9f6bd6ee69ac3",
"schema/core/migrations/0010_registry_seed.sql":"eb3898df4a58409de32456c99e5541092dd2f44990589dc6e22df0ad8a15d583",
"schema/core/migrations/0011_publication_guard_closure.sql":"c1ea22d6730d32f3de61f9dec3eb82f01949c64e30303a3e8b31f5575204ea9d",
"schema/core/migrations/0012_auth_physical_alignment.sql":"64e71eae24d9c6c6a8ea279269ac71faf7b7ae93732db2a9b0e99848ccdcaedc",
"schema/core/migrations/0013_cms_extensions_and_analytics_seam.sql":"c4cad248d3d4ee8aaca2b87029517ffd1db08f0f73f432fa4a9bc19b9344bd33",
"schema/core/migrations/0014_permissions_roles_retention_registry.sql":"dfab0df6c6b436b4b97dfa0d5419a94f1adf08dd5f6309cb752cc564666c0ad1",
}
def sha(p:pathlib.Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()
def run(cmd:list[str])->None:
    print('+',' '.join(cmd),flush=True); subprocess.run(cmd,cwd=ROOT,check=True)
def listed_files()->set[str]:
    out=set()
    for p in ROOT.rglob('*'):
        if not p.is_file(): continue
        rel=p.relative_to(ROOT).as_posix()
        if rel=='SHA256SUMS.txt' or rel.startswith('dist/') or rel.startswith('node_modules/') or '/__pycache__/' in '/'+rel: continue
        out.add(rel)
    return out
def verify_checksums()->None:
    sums=ROOT/'SHA256SUMS.txt'; assert sums.is_file(),'missing SHA256SUMS.txt'
    declared={}
    for raw in sums.read_text(encoding='utf-8').splitlines():
        if not raw.strip():continue
        digest,rel=raw.split('  ',1); assert len(digest)==64 and rel not in declared
        declared[rel]=digest
    actual=listed_files(); assert set(declared)==actual, f'checksum file set mismatch missing={sorted(actual-set(declared))} extra={sorted(set(declared)-actual)}'
    for rel,digest in declared.items(): assert sha(ROOT/rel)==digest,f'checksum mismatch {rel}'
def main()->None:
    verify_checksums(); print('INTERNAL_SHA256SUMS_PASS')
    for rel,digest in EXPECTED_MIGRATIONS.items(): assert sha(ROOT/rel)==digest,f'accepted migration changed: {rel}'
    print('ACCEPTED_MIGRATION_LINEAGE_PASS')
    got={
      'node':subprocess.check_output(['node','--version'],text=True).strip(),
      'npm':subprocess.check_output(['npm','--version'],text=True).strip(),
      'tsc':subprocess.check_output(['tsc','--version'],text=True).strip(),
    }
    assert got==EXPECTED_TOOLCHAIN,f'toolchain mismatch: {got!r}'
    print('PINNED_TOOLCHAIN_PASS')
    run(['npm','ci','--ignore-scripts','--offline'])
    run(['npm','run','typecheck'])
    run(['npm','run','build'])
    run(['npm','test'])
    print('P1_AN_01_SEALED_SOURCE_VERIFY_PASS')
if __name__=='__main__': main()
