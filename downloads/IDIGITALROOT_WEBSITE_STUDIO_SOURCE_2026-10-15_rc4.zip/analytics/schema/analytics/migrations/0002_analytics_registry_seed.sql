-- P1-DATA-02 / Analytics D1 0002
-- Code-owned synthetic registry seeds. No real PII, account identifiers, or policy durations.

INSERT INTO analytics_schema_meta(meta_key,meta_value,updated_at) VALUES
('contract.task','P1-DATA-02','2026-09-30T00:00:00Z'),
('analytics.lineage','0001+ separate D1','2026-09-30T00:00:00Z'),
('event.registry.version','v1','2026-09-30T00:00:00Z'),
('properties.max_bytes','8192','2026-09-30T00:00:00Z');

INSERT INTO analytics_event_registry(event_key,event_class,schema_version,enabled,allowed_modes_json,property_schema_json,cardinality_policy_json,reporting_dimensions_json,retention_category_key,raw_export_allowed,updated_at) VALUES
('page_view','NAVIGATION',1,1,'["COOKIELESS","CONSENTED"]','{"type":"object","additionalProperties":false}','{"maxKeys":0}','["route_id","locale_code","device_class","country_code"]','analytics.raw_events',1,'2026-09-30T00:00:00Z'),
('component_interaction','ENGAGEMENT',1,1,'["COOKIELESS","CONSENTED"]','{"type":"object","allowed":["interaction_key"]}','{"interaction_key":64}','["route_id","component_key","locale_code"]','analytics.raw_events',1,'2026-09-30T00:00:00Z'),
('internal_search','SEARCH',1,1,'["COOKIELESS","CONSENTED"]','{"type":"object","allowed":["result_count_class","query_length_class","query_group_hash"]}','{"query_group_hash":256}','["route_id","locale_code"]','analytics.raw_events',0,'2026-09-30T00:00:00Z'),
('inquiry_funnel_step','FUNNEL',1,1,'["COOKIELESS","CONSENTED"]','{"type":"object","allowed":["step_key","outcome"]}','{"step_key":32,"outcome":16}','["route_id","locale_code"]','analytics.raw_events',1,'2026-09-30T00:00:00Z'),
('inquiry_accepted','FUNNEL',1,1,'["COOKIELESS","CONSENTED"]','{"type":"object","allowed":["conversion_kind"]}','{"conversion_kind":8}','["route_id","locale_code"]','analytics.raw_events',1,'2026-09-30T00:00:00Z'),
('web_vital','PERFORMANCE',1,1,'["COOKIELESS","CONSENTED"]','{"type":"object","allowed":["metric_key","value_bucket"]}','{"metric_key":16,"value_bucket":32}','["route_id","device_class"]','analytics.raw_events',1,'2026-09-30T00:00:00Z'),
('runtime_error','RUNTIME_HEALTH',1,1,'["COOKIELESS","CONSENTED"]','{"type":"object","allowed":["error_code","build_id","stack_signature"]}','{"error_code":128,"build_id":64,"stack_signature":1024}','["route_id","component_key","browser_class"]','analytics.raw_events',0,'2026-09-30T00:00:00Z'),
('ingest_security','BOT_SECURITY',1,1,'["COOKIELESS","CONSENTED"]','{"type":"object","additionalProperties":false}','{"maxKeys":0}','["bot_class","country_code"]','analytics.ingest_security',0,'2026-09-30T00:00:00Z');
