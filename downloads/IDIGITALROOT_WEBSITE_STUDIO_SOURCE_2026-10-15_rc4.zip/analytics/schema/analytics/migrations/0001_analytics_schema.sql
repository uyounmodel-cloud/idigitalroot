-- P1-DATA-02 / Analytics D1 0001
-- Separate analytics database. No cross-database foreign keys into Core D1.

CREATE TABLE analytics_schema_meta (
  meta_key TEXT PRIMARY KEY,
  meta_value TEXT NOT NULL,
  updated_at TEXT NOT NULL CHECK (substr(updated_at,-1)='Z')
);

CREATE TABLE analytics_event_registry (
  event_key TEXT PRIMARY KEY,
  event_class TEXT NOT NULL CHECK (event_class IN ('NAVIGATION','ENGAGEMENT','ACQUISITION','SEARCH','FUNNEL','PERFORMANCE','RUNTIME_HEALTH','BOT_SECURITY')),
  schema_version INTEGER NOT NULL CHECK (schema_version >= 1),
  enabled INTEGER NOT NULL CHECK (enabled IN (0,1)),
  allowed_modes_json TEXT NOT NULL,
  property_schema_json TEXT NOT NULL,
  cardinality_policy_json TEXT NOT NULL,
  reporting_dimensions_json TEXT NOT NULL,
  retention_category_key TEXT NOT NULL,
  raw_export_allowed INTEGER NOT NULL CHECK (raw_export_allowed IN (0,1)),
  updated_at TEXT NOT NULL CHECK (substr(updated_at,-1)='Z'),
  UNIQUE(event_key,schema_version)
);

CREATE TABLE analytics_sessions (
  session_id TEXT PRIMARY KEY,
  visitor_key_hash TEXT NULL CHECK (visitor_key_hash IS NULL OR length(visitor_key_hash)=64),
  started_at TEXT NOT NULL CHECK (substr(started_at,-1)='Z'),
  last_event_at TEXT NOT NULL CHECK (substr(last_event_at,-1)='Z'),
  consent_mode TEXT NOT NULL CHECK (consent_mode IN ('COOKIELESS','CONSENTED')),
  privacy_policy_version TEXT NULL,
  locale_code TEXT NULL,
  landing_route_id TEXT NULL,
  landing_entity_id TEXT NULL,
  referrer_class TEXT NULL,
  referrer_host TEXT NULL CHECK (referrer_host IS NULL OR length(referrer_host)<=253),
  utm_source TEXT NULL CHECK (utm_source IS NULL OR length(utm_source)<=160),
  utm_medium TEXT NULL CHECK (utm_medium IS NULL OR length(utm_medium)<=160),
  utm_campaign TEXT NULL CHECK (utm_campaign IS NULL OR length(utm_campaign)<=240),
  utm_content TEXT NULL CHECK (utm_content IS NULL OR length(utm_content)<=240),
  utm_term TEXT NULL CHECK (utm_term IS NULL OR length(utm_term)<=240),
  browser_class TEXT NULL,
  os_class TEXT NULL,
  device_class TEXT NULL,
  language_class TEXT NULL,
  viewport_class TEXT NULL,
  country_code TEXT NULL CHECK (country_code IS NULL OR length(country_code)=2),
  continent_code TEXT NULL CHECK (continent_code IS NULL OR length(continent_code)<=3),
  bot_class TEXT NULL CHECK (bot_class IS NULL OR bot_class IN ('HUMAN_LIKELY','AUTOMATION_LIKELY','VERIFIED_BOT','UNKNOWN')),
  first_event_id TEXT NULL
);
CREATE INDEX idx_analytics_sessions_started ON analytics_sessions(started_at);
CREATE INDEX idx_analytics_sessions_visitor_started ON analytics_sessions(visitor_key_hash,started_at) WHERE visitor_key_hash IS NOT NULL;
CREATE INDEX idx_analytics_sessions_landing_started ON analytics_sessions(landing_route_id,started_at);

CREATE TABLE analytics_events (
  event_id TEXT PRIMARY KEY,
  event_key TEXT NOT NULL,
  schema_version INTEGER NOT NULL CHECK (schema_version >= 1),
  occurred_at TEXT NOT NULL CHECK (substr(occurred_at,-1)='Z'),
  received_at TEXT NOT NULL CHECK (substr(received_at,-1)='Z'),
  session_id TEXT NULL REFERENCES analytics_sessions(session_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  visitor_key_hash TEXT NULL CHECK (visitor_key_hash IS NULL OR length(visitor_key_hash)=64),
  route_id TEXT NULL,
  entity_id TEXT NULL,
  revision_id TEXT NULL,
  section_instance_id TEXT NULL,
  component_key TEXT NULL,
  locale_code TEXT NULL,
  consent_mode TEXT NOT NULL CHECK (consent_mode IN ('COOKIELESS','CONSENTED')),
  browser_class TEXT NULL,
  os_class TEXT NULL,
  device_class TEXT NULL,
  language_class TEXT NULL,
  viewport_class TEXT NULL,
  country_code TEXT NULL CHECK (country_code IS NULL OR length(country_code)=2),
  continent_code TEXT NULL CHECK (continent_code IS NULL OR length(continent_code)<=3),
  bot_class TEXT NULL CHECK (bot_class IS NULL OR bot_class IN ('HUMAN_LIKELY','AUTOMATION_LIKELY','VERIFIED_BOT','UNKNOWN')),
  properties_json TEXT NOT NULL DEFAULT '{}' CHECK (length(CAST(properties_json AS BLOB)) <= 8192),
  ingest_batch_id TEXT NULL,
  FOREIGN KEY(event_key,schema_version) REFERENCES analytics_event_registry(event_key,schema_version) ON UPDATE CASCADE ON DELETE RESTRICT
);
CREATE INDEX idx_analytics_events_received ON analytics_events(received_at DESC);
CREATE INDEX idx_analytics_events_key_received ON analytics_events(event_key,received_at DESC);
CREATE INDEX idx_analytics_events_route_received ON analytics_events(route_id,received_at DESC);
CREATE INDEX idx_analytics_events_session_received ON analytics_events(session_id,received_at);
CREATE INDEX idx_analytics_events_visitor_received ON analytics_events(visitor_key_hash,received_at) WHERE visitor_key_hash IS NOT NULL;

CREATE TABLE analytics_consent_receipts (
  receipt_id TEXT PRIMARY KEY,
  session_id TEXT NULL REFERENCES analytics_sessions(session_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  visitor_key_hash TEXT NULL CHECK (visitor_key_hash IS NULL OR length(visitor_key_hash)=64),
  prior_mode TEXT NOT NULL CHECK (prior_mode IN ('OFF','COOKIELESS','CONSENTED')),
  new_mode TEXT NOT NULL CHECK (new_mode IN ('OFF','COOKIELESS','CONSENTED')),
  policy_version_reference TEXT NOT NULL,
  captured_at TEXT NOT NULL CHECK (substr(captured_at,-1)='Z')
);

CREATE TABLE analytics_rollups (
  rollup_id TEXT PRIMARY KEY,
  report_key TEXT NOT NULL,
  window_granularity TEXT NOT NULL CHECK (window_granularity IN ('HOUR','DAY')),
  window_start TEXT NOT NULL CHECK (substr(window_start,-1)='Z'),
  window_end TEXT NOT NULL CHECK (substr(window_end,-1)='Z'),
  dimension_hash TEXT NOT NULL CHECK (length(dimension_hash)=64),
  dimensions_json TEXT NOT NULL CHECK (length(CAST(dimensions_json AS BLOB)) <= 8192),
  metric_count INTEGER NULL CHECK (metric_count IS NULL OR metric_count >= 0),
  metric_sum REAL NULL,
  metric_min REAL NULL,
  metric_max REAL NULL,
  metrics_json TEXT NOT NULL DEFAULT '{}' CHECK (length(CAST(metrics_json AS BLOB)) <= 16384),
  source_through_received_at TEXT NOT NULL CHECK (substr(source_through_received_at,-1)='Z'),
  updated_at TEXT NOT NULL CHECK (substr(updated_at,-1)='Z'),
  UNIQUE(report_key,window_granularity,window_start,dimension_hash)
);
CREATE INDEX idx_analytics_rollups_report_window ON analytics_rollups(report_key,window_start DESC);

CREATE TABLE analytics_rollup_cursors (
  report_key TEXT PRIMARY KEY,
  through_received_at TEXT NOT NULL CHECK (substr(through_received_at,-1)='Z'),
  through_event_id TEXT NULL,
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version >= 1),
  updated_at TEXT NOT NULL CHECK (substr(updated_at,-1)='Z')
);

CREATE TABLE analytics_ingest_security_buckets (
  bucket_start TEXT NOT NULL CHECK (substr(bucket_start,-1)='Z'),
  reason_code TEXT NOT NULL,
  bot_class TEXT NOT NULL DEFAULT 'UNKNOWN' CHECK (bot_class IN ('HUMAN_LIKELY','AUTOMATION_LIKELY','VERIFIED_BOT','UNKNOWN')),
  country_code TEXT NOT NULL DEFAULT 'ZZ' CHECK (length(country_code)=2),
  count_value INTEGER NOT NULL CHECK (count_value >= 0),
  updated_at TEXT NOT NULL CHECK (substr(updated_at,-1)='Z'),
  PRIMARY KEY(bucket_start,reason_code,bot_class,country_code)
);
