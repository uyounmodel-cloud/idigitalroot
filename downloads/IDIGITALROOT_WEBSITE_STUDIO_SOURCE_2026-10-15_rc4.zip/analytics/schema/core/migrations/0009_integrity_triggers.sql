-- P1-DATA-01 / 0009
-- Fail-closed database invariants for immutable history and public publication safety.

CREATE TRIGGER trg_content_revisions_no_update
BEFORE UPDATE ON content_revisions
BEGIN
  SELECT RAISE(ABORT, 'content revisions are immutable');
END;

CREATE TRIGGER trg_content_revisions_no_delete
BEFORE DELETE ON content_revisions
BEGIN
  SELECT RAISE(ABORT, 'content revisions are immutable');
END;

CREATE TRIGGER trg_page_revision_sections_no_update
BEFORE UPDATE ON page_revision_sections
BEGIN
  SELECT RAISE(ABORT, 'page revision sections are immutable');
END;

CREATE TRIGGER trg_page_revision_sections_no_delete
BEFORE DELETE ON page_revision_sections
BEGIN
  SELECT RAISE(ABORT, 'page revision sections are immutable');
END;

CREATE TRIGGER trg_media_localized_revisions_no_update
BEFORE UPDATE ON media_localized_revisions
BEGIN
  SELECT RAISE(ABORT, 'media localized revisions are immutable');
END;

CREATE TRIGGER trg_media_localized_revisions_no_delete
BEFORE DELETE ON media_localized_revisions
BEGIN
  SELECT RAISE(ABORT, 'media localized revisions are immutable');
END;

CREATE TRIGGER trg_publication_events_no_update
BEFORE UPDATE ON publication_events
BEGIN
  SELECT RAISE(ABORT, 'publication events are immutable');
END;

CREATE TRIGGER trg_publication_events_no_delete
BEFORE DELETE ON publication_events
BEGIN
  SELECT RAISE(ABORT, 'publication events are immutable');
END;

CREATE TRIGGER trg_audit_events_no_update
BEFORE UPDATE ON audit_events
BEGIN
  SELECT RAISE(ABORT, 'audit events are append-only');
END;

CREATE TRIGGER trg_audit_events_no_delete
BEFORE DELETE ON audit_events
BEGIN
  SELECT RAISE(ABORT, 'audit events are append-only');
END;

CREATE TRIGGER trg_lead_answers_no_update
BEFORE UPDATE ON lead_answers
BEGIN
  SELECT RAISE(ABORT, 'submitted lead answers are immutable');
END;

CREATE TRIGGER trg_lead_answers_no_delete
BEFORE DELETE ON lead_answers
BEGIN
  SELECT RAISE(ABORT, 'submitted lead answers are immutable');
END;

CREATE TRIGGER trg_lead_answer_options_no_update
BEFORE UPDATE ON lead_answer_options
BEGIN
  SELECT RAISE(ABORT, 'submitted lead answer options are immutable');
END;

CREATE TRIGGER trg_lead_answer_options_no_delete
BEFORE DELETE ON lead_answer_options
BEGIN
  SELECT RAISE(ABORT, 'submitted lead answer options are immutable');
END;

CREATE TRIGGER trg_idempotency_identity_immutable
BEFORE UPDATE ON idempotency_records
WHEN NEW.operation_scope <> OLD.operation_scope
   OR NEW.context_hash <> OLD.context_hash
   OR NEW.idempotency_key_hash <> OLD.idempotency_key_hash
   OR NEW.request_hash <> OLD.request_hash
BEGIN
  SELECT RAISE(ABORT, 'idempotency identity and request hash are immutable');
END;

CREATE TRIGGER trg_published_wizard_step_locked_update
BEFORE UPDATE ON inquiry_steps
WHEN (SELECT status FROM inquiry_wizard_versions WHERE wizard_version_id = OLD.wizard_version_id) IN ('PUBLISHED','ARCHIVED')
BEGIN
  SELECT RAISE(ABORT, 'published inquiry wizard structure is immutable');
END;

CREATE TRIGGER trg_published_wizard_step_locked_delete
BEFORE DELETE ON inquiry_steps
WHEN (SELECT status FROM inquiry_wizard_versions WHERE wizard_version_id = OLD.wizard_version_id) IN ('PUBLISHED','ARCHIVED')
BEGIN
  SELECT RAISE(ABORT, 'published inquiry wizard structure is immutable');
END;

CREATE TRIGGER trg_published_wizard_field_locked_update
BEFORE UPDATE ON inquiry_fields
WHEN (SELECT status FROM inquiry_wizard_versions w JOIN inquiry_steps s ON s.wizard_version_id=w.wizard_version_id WHERE s.step_id = OLD.step_id) IN ('PUBLISHED','ARCHIVED')
BEGIN
  SELECT RAISE(ABORT, 'published inquiry wizard fields are immutable');
END;

CREATE TRIGGER trg_published_wizard_field_locked_delete
BEFORE DELETE ON inquiry_fields
WHEN (SELECT status FROM inquiry_wizard_versions w JOIN inquiry_steps s ON s.wizard_version_id=w.wizard_version_id WHERE s.step_id = OLD.step_id) IN ('PUBLISHED','ARCHIVED')
BEGIN
  SELECT RAISE(ABORT, 'published inquiry wizard fields are immutable');
END;

CREATE TRIGGER trg_revision_dependencies_no_update
BEFORE UPDATE ON revision_dependencies
BEGIN
  SELECT RAISE(ABORT, 'revision dependencies are immutable');
END;

CREATE TRIGGER trg_revision_dependencies_no_delete
BEFORE DELETE ON revision_dependencies
BEGIN
  SELECT RAISE(ABORT, 'revision dependencies are immutable');
END;

CREATE TRIGGER trg_revision_media_refs_no_update
BEFORE UPDATE ON revision_media_refs
BEGIN
  SELECT RAISE(ABORT, 'revision media references are immutable');
END;

CREATE TRIGGER trg_revision_media_refs_no_delete
BEFORE DELETE ON revision_media_refs
BEGIN
  SELECT RAISE(ABORT, 'revision media references are immutable');
END;

CREATE TRIGGER trg_page_section_requires_page_entity
BEFORE INSERT ON page_revision_sections
BEGIN
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM content_revisions r
    JOIN content_entities e ON e.entity_id=r.entity_id
    WHERE r.revision_id=NEW.content_revision_id AND e.entity_type='PAGE'
  ) THEN RAISE(ABORT, 'page sections require a PAGE content entity') END;
END;

CREATE TRIGGER trg_revision_media_ref_locale_match
BEFORE INSERT ON revision_media_refs
WHEN NEW.media_localized_revision_id IS NOT NULL
BEGIN
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1
    FROM media_localized_revisions mlr
    JOIN content_revisions cr ON cr.revision_id=NEW.content_revision_id
    WHERE mlr.media_localized_revision_id=NEW.media_localized_revision_id
      AND mlr.media_id=NEW.media_id
      AND mlr.locale_code=cr.locale_code
  ) THEN RAISE(ABORT, 'media localization must match revision media and locale') END;
END;

CREATE TRIGGER trg_publication_pointer_validate_insert
BEFORE INSERT ON publication_pointers
BEGIN
  SELECT CASE WHEN NEW.is_published=1 AND NOT EXISTS (
    SELECT 1 FROM content_revisions r
    WHERE r.revision_id=NEW.revision_id
      AND r.entity_id=NEW.entity_id
      AND r.locale_code=NEW.locale_code
      AND r.workflow_state='READY'
      AND r.validation_state='VALID'
  ) THEN RAISE(ABORT, 'publication requires exact READY + VALID revision') END;

  SELECT CASE WHEN NEW.is_published=1 AND NOT EXISTS (
    SELECT 1 FROM content_locale_state s
    WHERE s.entity_id=NEW.entity_id
      AND s.locale_code=NEW.locale_code
      AND s.translation_state IN ('READY','PUBLISHED')
  ) THEN RAISE(ABORT, 'publication requires READY/PUBLISHED locale state') END;

  SELECT CASE WHEN NEW.is_published=1 AND NOT EXISTS (
    SELECT 1 FROM publication_events e
    WHERE e.publication_event_id=NEW.publication_event_id
      AND e.entity_id=NEW.entity_id
      AND e.locale_code=NEW.locale_code
      AND e.revision_id=NEW.revision_id
      AND e.action IN ('PUBLISH','ROLLBACK')
  ) THEN RAISE(ABORT, 'publication pointer/event mismatch') END;

  SELECT CASE WHEN NEW.is_published=0 AND NOT EXISTS (
    SELECT 1 FROM publication_events e
    WHERE e.publication_event_id=NEW.publication_event_id
      AND e.entity_id=NEW.entity_id
      AND e.locale_code=NEW.locale_code
      AND e.action='UNPUBLISH'
      AND e.revision_id IS NULL
  ) THEN RAISE(ABORT, 'unpublish pointer/event mismatch') END;

  SELECT CASE WHEN NEW.is_published=1 AND EXISTS (
    SELECT 1
    FROM revision_media_refs rm
    JOIN media_assets m ON m.media_id=rm.media_id
    WHERE rm.content_revision_id=NEW.revision_id
      AND rm.required=1
      AND m.approval_state <> 'APPROVED'
  ) THEN RAISE(ABORT, 'required media is not approved') END;

  SELECT CASE WHEN NEW.is_published=1 AND EXISTS (
    SELECT 1
    FROM revision_media_refs rm
    JOIN media_assets m ON m.media_id=rm.media_id
    WHERE rm.content_revision_id=NEW.revision_id
      AND rm.required=1
      AND m.source_class='LOCAL_UPLOAD'
      AND NOT EXISTS (
        SELECT 1 FROM media_objects mo
        WHERE mo.media_id=m.media_id AND mo.object_state='APPROVED_PUBLIC'
      )
  ) THEN RAISE(ABORT, 'required local media has no approved public object') END;

  SELECT CASE WHEN NEW.is_published=1 AND EXISTS (
    SELECT 1
    FROM revision_media_refs rm
    JOIN media_assets m ON m.media_id=rm.media_id
    JOIN media_external_sources es ON es.media_id=m.media_id
    JOIN embed_providers ep ON ep.provider_id=es.provider_id
    WHERE rm.content_revision_id=NEW.revision_id
      AND rm.required=1
      AND m.source_class='EXTERNAL_EMBED'
      AND ep.enabled <> 1
  ) THEN RAISE(ABORT, 'required external provider is not enabled') END;
END;

CREATE TRIGGER trg_publication_pointer_validate_update
BEFORE UPDATE OF revision_id, is_published, publication_event_id ON publication_pointers
BEGIN
  SELECT CASE WHEN NEW.is_published=1 AND NOT EXISTS (
    SELECT 1 FROM content_revisions r
    WHERE r.revision_id=NEW.revision_id
      AND r.entity_id=NEW.entity_id
      AND r.locale_code=NEW.locale_code
      AND r.workflow_state='READY'
      AND r.validation_state='VALID'
  ) THEN RAISE(ABORT, 'publication requires exact READY + VALID revision') END;

  SELECT CASE WHEN NEW.is_published=1 AND NOT EXISTS (
    SELECT 1 FROM publication_events e
    WHERE e.publication_event_id=NEW.publication_event_id
      AND e.entity_id=NEW.entity_id
      AND e.locale_code=NEW.locale_code
      AND e.revision_id=NEW.revision_id
      AND e.action IN ('PUBLISH','ROLLBACK')
  ) THEN RAISE(ABORT, 'publication pointer/event mismatch') END;

  SELECT CASE WHEN NEW.is_published=0 AND NOT EXISTS (
    SELECT 1 FROM publication_events e
    WHERE e.publication_event_id=NEW.publication_event_id
      AND e.entity_id=NEW.entity_id
      AND e.locale_code=NEW.locale_code
      AND e.action='UNPUBLISH'
      AND e.revision_id IS NULL
  ) THEN RAISE(ABORT, 'unpublish pointer/event mismatch') END;

  SELECT CASE WHEN NEW.is_published=1 AND EXISTS (
    SELECT 1
    FROM revision_media_refs rm
    JOIN media_assets m ON m.media_id=rm.media_id
    WHERE rm.content_revision_id=NEW.revision_id
      AND rm.required=1
      AND m.approval_state <> 'APPROVED'
  ) THEN RAISE(ABORT, 'required media is not approved') END;
END;

CREATE TRIGGER trg_publication_schedule_revision_guard
BEFORE INSERT ON publication_schedules
BEGIN
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM content_revisions r
    WHERE r.revision_id=NEW.revision_id
      AND r.entity_id=NEW.entity_id
      AND r.locale_code=NEW.locale_code
      AND r.workflow_state='READY'
      AND r.validation_state='VALID'
  ) THEN RAISE(ABORT, 'schedule requires exact READY + VALID revision') END;
END;
