-- P1-DATA-01 / 0004
-- Immutable localized content revisions and registered page-section composition.

CREATE TABLE content_revisions (
  revision_id TEXT PRIMARY KEY,
  entity_id TEXT NOT NULL REFERENCES content_entities(entity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  locale_code TEXT NOT NULL REFERENCES locales(locale_code) ON UPDATE CASCADE ON DELETE RESTRICT,
  revision_number INTEGER NOT NULL CHECK (revision_number >= 1),
  workflow_state TEXT NOT NULL CHECK (workflow_state IN ('DRAFT','NEEDS_REVIEW','READY','ARCHIVED')),
  validation_state TEXT NOT NULL DEFAULT 'PENDING' CHECK (validation_state IN ('PENDING','VALID','INVALID')),
  schema_version INTEGER NOT NULL DEFAULT 1 CHECK (schema_version >= 1),
  sanitizer_policy_version TEXT NULL,
  content_json TEXT NOT NULL DEFAULT '{}',
  content_hash_sha256 TEXT NOT NULL CHECK (length(content_hash_sha256) = 64),
  source_revision_id TEXT NULL REFERENCES content_revisions(revision_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  created_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  created_at TEXT NOT NULL CHECK (substr(created_at, -1) = 'Z'),
  UNIQUE(entity_id, locale_code, revision_number),
  UNIQUE(revision_id, entity_id, locale_code)
);

CREATE INDEX idx_content_revisions_entity_locale ON content_revisions(entity_id, locale_code, revision_number DESC);

CREATE TABLE content_locale_state (
  entity_id TEXT NOT NULL REFERENCES content_entities(entity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  locale_code TEXT NOT NULL REFERENCES locales(locale_code) ON UPDATE CASCADE ON DELETE RESTRICT,
  translation_state TEXT NOT NULL CHECK (translation_state IN ('MISSING','DRAFT','NEEDS_REVIEW','READY','PUBLISHED','OUTDATED','ARCHIVED')),
  latest_revision_id TEXT NULL,
  source_revision_id TEXT NULL REFERENCES content_revisions(revision_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version >= 1),
  updated_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  updated_at TEXT NOT NULL CHECK (substr(updated_at, -1) = 'Z'),
  PRIMARY KEY(entity_id, locale_code),
  FOREIGN KEY(latest_revision_id, entity_id, locale_code)
    REFERENCES content_revisions(revision_id, entity_id, locale_code)
    ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE page_revision_sections (
  section_row_id TEXT PRIMARY KEY,
  content_revision_id TEXT NOT NULL REFERENCES content_revisions(revision_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  section_instance_id TEXT NOT NULL,
  component_family_id TEXT NOT NULL REFERENCES component_families(component_family_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  ordinal INTEGER NOT NULL CHECK (ordinal >= 1),
  visible INTEGER NOT NULL DEFAULT 1 CHECK (visible IN (0,1)),
  variant_key TEXT NULL,
  config_json TEXT NOT NULL DEFAULT '{}',
  localized_content_json TEXT NOT NULL DEFAULT '{}',
  UNIQUE(content_revision_id, section_instance_id),
  UNIQUE(content_revision_id, ordinal)
);

CREATE INDEX idx_page_sections_component ON page_revision_sections(component_family_id);

CREATE TABLE revision_dependencies (
  dependency_id TEXT PRIMARY KEY,
  content_revision_id TEXT NOT NULL REFERENCES content_revisions(revision_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  dependency_kind TEXT NOT NULL CHECK (dependency_kind IN ('CONTENT','ROUTE','LEGAL','CONFIG')),
  dependency_entity_id TEXT NULL REFERENCES content_entities(entity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  dependency_revision_id TEXT NULL REFERENCES content_revisions(revision_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  required INTEGER NOT NULL DEFAULT 1 CHECK (required IN (0,1))
);

CREATE INDEX idx_revision_dependencies_revision ON revision_dependencies(content_revision_id);
