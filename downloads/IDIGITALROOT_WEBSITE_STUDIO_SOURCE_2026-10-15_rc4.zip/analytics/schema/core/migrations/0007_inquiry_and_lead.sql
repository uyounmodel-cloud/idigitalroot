-- P1-DATA-01 / 0007
-- Versioned 8-step inquiry definition and one stable Phase-1 Lead family for later Phase-2 consumption.

CREATE TABLE inquiry_wizard_versions (
  wizard_version_id TEXT PRIMARY KEY,
  version_key TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL CHECK (status IN ('DRAFT','READY','PUBLISHED','ARCHIVED')),
  schema_hash_sha256 TEXT NOT NULL CHECK (length(schema_hash_sha256) = 64),
  effective_at TEXT NULL CHECK (effective_at IS NULL OR substr(effective_at, -1) = 'Z'),
  created_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  created_at TEXT NOT NULL CHECK (substr(created_at, -1) = 'Z')
);

CREATE TABLE inquiry_steps (
  step_id TEXT PRIMARY KEY,
  wizard_version_id TEXT NOT NULL REFERENCES inquiry_wizard_versions(wizard_version_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  step_key TEXT NOT NULL,
  ordinal INTEGER NOT NULL CHECK (ordinal BETWEEN 1 AND 64),
  protected_system_step INTEGER NOT NULL DEFAULT 1 CHECK (protected_system_step IN (0,1)),
  UNIQUE(wizard_version_id, step_key),
  UNIQUE(wizard_version_id, ordinal)
);

CREATE TABLE inquiry_step_localizations (
  step_id TEXT NOT NULL REFERENCES inquiry_steps(step_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  locale_code TEXT NOT NULL REFERENCES locales(locale_code) ON UPDATE CASCADE ON DELETE RESTRICT,
  title TEXT NOT NULL,
  subtitle TEXT NULL,
  PRIMARY KEY(step_id, locale_code)
);

CREATE TABLE inquiry_fields (
  field_id TEXT PRIMARY KEY,
  step_id TEXT NOT NULL REFERENCES inquiry_steps(step_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  field_key TEXT NOT NULL,
  field_type TEXT NOT NULL CHECK (field_type IN ('SINGLE_SELECT','MULTI_SELECT','TEXT','TEXTAREA','EMAIL','URL','TEL','CHECKBOX','REVIEW')),
  required INTEGER NOT NULL DEFAULT 0 CHECK (required IN (0,1)),
  protected_system_field INTEGER NOT NULL DEFAULT 1 CHECK (protected_system_field IN (0,1)),
  max_length INTEGER NULL CHECK (max_length IS NULL OR max_length BETWEEN 1 AND 65536),
  validation_key TEXT NULL,
  ordinal INTEGER NOT NULL CHECK (ordinal >= 1),
  UNIQUE(step_id, field_key),
  UNIQUE(step_id, ordinal)
);

CREATE TABLE inquiry_field_localizations (
  field_id TEXT NOT NULL REFERENCES inquiry_fields(field_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  locale_code TEXT NOT NULL REFERENCES locales(locale_code) ON UPDATE CASCADE ON DELETE RESTRICT,
  label TEXT NOT NULL,
  help_text TEXT NULL,
  placeholder TEXT NULL,
  PRIMARY KEY(field_id, locale_code)
);

CREATE TABLE inquiry_field_options (
  option_id TEXT PRIMARY KEY,
  field_id TEXT NOT NULL REFERENCES inquiry_fields(field_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  option_key TEXT NOT NULL,
  ordinal INTEGER NOT NULL CHECK (ordinal >= 1),
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  UNIQUE(field_id, option_key),
  UNIQUE(field_id, ordinal)
);

CREATE TABLE inquiry_option_localizations (
  option_id TEXT NOT NULL REFERENCES inquiry_field_options(option_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  locale_code TEXT NOT NULL REFERENCES locales(locale_code) ON UPDATE CASCADE ON DELETE RESTRICT,
  label TEXT NOT NULL,
  PRIMARY KEY(option_id, locale_code)
);

CREATE TABLE leads (
  lead_id TEXT PRIMARY KEY,
  public_reference TEXT NULL UNIQUE,
  wizard_version_id TEXT NOT NULL REFERENCES inquiry_wizard_versions(wizard_version_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  locale_code TEXT NOT NULL REFERENCES locales(locale_code) ON UPDATE CASCADE ON DELETE RESTRICT,
  name TEXT NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 160),
  email_normalized TEXT NOT NULL CHECK (length(email_normalized) BETWEEN 3 AND 320),
  university_or_institution TEXT NULL CHECK (university_or_institution IS NULL OR length(university_or_institution) <= 240),
  country TEXT NULL CHECK (country IS NULL OR length(country) <= 160),
  phone TEXT NULL CHECK (phone IS NULL OR length(phone) <= 80),
  preferred_contact_method TEXT NULL CHECK (preferred_contact_method IS NULL OR preferred_contact_method IN ('Email','Phone','Either')),
  intake_state TEXT NOT NULL DEFAULT 'ACCEPTED' CHECK (intake_state IN ('ACCEPTED','REJECTED_ABUSE','SPAM')),
  source_context_json TEXT NOT NULL DEFAULT '{}',
  retention_category_id TEXT NULL REFERENCES retention_categories(retention_category_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  received_at TEXT NOT NULL CHECK (substr(received_at, -1) = 'Z')
);

CREATE TABLE lead_answers (
  answer_id TEXT PRIMARY KEY,
  lead_id TEXT NOT NULL REFERENCES leads(lead_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  field_id TEXT NOT NULL REFERENCES inquiry_fields(field_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  value_text TEXT NULL,
  value_json TEXT NULL,
  submitted_at TEXT NOT NULL CHECK (substr(submitted_at, -1) = 'Z'),
  CHECK ((value_text IS NOT NULL AND value_json IS NULL) OR (value_text IS NULL AND value_json IS NOT NULL)),
  UNIQUE(lead_id, field_id)
);

CREATE TABLE lead_answer_options (
  answer_id TEXT NOT NULL REFERENCES lead_answers(answer_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  option_id TEXT NOT NULL REFERENCES inquiry_field_options(option_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  ordinal INTEGER NOT NULL CHECK (ordinal >= 1),
  PRIMARY KEY(answer_id, option_id),
  UNIQUE(answer_id, ordinal)
);

CREATE TABLE lead_attribution (
  lead_id TEXT PRIMARY KEY REFERENCES leads(lead_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  landing_path TEXT NULL,
  referring_url TEXT NULL,
  campaign TEXT NULL,
  utm_source TEXT NULL,
  utm_medium TEXT NULL,
  utm_campaign TEXT NULL,
  utm_term TEXT NULL,
  utm_content TEXT NULL,
  cta_source TEXT NULL
);

CREATE TABLE lead_consents (
  lead_consent_id TEXT PRIMARY KEY,
  lead_id TEXT NOT NULL REFERENCES leads(lead_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  consent_type TEXT NOT NULL CHECK (consent_type IN ('INQUIRY_CONTACT','MARKETING','PRIVACY_NOTICE_ACK')),
  granted INTEGER NOT NULL CHECK (granted IN (0,1)),
  policy_version_reference TEXT NULL,
  legal_revision_id TEXT NULL REFERENCES content_revisions(revision_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  captured_at TEXT NOT NULL CHECK (substr(captured_at, -1) = 'Z'),
  UNIQUE(lead_id, consent_type)
);

CREATE TABLE lead_security_events (
  lead_security_event_id TEXT PRIMARY KEY,
  lead_id TEXT NULL REFERENCES leads(lead_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  event_type TEXT NOT NULL CHECK (event_type IN ('RATE_DECISION','BOT_DECISION','ABUSE_FLAG','REPLAY_CONFLICT','VALIDATION_FAILURE','ACCEPTED')),
  outcome TEXT NOT NULL,
  signal_hash TEXT NULL,
  minimized_metadata_json TEXT NOT NULL DEFAULT '{}',
  retention_category_id TEXT NULL REFERENCES retention_categories(retention_category_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  created_at TEXT NOT NULL CHECK (substr(created_at, -1) = 'Z')
);

CREATE INDEX idx_leads_received ON leads(received_at DESC);
CREATE INDEX idx_leads_email ON leads(email_normalized);
CREATE INDEX idx_lead_answers_lead ON lead_answers(lead_id);
CREATE INDEX idx_lead_security_events_lead ON lead_security_events(lead_id, created_at DESC);
