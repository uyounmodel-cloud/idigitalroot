-- P1-DATA-01 / 0010
-- Code-owned launch registry seeds. No legal copy, numeric retention duration, legal basis, secrets or live IDs.

INSERT INTO schema_contract_meta(meta_key,meta_value,updated_at) VALUES
('contract.task','P1-DATA-01','2026-09-29T00:00:00Z'),
('contract.architecture','P1-ARCH-01','2026-09-29T00:00:00Z'),
('contract.ui_sha256','d10b1cff47d5912fecb49d88579971f3e21bb19a33b179e29356ea0eac5646fd','2026-09-29T00:00:00Z'),
('component.registry.version','v4.3','2026-09-29T00:00:00Z');

INSERT INTO locales(locale_code,display_name,native_name,direction,public_enabled,cms_enabled,inquiry_enabled,publication_eligible,formatting_json) VALUES
('en','English','English','ltr',1,1,1,1,'{}'),
('ar','Arabic','العربية','rtl',1,1,1,1,'{}');

INSERT INTO component_families(component_family_id,component_key,family_type,registry_version,schema_version,max_instances_per_page,reorderable,optional,code_registered,allowed_variants_json) VALUES
('cmp_hero','hero','SECTION','v4.3',1,1,0,0,1,'[]'),
('cmp_student_problem','student-problem','SECTION','v4.3',1,1,1,1,1,'[]'),
('cmp_student_foundation','student-foundation','SECTION','v4.3',1,1,1,1,1,'[]'),
('cmp_story','story','SECTION','v4.3',1,1,1,1,1,'[]'),
('cmp_human_stories','human-stories','SECTION','v4.3',1,1,1,1,1,'[]'),
('cmp_three_experiences','three-experiences','SECTION','v4.3',1,1,1,1,1,'[]'),
('cmp_roots','roots','SECTION','v4.3',1,1,1,1,1,'[]'),
('cmp_toolbox','toolbox','SECTION','v4.3',1,1,1,1,1,'[]'),
('cmp_student_workspace','student-workspace','SECTION','v4.3',1,1,1,1,1,'[]'),
('cmp_student_benefits','student-benefits','SECTION','v4.3',1,1,1,1,1,'[]'),
('cmp_my_dream','my-dream','SECTION','v4.3',1,1,1,1,1,'[]'),
('cmp_major_personalization','major-personalization','SECTION','v4.3',1,1,1,1,1,'[]'),
('cmp_project_to_career','project-to-career','SECTION','v4.3',1,1,1,1,1,'[]'),
('cmp_human_built','human-built','SECTION','v4.3',1,1,1,1,1,'[]'),
('cmp_knowledge','knowledge','SECTION','v4.3',1,1,1,1,1,'[]'),
('cmp_not_student','not-student','SECTION','v4.3',1,1,1,1,1,'[]'),
('cmp_proof','proof','SECTION','v4.3',1,1,1,1,1,'[]'),
('cmp_faq','faq','SECTION','v4.3',1,1,1,1,1,'[]'),
('cmp_final_cta','final-cta','SECTION','v4.3',1,1,1,0,1,'[]'),
('cmp_footer','footer','SECTION','v4.3',1,1,0,0,1,'[]'),
('blk_signature_ticker','signature-ticker','BLOCK','v4.3',1,NULL,1,1,1,'[]'),
('blk_illustrative_people_stories','illustrative-people-stories','BLOCK','v4.3',1,NULL,1,1,1,'[]'),
('blk_brand_manifesto','brand-manifesto','BLOCK','v4.3',1,NULL,1,1,1,'[]');

INSERT INTO permissions(permission_id,permission_key,description,resource_family) VALUES
('perm_content_read_drafts','content.read_drafts','Read draft content and retained history','content'),
('perm_content_edit','content.edit','Create/edit validated draft content revisions','content'),
('perm_translation_edit','translations.edit','Edit localized content and translation states','translation'),
('perm_media_manage','media.manage','Manage media metadata and approved upload lifecycle','media'),
('perm_preview_issue','preview.issue','Issue or use governed draft preview capabilities','preview'),
('perm_publish_execute','publish.execute','Publish or unpublish validated content','publication'),
('perm_schedule_manage','schedule.manage','Create/cancel publication schedules','publication'),
('perm_rollback_execute','rollback.execute','Republish retained valid revisions','publication'),
('perm_provider_manage','providers.manage','Manage trusted embed/provider configuration','configuration'),
('perm_audit_read','audit.read','Read protected audit/history data','audit'),
('perm_identity_manage','identities.manage','Manage CMS identity/role assignments when authorized','identity'),
('perm_locale_manage','locales.manage','Manage locale registry and publication eligibility','localization');

INSERT INTO retention_categories(retention_category_id,category_key,description,policy_gate_state) VALUES
('ret_lead_spam','lead.spam','Spam or abusive public inquiry records','OPEN'),
('ret_lead_rejected','lead.rejected','Rejected inquiry/Lead records','OPEN'),
('ret_lead_no_response','lead.no_response','No-response inquiry/Lead records','OPEN'),
('ret_lead_qualified','lead.qualified','Qualified inquiry/Lead records','OPEN'),
('ret_lead_converted','lead.converted','Converted Lead source records retained for lineage','OPEN'),
('ret_communication','communication.history','Future communication history linked to Leads/clients','OPEN'),
('ret_security','security.metadata','Security/abuse/idempotency metadata','OPEN'),
('ret_cms_sessions','cms.session_security','CMS session and security-event metadata','OPEN'),
('ret_audit','audit.records','Protected audit records','OPEN'),
('ret_media_quarantine','media.quarantine','Rejected/quarantined media metadata and objects','OPEN'),
('ret_idempotency','idempotency.records','Duplicate-prevention records','OPEN');
