-- P1-DATA-01 / 0008
-- Policy-support tables. Numeric durations/legal bases are deliberately nullable until approved.

CREATE TABLE retention_policy_versions (
  retention_policy_version_id TEXT PRIMARY KEY,
  retention_category_id TEXT NOT NULL REFERENCES retention_categories(retention_category_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  policy_version_key TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('DRAFT','PENDING_APPROVAL','APPROVED','RETIRED')),
  duration_seconds INTEGER NULL CHECK (duration_seconds IS NULL OR duration_seconds >= 0),
  legal_basis_code TEXT NULL,
  deletion_exception_reference TEXT NULL,
  effective_at TEXT NULL CHECK (effective_at IS NULL OR substr(effective_at, -1) = 'Z'),
  approved_at TEXT NULL CHECK (approved_at IS NULL OR substr(approved_at, -1) = 'Z'),
  approved_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  created_at TEXT NOT NULL CHECK (substr(created_at, -1) = 'Z'),
  UNIQUE(retention_category_id, policy_version_key)
);

CREATE TABLE record_retention_assignments (
  retention_assignment_id TEXT PRIMARY KEY,
  record_type TEXT NOT NULL,
  record_id TEXT NOT NULL,
  retention_category_id TEXT NOT NULL REFERENCES retention_categories(retention_category_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  retention_policy_version_id TEXT NULL REFERENCES retention_policy_versions(retention_policy_version_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  legal_hold INTEGER NOT NULL DEFAULT 0 CHECK (legal_hold IN (0,1)),
  assigned_at TEXT NOT NULL CHECK (substr(assigned_at, -1) = 'Z'),
  UNIQUE(record_type, record_id, retention_category_id)
);

CREATE TABLE audit_events (
  audit_event_id TEXT PRIMARY KEY,
  actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  source_kind TEXT NOT NULL CHECK (source_kind IN ('CMS','PUBLIC_INTAKE','SYSTEM','RELEASE')),
  action_key TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_id TEXT NOT NULL,
  before_revision_id TEXT NULL REFERENCES content_revisions(revision_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  after_revision_id TEXT NULL REFERENCES content_revisions(revision_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  environment_key TEXT NOT NULL,
  outcome TEXT NOT NULL CHECK (outcome IN ('SUCCESS','DENIED','FAILED')),
  correlation_id TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL CHECK (substr(created_at, -1) = 'Z')
);

CREATE INDEX idx_audit_target ON audit_events(target_type, target_id, created_at DESC);
CREATE INDEX idx_audit_actor ON audit_events(actor_id, created_at DESC);
CREATE INDEX idx_retention_assignments_record ON record_retention_assignments(record_type, record_id);
