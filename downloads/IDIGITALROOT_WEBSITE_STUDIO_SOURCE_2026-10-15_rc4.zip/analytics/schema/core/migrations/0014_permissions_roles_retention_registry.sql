-- P1-DATA-02 / Core 0014
-- Exact P1-AUTH permission keys/role bundles plus additive analytics roles and open retention categories.

-- Update exact legacy-overlap permission metadata without changing stable IDs.
UPDATE permissions SET description='Edit draft page/component content',resource_family='content',risk_class='normal',authorization_state='ACTIVE' WHERE permission_key='content.edit';
UPDATE permissions SET description='Edit locale/translation content without publish authority',resource_family='translation',risk_class='normal',authorization_state='ACTIVE' WHERE permission_key='translations.edit';
UPDATE permissions SET description='Upload/replace/organize CMS media within media policy',resource_family='media',risk_class='normal/sensitive',authorization_state='ACTIVE' WHERE permission_key='media.manage';
UPDATE permissions SET description='View application security/authorization/content audit subject to privacy policy',resource_family='audit',risk_class='privileged-read',authorization_state='ACTIVE' WHERE permission_key='audit.read';

INSERT INTO permissions(permission_id,permission_key,description,resource_family,authorization_state,risk_class) VALUES
('perm_p1auth_content_read','content.read','View CMS content, drafts and version metadata allowed by scope','content','ACTIVE','normal'),
('perm_p1auth_navigation_edit','navigation.edit','Edit public navigation/footer/menu structures','content','ACTIVE','normal'),
('perm_p1auth_seo_edit','seo.edit','Edit CMS-owned SEO/metadata fields','content','ACTIVE','normal'),
('perm_p1auth_preview_use','preview.use','Render authenticated draft preview','preview','ACTIVE','normal'),
('perm_p1auth_publication_publish','publication.publish','Publish an approved draft/version','publication','ACTIVE','privileged'),
('perm_p1auth_publication_unpublish','publication.unpublish','Remove published visibility through supported publication flow','publication','ACTIVE','privileged'),
('perm_p1auth_publication_schedule','publication.schedule','Create publication schedule','publication','ACTIVE','privileged'),
('perm_p1auth_publication_cancel','publication.cancel','Cancel scheduled publication','publication','ACTIVE','privileged'),
('perm_p1auth_publication_rollback','publication.rollback','Republish/restore an earlier valid version through controlled flow','publication','ACTIVE','privileged'),
('perm_p1auth_config_providers_manage','config.providers.manage','Change registered provider/embed non-secret configuration','configuration','ACTIVE','privileged'),
('perm_p1auth_config_global_manage','config.global.manage','Change privileged global CMS configuration excluding secrets/infrastructure','configuration','ACTIVE','privileged'),
('perm_p1auth_identity_read','identity.read','View CMS actor/role/session administrative state','identity','ACTIVE','privileged-read'),
('perm_p1auth_identity_invite','identity.invite','Create/revoke pending CMS actor invitations','identity','ACTIVE','Tier A'),
('perm_p1auth_identity_deprovision','identity.deprovision','Disable/reactivate actor under recovery rules; revoke bindings','identity','ACTIVE','Tier A'),
('perm_p1auth_roles_assign','roles.assign','Grant/revoke roles/scopes subject to invariants','identity','ACTIVE','Tier A'),
('perm_p1auth_sessions_revoke','sessions.revoke','Revoke another actor CMS sessions','identity','ACTIVE','Tier A'),
('perm_p1auth_security_recovery','security.recovery','Execute approved identity recovery/rebind/bootstrap recovery operations','identity','ACTIVE','Tier A'),
('perm_analytics_read_aggregate','analytics.read.aggregate','Read privacy-approved aggregate analytics dashboards/reports','analytics','ACTIVE','privileged-read'),
('perm_analytics_read_raw','analytics.read.raw','Read permitted pseudonymous raw-event detail','analytics','ACTIVE','privileged-read/high'),
('perm_analytics_export','analytics.export','Export only data classes separately allowed to the actor','analytics','ACTIVE','privileged'),
('perm_analytics_config_manage','analytics.config.manage','Manage non-secret analytics collection/report configuration within frozen registry','analytics','ACTIVE','privileged');

INSERT INTO roles(role_id,role_key,display_name,description,system_managed) VALUES
('role_cms_viewer','CMS_VIEWER','CMS Viewer','Frozen P1-AUTH role bundle',1),
('role_cms_editor','CMS_EDITOR','CMS Editor','Frozen P1-AUTH role bundle',1),
('role_cms_translator','CMS_TRANSLATOR','CMS Translator','Frozen P1-AUTH role bundle',1),
('role_cms_media_editor','CMS_MEDIA_EDITOR','CMS Media Editor','Frozen P1-AUTH role bundle',1),
('role_cms_publisher','CMS_PUBLISHER','CMS Publisher','Frozen P1-AUTH role bundle',1),
('role_cms_config_admin','CMS_CONFIG_ADMIN','CMS Config Admin','Frozen P1-AUTH role bundle',1),
('role_cms_identity_admin','CMS_IDENTITY_ADMIN','CMS Identity Admin','Frozen P1-AUTH role bundle',1),
('role_cms_security_auditor','CMS_SECURITY_AUDITOR','CMS Security Auditor','Frozen P1-AUTH role bundle',1),
('role_cms_root_admin','CMS_ROOT_ADMIN','CMS Root Admin','Emergency/bootstrap role; every active Phase 1 permission',1),
('role_cms_analytics_viewer','CMS_ANALYTICS_VIEWER','CMS Analytics Viewer','Aggregate analytics only',1),
('role_cms_analytics_analyst','CMS_ANALYTICS_ANALYST','CMS Analytics Analyst','Aggregate/raw analytics and export',1),
('role_cms_analytics_admin','CMS_ANALYTICS_ADMIN','CMS Analytics Admin','All analytics permissions',1);

-- Exact P1-AUTH ordinary bundles.
INSERT INTO role_permissions(role_id,permission_id,granted_at,granted_by_actor_id)
SELECT 'role_cms_viewer',permission_id,'2026-09-30T00:00:00Z',NULL FROM permissions WHERE permission_key IN ('content.read','preview.use');
INSERT INTO role_permissions(role_id,permission_id,granted_at,granted_by_actor_id)
SELECT 'role_cms_editor',permission_id,'2026-09-30T00:00:00Z',NULL FROM permissions WHERE permission_key IN ('content.read','content.edit','navigation.edit','seo.edit','preview.use');
INSERT INTO role_permissions(role_id,permission_id,granted_at,granted_by_actor_id)
SELECT 'role_cms_translator',permission_id,'2026-09-30T00:00:00Z',NULL FROM permissions WHERE permission_key IN ('content.read','translations.edit','preview.use');
INSERT INTO role_permissions(role_id,permission_id,granted_at,granted_by_actor_id)
SELECT 'role_cms_media_editor',permission_id,'2026-09-30T00:00:00Z',NULL FROM permissions WHERE permission_key IN ('content.read','media.manage','preview.use');
INSERT INTO role_permissions(role_id,permission_id,granted_at,granted_by_actor_id)
SELECT 'role_cms_publisher',permission_id,'2026-09-30T00:00:00Z',NULL FROM permissions WHERE permission_key IN ('content.read','preview.use','publication.publish','publication.unpublish','publication.schedule','publication.cancel','publication.rollback');
INSERT INTO role_permissions(role_id,permission_id,granted_at,granted_by_actor_id)
SELECT 'role_cms_config_admin',permission_id,'2026-09-30T00:00:00Z',NULL FROM permissions WHERE permission_key IN ('content.read','preview.use','config.providers.manage','config.global.manage','audit.read');
INSERT INTO role_permissions(role_id,permission_id,granted_at,granted_by_actor_id)
SELECT 'role_cms_identity_admin',permission_id,'2026-09-30T00:00:00Z',NULL FROM permissions WHERE permission_key IN ('identity.read','identity.invite','identity.deprovision','roles.assign','sessions.revoke','audit.read');
INSERT INTO role_permissions(role_id,permission_id,granted_at,granted_by_actor_id)
SELECT 'role_cms_security_auditor',permission_id,'2026-09-30T00:00:00Z',NULL FROM permissions WHERE permission_key IN ('identity.read','audit.read');

-- Analytics bundles are additive and are not granted to existing ordinary roles.
INSERT INTO role_permissions(role_id,permission_id,granted_at,granted_by_actor_id)
SELECT 'role_cms_analytics_viewer',permission_id,'2026-09-30T00:00:00Z',NULL FROM permissions WHERE permission_key='analytics.read.aggregate';
INSERT INTO role_permissions(role_id,permission_id,granted_at,granted_by_actor_id)
SELECT 'role_cms_analytics_analyst',permission_id,'2026-09-30T00:00:00Z',NULL FROM permissions WHERE permission_key IN ('analytics.read.aggregate','analytics.read.raw','analytics.export');
INSERT INTO role_permissions(role_id,permission_id,granted_at,granted_by_actor_id)
SELECT 'role_cms_analytics_admin',permission_id,'2026-09-30T00:00:00Z',NULL FROM permissions WHERE permission_key IN ('analytics.read.aggregate','analytics.read.raw','analytics.export','analytics.config.manage');

-- Root receives every currently ACTIVE Phase 1 permission, including analytics additions and exact overlapping legacy IDs.
INSERT INTO role_permissions(role_id,permission_id,granted_at,granted_by_actor_id)
SELECT 'role_cms_root_admin',permission_id,'2026-09-30T00:00:00Z',NULL FROM permissions WHERE authorization_state='ACTIVE';

INSERT INTO retention_categories(retention_category_id,category_key,description,policy_gate_state) VALUES
('ret_analytics_raw_events','analytics.raw_events','Raw first-party analytics events','OPEN'),
('ret_analytics_session_pseudonyms','analytics.session_pseudonyms','Pseudonymous analytics session/visitor state','OPEN'),
('ret_analytics_consent_receipts','analytics.consent_receipts','Analytics consent receipts when policy requires them','OPEN'),
('ret_analytics_aggregate_rollups','analytics.aggregate_rollups','Privacy-approved aggregate analytics rollups','OPEN'),
('ret_analytics_export_artifacts','analytics.export_artifacts','Temporary analytics export artifacts when implemented','OPEN'),
('ret_analytics_ingest_security','analytics.ingest_security','Aggregated analytics ingestion security metadata','OPEN'),
('ret_media_import_jobs','media.import_jobs','Media import/provider operational records','OPEN');

INSERT OR REPLACE INTO schema_contract_meta(meta_key,meta_value,updated_at) VALUES
('contract.task','P1-DATA-02','2026-09-30T00:00:00Z'),
('contract.auth','P1-AUTH-01','2026-09-30T00:00:00Z'),
('contract.extension','P1-EXT-01','2026-09-30T00:00:00Z'),
('core.migration.lineage','0001-0014; 0001-0011 immutable','2026-09-30T00:00:00Z');
