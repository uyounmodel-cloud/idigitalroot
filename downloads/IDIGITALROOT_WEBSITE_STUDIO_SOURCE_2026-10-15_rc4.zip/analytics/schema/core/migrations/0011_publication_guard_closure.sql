-- P1-DATA-01R1 / 0011
-- Publication guard closure. Replaces only publication-pointer validation triggers so
-- INSERT and UPDATE enforce the same release-critical publication prerequisites.

DROP TRIGGER IF EXISTS trg_publication_pointer_validate_insert;
DROP TRIGGER IF EXISTS trg_publication_pointer_validate_update;

CREATE TRIGGER trg_publication_pointer_validate_insert
BEFORE INSERT ON publication_pointers
BEGIN
  SELECT CASE WHEN NEW.is_published=1 AND NOT EXISTS (
    SELECT 1 FROM content_revisions r
    WHERE r.revision_id=NEW.revision_id
      AND r.entity_id=NEW.entity_id
      AND r.locale_code=NEW.locale_code
      AND r.workflow_state='READY'
      AND r.validation_state='VALID'
  ) THEN RAISE(ABORT, 'publication requires exact READY + VALID revision') END;

  SELECT CASE WHEN NEW.is_published=1 AND NOT EXISTS (
    SELECT 1 FROM content_locale_state s
    WHERE s.entity_id=NEW.entity_id
      AND s.locale_code=NEW.locale_code
      AND s.translation_state IN ('READY','PUBLISHED')
  ) THEN RAISE(ABORT, 'publication requires READY/PUBLISHED locale state') END;

  SELECT CASE WHEN NEW.is_published=1 AND NOT EXISTS (
    SELECT 1 FROM publication_events e
    WHERE e.publication_event_id=NEW.publication_event_id
      AND e.entity_id=NEW.entity_id
      AND e.locale_code=NEW.locale_code
      AND e.revision_id=NEW.revision_id
      AND e.action IN ('PUBLISH','ROLLBACK')
  ) THEN RAISE(ABORT, 'publication pointer/event mismatch') END;

  SELECT CASE WHEN NEW.is_published=0 AND NOT EXISTS (
    SELECT 1 FROM publication_events e
    WHERE e.publication_event_id=NEW.publication_event_id
      AND e.entity_id=NEW.entity_id
      AND e.locale_code=NEW.locale_code
      AND e.action='UNPUBLISH'
      AND e.revision_id IS NULL
  ) THEN RAISE(ABORT, 'unpublish pointer/event mismatch') END;

  SELECT CASE WHEN NEW.is_published=1 AND EXISTS (
    SELECT 1
    FROM revision_media_refs rm
    JOIN media_assets m ON m.media_id=rm.media_id
    WHERE rm.content_revision_id=NEW.revision_id
      AND rm.required=1
      AND m.approval_state <> 'APPROVED'
  ) THEN RAISE(ABORT, 'required media is not approved') END;

  SELECT CASE WHEN NEW.is_published=1 AND EXISTS (
    SELECT 1
    FROM revision_media_refs rm
    JOIN media_assets m ON m.media_id=rm.media_id
    WHERE rm.content_revision_id=NEW.revision_id
      AND rm.required=1
      AND m.source_class='LOCAL_UPLOAD'
      AND NOT EXISTS (
        SELECT 1 FROM media_objects mo
        WHERE mo.media_id=m.media_id AND mo.object_state='APPROVED_PUBLIC'
      )
  ) THEN RAISE(ABORT, 'required local media has no approved public object') END;

  SELECT CASE WHEN NEW.is_published=1 AND EXISTS (
    SELECT 1
    FROM revision_media_refs rm
    JOIN media_assets m ON m.media_id=rm.media_id
    WHERE rm.content_revision_id=NEW.revision_id
      AND rm.required=1
      AND m.source_class='EXTERNAL_EMBED'
      AND NOT EXISTS (
        SELECT 1
        FROM media_external_sources es
        JOIN embed_providers ep ON ep.provider_id=es.provider_id
        WHERE es.media_id=m.media_id
          AND ep.enabled=1
      )
  ) THEN RAISE(ABORT, 'required external media lacks valid enabled provider binding') END;
END;

CREATE TRIGGER trg_publication_pointer_validate_update
BEFORE UPDATE ON publication_pointers
BEGIN
  SELECT CASE WHEN NEW.is_published=1 AND NOT EXISTS (
    SELECT 1 FROM content_revisions r
    WHERE r.revision_id=NEW.revision_id
      AND r.entity_id=NEW.entity_id
      AND r.locale_code=NEW.locale_code
      AND r.workflow_state='READY'
      AND r.validation_state='VALID'
  ) THEN RAISE(ABORT, 'publication requires exact READY + VALID revision') END;

  SELECT CASE WHEN NEW.is_published=1 AND NOT EXISTS (
    SELECT 1 FROM content_locale_state s
    WHERE s.entity_id=NEW.entity_id
      AND s.locale_code=NEW.locale_code
      AND s.translation_state IN ('READY','PUBLISHED')
  ) THEN RAISE(ABORT, 'publication requires READY/PUBLISHED locale state') END;

  SELECT CASE WHEN NEW.is_published=1 AND NOT EXISTS (
    SELECT 1 FROM publication_events e
    WHERE e.publication_event_id=NEW.publication_event_id
      AND e.entity_id=NEW.entity_id
      AND e.locale_code=NEW.locale_code
      AND e.revision_id=NEW.revision_id
      AND e.action IN ('PUBLISH','ROLLBACK')
  ) THEN RAISE(ABORT, 'publication pointer/event mismatch') END;

  SELECT CASE WHEN NEW.is_published=0 AND NOT EXISTS (
    SELECT 1 FROM publication_events e
    WHERE e.publication_event_id=NEW.publication_event_id
      AND e.entity_id=NEW.entity_id
      AND e.locale_code=NEW.locale_code
      AND e.action='UNPUBLISH'
      AND e.revision_id IS NULL
  ) THEN RAISE(ABORT, 'unpublish pointer/event mismatch') END;

  SELECT CASE WHEN NEW.is_published=1 AND EXISTS (
    SELECT 1
    FROM revision_media_refs rm
    JOIN media_assets m ON m.media_id=rm.media_id
    WHERE rm.content_revision_id=NEW.revision_id
      AND rm.required=1
      AND m.approval_state <> 'APPROVED'
  ) THEN RAISE(ABORT, 'required media is not approved') END;

  SELECT CASE WHEN NEW.is_published=1 AND EXISTS (
    SELECT 1
    FROM revision_media_refs rm
    JOIN media_assets m ON m.media_id=rm.media_id
    WHERE rm.content_revision_id=NEW.revision_id
      AND rm.required=1
      AND m.source_class='LOCAL_UPLOAD'
      AND NOT EXISTS (
        SELECT 1 FROM media_objects mo
        WHERE mo.media_id=m.media_id AND mo.object_state='APPROVED_PUBLIC'
      )
  ) THEN RAISE(ABORT, 'required local media has no approved public object') END;

  SELECT CASE WHEN NEW.is_published=1 AND EXISTS (
    SELECT 1
    FROM revision_media_refs rm
    JOIN media_assets m ON m.media_id=rm.media_id
    WHERE rm.content_revision_id=NEW.revision_id
      AND rm.required=1
      AND m.source_class='EXTERNAL_EMBED'
      AND NOT EXISTS (
        SELECT 1
        FROM media_external_sources es
        JOIN embed_providers ep ON ep.provider_id=es.provider_id
        WHERE es.media_id=m.media_id
          AND ep.enabled=1
      )
  ) THEN RAISE(ABORT, 'required external media lacks valid enabled provider binding') END;
END;
