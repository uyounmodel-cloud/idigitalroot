-- P1-DATA-01 / 0003
-- Stable route and content identities. Mutable paths/slugs are separate from stable IDs.

CREATE TABLE routes (
  route_id TEXT PRIMARY KEY,
  route_key TEXT NOT NULL UNIQUE,
  route_kind TEXT NOT NULL CHECK (route_kind IN ('PRIMARY','SUPPORTING','COMPATIBILITY','SYSTEM')),
  code_owned INTEGER NOT NULL DEFAULT 1 CHECK (code_owned IN (0,1)),
  created_at TEXT NOT NULL CHECK (substr(created_at, -1) = 'Z'),
  archived_at TEXT NULL CHECK (archived_at IS NULL OR substr(archived_at, -1) = 'Z')
);

CREATE TABLE route_paths (
  route_path_id TEXT PRIMARY KEY,
  route_id TEXT NOT NULL REFERENCES routes(route_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  locale_code TEXT NOT NULL REFERENCES locales(locale_code) ON UPDATE CASCADE ON DELETE RESTRICT,
  path TEXT NOT NULL,
  is_canonical INTEGER NOT NULL DEFAULT 1 CHECK (is_canonical IN (0,1)),
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version >= 1),
  updated_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  updated_at TEXT NOT NULL CHECK (substr(updated_at, -1) = 'Z'),
  CHECK (substr(path,1,1) = '/'),
  UNIQUE(locale_code, path)
);

CREATE INDEX idx_route_paths_route_locale ON route_paths(route_id, locale_code, is_active);
CREATE UNIQUE INDEX uq_route_paths_one_active_canonical
  ON route_paths(route_id, locale_code)
  WHERE is_active=1 AND is_canonical=1;

CREATE TABLE content_entities (
  entity_id TEXT PRIMARY KEY,
  entity_type TEXT NOT NULL CHECK (entity_type IN (
    'PAGE','NAVIGATION','FOOTER','SERVICE','KNOWLEDGE_INDEX','KNOWLEDGE_ARTICLE',
    'LEGAL_DOCUMENT','PRODUCT_RECORD','INQUIRY_PUBLIC_COPY','GLOBAL_PUBLIC_COPY'
  )),
  stable_key TEXT NOT NULL UNIQUE,
  route_id TEXT NULL UNIQUE REFERENCES routes(route_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  created_at TEXT NOT NULL CHECK (substr(created_at, -1) = 'Z'),
  archived_at TEXT NULL CHECK (archived_at IS NULL OR substr(archived_at, -1) = 'Z')
);

CREATE TABLE navigation_sets (
  entity_id TEXT PRIMARY KEY REFERENCES content_entities(entity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  navigation_key TEXT NOT NULL UNIQUE
);

CREATE TABLE footer_sets (
  entity_id TEXT PRIMARY KEY REFERENCES content_entities(entity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  footer_key TEXT NOT NULL UNIQUE
);

CREATE TABLE service_records (
  entity_id TEXT PRIMARY KEY REFERENCES content_entities(entity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  service_key TEXT NOT NULL UNIQUE,
  availability_state TEXT NOT NULL DEFAULT 'DRAFT' CHECK (availability_state IN ('DRAFT','AVAILABLE','UNAVAILABLE','ARCHIVED'))
);

CREATE TABLE knowledge_records (
  entity_id TEXT PRIMARY KEY REFERENCES content_entities(entity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  knowledge_key TEXT NOT NULL UNIQUE,
  knowledge_kind TEXT NOT NULL CHECK (knowledge_kind IN ('INSIGHT','GUIDE','DIGITAL_FUTURE','RESEARCH','STORY','NEWS','OTHER'))
);

CREATE TABLE legal_documents (
  entity_id TEXT PRIMARY KEY REFERENCES content_entities(entity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  legal_code TEXT NOT NULL UNIQUE CHECK (legal_code IN ('TERMS','PRIVACY','COOKIES')),
  approval_gate_state TEXT NOT NULL DEFAULT 'OPEN' CHECK (approval_gate_state IN ('OPEN','APPROVED','RETIRED'))
);
