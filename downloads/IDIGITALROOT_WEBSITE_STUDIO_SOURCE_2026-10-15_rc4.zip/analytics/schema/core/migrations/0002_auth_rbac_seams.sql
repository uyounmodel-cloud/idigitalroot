-- P1-DATA-01 / 0002
-- Provider-agnostic CMS actor, principal, role, permission and session persistence seams.

CREATE TABLE actors (
  actor_id TEXT PRIMARY KEY,
  actor_type TEXT NOT NULL CHECK (actor_type IN ('HUMAN','SERVICE','SYSTEM')),
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','DISABLED','ARCHIVED')),
  display_name TEXT NULL,
  primary_email_normalized TEXT NULL,
  created_at TEXT NOT NULL CHECK (substr(created_at, -1) = 'Z'),
  archived_at TEXT NULL CHECK (archived_at IS NULL OR substr(archived_at, -1) = 'Z')
);

CREATE UNIQUE INDEX uq_actors_primary_email_active
  ON actors(primary_email_normalized)
  WHERE primary_email_normalized IS NOT NULL AND archived_at IS NULL;

CREATE TABLE auth_principals (
  principal_id TEXT PRIMARY KEY,
  actor_id TEXT NOT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  provider_namespace TEXT NOT NULL,
  external_subject TEXT NOT NULL,
  assurance_level TEXT NULL,
  created_at TEXT NOT NULL CHECK (substr(created_at, -1) = 'Z'),
  last_seen_at TEXT NULL CHECK (last_seen_at IS NULL OR substr(last_seen_at, -1) = 'Z'),
  UNIQUE(provider_namespace, external_subject)
);

CREATE TABLE roles (
  role_id TEXT PRIMARY KEY,
  role_key TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  description TEXT NULL,
  system_managed INTEGER NOT NULL DEFAULT 0 CHECK (system_managed IN (0,1)),
  archived_at TEXT NULL CHECK (archived_at IS NULL OR substr(archived_at, -1) = 'Z')
);

CREATE TABLE permissions (
  permission_id TEXT PRIMARY KEY,
  permission_key TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL,
  resource_family TEXT NOT NULL
);

CREATE TABLE role_permissions (
  role_id TEXT NOT NULL REFERENCES roles(role_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  permission_id TEXT NOT NULL REFERENCES permissions(permission_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  granted_at TEXT NOT NULL CHECK (substr(granted_at, -1) = 'Z'),
  granted_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  PRIMARY KEY(role_id, permission_id)
);

CREATE TABLE actor_roles (
  actor_id TEXT NOT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  role_id TEXT NOT NULL REFERENCES roles(role_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  granted_at TEXT NOT NULL CHECK (substr(granted_at, -1) = 'Z'),
  granted_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  revoked_at TEXT NULL CHECK (revoked_at IS NULL OR substr(revoked_at, -1) = 'Z'),
  PRIMARY KEY(actor_id, role_id, granted_at)
);

CREATE TABLE cms_sessions (
  session_id TEXT PRIMARY KEY,
  actor_id TEXT NOT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  provider_namespace TEXT NOT NULL,
  provider_session_reference_hash TEXT NULL,
  state TEXT NOT NULL CHECK (state IN ('ACTIVE','REVOKED','EXPIRED')),
  mfa_level TEXT NULL,
  issued_at TEXT NOT NULL CHECK (substr(issued_at, -1) = 'Z'),
  last_seen_at TEXT NOT NULL CHECK (substr(last_seen_at, -1) = 'Z'),
  inactivity_expires_at TEXT NULL CHECK (inactivity_expires_at IS NULL OR substr(inactivity_expires_at, -1) = 'Z'),
  absolute_expires_at TEXT NULL CHECK (absolute_expires_at IS NULL OR substr(absolute_expires_at, -1) = 'Z'),
  revoked_at TEXT NULL CHECK (revoked_at IS NULL OR substr(revoked_at, -1) = 'Z'),
  revocation_reason TEXT NULL,
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version >= 1)
);

CREATE INDEX idx_auth_principals_actor ON auth_principals(actor_id);
CREATE INDEX idx_actor_roles_actor_active ON actor_roles(actor_id, revoked_at);
CREATE INDEX idx_cms_sessions_actor_state ON cms_sessions(actor_id, state);
