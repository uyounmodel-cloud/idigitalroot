-- P1-DATA-01 / 0001
-- Core registry, locale, component registry, non-secret config, retention categories.

CREATE TABLE schema_contract_meta (
  meta_key TEXT PRIMARY KEY,
  meta_value TEXT NOT NULL,
  updated_at TEXT NOT NULL CHECK (substr(updated_at, -1) = 'Z')
);

CREATE TABLE locales (
  locale_code TEXT PRIMARY KEY,
  display_name TEXT NOT NULL,
  native_name TEXT NOT NULL,
  direction TEXT NOT NULL CHECK (direction IN ('ltr','rtl')),
  fallback_locale_code TEXT NULL REFERENCES locales(locale_code) ON UPDATE CASCADE ON DELETE RESTRICT,
  public_enabled INTEGER NOT NULL DEFAULT 0 CHECK (public_enabled IN (0,1)),
  cms_enabled INTEGER NOT NULL DEFAULT 1 CHECK (cms_enabled IN (0,1)),
  inquiry_enabled INTEGER NOT NULL DEFAULT 0 CHECK (inquiry_enabled IN (0,1)),
  publication_eligible INTEGER NOT NULL DEFAULT 0 CHECK (publication_eligible IN (0,1)),
  formatting_json TEXT NOT NULL DEFAULT '{}',
  archived_at TEXT NULL CHECK (archived_at IS NULL OR substr(archived_at, -1) = 'Z')
);

CREATE TABLE component_families (
  component_family_id TEXT PRIMARY KEY,
  component_key TEXT NOT NULL UNIQUE,
  family_type TEXT NOT NULL CHECK (family_type IN ('SECTION','BLOCK')),
  registry_version TEXT NOT NULL,
  schema_version INTEGER NOT NULL DEFAULT 1 CHECK (schema_version >= 1),
  max_instances_per_page INTEGER NULL CHECK (max_instances_per_page IS NULL OR max_instances_per_page >= 1),
  reorderable INTEGER NOT NULL DEFAULT 1 CHECK (reorderable IN (0,1)),
  optional INTEGER NOT NULL DEFAULT 1 CHECK (optional IN (0,1)),
  code_registered INTEGER NOT NULL DEFAULT 1 CHECK (code_registered IN (0,1)),
  allowed_variants_json TEXT NOT NULL DEFAULT '[]'
);

CREATE TABLE non_secret_runtime_config (
  config_key TEXT PRIMARY KEY,
  value_json TEXT NOT NULL,
  value_type TEXT NOT NULL CHECK (value_type IN ('STRING','NUMBER','BOOLEAN','JSON')),
  visibility TEXT NOT NULL DEFAULT 'SERVER_ONLY' CHECK (visibility IN ('SERVER_ONLY','PUBLIC_SAFE')),
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version >= 1),
  updated_by_actor_id TEXT NULL,
  updated_at TEXT NOT NULL CHECK (substr(updated_at, -1) = 'Z'),
  CHECK (length(config_key) BETWEEN 1 AND 160),
  CHECK (length(value_json) <= 65536)
);

CREATE TABLE retention_categories (
  retention_category_id TEXT PRIMARY KEY,
  category_key TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL,
  policy_gate_state TEXT NOT NULL DEFAULT 'OPEN' CHECK (policy_gate_state IN ('OPEN','APPROVED','RETIRED'))
);
