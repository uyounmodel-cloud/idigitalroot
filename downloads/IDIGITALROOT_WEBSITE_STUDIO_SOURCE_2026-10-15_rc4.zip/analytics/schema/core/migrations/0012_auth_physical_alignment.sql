-- P1-DATA-02 / Core 0012
-- Forward-only P1-AUTH physical alignment. Migrations 0001-0011 remain byte-identical.
-- Existing auth seam rows are preserved; newer security authority lives in the additive tables/columns below.

-- Actor activation/deactivation lifecycle authority.
CREATE TABLE actor_security_state (
  actor_id TEXT PRIMARY KEY REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  activation_state TEXT NOT NULL CHECK (activation_state IN ('pending_activation','active','disabled')),
  reauth_after TEXT NULL CHECK (reauth_after IS NULL OR substr(reauth_after,-1)='Z'),
  disabled_at TEXT NULL CHECK (disabled_at IS NULL OR substr(disabled_at,-1)='Z'),
  disabled_reason TEXT NULL,
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version >= 1),
  updated_at TEXT NOT NULL CHECK (substr(updated_at,-1)='Z'),
  CHECK ((activation_state='disabled' AND disabled_at IS NOT NULL) OR activation_state<>'disabled')
);

INSERT INTO actor_security_state(actor_id,activation_state,disabled_at,row_version,updated_at)
SELECT actor_id,
       CASE WHEN status='ACTIVE' THEN 'active' ELSE 'disabled' END,
       CASE WHEN status='ACTIVE' THEN NULL ELSE COALESCE(archived_at,created_at) END,
       1,
       created_at
FROM actors;

CREATE TRIGGER trg_actor_security_state_no_delete
BEFORE DELETE ON actor_security_state
BEGIN
  SELECT RAISE(ABORT,'actor security state is historical authority and cannot be deleted');
END;

-- Exact external identity lineage. Legacy auth_principals remain preserved and are copied only as REVOKED unresolved lineage.
CREATE TABLE cms_external_identities (
  identity_id TEXT PRIMARY KEY,
  actor_id TEXT NOT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  provider_key TEXT NOT NULL,
  issuer TEXT NOT NULL,
  subject TEXT NOT NULL,
  observed_email_normalized TEXT NULL,
  identity_state TEXT NOT NULL CHECK (identity_state IN ('PENDING','ACTIVE','REVOKED')),
  bound_at TEXT NOT NULL CHECK (substr(bound_at,-1)='Z'),
  revoked_at TEXT NULL CHECK (revoked_at IS NULL OR substr(revoked_at,-1)='Z'),
  replaced_by_identity_id TEXT NULL REFERENCES cms_external_identities(identity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  legacy_principal_id TEXT NULL UNIQUE REFERENCES auth_principals(principal_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version >= 1),
  CHECK (replaced_by_identity_id IS NULL OR replaced_by_identity_id <> identity_id),
  CHECK ((identity_state='REVOKED' AND revoked_at IS NOT NULL) OR identity_state<>'REVOKED')
);

CREATE UNIQUE INDEX uq_cms_external_identity_active_principal
  ON cms_external_identities(provider_key,issuer,subject)
  WHERE identity_state='ACTIVE';
CREATE INDEX idx_cms_external_identity_actor_state
  ON cms_external_identities(actor_id,identity_state);

INSERT INTO cms_external_identities(
  identity_id,actor_id,provider_key,issuer,subject,identity_state,bound_at,revoked_at,legacy_principal_id,row_version
)
SELECT principal_id,actor_id,provider_namespace,'legacy-unresolved:'||provider_namespace,external_subject,
       'REVOKED',created_at,COALESCE(last_seen_at,created_at),principal_id,1
FROM auth_principals;

CREATE TRIGGER trg_cms_external_identity_no_unrevoke_legacy
BEFORE UPDATE OF identity_state ON cms_external_identities
WHEN OLD.legacy_principal_id IS NOT NULL AND NEW.identity_state <> 'REVOKED'
BEGIN
  SELECT RAISE(ABORT,'legacy unresolved identity cannot become active; explicit rebind required');
END;

-- 72-hour, single-use invitation lineage.
CREATE TABLE cms_invitations (
  invitation_id TEXT PRIMARY KEY,
  actor_id TEXT NOT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  invited_email_normalized TEXT NOT NULL,
  created_by_actor_id TEXT NOT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  invitation_state TEXT NOT NULL CHECK (invitation_state IN ('PENDING','CONSUMED','REVOKED','EXPIRED')),
  created_at TEXT NOT NULL CHECK (substr(created_at,-1)='Z'),
  expires_at TEXT NOT NULL CHECK (substr(expires_at,-1)='Z'),
  consumed_at TEXT NULL CHECK (consumed_at IS NULL OR substr(consumed_at,-1)='Z'),
  consumed_identity_id TEXT NULL REFERENCES cms_external_identities(identity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  revoked_at TEXT NULL CHECK (revoked_at IS NULL OR substr(revoked_at,-1)='Z'),
  revoked_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version >= 1),
  CHECK (length(invited_email_normalized) BETWEEN 3 AND 320),
  CHECK (abs((julianday(expires_at)-julianday(created_at))-3.0) < 0.000001),
  CHECK (
    (invitation_state='PENDING' AND consumed_at IS NULL AND consumed_identity_id IS NULL AND revoked_at IS NULL) OR
    (invitation_state='CONSUMED' AND consumed_at IS NOT NULL AND consumed_identity_id IS NOT NULL AND revoked_at IS NULL) OR
    (invitation_state='REVOKED' AND consumed_at IS NULL AND consumed_identity_id IS NULL AND revoked_at IS NOT NULL) OR
    (invitation_state='EXPIRED' AND consumed_at IS NULL AND consumed_identity_id IS NULL AND revoked_at IS NULL)
  )
);
CREATE INDEX idx_cms_invitations_email_state ON cms_invitations(invited_email_normalized,invitation_state,expires_at);
CREATE INDEX idx_cms_invitations_actor_state ON cms_invitations(actor_id,invitation_state);

CREATE TRIGGER trg_cms_invitation_terminal_state
BEFORE UPDATE ON cms_invitations
WHEN OLD.invitation_state IN ('CONSUMED','REVOKED','EXPIRED') AND (
  NEW.invitation_state<>OLD.invitation_state OR NEW.actor_id<>OLD.actor_id OR NEW.invited_email_normalized<>OLD.invited_email_normalized
)
BEGIN
  SELECT RAISE(ABORT,'terminal invitation cannot be reused or rebound');
END;

-- Scope representation is attached to the immutable actor_roles grant identity.
CREATE TABLE actor_role_scopes (
  actor_id TEXT NOT NULL,
  role_id TEXT NOT NULL,
  granted_at TEXT NOT NULL,
  scope_kind TEXT NOT NULL CHECK (scope_kind IN ('global','locale','content')),
  locale_code TEXT NULL REFERENCES locales(locale_code) ON UPDATE CASCADE ON DELETE RESTRICT,
  content_entity_id TEXT NULL REFERENCES content_entities(entity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  PRIMARY KEY(actor_id,role_id,granted_at),
  FOREIGN KEY(actor_id,role_id,granted_at)
    REFERENCES actor_roles(actor_id,role_id,granted_at) ON UPDATE CASCADE ON DELETE RESTRICT,
  CHECK (
    (scope_kind='global' AND locale_code IS NULL AND content_entity_id IS NULL) OR
    (scope_kind='locale' AND locale_code IS NOT NULL AND content_entity_id IS NULL) OR
    (scope_kind='content' AND locale_code IS NULL AND content_entity_id IS NOT NULL)
  )
);

INSERT INTO actor_role_scopes(actor_id,role_id,granted_at,scope_kind)
SELECT actor_id,role_id,granted_at,'global' FROM actor_roles;

CREATE TRIGGER trg_actor_role_scope_global_only_insert
BEFORE INSERT ON actor_role_scopes
WHEN NEW.scope_kind <> 'global' AND EXISTS (
  SELECT 1
  FROM roles r
  LEFT JOIN role_permissions rp ON rp.role_id=r.role_id
  LEFT JOIN permissions p ON p.permission_id=rp.permission_id
  WHERE r.role_id=NEW.role_id
    AND (r.role_key='CMS_ROOT_ADMIN' OR p.permission_key IN (
      'identity.read','identity.invite','identity.deprovision','roles.assign','sessions.revoke','security.recovery'
    ))
)
BEGIN
  SELECT RAISE(ABORT,'identity/security/root grants are global-only');
END;

CREATE TRIGGER trg_actor_role_scope_global_only_update
BEFORE UPDATE ON actor_role_scopes
WHEN NEW.scope_kind <> 'global' AND EXISTS (
  SELECT 1
  FROM roles r
  LEFT JOIN role_permissions rp ON rp.role_id=r.role_id
  LEFT JOIN permissions p ON p.permission_id=rp.permission_id
  WHERE r.role_id=NEW.role_id
    AND (r.role_key='CMS_ROOT_ADMIN' OR p.permission_key IN (
      'identity.read','identity.invite','identity.deprovision','roles.assign','sessions.revoke','security.recovery'
    ))
)
BEGIN
  SELECT RAISE(ABORT,'identity/security/root grants are global-only');
END;

-- Secure local-session material. Raw tokens never have a column.
CREATE TABLE cms_session_security (
  session_id TEXT PRIMARY KEY REFERENCES cms_sessions(session_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  external_identity_id TEXT NOT NULL REFERENCES cms_external_identities(identity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  session_token_sha256 TEXT NOT NULL UNIQUE CHECK (length(session_token_sha256)=64),
  csrf_token_sha256 TEXT NOT NULL CHECK (length(csrf_token_sha256)=64),
  upstream_access_expires_at TEXT NOT NULL CHECK (substr(upstream_access_expires_at,-1)='Z'),
  fresh_auth_at TEXT NULL CHECK (fresh_auth_at IS NULL OR substr(fresh_auth_at,-1)='Z'),
  reauth_required_at TEXT NULL CHECK (reauth_required_at IS NULL OR substr(reauth_required_at,-1)='Z'),
  rotated_from_session_id TEXT NULL REFERENCES cms_sessions(session_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  rotation_counter INTEGER NOT NULL DEFAULT 0 CHECK (rotation_counter >= 0),
  created_at TEXT NOT NULL CHECK (substr(created_at,-1)='Z'),
  CHECK (rotated_from_session_id IS NULL OR rotated_from_session_id<>session_id)
);
CREATE INDEX idx_cms_session_security_identity ON cms_session_security(external_identity_id);

-- Richer application-audit context required by P1-AUTH. Nullable for preserved historical rows.
ALTER TABLE audit_events ADD COLUMN external_identity_id TEXT NULL;
ALTER TABLE audit_events ADD COLUMN session_id TEXT NULL;
ALTER TABLE audit_events ADD COLUMN request_id TEXT NULL;
ALTER TABLE audit_events ADD COLUMN ray_or_correlation_id TEXT NULL;
ALTER TABLE audit_events ADD COLUMN permission_key TEXT NULL;
ALTER TABLE audit_events ADD COLUMN reason_code TEXT NULL;
ALTER TABLE audit_events ADD COLUMN before_reference_json TEXT NULL;
ALTER TABLE audit_events ADD COLUMN after_reference_json TEXT NULL;

-- Permission rows gain explicit authorization lifecycle and risk without rewriting existing IDs.
ALTER TABLE permissions ADD COLUMN authorization_state TEXT NOT NULL DEFAULT 'ACTIVE'
  CHECK (authorization_state IN ('ACTIVE','RETIRED'));
ALTER TABLE permissions ADD COLUMN risk_class TEXT NULL
  CHECK (risk_class IS NULL OR risk_class IN ('normal','normal/sensitive','privileged','privileged-read','privileged-read/high','Tier A'));

-- Retire only obsolete legacy authorization keys. Historical rows and grants remain intact as non-authoritative lineage.
UPDATE permissions SET authorization_state='RETIRED' WHERE permission_key IN (
  'content.read_drafts','preview.issue','publish.execute','schedule.manage','rollback.execute',
  'providers.manage','identities.manage','locales.manage'
);
