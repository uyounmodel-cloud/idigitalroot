-- P1-DATA-02 / Core 0013
-- Advanced CMS hierarchy/taxonomy/media provenance and restricted Lead<->Analytics outbox seam.

CREATE TABLE page_hierarchy (
  page_entity_id TEXT PRIMARY KEY REFERENCES content_entities(entity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  parent_page_entity_id TEXT NULL REFERENCES content_entities(entity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  sibling_ordinal INTEGER NOT NULL CHECK (sibling_ordinal >= 1),
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version >= 1),
  updated_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  updated_at TEXT NOT NULL CHECK (substr(updated_at,-1)='Z'),
  CHECK (page_entity_id <> parent_page_entity_id)
);
CREATE UNIQUE INDEX uq_page_hierarchy_sibling_order
  ON page_hierarchy(ifnull(parent_page_entity_id,'__ROOT__'),sibling_ordinal);
CREATE INDEX idx_page_hierarchy_parent ON page_hierarchy(parent_page_entity_id,sibling_ordinal);

CREATE TRIGGER trg_page_hierarchy_validate_insert
BEFORE INSERT ON page_hierarchy
BEGIN
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM content_entities e WHERE e.entity_id=NEW.page_entity_id AND e.entity_type='PAGE' AND e.archived_at IS NULL
  ) THEN RAISE(ABORT,'page hierarchy child must be an active PAGE') END;
  SELECT CASE WHEN NEW.parent_page_entity_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM content_entities e WHERE e.entity_id=NEW.parent_page_entity_id AND e.entity_type='PAGE' AND e.archived_at IS NULL
  ) THEN RAISE(ABORT,'page hierarchy parent must be an active PAGE') END;
  SELECT CASE WHEN NEW.parent_page_entity_id IS NOT NULL AND EXISTS (
    WITH RECURSIVE ancestors(id) AS (
      SELECT NEW.parent_page_entity_id
      UNION ALL
      SELECT ph.parent_page_entity_id FROM page_hierarchy ph JOIN ancestors a ON ph.page_entity_id=a.id
      WHERE ph.parent_page_entity_id IS NOT NULL
    ) SELECT 1 FROM ancestors WHERE id=NEW.page_entity_id
  ) THEN RAISE(ABORT,'page hierarchy cycle') END;
END;

CREATE TRIGGER trg_page_hierarchy_validate_update
BEFORE UPDATE ON page_hierarchy
BEGIN
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM content_entities e WHERE e.entity_id=NEW.page_entity_id AND e.entity_type='PAGE' AND e.archived_at IS NULL
  ) THEN RAISE(ABORT,'page hierarchy child must be an active PAGE') END;
  SELECT CASE WHEN NEW.parent_page_entity_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM content_entities e WHERE e.entity_id=NEW.parent_page_entity_id AND e.entity_type='PAGE' AND e.archived_at IS NULL
  ) THEN RAISE(ABORT,'page hierarchy parent must be an active PAGE') END;
  SELECT CASE WHEN NEW.parent_page_entity_id IS NOT NULL AND EXISTS (
    WITH RECURSIVE ancestors(id) AS (
      SELECT NEW.parent_page_entity_id
      UNION ALL
      SELECT ph.parent_page_entity_id FROM page_hierarchy ph JOIN ancestors a ON ph.page_entity_id=a.id
      WHERE ph.parent_page_entity_id IS NOT NULL
    ) SELECT 1 FROM ancestors WHERE id=NEW.page_entity_id
  ) THEN RAISE(ABORT,'page hierarchy cycle') END;
END;

CREATE TABLE taxonomy_vocabularies (
  vocabulary_id TEXT PRIMARY KEY,
  vocabulary_key TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  hierarchical INTEGER NOT NULL CHECK (hierarchical IN (0,1)),
  enabled INTEGER NOT NULL CHECK (enabled IN (0,1)),
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version >= 1),
  created_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  created_at TEXT NOT NULL CHECK (substr(created_at,-1)='Z'),
  updated_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  updated_at TEXT NOT NULL CHECK (substr(updated_at,-1)='Z'),
  archived_at TEXT NULL CHECK (archived_at IS NULL OR substr(archived_at,-1)='Z')
);

CREATE TABLE taxonomy_terms (
  term_id TEXT PRIMARY KEY,
  vocabulary_id TEXT NOT NULL REFERENCES taxonomy_vocabularies(vocabulary_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  stable_key TEXT NOT NULL,
  parent_term_id TEXT NULL REFERENCES taxonomy_terms(term_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  sibling_ordinal INTEGER NOT NULL CHECK (sibling_ordinal >= 1),
  state TEXT NOT NULL CHECK (state IN ('ACTIVE','ARCHIVED')),
  created_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  created_at TEXT NOT NULL CHECK (substr(created_at,-1)='Z'),
  updated_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  updated_at TEXT NOT NULL CHECK (substr(updated_at,-1)='Z'),
  UNIQUE(vocabulary_id,stable_key),
  UNIQUE(term_id,vocabulary_id),
  CHECK (parent_term_id IS NULL OR parent_term_id<>term_id)
);
CREATE UNIQUE INDEX uq_taxonomy_term_sibling_order
  ON taxonomy_terms(vocabulary_id,ifnull(parent_term_id,'__ROOT__'),sibling_ordinal);
CREATE INDEX idx_taxonomy_terms_parent ON taxonomy_terms(vocabulary_id,parent_term_id,sibling_ordinal);

CREATE TRIGGER trg_taxonomy_term_validate_insert
BEFORE INSERT ON taxonomy_terms
BEGIN
  SELECT CASE WHEN NEW.parent_term_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM taxonomy_terms p
    WHERE p.term_id=NEW.parent_term_id AND p.vocabulary_id=NEW.vocabulary_id AND p.state='ACTIVE'
  ) THEN RAISE(ABORT,'taxonomy parent must be active and in same vocabulary') END;
END;
CREATE TRIGGER trg_taxonomy_term_validate_update
BEFORE UPDATE ON taxonomy_terms
BEGIN
  SELECT CASE WHEN NEW.parent_term_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM taxonomy_terms p
    WHERE p.term_id=NEW.parent_term_id AND p.vocabulary_id=NEW.vocabulary_id AND p.state='ACTIVE'
  ) THEN RAISE(ABORT,'taxonomy parent must be active and in same vocabulary') END;
  SELECT CASE WHEN NEW.parent_term_id IS NOT NULL AND EXISTS (
    WITH RECURSIVE ancestors(id) AS (
      SELECT NEW.parent_term_id
      UNION ALL
      SELECT t.parent_term_id FROM taxonomy_terms t JOIN ancestors a ON t.term_id=a.id
      WHERE t.parent_term_id IS NOT NULL
    ) SELECT 1 FROM ancestors WHERE id=NEW.term_id
  ) THEN RAISE(ABORT,'taxonomy cycle') END;
END;

CREATE TABLE taxonomy_term_localizations (
  term_id TEXT NOT NULL,
  vocabulary_id TEXT NOT NULL,
  locale_code TEXT NOT NULL REFERENCES locales(locale_code) ON UPDATE CASCADE ON DELETE RESTRICT,
  label TEXT NOT NULL,
  slug TEXT NULL,
  description TEXT NULL,
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version >= 1),
  updated_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  updated_at TEXT NOT NULL CHECK (substr(updated_at,-1)='Z'),
  PRIMARY KEY(term_id,locale_code),
  FOREIGN KEY(term_id,vocabulary_id) REFERENCES taxonomy_terms(term_id,vocabulary_id) ON UPDATE CASCADE ON DELETE RESTRICT
);
CREATE UNIQUE INDEX uq_taxonomy_localized_slug
  ON taxonomy_term_localizations(vocabulary_id,locale_code,slug)
  WHERE slug IS NOT NULL;

CREATE TABLE content_taxonomy_assignments (
  entity_id TEXT NOT NULL REFERENCES content_entities(entity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  term_id TEXT NOT NULL REFERENCES taxonomy_terms(term_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  ordinal INTEGER NOT NULL DEFAULT 1 CHECK (ordinal >= 1),
  assigned_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  assigned_at TEXT NOT NULL CHECK (substr(assigned_at,-1)='Z'),
  PRIMARY KEY(entity_id,term_id)
);
CREATE INDEX idx_content_taxonomy_by_term ON content_taxonomy_assignments(term_id,entity_id);
CREATE INDEX idx_content_taxonomy_by_entity ON content_taxonomy_assignments(entity_id,ordinal);
CREATE TRIGGER trg_content_taxonomy_active_term_insert
BEFORE INSERT ON content_taxonomy_assignments
WHEN NOT EXISTS (
  SELECT 1 FROM taxonomy_terms t JOIN taxonomy_vocabularies v ON v.vocabulary_id=t.vocabulary_id
  WHERE t.term_id=NEW.term_id AND t.state='ACTIVE' AND v.enabled=1 AND v.archived_at IS NULL
)
BEGIN
  SELECT RAISE(ABORT,'taxonomy assignment requires active term/vocabulary');
END;
CREATE TRIGGER trg_taxonomy_term_no_delete BEFORE DELETE ON taxonomy_terms BEGIN SELECT RAISE(ABORT,'archive taxonomy terms; do not delete'); END;
CREATE TRIGGER trg_taxonomy_vocabulary_no_delete BEFORE DELETE ON taxonomy_vocabularies BEGIN SELECT RAISE(ABORT,'archive taxonomy vocabularies; do not delete'); END;

CREATE TABLE media_import_providers (
  import_provider_id TEXT PRIMARY KEY,
  provider_key TEXT NOT NULL UNIQUE,
  adapter_key TEXT NOT NULL,
  adapter_version TEXT NOT NULL,
  mode TEXT NOT NULL CHECK (mode IN ('MANAGED_IMPORT','EXTERNAL_EMBED')),
  enabled INTEGER NOT NULL CHECK (enabled IN (0,1)),
  authorization_mode TEXT NOT NULL,
  non_secret_config_json TEXT NOT NULL DEFAULT '{}' CHECK (length(non_secret_config_json) <= 32768),
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version >= 1),
  updated_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  updated_at TEXT NOT NULL CHECK (substr(updated_at,-1)='Z')
);

CREATE TABLE media_import_jobs (
  import_job_id TEXT PRIMARY KEY,
  import_provider_id TEXT NOT NULL REFERENCES media_import_providers(import_provider_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  requested_by_actor_id TEXT NOT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  idempotency_record_id TEXT NULL REFERENCES idempotency_records(idempotency_record_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  provider_reference TEXT NOT NULL,
  state TEXT NOT NULL CHECK (state IN ('REQUESTED','FETCHING','VALIDATING','SUCCEEDED','FAILED','CANCELLED')),
  target_media_id TEXT NULL REFERENCES media_assets(media_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  safe_remote_metadata_json TEXT NOT NULL DEFAULT '{}' CHECK (length(safe_remote_metadata_json) <= 32768),
  error_code TEXT NULL,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL CHECK (substr(created_at,-1)='Z'),
  started_at TEXT NULL CHECK (started_at IS NULL OR substr(started_at,-1)='Z'),
  completed_at TEXT NULL CHECK (completed_at IS NULL OR substr(completed_at,-1)='Z'),
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version >= 1),
  CHECK (provider_reference NOT LIKE 'http://%' AND provider_reference NOT LIKE 'https://%')
);
CREATE INDEX idx_media_import_jobs_state_created ON media_import_jobs(state,created_at);
CREATE INDEX idx_media_import_jobs_actor_created ON media_import_jobs(requested_by_actor_id,created_at DESC);
CREATE INDEX idx_media_import_jobs_provider_created ON media_import_jobs(import_provider_id,created_at DESC);

CREATE TABLE media_asset_provenance (
  media_id TEXT PRIMARY KEY REFERENCES media_assets(media_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  origin_kind TEXT NOT NULL CHECK (origin_kind IN ('DIRECT_CMS_UPLOAD','PROVIDER_IMPORT')),
  import_provider_id TEXT NULL REFERENCES media_import_providers(import_provider_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  provider_reference TEXT NULL,
  source_filename TEXT NULL,
  source_declared_mime TEXT NULL,
  managed_sha256 TEXT NULL CHECK (managed_sha256 IS NULL OR length(managed_sha256)=64),
  validation_profile_key TEXT NOT NULL,
  validation_profile_version TEXT NOT NULL,
  imported_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  imported_at TEXT NULL CHECK (imported_at IS NULL OR substr(imported_at,-1)='Z'),
  provenance_json TEXT NOT NULL DEFAULT '{}' CHECK (length(provenance_json) <= 32768),
  CHECK (
    (origin_kind='DIRECT_CMS_UPLOAD' AND import_provider_id IS NULL AND provider_reference IS NULL) OR
    (origin_kind='PROVIDER_IMPORT' AND import_provider_id IS NOT NULL AND provider_reference IS NOT NULL AND provider_reference NOT LIKE 'http://%' AND provider_reference NOT LIKE 'https://%')
  )
);

CREATE TABLE lead_analytics_links (
  lead_id TEXT PRIMARY KEY REFERENCES leads(lead_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  analytics_session_id TEXT NULL,
  conversion_event_id TEXT NOT NULL UNIQUE,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL CHECK (substr(created_at,-1)='Z')
);

CREATE TABLE analytics_conversion_outbox (
  outbox_id TEXT PRIMARY KEY,
  lead_id TEXT NOT NULL REFERENCES leads(lead_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  conversion_event_id TEXT NOT NULL UNIQUE,
  analytics_session_id TEXT NULL,
  event_schema_version INTEGER NOT NULL CHECK (event_schema_version >= 1),
  sanitized_payload_json TEXT NOT NULL CHECK (length(sanitized_payload_json) <= 8192),
  state TEXT NOT NULL CHECK (state IN ('PENDING','SENT','FAILED')),
  attempt_count INTEGER NOT NULL DEFAULT 0 CHECK (attempt_count >= 0),
  next_attempt_at TEXT NULL CHECK (next_attempt_at IS NULL OR substr(next_attempt_at,-1)='Z'),
  last_error_code TEXT NULL,
  created_at TEXT NOT NULL CHECK (substr(created_at,-1)='Z'),
  sent_at TEXT NULL CHECK (sent_at IS NULL OR substr(sent_at,-1)='Z'),
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version >= 1),
  CHECK (lower(sanitized_payload_json) NOT LIKE '%"email"%'),
  CHECK (lower(sanitized_payload_json) NOT LIKE '%"name"%'),
  CHECK (lower(sanitized_payload_json) NOT LIKE '%"phone"%'),
  CHECK (lower(sanitized_payload_json) NOT LIKE '%"answer%')
);
CREATE INDEX idx_analytics_conversion_outbox_retry ON analytics_conversion_outbox(state,next_attempt_at);

CREATE TRIGGER trg_analytics_outbox_lead_link_match
BEFORE INSERT ON analytics_conversion_outbox
WHEN EXISTS (SELECT 1 FROM lead_analytics_links l WHERE l.lead_id=NEW.lead_id AND l.conversion_event_id<>NEW.conversion_event_id)
BEGIN
  SELECT RAISE(ABORT,'outbox conversion event must match lead analytics link');
END;
