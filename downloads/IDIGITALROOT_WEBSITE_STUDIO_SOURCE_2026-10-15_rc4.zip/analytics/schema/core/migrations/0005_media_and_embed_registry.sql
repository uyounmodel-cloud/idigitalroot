-- P1-DATA-01 / 0005
-- D1 stores media metadata/state; R2 object bytes are referenced only by opaque object keys.

CREATE TABLE embed_providers (
  provider_id TEXT PRIMARY KEY,
  provider_key TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 0 CHECK (enabled IN (0,1)),
  allowed_hosts_json TEXT NOT NULL DEFAULT '[]',
  url_patterns_json TEXT NOT NULL DEFAULT '[]',
  embed_mode TEXT NOT NULL CHECK (embed_mode IN ('IFRAME','OEMBED','LINK','PREVIEW')),
  iframe_attributes_json TEXT NOT NULL DEFAULT '{}',
  sandbox_policy TEXT NULL,
  referrer_policy TEXT NULL,
  autoplay_policy TEXT NULL,
  privacy_mode TEXT NULL,
  csp_requirements_json TEXT NOT NULL DEFAULT '{}',
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version >= 1),
  updated_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  updated_at TEXT NOT NULL CHECK (substr(updated_at, -1) = 'Z')
);

CREATE TABLE media_assets (
  media_id TEXT PRIMARY KEY,
  source_class TEXT NOT NULL CHECK (source_class IN ('LOCAL_UPLOAD','EXTERNAL_EMBED')),
  media_kind TEXT NOT NULL CHECK (media_kind IN ('IMAGE','DOCUMENT','VIDEO','AUDIO','EMBED','OTHER')),
  approval_state TEXT NOT NULL CHECK (approval_state IN ('UPLOADED_PRIVATE','VALIDATING','APPROVED','REJECTED','QUARANTINED','ARCHIVED')),
  original_filename TEXT NULL,
  declared_mime TEXT NULL,
  detected_mime TEXT NULL,
  size_bytes INTEGER NULL CHECK (size_bytes IS NULL OR size_bytes >= 0),
  width_px INTEGER NULL CHECK (width_px IS NULL OR width_px >= 0),
  height_px INTEGER NULL CHECK (height_px IS NULL OR height_px >= 0),
  duration_ms INTEGER NULL CHECK (duration_ms IS NULL OR duration_ms >= 0),
  checksum_sha256 TEXT NULL CHECK (checksum_sha256 IS NULL OR length(checksum_sha256) = 64),
  source_origin_class TEXT NULL,
  retention_category_id TEXT NULL REFERENCES retention_categories(retention_category_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  created_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  created_at TEXT NOT NULL CHECK (substr(created_at, -1) = 'Z'),
  archived_at TEXT NULL CHECK (archived_at IS NULL OR substr(archived_at, -1) = 'Z')
);

CREATE TABLE media_objects (
  media_object_id TEXT PRIMARY KEY,
  media_id TEXT NOT NULL REFERENCES media_assets(media_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  object_role TEXT NOT NULL CHECK (object_role IN ('ORIGINAL','DERIVATIVE','PREVIEW','THUMBNAIL')),
  r2_object_key TEXT NOT NULL UNIQUE,
  object_state TEXT NOT NULL CHECK (object_state IN ('PRIVATE','APPROVED_PUBLIC','DELETED')),
  checksum_sha256 TEXT NULL CHECK (checksum_sha256 IS NULL OR length(checksum_sha256) = 64),
  created_at TEXT NOT NULL CHECK (substr(created_at, -1) = 'Z')
);

CREATE TABLE media_external_sources (
  media_id TEXT PRIMARY KEY REFERENCES media_assets(media_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  provider_id TEXT NOT NULL REFERENCES embed_providers(provider_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  source_url TEXT NOT NULL,
  canonical_reference TEXT NULL,
  CHECK (source_url LIKE 'https://%' OR source_url LIKE 'http://%')
);

CREATE TABLE media_localized_revisions (
  media_localized_revision_id TEXT PRIMARY KEY,
  media_id TEXT NOT NULL REFERENCES media_assets(media_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  locale_code TEXT NOT NULL REFERENCES locales(locale_code) ON UPDATE CASCADE ON DELETE RESTRICT,
  revision_number INTEGER NOT NULL CHECK (revision_number >= 1),
  title TEXT NULL,
  alt_text TEXT NULL,
  caption TEXT NULL,
  credit TEXT NULL,
  license_reference TEXT NULL,
  created_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  created_at TEXT NOT NULL CHECK (substr(created_at, -1) = 'Z'),
  UNIQUE(media_id, locale_code, revision_number),
  UNIQUE(media_localized_revision_id, media_id),
  UNIQUE(media_localized_revision_id, media_id, locale_code)
);

CREATE TABLE revision_media_refs (
  content_revision_id TEXT NOT NULL REFERENCES content_revisions(revision_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  media_id TEXT NOT NULL REFERENCES media_assets(media_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  media_localized_revision_id TEXT NULL,
  usage_role TEXT NOT NULL,
  required INTEGER NOT NULL DEFAULT 1 CHECK (required IN (0,1)),
  PRIMARY KEY(content_revision_id, media_id, usage_role),
  FOREIGN KEY(media_localized_revision_id, media_id)
    REFERENCES media_localized_revisions(media_localized_revision_id, media_id)
    ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE INDEX idx_media_assets_state ON media_assets(approval_state, source_class);
CREATE INDEX idx_media_objects_media_state ON media_objects(media_id, object_state);
