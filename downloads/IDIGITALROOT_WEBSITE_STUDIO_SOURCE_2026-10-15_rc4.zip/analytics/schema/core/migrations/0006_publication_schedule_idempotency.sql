-- P1-DATA-01 / 0006
-- Publication events/pointers/schedules and generic duplicate-sensitive operation idempotency.

CREATE TABLE idempotency_records (
  idempotency_record_id TEXT PRIMARY KEY,
  operation_scope TEXT NOT NULL,
  context_hash TEXT NOT NULL CHECK (length(context_hash) = 64),
  idempotency_key_hash TEXT NOT NULL CHECK (length(idempotency_key_hash) = 64),
  request_hash TEXT NOT NULL CHECK (length(request_hash) = 64),
  state TEXT NOT NULL CHECK (state IN ('PROCESSING','SUCCEEDED','FAILED')),
  result_type TEXT NULL,
  result_id TEXT NULL,
  response_reference TEXT NULL,
  created_at TEXT NOT NULL CHECK (substr(created_at, -1) = 'Z'),
  completed_at TEXT NULL CHECK (completed_at IS NULL OR substr(completed_at, -1) = 'Z'),
  expires_at TEXT NULL CHECK (expires_at IS NULL OR substr(expires_at, -1) = 'Z'),
  UNIQUE(operation_scope, context_hash, idempotency_key_hash)
);

CREATE TABLE publication_events (
  publication_event_id TEXT PRIMARY KEY,
  entity_id TEXT NOT NULL REFERENCES content_entities(entity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  locale_code TEXT NOT NULL REFERENCES locales(locale_code) ON UPDATE CASCADE ON DELETE RESTRICT,
  action TEXT NOT NULL CHECK (action IN ('PUBLISH','ROLLBACK','UNPUBLISH')),
  revision_id TEXT NULL REFERENCES content_revisions(revision_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  prior_revision_id TEXT NULL REFERENCES content_revisions(revision_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  idempotency_record_id TEXT NULL REFERENCES idempotency_records(idempotency_record_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL CHECK (substr(created_at, -1) = 'Z')
);

CREATE TABLE publication_pointers (
  entity_id TEXT NOT NULL REFERENCES content_entities(entity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  locale_code TEXT NOT NULL REFERENCES locales(locale_code) ON UPDATE CASCADE ON DELETE RESTRICT,
  revision_id TEXT NULL,
  is_published INTEGER NOT NULL DEFAULT 1 CHECK (is_published IN (0,1)),
  publication_event_id TEXT NOT NULL UNIQUE REFERENCES publication_events(publication_event_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  pointer_version INTEGER NOT NULL DEFAULT 1 CHECK (pointer_version >= 1),
  published_at TEXT NOT NULL CHECK (substr(published_at, -1) = 'Z'),
  PRIMARY KEY(entity_id, locale_code),
  CHECK ((is_published=1 AND revision_id IS NOT NULL) OR (is_published=0 AND revision_id IS NULL)),
  FOREIGN KEY(revision_id, entity_id, locale_code)
    REFERENCES content_revisions(revision_id, entity_id, locale_code)
    ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE publication_schedules (
  schedule_id TEXT PRIMARY KEY,
  entity_id TEXT NOT NULL REFERENCES content_entities(entity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  locale_code TEXT NOT NULL REFERENCES locales(locale_code) ON UPDATE CASCADE ON DELETE RESTRICT,
  revision_id TEXT NOT NULL,
  scheduled_at_utc TEXT NOT NULL CHECK (substr(scheduled_at_utc, -1) = 'Z'),
  status TEXT NOT NULL CHECK (status IN ('SCHEDULED','CANCELLED','EXECUTING','SUCCEEDED','FAILED')),
  created_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  idempotency_record_id TEXT NULL REFERENCES idempotency_records(idempotency_record_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  created_at TEXT NOT NULL CHECK (substr(created_at, -1) = 'Z'),
  executed_at TEXT NULL CHECK (executed_at IS NULL OR substr(executed_at, -1) = 'Z'),
  execution_message TEXT NULL,
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version >= 1),
  FOREIGN KEY(revision_id, entity_id, locale_code)
    REFERENCES content_revisions(revision_id, entity_id, locale_code)
    ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE INDEX idx_publication_events_entity_locale ON publication_events(entity_id, locale_code, created_at DESC);
CREATE INDEX idx_publication_schedules_due ON publication_schedules(status, scheduled_at_utc);
