-- Synthetic first-party analytics fixture; contains no real PII.
INSERT INTO analytics_sessions(session_id,visitor_key_hash,started_at,last_event_at,consent_mode,privacy_policy_version,locale_code,landing_route_id,landing_entity_id,referrer_class,referrer_host,utm_source,utm_medium,utm_campaign,browser_class,os_class,device_class,language_class,viewport_class,country_code,continent_code,bot_class,first_event_id)
VALUES ('anasess_fixture_001','dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd','2026-09-30T00:20:00Z','2026-09-30T00:21:00Z','CONSENTED','policy-open-placeholder','en','rt_fixture_home_001','ent_fixture_home','direct',NULL,NULL,NULL,NULL,'CHROMIUM','WINDOWS','DESKTOP','en','LARGE','LB','ASI','HUMAN_LIKELY','evt_page_fixture_001');

INSERT INTO analytics_events(event_id,event_key,schema_version,occurred_at,received_at,session_id,visitor_key_hash,route_id,entity_id,revision_id,section_instance_id,component_key,locale_code,consent_mode,browser_class,os_class,device_class,language_class,viewport_class,country_code,continent_code,bot_class,properties_json,ingest_batch_id)
VALUES
('evt_page_fixture_001','page_view',1,'2026-09-30T00:20:00Z','2026-09-30T00:20:01Z','anasess_fixture_001','dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd','rt_fixture_home_001','ent_fixture_home','rev_fixture_home_en_1',NULL,NULL,'en','CONSENTED','CHROMIUM','WINDOWS','DESKTOP','en','LARGE','LB','ASI','HUMAN_LIKELY','{}','batch_fixture_001'),
('evt_conversion_fixture_001','inquiry_accepted',1,'2026-09-30T00:21:00Z','2026-09-30T00:21:01Z','anasess_fixture_001','dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd','rt_fixture_home_001','ent_fixture_home',NULL,NULL,NULL,'en','CONSENTED','CHROMIUM','WINDOWS','DESKTOP','en','LARGE','LB','ASI','HUMAN_LIKELY','{"conversion_kind":"inquiry_accepted"}','batch_fixture_001');

INSERT INTO analytics_consent_receipts(receipt_id,session_id,visitor_key_hash,prior_mode,new_mode,policy_version_reference,captured_at)
VALUES ('receipt_fixture_001','anasess_fixture_001','dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd','OFF','CONSENTED','policy-open-placeholder','2026-09-30T00:20:00Z');

INSERT INTO analytics_rollups(rollup_id,report_key,window_granularity,window_start,window_end,dimension_hash,dimensions_json,metric_count,metric_sum,metric_min,metric_max,metrics_json,source_through_received_at,updated_at)
VALUES ('rollup_fixture_001','overview.page_views','HOUR','2026-09-30T00:00:00Z','2026-09-30T01:00:00Z','eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee','{"locale_code":"en"}',1,NULL,NULL,NULL,'{}','2026-09-30T00:21:01Z','2026-09-30T00:22:00Z');
INSERT INTO analytics_rollup_cursors(report_key,through_received_at,through_event_id,row_version,updated_at)
VALUES ('overview.page_views','2026-09-30T00:21:01Z','evt_conversion_fixture_001',1,'2026-09-30T00:22:00Z');
INSERT INTO analytics_ingest_security_buckets(bucket_start,reason_code,bot_class,country_code,count_value,updated_at)
VALUES ('2026-09-30T00:00:00Z','ACCEPTED','HUMAN_LIKELY','LB',2,'2026-09-30T00:22:00Z');
