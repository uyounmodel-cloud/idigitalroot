-- P1-DATA-01 representative non-sensitive fixture set
-- Uses example.invalid and opaque local-only IDs; no credentials, live IDs, legal copy or retention durations.

INSERT INTO actors(actor_id,actor_type,status,display_name,primary_email_normalized,created_at) VALUES ('actor_fixture_editor','HUMAN','ACTIVE','Fixture Editor','editor@example.invalid','2026-09-29T00:00:00Z');
INSERT INTO roles(role_id,role_key,display_name,description,system_managed) VALUES ('role_fixture_editor','fixture.editor','Fixture Editor','Local test role only',0);
INSERT INTO role_permissions(role_id,permission_id,granted_at,granted_by_actor_id) VALUES ('role_fixture_editor','perm_content_edit','2026-09-29T00:00:00Z','actor_fixture_editor'),('role_fixture_editor','perm_publish_execute','2026-09-29T00:00:00Z','actor_fixture_editor');
INSERT INTO actor_roles(actor_id,role_id,granted_at,granted_by_actor_id) VALUES ('actor_fixture_editor','role_fixture_editor','2026-09-29T00:00:00Z','actor_fixture_editor');

INSERT INTO routes(route_id,route_key,route_kind,code_owned,created_at) VALUES ('rt_fixture_home_001','home','PRIMARY',1,'2026-09-29T00:00:00Z');
INSERT INTO route_paths(route_path_id,route_id,locale_code,path,is_canonical,is_active,updated_by_actor_id,updated_at) VALUES ('rpath_fixture_home_en','rt_fixture_home_001','en','/',1,1,'actor_fixture_editor','2026-09-29T00:00:00Z'),('rpath_fixture_home_ar','rt_fixture_home_001','ar','/',1,1,'actor_fixture_editor','2026-09-29T00:00:00Z');
INSERT INTO content_entities(entity_id,entity_type,stable_key,route_id,created_at) VALUES ('ent_fixture_home','PAGE','page.home','rt_fixture_home_001','2026-09-29T00:00:00Z'),('ent_fixture_nav','NAVIGATION','navigation.primary',NULL,'2026-09-29T00:00:00Z'),('ent_fixture_footer','FOOTER','footer.primary',NULL,'2026-09-29T00:00:00Z'),('ent_fixture_service','SERVICE','service.website',NULL,'2026-09-29T00:00:00Z'),('ent_fixture_knowledge','KNOWLEDGE_ARTICLE','knowledge.fixture',NULL,'2026-09-29T00:00:00Z'),('ent_legal_terms','LEGAL_DOCUMENT','legal.terms',NULL,'2026-09-29T00:00:00Z'),('ent_legal_privacy','LEGAL_DOCUMENT','legal.privacy',NULL,'2026-09-29T00:00:00Z'),('ent_legal_cookies','LEGAL_DOCUMENT','legal.cookies',NULL,'2026-09-29T00:00:00Z');
INSERT INTO navigation_sets(entity_id,navigation_key) VALUES ('ent_fixture_nav','primary');
INSERT INTO footer_sets(entity_id,footer_key) VALUES ('ent_fixture_footer','primary');
INSERT INTO service_records(entity_id,service_key,availability_state) VALUES ('ent_fixture_service','website','DRAFT');
INSERT INTO knowledge_records(entity_id,knowledge_key,knowledge_kind) VALUES ('ent_fixture_knowledge','fixture-article','GUIDE');
INSERT INTO legal_documents(entity_id,legal_code,approval_gate_state) VALUES ('ent_legal_terms','TERMS','OPEN'),('ent_legal_privacy','PRIVACY','OPEN'),('ent_legal_cookies','COOKIES','OPEN');

INSERT INTO content_revisions(revision_id,entity_id,locale_code,revision_number,workflow_state,validation_state,schema_version,sanitizer_policy_version,content_json,content_hash_sha256,created_by_actor_id,created_at) VALUES ('rev_fixture_home_en_1','ent_fixture_home','en',1,'READY','VALID',1,'sanitizer-v1','{"title":"Fixture home","lead":"Local validation only"}','ed1b1392ee2d5e701b3fc5e6d6a7f441dd5da13f9a3016399eb3f970039d05f3','actor_fixture_editor','2026-09-29T00:01:00Z'),('rev_fixture_home_ar_1','ent_fixture_home','ar',1,'READY','VALID',1,'sanitizer-v1','{"title":"صفحة تجريبية","lead":"للتحقق المحلي فقط"}','5f88d0f11082d087229d3f8bf9566df9eb77e4fab964c5428b7a329fc5ab2089','actor_fixture_editor','2026-09-29T00:01:00Z');
INSERT INTO content_locale_state(entity_id,locale_code,translation_state,latest_revision_id,row_version,updated_by_actor_id,updated_at) VALUES ('ent_fixture_home','en','READY','rev_fixture_home_en_1',1,'actor_fixture_editor','2026-09-29T00:01:00Z'),('ent_fixture_home','ar','READY','rev_fixture_home_ar_1',1,'actor_fixture_editor','2026-09-29T00:01:00Z');
INSERT INTO page_revision_sections(section_row_id,content_revision_id,section_instance_id,component_family_id,ordinal,visible,variant_key,config_json,localized_content_json) VALUES ('secrow_fixture_en_hero','rev_fixture_home_en_1','sec_home_hero','cmp_hero',1,1,NULL,'{}','{"heading":"Fixture hero"}'),('secrow_fixture_en_footer','rev_fixture_home_en_1','sec_home_footer','cmp_footer',2,1,NULL,'{}','{"label":"Fixture footer"}'),('secrow_fixture_ar_hero','rev_fixture_home_ar_1','sec_home_hero','cmp_hero',1,1,NULL,'{}','{"heading":"واجهة تجريبية"}'),('secrow_fixture_ar_footer','rev_fixture_home_ar_1','sec_home_footer','cmp_footer',2,1,NULL,'{}','{"label":"تذييل تجريبي"}');

INSERT INTO media_assets(media_id,source_class,media_kind,approval_state,original_filename,declared_mime,detected_mime,size_bytes,width_px,height_px,checksum_sha256,created_by_actor_id,created_at) VALUES ('media_fixture_001','LOCAL_UPLOAD','IMAGE','APPROVED','fixture.png','image/png','image/png',1234,1200,800,'07b8d1c17393554299c69c1888878b7e78b52d6175bac85a4ed09331a82502c9','actor_fixture_editor','2026-09-29T00:02:00Z');
INSERT INTO media_objects(media_object_id,media_id,object_role,r2_object_key,object_state,checksum_sha256,created_at) VALUES ('mobj_fixture_001','media_fixture_001','DERIVATIVE','fixtures/media/opaque-object-001.webp','APPROVED_PUBLIC','07b8d1c17393554299c69c1888878b7e78b52d6175bac85a4ed09331a82502c9','2026-09-29T00:02:00Z');
INSERT INTO media_localized_revisions(media_localized_revision_id,media_id,locale_code,revision_number,title,alt_text,created_by_actor_id,created_at) VALUES ('mlr_fixture_en_1','media_fixture_001','en',1,'Fixture visual','Decorative fixture visual','actor_fixture_editor','2026-09-29T00:02:00Z'),('mlr_fixture_ar_1','media_fixture_001','ar',1,'صورة تجريبية','صورة تجريبية للمعاينة','actor_fixture_editor','2026-09-29T00:02:00Z');
INSERT INTO revision_media_refs(content_revision_id,media_id,media_localized_revision_id,usage_role,required) VALUES ('rev_fixture_home_en_1','media_fixture_001','mlr_fixture_en_1','hero_visual',1),('rev_fixture_home_ar_1','media_fixture_001','mlr_fixture_ar_1','hero_visual',1);

INSERT INTO idempotency_records(idempotency_record_id,operation_scope,context_hash,idempotency_key_hash,request_hash,state,result_type,result_id,response_reference,created_at,completed_at) VALUES ('idem_fixture_publish_en','publish','768b03e2ee636091971475502e64d94b8298627c14dcc423bcae4773fa65db92','5f442044ee6a332072cbf3e50de7794a21ecd755e9e6cedcd8a9398ae40e3143','6b15e3bac4f9088c3c8d780ca8a6790f2681d590286e97ac600640c537ff9132','SUCCEEDED','publication','rev_fixture_home_en_1','PUB-FIXTURE-EN','2026-09-29T00:03:00Z','2026-09-29T00:03:01Z');
INSERT INTO publication_events(publication_event_id,entity_id,locale_code,action,revision_id,actor_id,idempotency_record_id,correlation_id,created_at) VALUES ('pevt_fixture_en_1','ent_fixture_home','en','PUBLISH','rev_fixture_home_en_1','actor_fixture_editor','idem_fixture_publish_en','corr-publish-en','2026-09-29T00:03:01Z');
INSERT INTO publication_pointers(entity_id,locale_code,revision_id,publication_event_id,pointer_version,published_at) VALUES ('ent_fixture_home','en','rev_fixture_home_en_1','pevt_fixture_en_1',1,'2026-09-29T00:03:01Z');
UPDATE content_locale_state SET translation_state='PUBLISHED', row_version=row_version+1, updated_at='2026-09-29T00:03:01Z' WHERE entity_id='ent_fixture_home' AND locale_code='en';
INSERT INTO idempotency_records(idempotency_record_id,operation_scope,context_hash,idempotency_key_hash,request_hash,state,result_type,result_id,response_reference,created_at,completed_at) VALUES ('idem_fixture_publish_ar','publish','b1acb8791d7f28bcd0c9e7de76c592e093b66a5ec82a07a15aa77fe15e3753c5','9fd0357fc99a67abb333bd26b6e99b6a40f64b592a0f229161e877923decf13e','d347d6fd8ed2f8a211eb4c00f3f5e2ecc445c79aa1b995235b16a3c3bbbdfbca','SUCCEEDED','publication','rev_fixture_home_ar_1','PUB-FIXTURE-AR','2026-09-29T00:03:00Z','2026-09-29T00:03:01Z');
INSERT INTO publication_events(publication_event_id,entity_id,locale_code,action,revision_id,actor_id,idempotency_record_id,correlation_id,created_at) VALUES ('pevt_fixture_ar_1','ent_fixture_home','ar','PUBLISH','rev_fixture_home_ar_1','actor_fixture_editor','idem_fixture_publish_ar','corr-publish-ar','2026-09-29T00:03:01Z');
INSERT INTO publication_pointers(entity_id,locale_code,revision_id,publication_event_id,pointer_version,published_at) VALUES ('ent_fixture_home','ar','rev_fixture_home_ar_1','pevt_fixture_ar_1',1,'2026-09-29T00:03:01Z');
UPDATE content_locale_state SET translation_state='PUBLISHED', row_version=row_version+1, updated_at='2026-09-29T00:03:01Z' WHERE entity_id='ent_fixture_home' AND locale_code='ar';
INSERT INTO publication_schedules(schedule_id,entity_id,locale_code,revision_id,scheduled_at_utc,status,created_by_actor_id,created_at) VALUES ('sched_fixture_future','ent_fixture_home','en','rev_fixture_home_en_1','2099-01-01T00:00:00Z','SCHEDULED','actor_fixture_editor','2026-09-29T00:04:00Z');

INSERT INTO inquiry_wizard_versions(wizard_version_id,version_key,status,schema_hash_sha256,created_by_actor_id,created_at) VALUES ('wiz_v43','personal-student-v4.3','DRAFT','bc0c1182f2a091097a29f95d4e5f192995248f93e3f7b9292a95653c16303749','actor_fixture_editor','2026-09-29T00:05:00Z');
INSERT INTO inquiry_steps(step_id,wizard_version_id,step_key,ordinal,protected_system_step) VALUES ('step_v43_01','wiz_v43','about-you',1,1);
INSERT INTO inquiry_step_localizations(step_id,locale_code,title,subtitle) VALUES ('step_v43_01','en','Where are you in your journey?','Choose the option that best describes where you are today.'),('step_v43_01','ar','أين أنت في رحلتك الآن؟','اختر الوصف الأقرب لمرحلتك الحالية.');
INSERT INTO inquiry_steps(step_id,wizard_version_id,step_key,ordinal,protected_system_step) VALUES ('step_v43_02','wiz_v43','what-you-need',2,1);
INSERT INTO inquiry_step_localizations(step_id,locale_code,title,subtitle) VALUES ('step_v43_02','en','What would you like your Personal Root to help you with?','You do not need to know technical details. Choose the direction that feels closest.'),('step_v43_02','ar','بماذا تريد أن يساعدك جذرك الشخصي؟','لا تحتاج لمعرفة التفاصيل التقنية. اختر الاتجاه الأقرب إلى ما تحتاجه.');
INSERT INTO inquiry_steps(step_id,wizard_version_id,step_key,ordinal,protected_system_step) VALUES ('step_v43_03','wiz_v43','your-goals',3,1);
INSERT INTO inquiry_step_localizations(step_id,locale_code,title,subtitle) VALUES ('step_v43_03','en','What do you want to move toward?','Choose one or more goals. These help our team understand the experience you need.'),('step_v43_03','ar','ما الذي تريد التقدم نحوه؟','اختر هدفاً أو أكثر حتى نفهم التجربة التي تناسبك.');
INSERT INTO inquiry_steps(step_id,wizard_version_id,step_key,ordinal,protected_system_step) VALUES ('step_v43_04','wiz_v43','current-presence',4,1);
INSERT INTO inquiry_step_localizations(step_id,locale_code,title,subtitle) VALUES ('step_v43_04','en','What do you already have?','Tell us only what is useful. Never send passwords or private credentials.'),('step_v43_04','ar','ما الذي تملكه حالياً؟','شارك ما يفيدنا فقط، ولا ترسل كلمات مرور أو بيانات دخول خاصة.');
INSERT INTO inquiry_steps(step_id,wizard_version_id,step_key,ordinal,protected_system_step) VALUES ('step_v43_05','wiz_v43','main-requirements',5,1);
INSERT INTO inquiry_step_localizations(step_id,locale_code,title,subtitle) VALUES ('step_v43_05','en','What should your personal digital home include?','A few practical preferences help us prepare the right conversation.'),('step_v43_05','ar','ماذا تريد أن يتضمن بيتك الرقمي الشخصي؟','بعض التفضيلات العملية تساعدنا على الاستعداد للمحادثة المناسبة.');
INSERT INTO inquiry_steps(step_id,wizard_version_id,step_key,ordinal,protected_system_step) VALUES ('step_v43_06','wiz_v43','additional-information',6,1);
INSERT INTO inquiry_step_localizations(step_id,locale_code,title,subtitle) VALUES ('step_v43_06','en','Anything else you want us to understand?','Optional. Share context about your studies, projects or next step.'),('step_v43_06','ar','هل هناك شيء آخر تريد أن نفهمه؟','اختياري. شارك ما يساعدنا على فهم دراستك أو مشاريعك أو خطوتك التالية.');
INSERT INTO inquiry_steps(step_id,wizard_version_id,step_key,ordinal,protected_system_step) VALUES ('step_v43_07','wiz_v43','contact-details',7,1);
INSERT INTO inquiry_step_localizations(step_id,locale_code,title,subtitle) VALUES ('step_v43_07','en','How should our team contact you?','This remains a human-reviewed inquiry, not public self-signup.'),('step_v43_07','ar','كيف يتواصل معك فريقنا؟','يبقى هذا استفساراً يراجعه فريق بشري، وليس تسجيلاً عاماً.');
INSERT INTO inquiry_steps(step_id,wizard_version_id,step_key,ordinal,protected_system_step) VALUES ('step_v43_08','wiz_v43','review',8,1);
INSERT INTO inquiry_step_localizations(step_id,locale_code,title,subtitle) VALUES ('step_v43_08','en','Review your inquiry.','Check your answers before the design-preview confirmation.'),('step_v43_08','ar','راجع استفسارك.','راجع إجاباتك قبل شاشة التأكيد التجريبية.');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_01_journey_stage','step_v43_01','journey_stage','SINGLE_SELECT',1,1,160,'enum',1);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_01_journey_stage','en','Where are you in your journey?'),('field_v43_01_journey_stage','ar','أين أنت في رحلتك الآن؟');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_02_need_direction','step_v43_02','need_direction','SINGLE_SELECT',1,1,160,'enum',1);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_02_need_direction','en','What would you like your Personal Root to help you with?'),('field_v43_02_need_direction','ar','بماذا تريد أن يساعدك جذرك الشخصي؟');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_03_goals','step_v43_03','goals','MULTI_SELECT',1,1,512,'enum_multi',1);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_03_goals','en','What do you want to move toward?'),('field_v43_03_goals','ar','ما الذي تريد التقدم نحوه؟');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_04_existingSite','step_v43_04','existingSite','URL',0,1,260,'http_https_url',1);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_04_existingSite','en','Personal website URL, if you already have one'),('field_v43_04_existingSite','ar','رابط موقعك الشخصي إن وجد');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_04_existingDomain','step_v43_04','existingDomain','TEXT',0,1,160,NULL,2);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_04_existingDomain','en','Domain you already own, if any'),('field_v43_04_existingDomain','ar','نطاق تملكه إن وجد');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_04_existingEmail','step_v43_04','existingEmail','SINGLE_SELECT',0,1,160,'enum',3);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_04_existingEmail','en','Do you already use a professional email?'),('field_v43_04_existingEmail','ar','هل تستخدم بريداً مهنياً؟');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_04_socialLinks','step_v43_04','socialLinks','TEXT',0,1,160,NULL,4);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_04_socialLinks','en','Public profile / portfolio links (optional)'),('field_v43_04_socialLinks','ar','روابط عامة لملفك أو أعمالك (اختياري)');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_05_languages','step_v43_05','languages','SINGLE_SELECT',0,1,160,'enum',1);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_05_languages','en','Preferred languages'),('field_v43_05_languages','ar','اللغات المفضلة');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_05_focus','step_v43_05','focus','SINGLE_SELECT',0,1,160,'enum',2);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_05_focus','en','What should feel most important?'),('field_v43_05_focus','ar','ما الذي يجب أن يكون الأهم؟');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_05_features','step_v43_05','features','TEXTAREA',0,1,1500,NULL,3);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_05_features','en','Anything you especially want to be able to create or share?'),('field_v43_05_features','ar','هل هناك شيء تريد إنشاءه أو مشاركته بشكل خاص؟');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_05_timing','step_v43_05','timing','TEXT',0,1,160,NULL,4);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_05_timing','en','Is there a date or opportunity you are preparing for?'),('field_v43_05_timing','ar','هل تستعد لموعد أو فرصة محددة؟');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_06_notes','step_v43_06','notes','TEXTAREA',0,1,1500,NULL,1);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_06_notes','en','Tell us anything that will help us understand you'),('field_v43_06_notes','ar','أخبرنا بما يساعدنا على فهم احتياجك');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_07_name','step_v43_07','name','TEXT',1,1,160,'name',1);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_07_name','en','Your name'),('field_v43_07_name','ar','الاسم');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_07_university','step_v43_07','university','TEXT',0,1,160,NULL,2);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_07_university','en','University / institution (optional)'),('field_v43_07_university','ar','الجامعة / المؤسسة (اختياري)');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_07_email','step_v43_07','email','EMAIL',1,1,160,'email',3);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_07_email','en','Email address'),('field_v43_07_email','ar','البريد الإلكتروني');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_07_country','step_v43_07','country','TEXT',0,1,160,NULL,4);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_07_country','en','Country'),('field_v43_07_country','ar','البلد');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_07_phone','step_v43_07','phone','TEL',0,1,160,NULL,5);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_07_phone','en','Phone (optional)'),('field_v43_07_phone','ar','الهاتف (اختياري)');
INSERT INTO inquiry_fields(field_id,step_id,field_key,field_type,required,protected_system_field,max_length,validation_key,ordinal) VALUES ('field_v43_07_method','step_v43_07','method','SINGLE_SELECT',0,1,160,'enum',6);
INSERT INTO inquiry_field_localizations(field_id,locale_code,label) VALUES ('field_v43_07_method','en','Preferred contact method'),('field_v43_07_method','ar','وسيلة التواصل المفضلة');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_01_journey_stage_student','field_v43_01_journey_stage','student',1,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_01_journey_stage_student','en','University student'),('opt_v43_01_journey_stage_student','ar','طالب جامعي');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_01_journey_stage_recent_grad','field_v43_01_journey_stage','recent-grad',2,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_01_journey_stage_recent_grad','en','Recent graduate'),('opt_v43_01_journey_stage_recent_grad','ar','خريج حديث');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_01_journey_stage_school_to_university','field_v43_01_journey_stage','school-to-university',3,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_01_journey_stage_school_to_university','en','Preparing for university'),('opt_v43_01_journey_stage_school_to_university','ar','أستعد للجامعة');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_01_journey_stage_personal','field_v43_01_journey_stage','personal',4,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_01_journey_stage_personal','en','Personal project outside university'),('opt_v43_01_journey_stage_personal','ar','مشروع شخصي خارج الجامعة');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_01_journey_stage_not_sure','field_v43_01_journey_stage','not-sure',5,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_01_journey_stage_not_sure','en','Not sure yet'),('opt_v43_01_journey_stage_not_sure','ar','لست متأكداً بعد');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_02_need_direction_first_root','field_v43_02_need_direction','first-root',1,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_02_need_direction_first_root','en','My first personal website'),('opt_v43_02_need_direction_first_root','ar','أول موقع شخصي لي');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_02_need_direction_portfolio','field_v43_02_need_direction','portfolio',2,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_02_need_direction_portfolio','en','A stronger portfolio for my work'),('opt_v43_02_need_direction_portfolio','ar','معرض أعمال أقوى');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_02_need_direction_career','field_v43_02_need_direction','career',3,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_02_need_direction_career','en','A professional presence for what comes next'),('opt_v43_02_need_direction_career','ar','حضور مهني لخطوتي القادمة');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_02_need_direction_organize','field_v43_02_need_direction','organize',4,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_02_need_direction_organize','en','One place for my projects, CV and links'),('opt_v43_02_need_direction_organize','ar','مكان واحد لمشاريعي وسيرتي وروابطي');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_02_need_direction_refresh','field_v43_02_need_direction','refresh',5,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_02_need_direction_refresh','en','Improve an existing personal website'),('opt_v43_02_need_direction_refresh','ar','تطوير موقع شخصي موجود');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_02_need_direction_not_sure','field_v43_02_need_direction','not-sure',6,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_02_need_direction_not_sure','en','I want guidance first'),('opt_v43_02_need_direction_not_sure','ar','أحتاج إلى التوجيه أولاً');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_03_goals_show_work','field_v43_03_goals','show-work',1,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_03_goals_show_work','en','Present my projects professionally'),('opt_v43_03_goals_show_work','ar','أعرض مشاريعي باحتراف');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_03_goals_internship','field_v43_03_goals','internship',2,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_03_goals_internship','en','Prepare for internships'),('opt_v43_03_goals_internship','ar','أستعد لفرص التدريب');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_03_goals_first_job','field_v43_03_goals','first-job',3,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_03_goals_first_job','en','Prepare for my first job'),('opt_v43_03_goals_first_job','ar','أستعد لأول وظيفة');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_03_goals_scholarship','field_v43_03_goals','scholarship',4,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_03_goals_scholarship','en','Prepare materials for applications'),('opt_v43_03_goals_scholarship','ar','أجهّز مواد للتقديم');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_03_goals_identity','field_v43_03_goals','identity',5,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_03_goals_identity','en','Build a clearer professional identity'),('opt_v43_03_goals_identity','ar','أبني هوية مهنية أوضح');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_03_goals_centralize','field_v43_03_goals','centralize',6,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_03_goals_centralize','en','Bring my digital presence together'),('opt_v43_03_goals_centralize','ar','أجمع حضوري الرقمي في مكان واحد');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_03_goals_personal_growth','field_v43_03_goals','personal-growth',7,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_03_goals_personal_growth','en','Organize my progress privately'),('opt_v43_03_goals_personal_growth','ar','أنظم تطوري بشكل خاص');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_04_existingEmail_not_sure','field_v43_04_existingEmail','not-sure',1,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_04_existingEmail_not_sure','en','Not sure'),('opt_v43_04_existingEmail_not_sure','ar','غير متأكد');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_04_existingEmail_yes','field_v43_04_existingEmail','yes',2,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_04_existingEmail_yes','en','Yes'),('opt_v43_04_existingEmail_yes','ar','نعم');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_04_existingEmail_no','field_v43_04_existingEmail','no',3,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_04_existingEmail_no','en','No'),('opt_v43_04_existingEmail_no','ar','لا');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_05_languages_arabic','field_v43_05_languages','arabic',1,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_05_languages_arabic','en','Arabic'),('opt_v43_05_languages_arabic','ar','العربية');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_05_languages_english','field_v43_05_languages','english',2,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_05_languages_english','en','English'),('opt_v43_05_languages_english','ar','الإنجليزية');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_05_languages_arabic_english','field_v43_05_languages','arabic-english',3,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_05_languages_arabic_english','en','Arabic & English'),('opt_v43_05_languages_arabic_english','ar','العربية والإنجليزية');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_05_languages_other_not_sure','field_v43_05_languages','other-not-sure',4,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_05_languages_other_not_sure','en','Other / not sure'),('opt_v43_05_languages_other_not_sure','ar','أخرى / غير متأكد');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_05_focus_projects_portfolio','field_v43_05_focus','projects-portfolio',1,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_05_focus_projects_portfolio','en','Projects & portfolio'),('opt_v43_05_focus_projects_portfolio','ar','المشاريع ومعرض الأعمال');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_05_focus_cv_career','field_v43_05_focus','cv-career',2,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_05_focus_cv_career','en','CV & career preparation'),('opt_v43_05_focus_cv_career','ar','السيرة والاستعداد المهني');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_05_focus_personal_identity','field_v43_05_focus','personal-identity',3,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_05_focus_personal_identity','en','Personal identity'),('opt_v43_05_focus_personal_identity','ar','الهوية الشخصية');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_05_focus_university_journey','field_v43_05_focus','university-journey',4,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_05_focus_university_journey','en','University journey'),('opt_v43_05_focus_university_journey','ar','الرحلة الجامعية');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_05_focus_balanced','field_v43_05_focus','balanced',5,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_05_focus_balanced','en','A balanced mix'),('opt_v43_05_focus_balanced','ar','مزيج متوازن');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_05_focus_not_sure','field_v43_05_focus','not-sure',6,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_05_focus_not_sure','en','Not sure'),('opt_v43_05_focus_not_sure','ar','غير متأكد');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_07_method_email','field_v43_07_method','email',1,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_07_method_email','en','Email'),('opt_v43_07_method_email','ar','البريد الإلكتروني');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_07_method_phone','field_v43_07_method','phone',2,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_07_method_phone','en','Phone'),('opt_v43_07_method_phone','ar','الهاتف');
INSERT INTO inquiry_field_options(option_id,field_id,option_key,ordinal,active) VALUES ('opt_v43_07_method_either','field_v43_07_method','either',3,1);
INSERT INTO inquiry_option_localizations(option_id,locale_code,label) VALUES ('opt_v43_07_method_either','en','Either'),('opt_v43_07_method_either','ar','أي منهما');
UPDATE inquiry_wizard_versions SET status='PUBLISHED', effective_at='2026-09-29T00:06:00Z' WHERE wizard_version_id='wiz_v43';

INSERT INTO leads(lead_id,public_reference,wizard_version_id,locale_code,name,email_normalized,university_or_institution,country,phone,preferred_contact_method,intake_state,source_context_json,retention_category_id,received_at) VALUES ('lead_fixture_001','INQ-FIXTURE-001','wiz_v43','en','Example Student','student@example.invalid',NULL,NULL,NULL,'Email','ACCEPTED','{"source":"local-fixture"}','ret_lead_qualified','2026-09-29T00:07:00Z');
INSERT INTO lead_answers(answer_id,lead_id,field_id,value_text,submitted_at) VALUES ('ans_fixture_01','lead_fixture_001','field_v43_01_journey_stage','student','2026-09-29T00:07:00Z');
INSERT INTO lead_answer_options(answer_id,option_id,ordinal) VALUES ('ans_fixture_01','opt_v43_01_journey_stage_student',1);
INSERT INTO lead_answers(answer_id,lead_id,field_id,value_text,submitted_at) VALUES ('ans_fixture_02','lead_fixture_001','field_v43_02_need_direction','first-root','2026-09-29T00:07:00Z');
INSERT INTO lead_answer_options(answer_id,option_id,ordinal) VALUES ('ans_fixture_02','opt_v43_02_need_direction_first_root',1);
INSERT INTO lead_answers(answer_id,lead_id,field_id,value_text,submitted_at) VALUES ('ans_fixture_03','lead_fixture_001','field_v43_03_goals','show-work','2026-09-29T00:07:00Z');
INSERT INTO lead_answer_options(answer_id,option_id,ordinal) VALUES ('ans_fixture_03','opt_v43_03_goals_show_work',1);
INSERT INTO lead_answers(answer_id,lead_id,field_id,value_text,submitted_at) VALUES ('ans_fixture_name','lead_fixture_001','field_v43_07_name','Example Student','2026-09-29T00:07:00Z');
INSERT INTO lead_answers(answer_id,lead_id,field_id,value_text,submitted_at) VALUES ('ans_fixture_email','lead_fixture_001','field_v43_07_email','student@example.invalid','2026-09-29T00:07:00Z');
INSERT INTO lead_attribution(lead_id,landing_path,cta_source) VALUES ('lead_fixture_001','/','fixture-home-cta');
INSERT INTO lead_security_events(lead_security_event_id,lead_id,event_type,outcome,minimized_metadata_json,retention_category_id,created_at) VALUES ('lse_fixture_001','lead_fixture_001','ACCEPTED','ALLOW','{}','ret_security','2026-09-29T00:07:00Z');
INSERT INTO idempotency_records(idempotency_record_id,operation_scope,context_hash,idempotency_key_hash,request_hash,state,result_type,result_id,response_reference,created_at,completed_at) VALUES ('idem_fixture_inquiry','inquiry.submit','c08b730861ca6cd02b0dc4383e6b63b0ce098f18f93ada62b99662fb3a9a0656','299b7df2d6c08679fb0f076e53bd21e21631f1209175cc4ef9568548ee7dbf0d','d8c4d7b6351ee394e2ebed2a8634977aec866b60749d247d66adb240daf738e2','SUCCEEDED','lead','lead_fixture_001','INQ-FIXTURE-001','2026-09-29T00:07:00Z','2026-09-29T00:07:01Z');
INSERT INTO audit_events(audit_event_id,actor_id,source_kind,action_key,target_type,target_id,environment_key,outcome,correlation_id,metadata_json,created_at) VALUES ('audit_fixture_publish','actor_fixture_editor','CMS','content.publish','content_entity','ent_fixture_home','local','SUCCESS','corr-publish-en','{}','2026-09-29T00:03:02Z');

-- P1-DATA-02 additive synthetic fixture extension. No real PII or provider credentials.
INSERT OR IGNORE INTO actor_security_state(actor_id,activation_state,reauth_after,disabled_at,disabled_reason,row_version,updated_at)
VALUES ('actor_fixture_editor','active',NULL,NULL,NULL,1,'2026-09-30T00:10:00Z');

INSERT INTO actors(actor_id,actor_type,status,display_name,primary_email_normalized,created_at)
VALUES ('actor_fixture_pending','HUMAN','DISABLED','Pending Fixture User','pending@example.invalid','2026-09-30T00:10:00Z');
INSERT INTO actor_security_state(actor_id,activation_state,reauth_after,disabled_at,disabled_reason,row_version,updated_at)
VALUES ('actor_fixture_pending','pending_activation',NULL,NULL,NULL,1,'2026-09-30T00:10:00Z');

INSERT INTO cms_external_identities(identity_id,actor_id,provider_key,issuer,subject,observed_email_normalized,identity_state,bound_at,row_version)
VALUES ('identity_fixture_editor','actor_fixture_editor','cloudflare_access','https://example.cloudflareaccess.invalid','fixture-subject-001','editor@example.invalid','ACTIVE','2026-09-30T00:10:00Z',1);

INSERT INTO cms_invitations(invitation_id,actor_id,invited_email_normalized,created_by_actor_id,invitation_state,created_at,expires_at,row_version)
VALUES ('invite_fixture_pending','actor_fixture_pending','pending@example.invalid','actor_fixture_editor','PENDING','2026-09-30T00:10:00Z','2026-10-03T00:10:00Z',1);

INSERT OR IGNORE INTO actor_role_scopes(actor_id,role_id,granted_at,scope_kind)
VALUES ('actor_fixture_editor','role_fixture_editor','2026-09-29T00:00:00Z','global');

INSERT INTO cms_sessions(session_id,actor_id,provider_namespace,provider_session_reference_hash,state,mfa_level,issued_at,last_seen_at,inactivity_expires_at,absolute_expires_at,row_version)
VALUES ('session_fixture_001','actor_fixture_editor','cloudflare_access','cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc','ACTIVE','webauthn','2026-09-30T00:11:00Z','2026-09-30T00:11:00Z','2026-09-30T00:41:00Z','2026-09-30T08:11:00Z',1);
INSERT INTO cms_session_security(session_id,external_identity_id,session_token_sha256,csrf_token_sha256,upstream_access_expires_at,fresh_auth_at,rotation_counter,created_at)
VALUES ('session_fixture_001','identity_fixture_editor','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb','2026-09-30T08:11:00Z','2026-09-30T00:11:00Z',0,'2026-09-30T00:11:00Z');

INSERT INTO content_entities(entity_id,entity_type,stable_key,route_id,created_at) VALUES
('ent_fixture_child_a','PAGE','page.fixture-child-a',NULL,'2026-09-30T00:12:00Z'),
('ent_fixture_child_b','PAGE','page.fixture-child-b',NULL,'2026-09-30T00:12:00Z');
INSERT INTO page_hierarchy(page_entity_id,parent_page_entity_id,sibling_ordinal,row_version,updated_by_actor_id,updated_at) VALUES
('ent_fixture_home',NULL,1,1,'actor_fixture_editor','2026-09-30T00:12:00Z'),
('ent_fixture_child_a','ent_fixture_home',1,1,'actor_fixture_editor','2026-09-30T00:12:00Z'),
('ent_fixture_child_b','ent_fixture_home',2,1,'actor_fixture_editor','2026-09-30T00:12:00Z');

INSERT INTO taxonomy_vocabularies(vocabulary_id,vocabulary_key,display_name,hierarchical,enabled,row_version,created_by_actor_id,created_at,updated_by_actor_id,updated_at)
VALUES ('vocab_fixture_knowledge','knowledge-topics','Knowledge Topics',1,1,1,'actor_fixture_editor','2026-09-30T00:13:00Z','actor_fixture_editor','2026-09-30T00:13:00Z');
INSERT INTO taxonomy_terms(term_id,vocabulary_id,stable_key,parent_term_id,sibling_ordinal,state,created_by_actor_id,created_at,updated_by_actor_id,updated_at) VALUES
('term_fixture_root','vocab_fixture_knowledge','digital-roots',NULL,1,'ACTIVE','actor_fixture_editor','2026-09-30T00:13:00Z','actor_fixture_editor','2026-09-30T00:13:00Z'),
('term_fixture_child','vocab_fixture_knowledge','student-roots','term_fixture_root',1,'ACTIVE','actor_fixture_editor','2026-09-30T00:13:00Z','actor_fixture_editor','2026-09-30T00:13:00Z');
INSERT INTO taxonomy_term_localizations(term_id,vocabulary_id,locale_code,label,slug,description,row_version,updated_by_actor_id,updated_at) VALUES
('term_fixture_root','vocab_fixture_knowledge','en','Digital roots','digital-roots',NULL,1,'actor_fixture_editor','2026-09-30T00:13:00Z'),
('term_fixture_child','vocab_fixture_knowledge','en','Student roots','student-roots',NULL,1,'actor_fixture_editor','2026-09-30T00:13:00Z');
INSERT INTO content_taxonomy_assignments(entity_id,term_id,ordinal,assigned_by_actor_id,assigned_at)
VALUES ('ent_fixture_knowledge','term_fixture_child',1,'actor_fixture_editor','2026-09-30T00:13:00Z');

INSERT INTO media_import_providers(import_provider_id,provider_key,adapter_key,adapter_version,mode,enabled,authorization_mode,non_secret_config_json,row_version,updated_by_actor_id,updated_at)
VALUES ('mip_fixture_drive','google_drive','google-drive-managed-import','1','MANAGED_IMPORT',1,'EPHEMERAL_PER_FILE','{}',1,'actor_fixture_editor','2026-09-30T00:14:00Z');
INSERT INTO media_import_jobs(import_job_id,import_provider_id,requested_by_actor_id,idempotency_record_id,provider_reference,state,target_media_id,safe_remote_metadata_json,error_code,correlation_id,created_at,started_at,completed_at,row_version)
VALUES ('mij_fixture_001','mip_fixture_drive','actor_fixture_editor',NULL,'drive-file-opaque-001','SUCCEEDED','media_fixture_001','{"mime":"image/png"}',NULL,'corr-import-001','2026-09-30T00:14:00Z','2026-09-30T00:14:01Z','2026-09-30T00:14:03Z',1);
INSERT INTO media_asset_provenance(media_id,origin_kind,import_provider_id,provider_reference,source_filename,source_declared_mime,managed_sha256,validation_profile_key,validation_profile_version,imported_by_actor_id,imported_at,provenance_json)
VALUES ('media_fixture_001','PROVIDER_IMPORT','mip_fixture_drive','drive-file-opaque-001','fixture.png','image/png','07b8d1c17393554299c69c1888878b7e78b52d6175bac85a4ed09331a82502c9','image-safe','1','actor_fixture_editor','2026-09-30T00:14:03Z','{"provider":"google_drive"}');

INSERT INTO lead_analytics_links(lead_id,analytics_session_id,conversion_event_id,correlation_id,created_at)
VALUES ('lead_fixture_001','anasess_fixture_001','evt_conversion_fixture_001','corr-conversion-001','2026-09-30T00:15:00Z');
INSERT INTO analytics_conversion_outbox(outbox_id,lead_id,conversion_event_id,analytics_session_id,event_schema_version,sanitized_payload_json,state,attempt_count,next_attempt_at,last_error_code,created_at,sent_at,row_version)
VALUES ('outbox_fixture_001','lead_fixture_001','evt_conversion_fixture_001','anasess_fixture_001',1,'{"conversion_kind":"inquiry_accepted","route_id":"rt_fixture_home_001"}','PENDING',0,'2026-09-30T00:16:00Z',NULL,'2026-09-30T00:15:00Z',NULL,1);
