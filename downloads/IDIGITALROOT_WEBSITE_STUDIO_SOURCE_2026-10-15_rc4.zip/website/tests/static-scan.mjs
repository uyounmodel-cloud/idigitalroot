import fs from 'node:fs';import path from 'node:path';
const root=path.resolve('.');
const files=[];function walk(d){for(const n of fs.readdirSync(d)){const p=path.join(d,n),st=fs.statSync(p);if(st.isDirectory()){if(['node_modules','dist','.fe02-build'].includes(n))continue;walk(p)}else if(/\.(?:ts|astro|js|mjs|json|css)$/.test(n))files.push(p)}}walk(path.join(root,'src'));
const text=files.map(p=>fs.readFileSync(p,'utf8')).join('\n');
const forbidden=[['CMS API','/api/cms/v1'],['direct D1 token','prepare('],['production Cloudflare account','account_id'],['R2 object key','r2_object_key'],['deployment command','wrangler deploy']];
let bad=false;for(const [name,needle] of forbidden){const found=text.includes(needle);console.log(found?'FAIL':'PASS',name,found?needle:'');if(found)bad=true}
if(bad)process.exit(1);console.log('P1_FE02_STATIC_SCAN_PASS');
