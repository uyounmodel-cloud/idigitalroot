import { spawn } from 'node:child_process';
import { setTimeout as sleep } from 'node:timers/promises';
import puppeteer from 'puppeteer-core';

const HOST = process.env.PREVIEW_HOST || '127.0.0.1';
const PORT = Number(process.env.PREVIEW_PORT || '4321');
const ORIGIN = `http://${HOST}:${PORT}`;
const CHROMIUM = process.env.CHROMIUM_PATH || '/usr/bin/chromium';
const expectedHomeSections = [
  'hero','student-problem','student-foundation','story','human-stories','three-experiences','roots',
  'student-benefits','toolbox','student-workspace','my-dream','major-personalization','project-to-career',
  'human-built','knowledge','not-student','proof','faq','final-cta'
];
const keyRoutes = [
  '/', '/personal', '/students', '/student/toolbox', '/student/workspace', '/student/majors',
  '/not-a-student', '/why-idigitalroot', '/what-you-get', '/services', '/how-we-build', '/knowledge',
  '/contact', '/pricing', '/inquiry', '/client-login'
];
const primaryRoutes = ['/', '/personal', '/students', '/student/toolbox', '/student/workspace', '/student/majors', '/not-a-student'];

const checks = [];
function record(name, ok, detail = '') {
  checks.push({ name, ok: Boolean(ok), detail: String(detail).slice(0, 1200) });
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}${detail ? ` — ${detail}` : ''}`);
}
async function waitForPreview(proc) {
  for (let i = 0; i < 80; i++) {
    if (proc.exitCode !== null) throw new Error(`preview exited with code ${proc.exitCode}`);
    try {
      const res = await fetch(`${ORIGIN}/`);
      if (res.ok) return;
    } catch {}
    await sleep(250);
  }
  throw new Error('preview did not become ready');
}
async function go(page, path) {
  const response = await page.goto(`${ORIGIN}${path}`, { waitUntil: 'networkidle0', timeout: 20000 });
  if (!response?.ok()) throw new Error(`${path}: HTTP ${response?.status()}`);
  await page.waitForSelector('#main', { timeout: 5000 });
}
async function getText(page, selector = '#main') {
  return page.$eval(selector, (el) => el.innerText);
}

const npmCommand = process.platform === 'win32' ? 'npm.cmd' : 'npm';
const preview = spawn(npmCommand, ['run', 'preview', '--', '--host', HOST, '--port', String(PORT)], {
  cwd: process.cwd(),
  stdio: ['ignore', 'pipe', 'pipe'],
  env: { ...process.env }
});
let previewLog = '';
preview.stdout.on('data', (d) => { previewLog += d.toString(); });
preview.stderr.on('data', (d) => { previewLog += d.toString(); });

let browser;
try {
  await waitForPreview(preview);
  browser = await puppeteer.launch({ executablePath: CHROMIUM, headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  const runtimeErrors = [];
  page.on('pageerror', (e) => runtimeErrors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') runtimeErrors.push(`console: ${m.text()}`); });

  await page.setViewport({ width: 1440, height: 900 });
  for (const route of primaryRoutes) {
    try { await go(page, route); record(`route loads ${route}`, true); }
    catch (e) { record(`route loads ${route}`, false, e.message); }
  }

  await go(page, '/');
  const sections = await page.$$eval('#main [data-cms-section]', (els) => els.map((el) => el.getAttribute('data-cms-section')));
  record('homepage approved chapter order', JSON.stringify(sections) === JSON.stringify(expectedHomeSections), JSON.stringify(sections));
  record('homepage approved H1', (await page.$eval('#main h1', (el) => el.textContent?.trim())) === 'Your ambition deserves its own address.');

  const mega = await page.$('[data-action="mega"]');
  const controls = await mega.evaluate((el) => el.getAttribute('aria-controls'));
  record('desktop Personal target exists while collapsed', controls === 'personal-mega' && Boolean(await page.$('#personal-mega')));
  await mega.click();
  record('desktop Personal opens', (await mega.evaluate((el) => el.getAttribute('aria-expanded'))) === 'true');
  await page.keyboard.press('Escape');
  record('desktop Personal closes with Escape', (await mega.evaluate((el) => el.getAttribute('aria-expanded'))) === 'false');
  record('desktop Personal restores focus', await page.evaluate(() => document.activeElement === document.querySelector('[data-action="mega"]')));

  const scatter = await page.$('#problem-scene [data-action="scatter"]');
  const beforeScene = await page.$eval('#problem-scene', (el) => el.className);
  await scatter.click();
  const afterScene = await page.$eval('#problem-scene', (el) => el.className);
  record('Root scene toggles', beforeScene !== afterScene && afterScene.includes('converged'));

  const faq = (await page.$$('.faq-question'))[1];
  const beforeFaq = await faq.evaluate((el) => el.getAttribute('aria-expanded'));
  await faq.focus(); await page.keyboard.press('Enter');
  record('FAQ keyboard operable', (await faq.evaluate((el) => el.getAttribute('aria-expanded'))) !== beforeFaq);

  const theme = await page.$('[data-action="theme"]');
  const oldTheme = await page.$eval('html', (el) => el.getAttribute('data-theme'));
  await theme.click();
  record('theme cycles', (await page.$eval('html', (el) => el.getAttribute('data-theme'))) !== oldTheme);

  const lang = await page.$('[data-action="lang"]');
  await lang.click();
  record('Arabic RTL', await page.evaluate(() => document.documentElement.lang === 'ar' && document.documentElement.dir === 'rtl'));
  await (await page.$('[data-action="lang"]')).click();
  record('English LTR', await page.evaluate(() => document.documentElement.lang === 'en' && document.documentElement.dir === 'ltr'));

  await go(page, '/student/workspace');
  const tabs = await page.$$('.workspace-tab');
  record('Workspace has exactly three views', tabs.length === 3, String(tabs.length));
  const viewIds = [];
  for (let i = 0; i < tabs.length; i++) {
    const currentTabs = await page.$$('.workspace-tab');
    await currentTabs[i].click();
    await sleep(40);
    viewIds.push(await page.$eval('[data-workspace-view]', (el) => el.getAttribute('data-workspace-view')));
  }
  record('Workspace views are distinct', new Set(viewIds).size === 3, JSON.stringify(viewIds));
  record('Workspace Personal Root link', Boolean(await page.$('#main a[href="/personal"]')));
  record('Workspace Toolbox link', Boolean(await page.$('#main a[href="/student/toolbox"]')));

  await page.setViewport({ width: 390, height: 844 });
  await go(page, '/');
  const mobile = await page.$('.mobile-trigger');
  record('mobile navigation trigger usable', Boolean(mobile));
  if (mobile) await mobile.click();
  record('mobile navigation panel opens', await page.$eval('.mobile-panel', (el) => getComputedStyle(el).display !== 'none'));

  const overflow = [];
  for (const vp of [{ width: 1440, height: 900 }, { width: 390, height: 844 }]) {
    await page.setViewport(vp);
    for (const route of keyRoutes) {
      try {
        await go(page, route);
        const widths = await page.evaluate(() => ({ scroll: document.documentElement.scrollWidth, inner: window.innerWidth }));
        if (widths.scroll > widths.inner + 1) overflow.push({ route, vp, ...widths });
      } catch (e) { overflow.push({ route, vp, error: e.message }); }
    }
  }
  record('representative routes have no horizontal overflow', overflow.length === 0, JSON.stringify(overflow));

  await page.setViewport({ width: 1440, height: 900 });
  await go(page, '/client-login');
  const clientText = (await getText(page)).toLowerCase();
  record('/client-login truthful and non-functional', clientText.includes('no credentials') && !(await page.$('#main input[type="password"]')));

  await go(page, '/solutions/legacy');
  const solutionsText = await getText(page);
  record('legacy Solutions does not revive Business', solutionsText.includes('A Personal Root can begin') && !solutionsText.includes('Business Edition'));
  await go(page, '/blueprints/legacy');
  record('legacy Blueprints maps to majors', (await getText(page)).includes('Your field changes the presentation'));

  await go(page, '/inquiry');
  const inquiryIntro = await getText(page);
  record('inquiry disclaims account/payment/automatic generation', inquiryIntro.includes('No account, no payment and no automatic website generation.'));
  await page.click('a[href="/inquiry/about-you"]');
  await page.waitForSelector('.wizard-progress');
  record('inquiry exactly eight steps', (await page.$$('.wizard-progress button')).length === 8);
  for (let i = 0; i < 3; i++) { await page.click('[data-action="wizard-choice"]'); await page.click('[data-action="wizard-next"]'); await sleep(30); }
  for (let i = 0; i < 3; i++) { await page.click('[data-action="wizard-next"]'); await sleep(30); }
  await page.type('[data-wfield="name"]', 'Test Student');
  await page.type('[data-wfield="email"]', 'test@example.com');
  await page.click('[data-wfield="understand"]');
  await page.click('[data-action="wizard-next"]'); await sleep(30);
  record('inquiry reaches review', new URL(page.url()).pathname === '/inquiry/review', page.url());
  await page.click('[data-action="wizard-next"]'); await sleep(30);
  const receipt = await getText(page);
  record('inquiry receipt remains local preview', new URL(page.url()).pathname === '/inquiry/received' && receipt.toUpperCase().includes('NOTHING SENT') && receipt.includes('no Lead was created'));

  const reduced = await browser.newPage();
  await reduced.emulateMediaFeatures([{ name: 'prefers-reduced-motion', value: 'reduce' }]);
  await go(reduced, '/');
  record('reduced-motion preference honored', (await reduced.$eval('html', (el) => el.getAttribute('data-motion'))) === 'off');
  await reduced.close();

  record('no uncaught browser errors', runtimeErrors.length === 0, runtimeErrors.join(' | '));
} catch (error) {
  record('acceptance harness completed', false, `${error?.stack || error}\n${previewLog}`);
} finally {
  if (browser) await browser.close();
  preview.kill('SIGTERM');
  await sleep(100);
}

if (!checks.every((c) => c.ok)) process.exitCode = 1;
