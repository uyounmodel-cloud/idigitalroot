import urllib.request, urllib.error, re, sys
from pathlib import Path
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:4399'; API='http://127.0.0.1:4388'; ROOT=Path(__file__).resolve().parents[1]
def fetch_url(url):
    try:
        with urllib.request.urlopen(url,timeout=10) as r:return r.status,dict(r.headers),r.read()
    except urllib.error.HTTPError as e:return e.code,dict(e.headers),e.read()
def control(path):return fetch_url(API+path)[0]
css=(ROOT/'src/styles/global.css').read_text()
fix=(ROOT/'.fe02-build/content/frozen-fixtures.js').read_text()
client=(ROOT/'.fe02-build/scripts/client.js').read_text()
fix=re.sub(r'\bexport\s+','',fix)
client=re.sub(r"^import\s+\{[^\n]+\}\s+from\s+['\"][^'\"]+['\"];?\s*","",client,count=1,flags=re.M)
client=re.sub(r'\bexport\s+','',client)
bundle=fix+'\n'+client

def load(page,path):
    status,headers,body=fetch_url(BASE+path); html=body.decode('utf-8','replace')
    html=re.sub(r'<link rel="stylesheet" href="/__assets/global.css">',f'<style>{css}</style>',html)
    html=re.sub(r'<script type="module" src="/__assets/client.js"></script>',lambda m:'<script>'+bundle+'</script>',html)
    page.goto('about:blank');page.set_content(html,wait_until='load');page.wait_for_timeout(50);return status,headers
checks=[]
def ck(name,ok,detail=''):
    checks.append(bool(ok));print(('PASS' if ok else 'FAIL'),name,detail)
with sync_playwright() as p:
    b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    page=b.new_page(viewport={'width':1440,'height':900});errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
    st,h=load(page,'/');ck('EN home published response',st==200 and page.locator('h1').inner_text()=='Fixture home');ck('EN LTR',page.locator('html').get_attribute('dir')=='ltr')
    ck('published media uses frontend seam',page.locator('#main img.published-media').count()==1 and page.locator('#main img.published-media').get_attribute('src')=='/media/media_fixture_001')
    ck('opaque R2 key not exposed', 'r2_object_key' not in page.content() and 'opaque-object-001' not in page.content())
    mega=page.locator('[data-action="mega"]');ck('Personal target exists',mega.get_attribute('aria-controls')=='personal-mega' and page.locator('#personal-mega').count()==1);mega.click();ck('Personal opens',page.locator('[data-action="mega"]').get_attribute('aria-expanded')=='true');page.keyboard.press('Escape');ck('Personal closes Escape',page.locator('[data-action="mega"]').get_attribute('aria-expanded')=='false');ck('Personal focus restored',page.evaluate("document.activeElement===document.querySelector('[data-action=mega]')"))
    st,h=load(page,'/ar');ck('AR independent published response',st==200 and page.locator('html').get_attribute('dir')=='rtl' and 'صفحة' in page.locator('h1').inner_text())
    for width in (1440,768,390):
        for route in ('/','/personal','/students','/student/toolbox','/student/workspace','/student/majors'):
            page.set_viewport_size({'width':width,'height':900 if width>390 else 844});st,h=load(page,route);ov=page.evaluate('document.documentElement.scrollWidth-window.innerWidth');ck(f'EN no overflow {width} {route}',st==200 and ov<=1,str(ov))
        st,h=load(page,'/ar');ov=page.evaluate('document.documentElement.scrollWidth-window.innerWidth');ck(f'AR no overflow {width}',st==200 and ov<=1,str(ov))
    st,h=load(page,'/client-login');txt=page.locator('#main').inner_text().lower();ck('client login truthful',st==200 and 'no credentials' in txt and page.locator('input[type=password]').count()==0)
    st,h=load(page,'/');before=page.locator('h1').inner_text();oldetag=h.get('etag') or h.get('ETag');control('/__test/publish-home?n=2&heading=Browser%20Published%20Update');st,h2=load(page,'/');after=page.locator('h1').inner_text();newetag=h2.get('etag') or h2.get('ETag');ck('published update visible without rebuild',before!=after and after=='Browser Published Update' and oldetag!=newetag)
    control('/__test/draft-home');st,h3=load(page,'/');ck('draft-only update invisible',page.locator('h1').inner_text()==after and (h3.get('etag') or h3.get('ETag'))==newetag)
    control('/__test/disable-ar');st,h=load(page,'/ar');ck('missing locale no fallback',st==404 and 'not published' in page.locator('body').inner_text().lower())
    control('/__test/fail-api?on=1');st,h=load(page,'/');ck('backend failure controlled',st==503 and 'temporarily unavailable' in page.locator('body').inner_text().lower());control('/__test/fail-api?on=0')
    ck('zero uncaught runtime errors',not errs,' | '.join(errs))
    b.close()
if not all(checks):sys.exit(1)
print('P1_FE02_BROWSER_PARITY_PASS')
