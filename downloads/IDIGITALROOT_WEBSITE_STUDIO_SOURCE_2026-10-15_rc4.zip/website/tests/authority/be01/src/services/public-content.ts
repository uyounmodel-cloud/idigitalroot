import type {D1Database} from '../core/types.js';
import {ApiError,boundedInt,normalizePublicPath} from '../core/http.js';
import {SITE_PROFILE} from '../site-profile/config.js';

type Row=Record<string,any>;
async function publishedRevision(db:D1Database,entityId:string,locale:string):Promise<Row>{
 const row=await db.prepare(`SELECT ce.entity_id,ce.entity_type,ce.stable_key,cr.revision_id,cr.revision_number,cr.content_json,cr.content_hash_sha256,pp.pointer_version,pp.published_at
 FROM content_entities ce JOIN publication_pointers pp ON pp.entity_id=ce.entity_id AND pp.locale_code=?
 JOIN content_revisions cr ON cr.revision_id=pp.revision_id AND cr.entity_id=ce.entity_id AND cr.locale_code=pp.locale_code
 JOIN content_locale_state cls ON cls.entity_id=ce.entity_id AND cls.locale_code=pp.locale_code
 WHERE ce.entity_id=? AND ce.archived_at IS NULL AND pp.is_published=1 AND cls.translation_state='PUBLISHED' AND cr.workflow_state='READY' AND cr.validation_state='VALID'`).bind(locale,entityId).first<Row>();
 if(!row) throw new ApiError(404,'NOT_FOUND','Published content was not found.');
 if(row.entity_type==='LEGAL_DOCUMENT'){const legal=await db.prepare("SELECT 1 AS approved FROM legal_documents WHERE entity_id=? AND approval_gate_state='APPROVED'").bind(entityId).first<Row>();if(!legal)throw new ApiError(404,'NOT_FOUND','Published content was not found.');}
 const badMedia=await db.prepare(`SELECT COUNT(*) AS n FROM revision_media_refs r JOIN media_assets ma ON ma.media_id=r.media_id LEFT JOIN media_objects mo ON mo.media_id=ma.media_id AND mo.object_state='APPROVED_PUBLIC' LEFT JOIN media_external_sources mes ON mes.media_id=ma.media_id LEFT JOIN embed_providers ep ON ep.provider_id=mes.provider_id AND ep.enabled=1 WHERE r.content_revision_id=? AND r.required=1 AND (ma.approval_state<>'APPROVED' OR ma.archived_at IS NOT NULL OR (ma.source_class='LOCAL_UPLOAD' AND mo.media_object_id IS NULL) OR (ma.source_class='EXTERNAL_EMBED' AND ep.provider_id IS NULL))`).bind(row.revision_id).first<{n:number}>();
 if((badMedia?.n||0)>0) throw new ApiError(404,'NOT_FOUND','Published content was not found.');
 const badDeps=await db.prepare(`SELECT COUNT(*) AS n FROM revision_dependencies d
 LEFT JOIN content_revisions pinned ON pinned.revision_id=d.dependency_revision_id
 LEFT JOIN content_entities dep ON dep.entity_id=d.dependency_entity_id AND dep.archived_at IS NULL
 LEFT JOIN publication_pointers pp ON pp.entity_id=dep.entity_id AND pp.locale_code=COALESCE(pinned.locale_code,?) AND pp.is_published=1
 LEFT JOIN content_revisions current ON current.revision_id=pp.revision_id AND current.entity_id=dep.entity_id AND current.locale_code=pp.locale_code AND current.workflow_state='READY' AND current.validation_state='VALID'
 LEFT JOIN content_locale_state cls ON cls.entity_id=dep.entity_id AND cls.locale_code=pp.locale_code AND cls.translation_state='PUBLISHED'
 LEFT JOIN legal_documents legal ON legal.entity_id=dep.entity_id
 WHERE d.content_revision_id=? AND d.required=1 AND (dep.entity_id IS NULL OR current.revision_id IS NULL OR cls.entity_id IS NULL OR (d.dependency_revision_id IS NOT NULL AND pp.revision_id<>d.dependency_revision_id) OR (d.dependency_kind='LEGAL' AND (legal.entity_id IS NULL OR legal.approval_gate_state<>'APPROVED')))`).bind(locale,row.revision_id).first<{n:number}>();
 if((badDeps?.n||0)>0) throw new ApiError(404,'NOT_FOUND','Published content was not found.');
 return row;
}
async function mediaForRevision(db:D1Database,revisionId:string,locale:string){
 const r=await db.prepare(`SELECT ma.media_id,ma.media_kind,ma.source_class,ma.detected_mime,ma.width_px,ma.height_px,mlr.title,mlr.alt_text,r.usage_role
 FROM revision_media_refs r JOIN media_assets ma ON ma.media_id=r.media_id AND ma.approval_state='APPROVED' AND ma.archived_at IS NULL
 LEFT JOIN media_objects mo ON mo.media_id=ma.media_id AND mo.object_state='APPROVED_PUBLIC'
 LEFT JOIN media_localized_revisions mlr ON mlr.media_localized_revision_id=r.media_localized_revision_id AND mlr.locale_code=?
 WHERE r.content_revision_id=? AND ((ma.source_class='LOCAL_UPLOAD' AND mo.media_object_id IS NOT NULL) OR (ma.source_class='EXTERNAL_EMBED' AND EXISTS(SELECT 1 FROM media_external_sources mes JOIN embed_providers ep ON ep.provider_id=mes.provider_id AND ep.enabled=1 WHERE mes.media_id=ma.media_id))) ORDER BY r.usage_role,ma.media_id`).bind(locale,revisionId).all<Row>();
 return r.results||[];
}
export async function resolveRoute(db:D1Database,locale:string,rawPath:string){const path=normalizePublicPath(rawPath); const r=await db.prepare(`SELECT rp.route_id,rp.path,ce.entity_id FROM route_paths rp JOIN routes ro ON ro.route_id=rp.route_id AND ro.archived_at IS NULL JOIN content_entities ce ON ce.route_id=ro.route_id AND ce.archived_at IS NULL WHERE rp.locale_code=? AND rp.path=? AND rp.is_active=1 AND rp.is_canonical=1`).bind(locale,path).first<Row>(); if(!r){const article=/^\/knowledge\/([A-Za-z0-9._~-]{1,160})$/.exec(path);if(article){const data=await getKnowledge(db,locale,article[1]!);return {routeId:`knowledge:${data.entity.id}`,path,entityId:data.entity.id,locale};}throw new ApiError(404,'NOT_FOUND','Published route was not found.');} await publishedRevision(db,r.entity_id,locale); return {routeId:r.route_id,path:r.path,entityId:r.entity_id,locale};}
export async function getPublicEntity(db:D1Database,entityId:string,locale:string){const r=await publishedRevision(db,entityId,locale); const sections=await db.prepare(`SELECT prs.section_instance_id,cf.component_key,prs.ordinal,prs.visible,prs.variant_key,prs.config_json,prs.localized_content_json FROM page_revision_sections prs JOIN component_families cf ON cf.component_family_id=prs.component_family_id WHERE prs.content_revision_id=? AND prs.visible=1 ORDER BY prs.ordinal,prs.section_instance_id`).bind(r.revision_id).all<Row>(); return {entity:{id:r.entity_id,type:r.entity_type,key:r.stable_key,locale,revisionNumber:r.revision_number,content:JSON.parse(r.content_json)},sections:(sections.results||[]).map(s=>({id:s.section_instance_id,component:s.component_key,ordinal:s.ordinal,variant:s.variant_key,config:JSON.parse(s.config_json),content:JSON.parse(s.localized_content_json)})),media:await mediaForRevision(db,r.revision_id,locale),version:{pointer:r.pointer_version,contentHash:r.content_hash_sha256,publishedAt:r.published_at}};}
export async function getSet(db:D1Database,kind:'navigation'|'footer',key:string,locale:string){const table=kind==='navigation'?'navigation_sets':'footer_sets'; const keycol=kind==='navigation'?'navigation_key':'footer_key'; const row=await db.prepare(`SELECT entity_id FROM ${table} WHERE ${keycol}=?`).bind(key).first<Row>(); if(!row) throw new ApiError(404,'NOT_FOUND',`${kind} was not found.`); return getPublicEntity(db,row.entity_id,locale);}
export async function listKnowledge(db:D1Database,locale:string,term:string|null,limitRaw:string|null,offsetRaw:string|null){const limit=boundedInt(limitRaw,20,1,SITE_PROFILE.knowledgeMaxPageSize),offset=boundedInt(offsetRaw,0,0,10000); const termJoin=term?`JOIN content_taxonomy_assignments cta ON cta.entity_id=ce.entity_id JOIN taxonomy_terms tt ON tt.term_id=cta.term_id AND tt.state='ACTIVE' JOIN taxonomy_term_localizations ttl ON ttl.term_id=tt.term_id AND ttl.locale_code=? AND ttl.slug=?`:''; const binds:any[]=term?[locale,locale,term,limit,offset]:[locale,limit,offset]; const sql=`SELECT kr.knowledge_key,kr.knowledge_kind,ce.entity_id,cr.content_json,pp.published_at FROM knowledge_records kr JOIN content_entities ce ON ce.entity_id=kr.entity_id AND ce.archived_at IS NULL JOIN publication_pointers pp ON pp.entity_id=ce.entity_id AND pp.locale_code=? AND pp.is_published=1 JOIN content_revisions cr ON cr.revision_id=pp.revision_id AND cr.workflow_state='READY' AND cr.validation_state='VALID' JOIN content_locale_state cls ON cls.entity_id=ce.entity_id AND cls.locale_code=pp.locale_code AND cls.translation_state='PUBLISHED' ${termJoin} ORDER BY pp.published_at DESC,kr.knowledge_key LIMIT ? OFFSET ?`; const rr=await db.prepare(sql).bind(...binds).all<Row>(); return {items:(rr.results||[]).map(x=>({key:x.knowledge_key,kind:x.knowledge_kind,entityId:x.entity_id,content:JSON.parse(x.content_json),publishedAt:x.published_at})),limit,offset};}
export async function getKnowledge(db:D1Database,locale:string,key:string){const r=await db.prepare('SELECT entity_id FROM knowledge_records WHERE knowledge_key=?').bind(key).first<Row>(); if(!r) throw new ApiError(404,'NOT_FOUND','Published article was not found.'); return getPublicEntity(db,r.entity_id,locale);}
export async function getLegal(db:D1Database,locale:string,code:string){const r=await db.prepare("SELECT ld.entity_id FROM legal_documents ld WHERE ld.legal_code=? AND ld.approval_gate_state='APPROVED'").bind(code).first<Row>(); if(!r) throw new ApiError(404,'NOT_FOUND','Published legal document was not found.'); return getPublicEntity(db,r.entity_id,locale);}


export async function getPublicMediaObject(db:D1Database,mediaId:string){
 const row=await db.prepare(`SELECT ma.media_id,ma.detected_mime,ma.declared_mime,ma.size_bytes,ma.width_px,ma.height_px,mo.r2_object_key,mo.checksum_sha256
 FROM media_assets ma JOIN media_objects mo ON mo.media_id=ma.media_id AND mo.object_state='APPROVED_PUBLIC'
 WHERE ma.media_id=? AND ma.approval_state='APPROVED' AND ma.archived_at IS NULL AND ma.source_class='LOCAL_UPLOAD'
 ORDER BY CASE mo.object_role WHEN 'DERIVATIVE' THEN 0 WHEN 'ORIGINAL' THEN 1 WHEN 'PREVIEW' THEN 2 ELSE 3 END, mo.media_object_id LIMIT 1`).bind(mediaId).first<Row>();
 if(!row)throw new ApiError(404,'NOT_FOUND','Published media was not found.');
 const mime=String(row.detected_mime||row.declared_mime||'').toLowerCase();if(!['image/png','image/jpeg','image/webp','image/gif','image/avif','application/pdf'].includes(mime))throw new ApiError(404,'NOT_FOUND','Published media was not found.');
 return {mediaId:String(row.media_id),objectKey:String(row.r2_object_key),mime,sizeBytes:row.size_bytes==null?null:Number(row.size_bytes),widthPx:row.width_px==null?null:Number(row.width_px),heightPx:row.height_px==null?null:Number(row.height_px),checksum:row.checksum_sha256?String(row.checksum_sha256):null};
}

function approvedExternalRedirect(raw:string){try{const u=new URL(raw);return u.protocol==='https:'&&!u.username&&!u.password&&!!u.hostname&&SITE_PROFILE.externalRedirectHosts.includes(u.hostname.toLowerCase())}catch{return false}}

export async function resolveRedirect(db:D1Database,locale:string,rawPath:string){
 const source=normalizePublicPath(rawPath), now=new Date().toISOString();
 const seen=new Set<string>(); let path=source;
 for(let depth=0;depth<8;depth++){
   if(seen.has(path))throw new ApiError(404,'NOT_FOUND','Published route was not found.');seen.add(path);
   const r=await db.prepare(`SELECT redirect_id,destination_kind,destination_value,status_code FROM http_redirects
     WHERE locale_code=? AND source_path=? AND active=1 AND (starts_at IS NULL OR starts_at<=?) AND (ends_at IS NULL OR ends_at>?)
     ORDER BY updated_at DESC LIMIT 1`).bind(locale,path,now,now).first<Row>();
   if(!r)return null;
   if(r.destination_kind==='HTTPS'){if(!approvedExternalRedirect(String(r.destination_value)))throw new ApiError(404,'NOT_FOUND','Published route was not found.');return {redirectId:r.redirect_id,statusCode:r.status_code,location:r.destination_value,external:true}};
   const dest=normalizePublicPath(r.destination_value);
   const canonical=await db.prepare(`SELECT rp.route_id,rp.path,ce.entity_id FROM route_paths rp JOIN routes ro ON ro.route_id=rp.route_id AND ro.archived_at IS NULL JOIN content_entities ce ON ce.route_id=ro.route_id AND ce.archived_at IS NULL WHERE rp.locale_code=? AND rp.path=? AND rp.is_active=1 AND rp.is_canonical=1`).bind(locale,dest).first<Row>();
   if(canonical){await publishedRevision(db,canonical.entity_id,locale);return {redirectId:r.redirect_id,statusCode:r.status_code,location:dest,external:false}}
   path=dest;
 }
 throw new ApiError(404,'NOT_FOUND','Published route was not found.');
}

export async function publicSearch(db:D1Database,locale:string,rawQuery:string,limitRaw:string|null,offsetRaw:string|null){
 const q=rawQuery.trim().replace(/\s+/g,' ').slice(0,120);if(q.length<2)throw new ApiError(400,'INVALID_SEARCH','Search query is too short.');
 const limit=boundedInt(limitRaw,12,1,30),offset=boundedInt(offsetRaw,0,0,1000),like=`%${q.toLowerCase().replace(/[\\%_]/g,'')}%`;
 const rows=await db.prepare(`SELECT ce.entity_id,ce.entity_type,ce.stable_key,cr.content_json,pp.published_at,
   CASE WHEN lower(ce.stable_key)=lower(?) THEN 0 WHEN lower(ce.stable_key) LIKE ? THEN 1 ELSE 2 END rank_class
   FROM content_entities ce
   JOIN publication_pointers pp ON pp.entity_id=ce.entity_id AND pp.locale_code=? AND pp.is_published=1
   JOIN content_revisions cr ON cr.revision_id=pp.revision_id AND cr.entity_id=ce.entity_id AND cr.locale_code=pp.locale_code AND cr.workflow_state='READY' AND cr.validation_state='VALID'
   JOIN content_locale_state cls ON cls.entity_id=ce.entity_id AND cls.locale_code=pp.locale_code AND cls.translation_state='PUBLISHED'
   LEFT JOIN service_records sr ON sr.entity_id=ce.entity_id
   WHERE ce.archived_at IS NULL AND (
     ce.entity_type IN ('PAGE','KNOWLEDGE_ARTICLE') OR (ce.entity_type='SERVICE' AND sr.availability_state='AVAILABLE')
   ) AND (lower(ce.stable_key) LIKE ? OR lower(cr.content_json) LIKE ?)
   ORDER BY rank_class ASC, pp.published_at DESC, ce.stable_key ASC, ce.entity_id ASC LIMIT ? OFFSET ?`)
   .bind(q,like,locale,like,like,limit,offset).all<Row>();
 const n=(rows.results||[]).length;const resultCountClass=n===0?'ZERO':n===1?'ONE':n<=5?'TWO_TO_FIVE':n<=20?'SIX_TO_TWENTY':'TWENTY_PLUS';const queryLengthClass=q.length<=12?'SHORT':q.length<=40?'MEDIUM':'LONG';return {items:(rows.results||[]).map(x=>{const c=JSON.parse(x.content_json);return {entityId:x.entity_id,type:x.entity_type,key:x.stable_key,title:typeof c.title==='string'?c.title:(typeof c.heading==='string'?c.heading:x.stable_key),description:typeof c.description==='string'?c.description:undefined,publishedAt:x.published_at}}),limit,offset,queryAccepted:true,analytics:{eventKey:'internal_search',resultCountClass,queryLengthClass}};
}
