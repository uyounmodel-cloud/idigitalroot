from pathlib import Path
import hashlib, json, sys
ROOT=Path(__file__).resolve().parents[1]
fail=[]
def ok(c,m):
    print(('PASS ' if c else 'FAIL ')+m)
    if not c: fail.append(m)
pkg=json.loads((ROOT/'package.json').read_text())
ok(pkg.get('dependencies',{}).get('astro')=='7.3.5','Astro exact pin 7.3.5')
ok(pkg.get('dependencies',{}).get('@astrojs/cloudflare')=='14.3.3','official Cloudflare adapter exact pin 14.3.3')
ok(pkg.get('devDependencies',{}).get('typescript')=='5.8.3','TypeScript exact pin 5.8.3')
ok(pkg.get('devDependencies',{}).get('wrangler')=='4.151.0','Wrangler exact pin 4.151.0')
ok((ROOT/'package-lock.json').exists(),'deterministic package lock present')
allow=pkg.get('allowScripts',{})
expected_allow={'esbuild@0.28.2':True,'workerd@1.20261012.1':True}

ok(allow==expected_allow,'install-script approvals are exact and pinned to required esbuild/workerd versions')

config=(ROOT/'astro.config.mjs').read_text(); wr=(ROOT/'wrangler.jsonc').read_text()
ok("output: 'server'" in config and "cloudflare({ imageService: 'passthrough' })" in config and "session: false" in config,'Astro server output uses official Cloudflare adapter')
ok('@astrojs/cloudflare/entrypoints/server' in wr and 'nodejs_compat' in wr,'Astro 6+/7 unified Workers SSR entrypoint and compatibility configured')
ok((ROOT/'public/.assetsignore').read_text().strip().splitlines()==['_worker.js','_routes.json'],'Cloudflare assets ignore boundary present')
src='\n'.join(p.read_text(errors='ignore') for p in (ROOT/'src').rglob('*') if p.is_file())
ok('/api/cms/v1' not in src,'no CMS API path in frontend source')
ok('prepare(' not in src and 'SELECT ' not in src and 'INSERT ' not in src and 'UPDATE ' not in src,'no direct SQL/D1 queries in frontend source')
ok('/api/public/v1/route' in src and '/api/public/v1/content/' in src,'published route/content API binding present')
ok('/api/public/v1/navigation/' in src and '/api/public/v1/footer/' in src,'navigation/footer public binding present')
ok('/api/public/v1/knowledge' in src and '/api/public/v1/legal/' in src and '/api/public/v1/inquiry-definition' in src,'knowledge/legal/inquiry definition public bindings present')
ok('/api/public/v1/inquiries' in src,'accepted live inquiry seam is connected')
ok('/api/analytics/v1/events' in src and 'COOKIELESS' in src,'bounded opt-in browser analytics seam is connected')
ok("getSecret('IDR_PUBLIC_API_BASE_URL')" in src and "getSecret('IDR_PUBLIC_SITE_ORIGIN')" in src,'public API/site origin injected at server runtime')
ok('UNKNOWN_COMPONENT' in src,'unknown components fail closed')
ok('no-store' in src and 'noindex,nofollow' in src,'controlled public failure response present')
ok('r2_object_key' not in src and 'opaque-object' not in src,'frontend source does not expose R2 object keys')
ok('/media/' in src and '/api/public/v1/media/' in src,'same-origin public media seam present')
be=ROOT/'tests/authority/be01/SHA256SUMS.txt'; ok(be.exists(),'bounded BE public integration authority checksum manifest present')
# Core migration lineage count remains frozen at 16 in integration authority.
migs=sorted((ROOT/'tests/authority/be01/schema/core/migrations').glob('*.sql'))
ok(len(migs)==16 and migs[0].name.startswith('0001_') and migs[-1].name.startswith('0016_'),'Core migration lineage remains exactly 0001-0016')
if fail: sys.exit(1)
print('P1_FE02_SOURCE_GATE_PASS')
