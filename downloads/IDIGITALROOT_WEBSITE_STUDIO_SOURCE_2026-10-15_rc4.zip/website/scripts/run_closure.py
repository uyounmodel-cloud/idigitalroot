#!/usr/bin/env python3
"""Local-only acceptance runner. Run from a fresh extraction; never deploys."""
import argparse, hashlib, json, os, pathlib, shutil, signal, subprocess, sys, time, urllib.request

p = argparse.ArgumentParser()
p.add_argument('--evidence-dir', required=True)
p.add_argument('--node', default=shutil.which('node'))
p.add_argument('--backend-node', required=True)
p.add_argument('--browser', default=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or shutil.which('google-chrome'))
a = p.parse_args()
root = pathlib.Path(__file__).resolve().parents[1]
out = pathlib.Path(a.evidence_dir).resolve()
out.mkdir(parents=True, exist_ok=True)
node = pathlib.Path(a.node).resolve()
version = subprocess.check_output([str(node), '-p', 'process.versions.node'], text=True).strip()
if version != '22.19.0':
    sys.exit('BLOCKED: use isolated frontend Node 22.19.0; no host upgrade needed.')
backend_node=pathlib.Path(a.backend_node).resolve()
backend_version=subprocess.check_output([str(backend_node),'-p','process.versions.node'],text=True).strip()
if backend_version != '22.16.0':
    sys.exit('BLOCKED: the accepted backend requires its unchanged isolated Node 22.16.0 toolchain.')
if not a.browser or not pathlib.Path(a.browser).exists():
    sys.exit('BLOCKED: a Linux Chromium executable is required; set --browser to an existing verified installation.')
env = os.environ.copy()
env.update(PATH=str(node.parent)+os.pathsep+str(root/'node_modules/.bin')+os.pathsep+env['PATH'],
           ASTRO_TELEMETRY_DISABLED='1', WRANGLER_SEND_METRICS='false',
           XDG_CONFIG_HOME=str(out/'config'), XDG_CACHE_HOME=str(out/'cache'),
           npm_config_cache=str(out/'npm-cache'),
           CHROMIUM_PATH=a.browser, EVIDENCE_DIR=str(out/'browser'))
for k in ['XDG_CONFIG_HOME', 'XDG_CACHE_HOME']:
    pathlib.Path(env[k]).mkdir(parents=True, exist_ok=True)
npm = str(backend_node.parent/'npm')
backend_env={**env,'PATH':str(backend_node.parent)+os.pathsep+str(root/'node_modules/.bin')+os.pathsep+os.environ['PATH']}
steps = []
def run(name, cmd, cwd=root, run_env=env):
    with (out/(name+'.log')).open('w') as log:
        result = subprocess.run(cmd, cwd=cwd, env=run_env, stdout=log, stderr=subprocess.STDOUT)
    steps.append({'name':name, 'command':cmd, 'exit_code':result.returncode})
    print(('PASS ' if result.returncode == 0 else 'FAIL ')+name, flush=True)
    (out/'steps.json').write_text(json.dumps(steps, indent=2)+'\n')
    if result.returncode:
        raise RuntimeError(name+' failed; see '+str(out/(name+'.log')))

def ready(url, process, marker=None):
    deadline = time.monotonic()+45
    while time.monotonic()<deadline:
        if process.poll() is not None: raise RuntimeError('Service exited during startup')
        try:
            with urllib.request.urlopen(url, timeout=1) as r:
                body = r.read().decode()
                if r.status == 200 and (marker is None or marker in body): return
        except Exception: pass
        time.sleep(.2)
    raise RuntimeError('Service readiness failed: '+url)

processes = []
logs = []
try:
    run('source-checksums', ['sha256sum', '--check', 'SHA256SUMS.txt'])
    run('clean-install', [npm, 'ci', '--engine-strict', '--no-audit', '--no-fund'])
    run('source-gates', [sys.executable, 'scripts/verify_source.py'])
    run('static-scan', [str(node), 'tests/static-scan.mjs'])
    # Local-only values; this fresh extraction has no production configuration.
    devvars = root/'.dev.vars'
    if devvars.exists(): raise RuntimeError('Refusing to overwrite existing .dev.vars; use a fresh extraction')
    devvars.write_text('IDR_PUBLIC_API_BASE_URL="http://127.0.0.1:4388"\nIDR_PUBLIC_SITE_ORIGIN="http://127.0.0.1:4400"\n')
    run('astro-check', [npm, 'run', 'check'])
    run('workers-build', [npm, 'run', 'build'])
    run('binding-boundary', [sys.executable, 'scripts/check_worker_bindings.py'])
    be = root/'tests/authority/be01'
    run('backend-clean-install', [npm, 'ci', '--ignore-scripts'], be, backend_env)
    run('backend-pinned-toolchain', [npm, 'run', 'install:verify'], be, backend_env)
    run('backend-check', [npm, 'run', 'check'], be, backend_env)
    run('backend-build', [npm, 'run', 'build'], be, backend_env)
    run('backend-tests', [npm, 'test'], be, backend_env)
    run('integration-compile', [str(root/'node_modules/.bin/tsc'), '-p', 'tsconfig.fe02.json', '--pretty', 'false'])
    run('runtime-adversarial-tests', [str(node), '--test', 'tests/runtime-contract.test.mjs'])
    for name, cmd in [('published-api', [str(backend_node), 'tests/integration-server.mjs']),
                      ('workerd-preview', [str(node), 'node_modules/.bin/astro', 'preview', '--ignore-lock', '--host', '127.0.0.1', '--port', '4400'])]:
        log = (out/(name+'.log')).open('w'); logs.append(log)
        proc = subprocess.Popen(cmd, cwd=root, env=backend_env if name=='published-api' else env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        processes.append(proc)
        ready('http://127.0.0.1:4388/api/public/v1/route?locale=en' if name=='published-api' else 'http://127.0.0.1:4400/', proc, 'Fixture home' if name=='workerd-preview' else 'rt_fixture_home_001')
    run('built-browser', [str(node), 'tests/built-published-acceptance.mjs'])
    report=json.loads((out/'browser/browser-checks.json').read_text())
    if not report['checks'] or report['failed']: raise RuntimeError('Browser evidence missing or failed')
    run('final-source-checksums', ['sha256sum', '--check', 'SHA256SUMS.txt'])
    (out/'outcome.json').write_text(json.dumps({'status':'PASS','scope':'Local FE-02 engineering gates; no owner/provider/release acceptance implied','node':version,'backend_node':backend_version,'npm':subprocess.check_output([npm,'--version'],env=env,text=True).strip(),'browser':subprocess.check_output([a.browser,'--version'],text=True).strip(),'browser_passed':report['passed'],'source_checksums_sha256':hashlib.sha256((root/'SHA256SUMS.txt').read_bytes()).hexdigest()},indent=2)+'\n')
    print('LOCAL_FE02_CLOSURE_PASS', flush=True)
except Exception as error:
    (out/'outcome.json').write_text(json.dumps({'status':'FAIL','reason':str(error)},indent=2)+'\n')
    print(str(error), file=sys.stderr)
    sys.exit(1)
finally:
    for proc in reversed(processes):
        if proc.poll() is None:
            os.killpg(proc.pid,signal.SIGTERM)
            try: proc.wait(timeout=10)
            except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGKILL); proc.wait()
    for log in logs: log.close()
