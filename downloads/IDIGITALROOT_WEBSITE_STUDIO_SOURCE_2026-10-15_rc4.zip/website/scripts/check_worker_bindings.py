import json
from pathlib import Path
config=json.loads(Path('dist/server/wrangler.json').read_text())
for key in ['d1_databases','r2_buckets','kv_namespaces','images']:
    assert not config.get(key), f'Unexpected privileged/optional public frontend binding: {key}'
assert config.get('assets',{}).get('binding')=='ASSETS'
print('PASS built public frontend uses ASSETS only; D1/R2 remain behind the backend, with no automatic KV/Images provisioning')
