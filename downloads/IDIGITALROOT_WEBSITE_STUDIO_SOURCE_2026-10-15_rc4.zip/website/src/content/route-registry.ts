import { KNOWLEDGE, ROUTE_DATA, SERVICES, WIZ } from './frozen-fixtures.js';

export const PRIMARY_PERSONAL_ROUTES = [
  '/',
  '/personal',
  '/students',
  '/student/toolbox',
  '/student/workspace',
  '/student/majors',
  '/not-a-student',
] as const;

export const SUPPORTING_STATIC_ROUTES = [
  '/why-idigitalroot',
  '/what-you-get',
  '/services',
  '/how-we-build',
  '/knowledge',
  '/knowledge/insights',
  '/knowledge/guides',
  '/knowledge/digital-future',
  '/knowledge/research',
  '/knowledge/stories',
  '/knowledge/news',
  '/company/about',
  '/company/trust',
  '/contact',
  '/pricing',
  '/legal/terms',
  '/legal/privacy',
  '/legal/cookies',
  '/search',
  '/root-check',
  '/root-check/methodology',
  '/inquiry',
  '/inquiry/received',
  '/client-login',
] as const;

export const COMPATIBILITY_ROOT_ROUTES = [
  '/solutions',
  '/solutions/personal',
  '/solutions/students',
  '/solutions/legacy',
  '/blueprints',
  '/blueprints/legacy',
] as const;

// Materialize every historical broad-product path present in the approved v4.3
// fixture corpus, but render it only through the bounded compatibility policy in
// client.ts. This prevents static output from accidentally exposing the old
// Business/industry presentation while still giving known legacy URLs a safe
// destination.
export const HISTORICAL_COMPATIBILITY_ROUTES = ROUTE_DATA
  .map((entry) => entry.route)
  .filter((route) => route === '/solutions' || route.startsWith('/solutions/') || route === '/blueprints' || route.startsWith('/blueprints/'));

export const COMPATIBILITY_ROUTES = Array.from(new Set([
  ...COMPATIBILITY_ROOT_ROUTES,
  ...HISTORICAL_COMPATIBILITY_ROUTES,
])) as readonly string[];

export const SERVICE_DETAIL_ROUTES = SERVICES.map((service) => `/services/${service.id}` as const);
export const KNOWLEDGE_ARTICLE_ROUTES = KNOWLEDGE.map((article) => `/knowledge/${article.slug}` as const);
export const INQUIRY_STEP_ROUTES = WIZ.map((step) => `/inquiry/${step.slug}` as const);

export const PHASE1B_ROUTES = Array.from(new Set([
  ...PRIMARY_PERSONAL_ROUTES,
  ...SUPPORTING_STATIC_ROUTES,
  ...SERVICE_DETAIL_ROUTES,
  ...KNOWLEDGE_ARTICLE_ROUTES,
  ...INQUIRY_STEP_ROUTES,
  ...COMPATIBILITY_ROUTES,
])) as readonly string[];

export type Phase1BRoute = (typeof PHASE1B_ROUTES)[number];
