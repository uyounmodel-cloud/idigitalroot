import { getSecret } from 'astro:env/server';
import { apiJson, loadPublishedPage, type ApiTransport, type Locale, type PublishedPageModel } from './runtime-public.js';

export interface PublicRuntimeConfig { apiBase:string; siteOrigin:string }
export function publicRuntimeConfig():PublicRuntimeConfig {
  const apiBase=getSecret('IDR_PUBLIC_API_BASE_URL')||'';
  const siteOrigin=getSecret('IDR_PUBLIC_SITE_ORIGIN')||'';
  if(!apiBase||!siteOrigin) throw Object.assign(new Error('PUBLIC_RUNTIME_CONFIG_MISSING'),{status:503});
  return {apiBase,siteOrigin};
}
export function parsePublicPath(url:URL):{locale:Locale;path:string}{
  let p=url.pathname||'/';
  let once:string;try{once=decodeURIComponent(p)}catch{throw Object.assign(new Error('PUBLIC_PATH_INVALID'),{status:404})} let twice=once; try{twice=decodeURIComponent(once)}catch{}
  const bad=(x:string)=>x.includes('\\')||x.includes('\0')||/(^|\/)\.\.?($|\/)/.test(x)||/%(?:2e|2f|5c)/i.test(x);
  if(bad(p)||bad(once)||bad(twice)||once!==twice) throw Object.assign(new Error('PUBLIC_PATH_INVALID'),{status:404});
  if(p==='/ar') return {locale:'ar',path:'/'};
  if(p.startsWith('/ar/')) return {locale:'ar',path:p.slice(3)||'/'};
  return {locale:'en',path:p};
}
export async function loadAstroPublicModel(request:Request,transport?:ApiTransport):Promise<PublishedPageModel>{
  const {locale,path}=parsePublicPath(new URL(request.url)); const cfg=publicRuntimeConfig();
  return loadPublishedPage(transport||{fetch:(i,init)=>fetch(i,init)},cfg.apiBase,path,locale,cfg.siteOrigin);
}
export async function proxyPublicMedia(request:Request,mediaId:string):Promise<Response>{
  const unavailable=()=>new Response('Media temporarily unavailable',{status:503,headers:{'cache-control':'no-store','x-content-type-options':'nosniff'}});
  const ctrl=new AbortController();const timer=setTimeout(()=>ctrl.abort(),4000);
  try {
  if(!/^[A-Za-z0-9._:-]{1,160}$/.test(mediaId)) return new Response('Not found',{status:404,headers:{'cache-control':'no-store'}});
  const cfg=publicRuntimeConfig(); const h=new Headers(); const inm=request.headers.get('if-none-match'); if(inm)h.set('if-none-match',inm);
  const r=await fetch(`${cfg.apiBase.replace(/\/$/,'')}/api/public/v1/media/${encodeURIComponent(mediaId)}`,{method:'GET',headers:h,redirect:'manual',signal:ctrl.signal});
  if(r.status===304)return new Response(null,{status:304,headers:{etag:r.headers.get('etag')||'','cache-control':r.headers.get('cache-control')||'public, max-age=60, must-revalidate'}});
  if(!r.ok)return new Response('Not found',{status:r.status===404?404:503,headers:{'cache-control':'no-store','x-content-type-options':'nosniff'}});
  const mime=(r.headers.get('content-type')||'').split(';')[0].trim().toLowerCase();
  if(!['image/png','image/jpeg','image/webp','image/gif','image/avif','application/pdf'].includes(mime))return unavailable();
  const out=new Headers(); for(const k of ['content-type','content-length','etag','cache-control','last-modified']){const v=r.headers.get(k);if(v)out.set(k,v)} out.set('x-content-type-options','nosniff');
  if(mime==='application/pdf')out.set('content-disposition','attachment');
  out.set('content-security-policy',"default-src 'none'; sandbox");
  return new Response(request.method==='HEAD'?null:r.body,{status:200,headers:out});
  } catch {return unavailable();}finally{clearTimeout(timer);}
}
