import { escapeHtml as e, safeText as text, safeUrl, type PublicSection, type PublicEntity } from './runtime-public.js';
import { sanitizePublishedProse } from './published-markup.js';

/** Code-owned rendering for the registered CMS families. CMS content supplies data, never code. */
export const EDITOR_COMPONENTS = new Set(['rich_text','rich-content','image','gallery','video-embed','cards','cta','feature-cards','audience-cards','service-cards','pricing-comparison','case-study','evidence-metric','process-timeline','downloadable-resource','article-research-feed','contact','personal-root-atlas','root-toolbox','major-explorer','root-convergence','managed-services','knowledge-preview']);
export const COMPONENT_ALIASES: Record<string,string> = {'personal-root-atlas':'roots','root-toolbox':'toolbox','major-explorer':'major-personalization','root-convergence':'project-to-career','managed-services':'student-foundation','knowledge-preview':'knowledge'};
const txt = (v: unknown, max=5000) => e(text(v,max));
function anchor(label: unknown, href: unknown, cls='btn primary') {const u=safeUrl(href);return u?`<a class="${cls}" href="${e(u)}">${txt(label,180)}</a>`:'';}
function image(value:any, page:PublicEntity) {const id=text(value?.mediaId||value?.media_id,160);const media=page.media.find(m=>m.media_id===id&&m.media_kind==='IMAGE'&&m.source_class==='LOCAL_UPLOAD');return media?`<img class="published-media" src="/media/${encodeURIComponent(id)}" alt="${txt(media.alt_text||media.title,500)}" loading="lazy" decoding="async">`:'';}
export function renderPublishedSection(s:PublicSection,page:PublicEntity):string {
 const c:any={...s.config,...s.content};const heading=txt(c.heading||c.title,240);const body=txt(c.description||c.summary||c.body);const items=Array.isArray(c.items)?c.items.slice(0,32):[];
 let content=heading?`<h2 class="section-title">${heading}</h2>`:'';
 if(['rich_text','rich-content'].includes(s.component)) content+=`<div class="editorial-long">${sanitizePublishedProse(text(c.text||c.body,12000))}</div>`;
 else if(s.component==='image')content+=`<figure>${image(c,page)}${c.caption?`<figcaption>${txt(c.caption)}</figcaption>`:''}</figure>`;
 else if(s.component==='gallery')content+=`<div class="published-gallery">${items.map((x:any)=>`<figure>${image(x,page)}${x.caption?`<figcaption>${txt(x.caption)}</figcaption>`:''}</figure>`).join('')}</div>`;
 else if(s.component==='cta')content+=anchor(c.label,c.href);
 else if(s.component==='video-embed') {const id=text(c.youtubeId||c.videoId,32);content+=body?`<p>${body}</p>`:'';if(/^[A-Za-z0-9_-]{11}$/.test(id))content+=anchor(c.label||c.title||'YouTube',`https://www.youtube.com/watch?v=${id}`);}
 else if(s.component==='faq')content+=items.map((x:any)=>`<details class="published-faq"><summary>${txt(x.question||x.title,500)}</summary><p>${txt(x.answer||x.body)}</p></details>`).join('');
 else {if(body)content+=`<p class="section-lead">${body}</p>`;if(items.length)content+=`<div class="content-cluster">${items.map((x:any)=>`<article class="published-card">${image(x,page)}${x.title||x.heading?`<h3>${txt(x.title||x.heading,240)}</h3>`:''}${x.description||x.body?`<p>${txt(x.description||x.body)}</p>`:''}${anchor(x.label||x.title,x.href,'published-link')}</article>`).join('')}</div>`;content+=anchor(c.label,c.href);}
 return `<section class="section-space published-section" data-cms-section="${e(s.component)}" data-section-instance="${e(s.id)}"><div class="shell">${content}</div></section>`;
}
