import {boundedBytes} from '../../bounded-response.js';
import {getSecret} from 'astro:env/server';
import {createRequestContext} from '../../request-context.js';
import type { APIRoute } from 'astro';
import {publicRuntimeConfig} from '../../server-runtime.js';
export const prerender=false;
const allowed=new Map([['/api/public/v1/search','GET'],['/api/public/v1/inquiry-definition','GET'],['/api/public/v1/inquiries','POST'],['/api/analytics/v1/events','POST']]);
export const ALL:APIRoute=async({request})=>{
 const reply=(status:number,code:string)=>new Response(JSON.stringify({ok:false,error:{code}}),{status,headers:{'content-type':'application/json','cache-control':'no-store'}});
 const u=new URL(request.url);if(allowed.get(u.pathname)!==request.method)return reply(404,'NOT_FOUND');
 const ctrl=new AbortController();const timer=setTimeout(()=>ctrl.abort(),8000);
 try{
  const cfg=publicRuntimeConfig();const h=new Headers({'accept':'application/json'});let body:Uint8Array|undefined;
  if(request.method==='POST'){
   if(request.headers.get('origin')!==cfg.siteOrigin)return reply(403,'ORIGIN_REJECTED');
   if(!(request.headers.get('content-type')||'').startsWith('application/json'))return reply(415,'UNSUPPORTED_MEDIA_TYPE');
   const length=request.headers.get('content-length');if(length&&(!/^\d{1,10}$/.test(length)||Number(length)>65536))return reply(413,'PAYLOAD_TOO_LARGE');
   const reader=request.body?.getReader();const chunks:Uint8Array[]=[];let size=0;
   if(reader){try{while(true){const r=await reader.read();if(r.done)break;size+=r.value.byteLength;if(size>65536)return reply(413,'PAYLOAD_TOO_LARGE');chunks.push(r.value)}}finally{reader.releaseLock()}}
   body=new Uint8Array(size);let offset=0;for(const x of chunks){body.set(x,offset);offset+=x.byteLength}
   h.set('content-type','application/json');h.set('origin',cfg.siteOrigin);const secret=getSecret('PUBLIC_API_CONTEXT_SECRET')||'';if(secret.length<32)return reply(503,'SERVICE_CONFIGURATION_UNAVAILABLE');h.set('x-idr-request-context',await createRequestContext(request,secret,cfg.siteOrigin));
   for(const k of ['idempotency-key','x-idr-csrf','user-agent','accept-language']){const v=request.headers.get(k);if(v)h.set(k,v.slice(0,512))}
  }
  const out=await fetch(cfg.apiBase.replace(/\/$/,'')+u.pathname+u.search,{method:request.method,headers:h,body:body as BodyInit|undefined,signal:ctrl.signal,redirect:'manual'});
  if(![200,201,202,400,403,409,413,415,422,429,503].includes(out.status))return reply(503,'SERVICE_UNAVAILABLE');
  const bytes=await boundedBytes(out,262144);
  return new Response(bytes as BodyInit,{status:out.status,headers:{'content-type':'application/json','cache-control':'no-store','x-content-type-options':'nosniff'}});
 }catch{return reply(503,'SERVICE_UNAVAILABLE')}finally{clearTimeout(timer)}
};
