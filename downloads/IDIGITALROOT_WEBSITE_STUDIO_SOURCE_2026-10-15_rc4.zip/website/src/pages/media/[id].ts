import type { APIRoute } from 'astro';
import { proxyPublicMedia } from '../../server-runtime.js';
export const prerender=false;
export const GET:APIRoute=({request,params})=>proxyPublicMedia(request,params.id||'');
export const HEAD:APIRoute=({request,params})=>proxyPublicMedia(request,params.id||'');
