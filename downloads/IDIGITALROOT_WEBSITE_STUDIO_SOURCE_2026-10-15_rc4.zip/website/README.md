> Integrated successor candidate: use ../README.md and ../docs/REPRODUCTION.md. The component history below is retained for provenance; it does not approve this successor or supersede the root verification workflow.

# iDigitalRoot Public Frontend v1.1.2 — bounded FE-02 successor

Parent candidate ZIP SHA-256: 3709a3aa234e7f1a5dbb840037b9a9c04e53ac49172b8b216bb309697f24ef95.
Owner-approved public UI v4.3 SHA-256: d10b1cff47d5912fecb49d88579971f3e21bb19a33b179e29356ea0eac5646fd.

Preserves Astro 7.3.5, official Cloudflare adapter 14.3.3, TypeScript 5.8.3 and the approved design. Adds the missing npm lock; updates Wrangler to 4.151.0 and overrides http-cache-semantics to 4.3.0 in response to advisory evidence. parse5 8.0.0 selects controlled component templates in published order and preserves Arabic internal links. No arbitrary CMS code is rendered. Published Knowledge and legal bodies replace prototype prose with bounded, sanitized content; hero/section configuration fields supply their published heading and body.

The original CMS and public backend archives remain unchanged. This candidate embeds the bounded public backend v1.1.3 (ZIP SHA-256 35daf1589f2e20c9e5251f88253312e497b57b3dfc9a1a60dcc0663af7869cbf), which resolves existing published Knowledge links without changing the accepted Core 0001–0016 / Analytics 0001–0002 migration lineages or CMS source. No deployment, provider mutation, spend or production credential use is authorized. Live inquiry POST and browser analytics remain FE-03 work; FE-02 intentionally shows a deferred submission state.

From a fresh extraction, use isolated frontend Node 22.19.0 and unchanged backend Node 22.16.0 (bundled npm 10.9.2), Linux Chromium and Python 3.11+. Run:

    python3 scripts/run_closure.py --node /path/to/node-v22.19.0-linux-x64/bin/node --backend-node /path/to/node-v22.16.0-linux-x64/bin/node --browser /usr/bin/chromium --evidence-dir /native/linux/path/evidence

The runner verifies source checksums, performs npm ci, source/static/type/build checks, checks the backend pinned toolchain and runs its tests, executes the built application under workerd and runs real browser regressions. It produces actual logs, JSON checks, screenshots and outcome.json, and stops only the local processes it starts. Read OUTCOME.md in the result bundle for verified status; this source archive alone is not PASS evidence.

Use native Ubuntu/WSL storage, not /mnt/c, for execution. Keep the existing owner workstation and Cloudflare account connection; verify `node_modules/.bin/wrangler whoami` read-only in that environment. This cloud session cannot establish its identity. No login, token entry or deployment is performed by the local runner.

Frontend tooling uses Node 22.19.0 because Astro’s pinned unifont/undici dependency requires it. Backend verification and the fixture service retain their accepted exact Node 22.16.0 toolchain. Both are isolated runtimes; the owner’s host installation is untouched. Frontend npm ci enforces engine compatibility.
