# FE v1.1.2r9 CANDIDATE

Base: sealed v1.1.2r6 SHA-256 677ea259a49364c3f4e8db976c7fa4ac60b8f86c5ba48c7e825184f15e79facd. Original approved v4.3 HTML, frozen fixtures, approved CSS, migration lineage and lockfile remain unchanged.

Bounded corrections: dynamic search/service links retain Arabic locale; search dialog restores focus and traps keyboard Tab; service-selection buttons use valid pressed semantics; clickable cards/brand/language names include visible labels; Arabic skip link is localized.

This is not multi-edition implementation or owner acceptance. Static search vs published search, generic component binding, navigation/footer structural binding, inquiry wizard/live submission, analytics collection, full contrast/visual/a11y acceptance, integrated security/QA/release and provider deployment remain open.

Root Check example handler repaired with an explicitly illustrative methodology panel; no domain is fetched and no score is invented. Real-browser regressions added for example open/close and Arabic search/focus.

Retain the approved initial selected-service highlight and accent with an active class/additive code-owned stylesheet after replacing invalid selected semantics. Frozen global.css remains byte-identical.
