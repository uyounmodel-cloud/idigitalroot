# Bounded changes from FE v1.1.1

- Preserve server-rendered published content during startup; reapply published composition during supported interactive redraws.
- Use code-owned templates in published section order, excluding omitted sections and rejecting missing/duplicate mappings.
- Preserve AR route context in internal links.
- Include public shell/locale/content dependencies in the page validator; return a bodyless conditional 304.
- Bound media fetch time, reject redirect responses, restrict executable MIME classes and keep error responses controlled.
- Add HTML security headers/CSP. Only code-owned inline style attributes require style-src unsafe-inline; arbitrary scripts/objects/frames remain prohibited. Verify provider-specific HTTPS headers separately before release.
- Generate and pin the missing lock, apply the reviewed dependency remediations and add actual closure evidence collection.
- Repair browser tests that used stale DOM handles/cached-response assumptions, add AR route/ordering/navigation/304/media-withdrawal/console regressions.

No accepted CMS/backend/migration source was changed. No owner acceptance, independent HQ verdict, owner-PC reproduction, staging verification or release readiness is claimed by this changelog.

- Explicitly disable unused public sessions and Cloudflare Images to prevent automatic KV/Images provisioning; verify the built frontend has ASSETS only.

- Localize controlled Arabic failure/read/deferred-submission copy; reject malformed path encoding as a controlled unavailable route.

- Add a bounded backend generated Knowledge route repair (v1.1.3), render only actual published Knowledge cards/detail and approved legal prose, and sanitize bounded rich text defensively. The original v1.1.2 archive remains authority/provenance; the new backend is a tested successor candidate, not an owner-approved replacement.
