from pathlib import Path
import subprocess, sys
root=Path(__file__).resolve().parents[1]
def run(*args):
    print('+',' '.join(args),flush=True)
    subprocess.run(args,cwd=root,check=True)
run(sys.executable,'scripts/verify_source.py')
run('npm','ci','--ignore-scripts','--offline')
run('npm','run','install:verify')
run('npm','run','check')
run('npm','run','build')
run('npm','test')
print('P1_BE11_LOCAL_VALIDATION_PASS')
