import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
const p=JSON.parse(fs.readFileSync('package.json','utf8'));const l=JSON.parse(fs.readFileSync('package-lock.json','utf8'));const tc=JSON.parse(fs.readFileSync('toolchain.json','utf8'));
if(l.name!==p.name||l.version!==p.version||Object.keys(l.packages||{}).some(k=>k!==''))throw new Error('lockfile mismatch');
const tv=execFileSync('tsc',['--version'],{encoding:'utf8'}).trim().replace(/^Version\s+/,''); if(tv!==tc.typescript)throw new Error(`TypeScript toolchain mismatch: ${tv}`);
const nv=process.versions.node;if(nv!==tc.node)throw new Error(`Node toolchain mismatch: ${nv}`);
console.log('LOCKFILE_AND_TOOLCHAIN_INTEGRITY_PASS');
