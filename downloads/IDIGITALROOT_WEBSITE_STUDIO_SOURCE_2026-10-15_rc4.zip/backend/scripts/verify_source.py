from pathlib import Path
import hashlib
root=Path(__file__).resolve().parents[1]
sums=root/'SHA256SUMS.txt'
if not sums.exists(): print('SOURCE_PRESEAL_MODE'); raise SystemExit(0)
for line in sums.read_text().splitlines():
    if not line.strip(): continue
    h, rel=line.split(None,1); rel=rel.strip().lstrip('*')
    if rel=='SHA256SUMS.txt': continue
    p=root/rel
    if hashlib.sha256(p.read_bytes()).hexdigest()!=h: raise SystemExit(f'CHECKSUM_MISMATCH {rel}')
print('SOURCE_CHECKSUMS_PASS')
