import {featureFlags} from './features.js';
import type {D1Database} from '../core/types.js';
const globals=new Set(['site-brand-contact-social','site-design-profile']);const product=/^(?:personal-root-|root-toolbox-|student-workspace-|major-)[a-z0-9-]{1,80}$/;
/** One bounded query; only declared public presentation properties cross this boundary. */
export async function publicPresentation(db:D1Database,locale:string){
 const rows=await db.prepare(`SELECT ce.stable_key,ce.entity_type,cr.content_json,pp.pointer_version,cr.content_hash_sha256,pp.published_at,sr.availability_state
 FROM content_entities ce JOIN publication_pointers pp ON pp.entity_id=ce.entity_id AND pp.is_published=1 AND pp.locale_code=CASE WHEN ce.stable_key='site-design-profile' THEN 'en' ELSE ? END
 JOIN content_revisions cr ON cr.revision_id=pp.revision_id AND cr.workflow_state='READY' AND cr.validation_state='VALID'
 JOIN content_locale_state cls ON cls.entity_id=ce.entity_id AND cls.locale_code=pp.locale_code
 LEFT JOIN service_records sr ON sr.entity_id=ce.entity_id
 WHERE ce.archived_at IS NULL AND ce.entity_type IN ('GLOBAL_PUBLIC_COPY','PRODUCT_RECORD','SERVICE') AND (cls.translation_state='PUBLISHED' OR (cls.translation_state IN ('DRAFT','OUTDATED','READY','NEEDS_REVIEW') AND cls.latest_revision_id<>pp.revision_id))
 AND (ce.entity_type<>'SERVICE' OR sr.availability_state IN ('AVAILABLE','UNAVAILABLE')) ORDER BY ce.stable_key LIMIT 100`).bind(locale).all<Record<string,any>>();const records=[];
 for(const row of rows.results||[]){if(row.entity_type==='GLOBAL_PUBLIC_COPY'&&!globals.has(row.stable_key)||row.entity_type==='PRODUCT_RECORD'&&!product.test(row.stable_key))continue;const raw=JSON.parse(row.content_json);const allowed=row.stable_key==='site-brand-contact-social'?['brandName','tagline','contactEmail','defaultTitle','defaultDescription','socialLinks']:row.stable_key==='site-design-profile'?['latinUi','latinAccent','arabicUi','arabicDisplay','arabicEditorial','body','lineHeight','headings','nav']:['title','description','summary'];const content=Object.fromEntries(allowed.filter(k=>raw[k]!==undefined).map(k=>[k,raw[k]]));records.push({key:row.stable_key,type:row.entity_type,content,availability:row.availability_state||undefined,version:{pointer:row.pointer_version,contentHash:row.content_hash_sha256,publishedAt:row.published_at}});}
 return {records,features:await featureFlags(db)};
}
