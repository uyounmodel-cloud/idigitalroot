import type {ApiErrorShape} from './types.js';
export const MAX_INQUIRY_BODY_BYTES = 64 * 1024;
export class ApiError extends Error { constructor(public status:number, public code:string, message:string){super(message);} }
export function jsonResponse(body:unknown,status=200,headers:Record<string,string>={}):Response {
  return new Response(JSON.stringify(body),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store',...headers}});
}
export function errorResponse(err:unknown,requestId:string):Response {
  const e = err instanceof ApiError ? err : new ApiError(500,'INTERNAL_ERROR','The request could not be completed.');
  const body:{ok:false,error:ApiErrorShape}={ok:false,error:{code:e.code,message:e.message,requestId}};
  return jsonResponse(body,e.status);
}
export async function readBoundedJson(request:Request,max=MAX_INQUIRY_BODY_BYTES):Promise<unknown>{
  const ct=(request.headers.get('content-type')||'').toLowerCase();
  if(!ct.startsWith('application/json')) throw new ApiError(415,'UNSUPPORTED_MEDIA_TYPE','Content-Type must be application/json.');
  const cl=request.headers.get('content-length');
  if(cl && Number(cl)>max) throw new ApiError(413,'PAYLOAD_TOO_LARGE','Request body is too large.');
  if(!request.body) throw new ApiError(400,'MALFORMED_JSON','A JSON body is required.');
  const reader=request.body.getReader(); const chunks:Uint8Array[]=[]; let total=0;
  try { while(true){ const {done,value}=await reader.read(); if(done) break; if(value){total+=value.byteLength; if(total>max){await reader.cancel(); throw new ApiError(413,'PAYLOAD_TOO_LARGE','Request body is too large.');} chunks.push(value);} } }
  finally { reader.releaseLock(); }
  const bytes=new Uint8Array(total); let o=0; for(const c of chunks){bytes.set(c,o);o+=c.byteLength;}
  try { return JSON.parse(new TextDecoder().decode(bytes)); } catch { throw new ApiError(400,'MALFORMED_JSON','Malformed JSON.'); }
}
export function normalizePublicPath(raw:string):string{
  let decoded:string; try{decoded=decodeURIComponent(raw);}catch{throw new ApiError(400,'INVALID_PATH','Invalid path encoding.');}
  if(decoded.includes('\\')||decoded.includes('\0')||decoded.split('/').some(x=>x==='..'||x==='.')) throw new ApiError(400,'INVALID_PATH','Invalid public path.');
  if(!decoded.startsWith('/')||decoded.includes('//')) throw new ApiError(400,'INVALID_PATH','Invalid public path.');
  if(decoded.length>2048) throw new ApiError(414,'PATH_TOO_LONG','Public path is too long.');
  return decoded;
}
export function boundedInt(v:string|null,def:number,min:number,max:number):number{const n=v===null?def:Number(v); if(!Number.isInteger(n)||n<min||n>max) throw new ApiError(400,'INVALID_PAGINATION','Invalid pagination value.'); return n;}
