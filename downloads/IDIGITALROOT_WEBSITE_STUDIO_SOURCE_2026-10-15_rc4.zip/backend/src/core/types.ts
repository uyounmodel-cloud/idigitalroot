export type SqlValue = string | number | null | ArrayBuffer | Uint8Array;
export interface D1Result<T=Record<string, unknown>> { success: boolean; results?: T[]; meta?: Record<string, unknown>; }
export interface D1PreparedStatement {
  bind(...values: SqlValue[]): D1PreparedStatement;
  first<T=Record<string, unknown>>(column?: string): Promise<T | null>;
  all<T=Record<string, unknown>>(): Promise<D1Result<T>>;
  run<T=Record<string, unknown>>(): Promise<D1Result<T>>;
}
export interface D1Database {
  prepare(sql: string): D1PreparedStatement;
  batch<T=Record<string, unknown>>(statements: D1PreparedStatement[]): Promise<D1Result<T>[]>;
}
export interface RateLimitResult { success: boolean; }
export interface RateLimiter { limit(input:{key:string}): Promise<RateLimitResult>; }
export interface R2ObjectBodyLike { body: ReadableStream<Uint8Array>; httpEtag?: string; size?: number; writeHttpMetadata?(headers:Headers):void; }
export interface R2BucketLike { get(key:string): Promise<R2ObjectBodyLike | null>; }
export interface Env {
  CORE_DB: D1Database;
  INQUIRY_RATE_LIMITER?: RateLimiter;
  PUBLIC_ORIGIN: string;
  ENVIRONMENT_KEY: string;
  RATE_LIMIT_HASH_SALT?: string;
  PUBLIC_MEDIA_BUCKET?: R2BucketLike;
}
export interface ApiErrorShape { code:string; message:string; requestId:string; }
