export const SITE_PROFILE = {
  siteKey:'idigitalroot-public',
  supportedLocales:['en','ar'] as const,
  defaultLocale:'en',
  inquiryOperationScope:'inquiry.submit',
  inquiryOutboxEventSchemaVersion:1,
  csrfHeader:'x-idr-csrf',
  csrfPublicToken:'same-site-v1',
  knowledgeMaxPageSize:50,
  externalRedirectHosts:[] as readonly string[],
} as const;
