-- P1-CMS-03 / 0016
-- Additive redirect truth + code-owned component registry parity only.

CREATE TABLE http_redirects (
  redirect_id TEXT PRIMARY KEY,
  locale_code TEXT NOT NULL REFERENCES locales(locale_code) ON UPDATE CASCADE ON DELETE RESTRICT,
  source_path TEXT NOT NULL,
  destination_kind TEXT NOT NULL CHECK (destination_kind IN ('PATH','HTTPS')),
  destination_value TEXT NOT NULL,
  status_code INTEGER NOT NULL CHECK (status_code IN (301,302,307,308)),
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  starts_at TEXT NULL CHECK (starts_at IS NULL OR substr(starts_at,-1)='Z'),
  ends_at TEXT NULL CHECK (ends_at IS NULL OR substr(ends_at,-1)='Z'),
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version>=1),
  created_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  created_at TEXT NOT NULL CHECK (substr(created_at,-1)='Z'),
  updated_by_actor_id TEXT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  updated_at TEXT NOT NULL CHECK (substr(updated_at,-1)='Z'),
  CHECK (substr(source_path,1,1)='/'),
  CHECK (
    (destination_kind='PATH' AND substr(destination_value,1,1)='/' AND source_path<>destination_value)
    OR
    (destination_kind='HTTPS' AND lower(substr(destination_value,1,8))='https://')
  ),
  CHECK (ends_at IS NULL OR starts_at IS NULL OR ends_at>starts_at)
);
CREATE UNIQUE INDEX uq_http_redirect_active_source
  ON http_redirects(locale_code,source_path) WHERE active=1;
CREATE INDEX idx_http_redirect_lookup
  ON http_redirects(locale_code,source_path,active,starts_at,ends_at);

CREATE TRIGGER trg_http_redirect_insert_guard
BEFORE INSERT ON http_redirects
BEGIN
  SELECT CASE WHEN NEW.active=1 AND EXISTS (
    SELECT 1 FROM route_paths rp WHERE rp.locale_code=NEW.locale_code AND rp.path=NEW.source_path
      AND rp.is_active=1 AND rp.is_canonical=1
  ) THEN RAISE(ABORT,'redirect source collides with canonical route') END;
  SELECT CASE WHEN NEW.destination_kind='PATH' AND NEW.active=1 AND EXISTS (
    WITH RECURSIVE chain(path,depth) AS (
      SELECT NEW.destination_value,1
      UNION ALL
      SELECT r.destination_value,depth+1 FROM http_redirects r JOIN chain c
        ON r.locale_code=NEW.locale_code AND r.source_path=c.path
       AND r.active=1 AND r.destination_kind='PATH' AND depth<32
    ) SELECT 1 FROM chain WHERE path=NEW.source_path
  ) THEN RAISE(ABORT,'redirect loop') END;
END;

CREATE TRIGGER trg_http_redirect_update_guard
BEFORE UPDATE ON http_redirects
BEGIN
  SELECT CASE WHEN NEW.active=1 AND EXISTS (
    SELECT 1 FROM route_paths rp WHERE rp.locale_code=NEW.locale_code AND rp.path=NEW.source_path
      AND rp.is_active=1 AND rp.is_canonical=1
  ) THEN RAISE(ABORT,'redirect source collides with canonical route') END;
  SELECT CASE WHEN NEW.destination_kind='PATH' AND NEW.active=1 AND EXISTS (
    WITH RECURSIVE chain(path,depth) AS (
      SELECT NEW.destination_value,1
      UNION ALL
      SELECT r.destination_value,depth+1 FROM http_redirects r JOIN chain c
        ON r.locale_code=NEW.locale_code AND r.source_path=c.path
       AND r.redirect_id<>NEW.redirect_id AND r.active=1 AND r.destination_kind='PATH' AND depth<32
    ) SELECT 1 FROM chain WHERE path=NEW.source_path
  ) THEN RAISE(ABORT,'redirect loop') END;
END;

-- G-01: additive D1 parity rows for current approved generic/current families not present in 0010.
INSERT OR IGNORE INTO component_families(component_family_id,component_key,family_type,registry_version,schema_version,max_instances_per_page,reorderable,optional,code_registered,allowed_variants_json) VALUES
('cmp_rich_content','rich-content','SECTION','v4.1-cms',1,8,1,1,1,'[]'),
('cmp_image','image','BLOCK','v4.1-cms',1,24,1,1,1,'[]'),
('cmp_gallery','gallery','SECTION','v4.1-cms',1,4,1,1,1,'[]'),
('cmp_video_embed','video-embed','BLOCK','v4.1-cms',1,8,1,1,1,'[]'),
('cmp_cta','cta','BLOCK','v4.1-cms',1,8,1,1,1,'[]'),
('cmp_feature_cards','feature-cards','SECTION','v4.1-cms',1,4,1,1,1,'[]'),
('cmp_audience_cards','audience-cards','SECTION','v4.1-cms',1,4,1,1,1,'[]'),
('cmp_service_cards','service-cards','SECTION','v4.1-cms',1,4,1,1,1,'[]'),
('cmp_pricing_comparison','pricing-comparison','SECTION','v4.1-cms',1,2,1,1,1,'[]'),
('cmp_case_study','case-study','SECTION','v4.1-cms',1,8,1,1,1,'[]'),
('cmp_evidence_metric','evidence-metric','BLOCK','v4.1-cms',1,16,1,1,1,'[]'),
('cmp_process_timeline','process-timeline','SECTION','v4.1-cms',1,4,1,1,1,'[]'),
('cmp_downloadable_resource','downloadable-resource','BLOCK','v4.1-cms',1,12,1,1,1,'[]'),
('cmp_article_research_feed','article-research-feed','SECTION','v4.1-cms',1,4,1,1,1,'[]'),
('cmp_contact','contact','SECTION','v4.1-cms',1,2,1,1,1,'[]'),
('cmp_personal_root_atlas','personal-root-atlas','SECTION','v4.1-cms',1,2,1,1,1,'[]'),
('cmp_root_toolbox','root-toolbox','SECTION','v4.1-cms',1,2,1,1,1,'[]'),
('cmp_major_explorer','major-explorer','SECTION','v4.1-cms',1,2,1,1,1,'[]'),
('cmp_root_convergence','root-convergence','SECTION','v4.1-cms',1,2,1,1,1,'[]'),
('cmp_managed_services','managed-services','SECTION','v4.1-cms',1,2,1,1,1,'[]'),
('cmp_knowledge_preview','knowledge-preview','SECTION','v4.1-cms',1,4,1,1,1,'[]'),
('cmp_rich_text','rich_text','BLOCK','v4.1-cms',1,12,1,1,1,'[]'),
('cmp_cards','cards','SECTION','v4.1-cms',1,8,1,1,1,'[]'),
('cmp_retired_legacy','retired_legacy','SECTION','v4.1-cms',1,NULL,0,1,0,'[]');
