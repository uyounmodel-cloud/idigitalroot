-- P1-CMS-02R1 / 0015
-- Durable hashed preview capability persistence. Raw bearer tokens are never stored.

CREATE TABLE IF NOT EXISTS preview_capabilities (
  token_hash TEXT PRIMARY KEY CHECK (length(token_hash)=64),
  environment_key TEXT NOT NULL,
  entity_id TEXT NOT NULL REFERENCES content_entities(entity_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  revision_id TEXT NOT NULL REFERENCES content_revisions(revision_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  locale_code TEXT NOT NULL REFERENCES locales(locale_code) ON UPDATE CASCADE ON DELETE RESTRICT,
  actor_id TEXT NOT NULL REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  session_id TEXT NOT NULL REFERENCES cms_sessions(session_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  purpose TEXT NOT NULL CHECK (purpose = 'content-preview'),
  created_at TEXT NOT NULL CHECK (substr(created_at,-1)='Z'),
  expires_at TEXT NOT NULL CHECK (substr(expires_at,-1)='Z'),
  revoked_at TEXT NULL CHECK (revoked_at IS NULL OR substr(revoked_at,-1)='Z'),
  row_version INTEGER NOT NULL DEFAULT 1 CHECK (row_version >= 1),
  UNIQUE(environment_key, entity_id, revision_id, locale_code, token_hash)
);

CREATE INDEX IF NOT EXISTS idx_preview_capability_scope ON preview_capabilities(entity_id,revision_id,locale_code,environment_key);
CREATE INDEX IF NOT EXISTS idx_preview_capability_expiry ON preview_capabilities(expires_at,revoked_at);
