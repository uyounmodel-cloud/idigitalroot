// Follow the disclosure controls introduced by the owner-directed CMS navigation.
// This opens only native <details> ancestors; it never removes hidden/disabled controls.
export async function revealAndClick(page,selector){
 await page.bringToFront();
 if(selector.startsWith('.sidebar')&&await page.$eval('.sidebar',element=>getComputedStyle(element).display==='none')){await page.click('.menu-button');await page.waitForFunction(()=>getComputedStyle(document.querySelector('.sidebar')).display!=='none')}

 await page.$eval(selector,element=>{let parent=element.parentElement;while(parent){if(parent.tagName==='DETAILS')parent.open=true;parent=parent.parentElement}});
 return page.click(selector);
}
