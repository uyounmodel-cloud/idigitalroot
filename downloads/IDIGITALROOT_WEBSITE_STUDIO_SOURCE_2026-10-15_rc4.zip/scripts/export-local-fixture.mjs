import {buildLocalReviewEnvironment} from '../cms/scripts/local-review-env.mjs';
import {seedIntegratedPublicContent} from './seed-integrated.mjs';
const {coreDb,analyticsDb,paths}=buildLocalReviewEnvironment('http://127.0.0.1:4198');seedIntegratedPublicContent(coreDb);for(const table of ['analytics_events','analytics_rollups','analytics_rollup_cursors','analytics_consent_receipts','analytics_sessions'])analyticsDb.db.exec(`DELETE FROM ${table}`);coreDb.close();analyticsDb.close();console.log(JSON.stringify(paths));
