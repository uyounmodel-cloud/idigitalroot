import fs from 'node:fs/promises';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {privatePreviewModel,privatePreviewHtml} from './private-preview-core.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
export async function renderPrivatePreview(data,coreDb,publicHandler,publicEnv){const model=await privatePreviewModel(data,coreDb,publicHandler,publicEnv);const css=(await fs.readdir(path.join(root,'website/dist/client/_astro'))).filter(x=>/^[A-Za-z0-9_.-]+\.css$/.test(x));const sprite=await fs.readFile(path.join(root,'website/src/components/IconSprite.astro'),'utf8');return privatePreviewHtml(model,data,css,sprite)}
