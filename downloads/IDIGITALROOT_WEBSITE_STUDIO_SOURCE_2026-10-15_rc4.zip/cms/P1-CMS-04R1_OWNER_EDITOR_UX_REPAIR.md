# P1-CMS-04R1 — Owner Editor UX Repair

## Trigger

Owner connected review returned `CHANGES_REQUIRED` after ordinary CMS workspaces exposed raw JSON/payload-oriented representations. The owner explicitly requires a simple, rich public-site CMS for content editors and intends the generic CMS core to be reusable for future public websites.

## Repair rule

Keep all accepted backend/data/security authority unchanged. Repair only the human-facing CMS layer so ordinary editors use visual, structured controls. Raw technical payloads may remain behind service boundaries or restricted diagnostics, but are not required for normal content management.

## Closed owner-review findings

1. Revision comparison: raw array -> readable Before/After cards.
2. Homepage chapters: technical section identity presentation -> human section cards opening the real visual editor.
3. Navigation: `Items JSON` -> ordered menu rows with label/destination/add/remove/reorder.
4. Footer: `Groups JSON` -> footer-group and link controls.
5. Localization: raw language payloads -> side-by-side EN/AR fields.
6. Visual editor: structured payload tab -> ordinary registered fields; content fields gain visual rich-text editor / safe source.
7. Media: raw detail/preview payloads -> media facts and protected visual/human preview.
8. Providers/imports: raw provider status -> provider cards and approved-host/service facts.
9. Analytics: raw connected report result -> metrics, chart bars and tables.
10. Operations: raw schedule payload -> readable schedule cards.

## Preserved gates

- No backend/schema authority change.
- No migration after Core 0016 / Analytics 0002.
- No arbitrary JavaScript/CSS/iframe/source execution.
- No browser direct D1/R2 access.
- No production/provider mutation.
- No fake successful mutations; the same accepted service endpoints remain authoritative.
- Existing future/policy gates remain truthful.

## Verification additions

Static/browser acceptance now checks that normal workspaces do not expose the prior raw payload editors/results, navigation saves through the connected service, footer/translation/provider/analytics/operations/chapters render human-facing controls, and unsafe rich markup is sanitized before draft application.
