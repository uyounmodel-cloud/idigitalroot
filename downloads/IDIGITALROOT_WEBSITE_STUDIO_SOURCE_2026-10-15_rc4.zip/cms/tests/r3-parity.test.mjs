import assert from 'node:assert/strict';
import {createLocalEnv,createProductionEnv,handleCmsRequest} from '../dist/worker.js';
import {LocalAccessVerifier} from '../dist/core/security.js';
import {NodeSqliteD1,applySchema,freshSqlitePath} from './helpers/local-d1.mjs';

let pass=0;
async function test(name,fn){try{await fn();pass++;console.log('PASS',name)}catch(e){console.error('FAIL',name,e);process.exitCode=1}}
const origin='https://cms.example.invalid';
const db=new NodeSqliteD1(freshSqlitePath('idr-r3-parity-'));applySchema(db);
const at=new Date().toISOString();
const rootRole=db.db.prepare(`SELECT role_id FROM roles WHERE role_key='CMS_ROOT_ADMIN'`).get().role_id;
db.db.exec('BEGIN');
try{
  db.db.prepare(`INSERT INTO actors(actor_id,actor_type,status,display_name,primary_email_normalized,created_at) VALUES('actor_root','HUMAN','ACTIVE','Root Admin','root@example.invalid',?)`).run(at);
  db.db.prepare(`INSERT INTO actor_security_state(actor_id,activation_state,row_version,updated_at) VALUES('actor_root','active',1,?)`).run(at);
  db.db.prepare(`INSERT INTO cms_external_identities(identity_id,actor_id,provider_key,issuer,subject,observed_email_normalized,identity_state,bound_at,row_version) VALUES('identity_root','actor_root','cloudflare_access','https://team.cloudflareaccess.com','root-sub','root@example.invalid','ACTIVE',?,1)`).run(at);
  db.db.prepare(`INSERT INTO actor_roles(actor_id,role_id,granted_at) VALUES('actor_root',?,?)`).run(rootRole,at);
  db.db.prepare(`INSERT INTO actor_role_scopes(actor_id,role_id,granted_at,scope_kind) VALUES('actor_root',?,?,'global')`).run(rootRole,at);
  db.db.exec('COMMIT');
}catch(e){db.db.exec('ROLLBACK');throw e}
const bucket={m:new Map(),async put(k,v){this.m.set(k,v)},async get(k){const v=this.m.get(k);return v?{async arrayBuffer(){return v instanceof Uint8Array?v.buffer:v}}:null},async delete(k){this.m.delete(k)}};
const analytics={async query(){return{}},async export(){return{}},async config(){return{}}};
const principal=()=>({providerKey:'cloudflare_access',issuer:'https://team.cloudflareaccess.com',subject:'root-sub',email:'root@example.invalid',issuedAt:new Date().toISOString(),expiresAt:new Date(Date.now()+8*3600_000).toISOString(),type:'app'});
const verifier=new LocalAccessVerifier({root:principal()});
let env=createProductionEnv({CORE_DB:db,MEDIA_BUCKET:bucket,PREVIEW_SECRET:'R3_TEST_SECRET_NOT_PRODUCTION_1234567890',CMS_ORIGIN:origin,accessVerifier:verifier,analytics});
let cookie='',csrf='';
async function call(path,method='GET',body,extra={},mode='normal'){
  const h={'x-local-access-fixture':'root',...extra};
  if(body!==undefined)h['content-type']='application/json';
  if(cookie)h.cookie=`__Host-idr_cms_sid=${cookie}`;
  if(!['GET','HEAD','OPTIONS'].includes(method)){
    if(!('origin' in h))h.origin=origin;
    if(mode==='normal'&&csrf)h['X-CSRF-Token']=csrf;
    if(mode==='legacy'&&csrf)h['x-idr-csrf']=csrf;
  }
  const r=await handleCmsRequest(new Request(origin+path,{method,headers:h,body:body===undefined?undefined:JSON.stringify(body)}),env);
  let j={};try{j=await r.json()}catch{}
  return {r,j};
}
let x=await call('/api/cms/v1/session/establish','POST',{}, {}, 'none');assert.equal(x.r.status,200);csrf=x.j.data.csrfToken;cookie=x.r.headers.get('set-cookie').match(/^__Host-idr_cms_sid=([^;]+)/)[1];

await test('F9 production exact X-CSRF-Token succeeds with exact origin',async()=>{
  const y=await call('/api/cms/v1/pages','POST',{stableKey:'r3-csrf-good',path:'/r3-csrf-good',locale:'en',title:'Good'});
  assert.equal(y.r.status,201);
  assert.equal(db.db.prepare(`SELECT count(*) c FROM content_entities WHERE stable_key='r3-csrf-good'`).get().c,1);
});
await test('F9 production legacy-only x-idr-csrf fails closed without mutation',async()=>{
  const y=await call('/api/cms/v1/pages','POST',{stableKey:'r3-csrf-legacy',path:'/r3-csrf-legacy',locale:'en',title:'Legacy'}, {}, 'legacy');
  assert.equal(y.r.status,403);assert.equal(y.j.error.code,'CSRF_REJECTED');
  assert.equal(db.db.prepare(`SELECT count(*) c FROM content_entities WHERE stable_key='r3-csrf-legacy'`).get().c,0);
});
await test('production missing CSRF fails closed without mutation',async()=>{
  const y=await call('/api/cms/v1/pages','POST',{stableKey:'r3-csrf-missing',path:'/r3-csrf-missing',locale:'en',title:'Missing'}, {}, 'none');
  assert.equal(y.r.status,403);assert.equal(y.j.error.code,'CSRF_REJECTED');
  assert.equal(db.db.prepare(`SELECT count(*) c FROM content_entities WHERE stable_key='r3-csrf-missing'`).get().c,0);
});
await test('production wrong Origin fails closed',async()=>{
  const y=await call('/api/cms/v1/pages','POST',{stableKey:'r3-origin-bad',path:'/r3-origin-bad',locale:'en',title:'Bad Origin'},{origin:'https://evil.invalid'});
  assert.equal(y.r.status,403);assert.equal(y.j.error.code,'ORIGIN_REJECTED');
  assert.equal(db.db.prepare(`SELECT count(*) c FROM content_entities WHERE stable_key='r3-origin-bad'`).get().c,0);
});
await test('LOCAL_TEST_MODE retains explicitly gated legacy CSRF compatibility',async()=>{
  const ldb=new NodeSqliteD1(freshSqlitePath('idr-r3-local-'));applySchema(ldb);const lenv=createLocalEnv('http://127.0.0.1:4177',ldb);
  let r=await handleCmsRequest(new Request('http://127.0.0.1:4177/api/cms/v1/local/login',{method:'POST',headers:{'x-local-access-fixture':'root',origin:'http://127.0.0.1:4177'}}),lenv);assert.equal(r.status,200);const j=await r.json();const lc=r.headers.get('set-cookie').match(/^idr_cms_session=([^;]+)/)[1];
  r=await handleCmsRequest(new Request('http://127.0.0.1:4177/api/cms/v1/pages',{method:'POST',headers:{'x-local-access-fixture':'root',cookie:`idr_cms_session=${lc}`,origin:'http://127.0.0.1:4177','x-idr-csrf':j.data.csrfToken,'content-type':'application/json'},body:JSON.stringify({stableKey:'local-legacy-ok',path:'/local-legacy-ok',locale:'en',title:'Local'})}),lenv);assert.equal(r.status,201);
});

// Controlled D1-backed content fixtures for F10/F11 and deterministic sort behavior.
for(const key of ['r3list-alpha','r3list-beta','r3list-gamma']){
  const y=await call('/api/cms/v1/pages','POST',{stableKey:key,path:'/'+key,locale:'en',title:key});assert.equal(y.r.status,201);
}
const ids=Object.fromEntries(db.db.prepare(`SELECT stable_key,entity_id FROM content_entities WHERE stable_key LIKE 'r3list-%'`).all().map(r=>[r.stable_key,r.entity_id]));
db.db.prepare(`UPDATE content_locale_state SET row_version=3,translation_state='READY' WHERE entity_id=? AND locale_code='en'`).run(ids['r3list-alpha']);
db.db.prepare(`UPDATE content_locale_state SET row_version=1,translation_state='DRAFT' WHERE entity_id=? AND locale_code='en'`).run(ids['r3list-beta']);
db.db.prepare(`UPDATE content_locale_state SET row_version=2,translation_state='READY' WHERE entity_id=? AND locale_code='en'`).run(ids['r3list-gamma']);
// Different entity type fixture to exercise entityType mapping/tie-breakers; no user input is used as SQL.
db.db.prepare(`INSERT INTO content_entities(entity_id,entity_type,stable_key,created_at) VALUES('r3_nav_entity','NAVIGATION','r3list-nav',?)`).run(at);

await test('F10 unknown production sort fails 400 with stable INVALID_SORT',async()=>{
  const y=await call('/api/cms/v1/content?sort=not-a-real-sort');assert.equal(y.r.status,400);assert.equal(y.j.error.code,'INVALID_SORT');
});
await test('stableKey sort is deterministic and UI production shape succeeds',async()=>{
  const y=await call('/api/cms/v1/content?search=r3list&sort=stableKey&limit=50');assert.equal(y.r.status,200);
  assert.deepEqual(y.j.data.rows.map(r=>r.stableKey),['r3list-alpha','r3list-beta','r3list-gamma','r3list-nav']);
});
await test('entityType sort is deterministic with stable-key tie-breaker',async()=>{
  const y=await call('/api/cms/v1/content?search=r3list&sort=entityType&limit=50');assert.equal(y.r.status,200);
  assert.deepEqual(y.j.data.rows.map(r=>[r.entityType,r.stableKey]),[['NAVIGATION','r3list-nav'],['PAGE','r3list-alpha'],['PAGE','r3list-beta'],['PAGE','r3list-gamma']]);
});
await test('rowVersion sort is deterministic with stable-key tie-breaker',async()=>{
  const y=await call('/api/cms/v1/content?search=r3list&sort=rowVersion&limit=50');assert.equal(y.r.status,200);
  assert.deepEqual(y.j.data.rows.map(r=>[r.rowVersion,r.stableKey]),[[1,'r3list-beta'],[1,'r3list-nav'],[2,'r3list-gamma'],[3,'r3list-alpha']]);
});
await test('F11 locale/state filtered total matches rows before pagination',async()=>{
  const y=await call('/api/cms/v1/content?search=r3list&locale=en&state=READY&sort=stableKey&limit=50');assert.equal(y.r.status,200);
  assert.equal(y.j.data.total,2);assert.deepEqual(y.j.data.rows.map(r=>r.stableKey),['r3list-alpha','r3list-gamma']);
});
await test('combined search locale state total remains full filtered count across pagination',async()=>{
  const y=await call('/api/cms/v1/content?search=r3list&locale=en&state=READY&sort=stableKey&limit=1&offset=1');assert.equal(y.r.status,200);
  assert.equal(y.j.data.total,2);assert.equal(y.j.data.rows.length,1);assert.equal(y.j.data.rows[0].stableKey,'r3list-gamma');
});
await test('pagination bounds remain enforced',async()=>{
  for(const path of ['/api/cms/v1/content?limit=51','/api/cms/v1/content?limit=0','/api/cms/v1/content?offset=-1']){const y=await call(path);assert.equal(y.r.status,400);assert.equal(y.j.error.code,'INVALID_PAGINATION')}
});

if(!process.exitCode)console.log('R3_PARITY_TESTS_PASS',pass);
