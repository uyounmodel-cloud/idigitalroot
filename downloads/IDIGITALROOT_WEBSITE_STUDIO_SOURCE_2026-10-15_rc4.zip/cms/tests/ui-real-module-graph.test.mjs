import assert from 'node:assert/strict';

try {
  await import('../ui/app.js?real-module-graph='+Date.now());
  assert.fail('ui/app.js unexpectedly executed without a DOM');
} catch (error) {
  assert.equal(error?.name,'ReferenceError',`unexpected module-graph error: ${error?.stack||error}`);
  assert.match(String(error?.message||''),/document is not defined/,`real browser module graph failed before application bootstrap: ${error?.stack||error}`);
}
console.log('UI_REAL_ESM_GRAPH_PASS');
