import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';

const root=path.resolve(new URL('../',import.meta.url).pathname),ui=path.join(root,'ui');
const read=r=>fs.readFileSync(path.join(root,r),'utf8');
const h=read('ui/index.html'),app=read('ui/app.js'),css=read('ui/styles.css'),i18n=read('ui/modules/i18n.js'),registry=read('ui/modules/registry.js');
const content=read('ui/modules/workspaces/content.js'),editor=read('ui/modules/workspaces/editor.js'),media=read('ui/modules/workspaces/media.js'),ops=read('ui/modules/workspaces/operations.js'),editorUx=read('ui/modules/editor-ux.js');
const all=[h,app,css,i18n,registry,content,editor,media,ops,editorUx].join('\n');
const pass=m=>console.log('PASS '+m);

assert.match(h,/class="skip" href="#main"/);assert.match(h,/id="statusLive"[^>]*role="status"[^>]*aria-live="polite"/);assert.match(h,/type="module" src="\/app\.js"/);pass('semantic bootstrap, skip link and aria-live status');
assert.match(app,/id="main" class="main" tabindex="0"/);assert.match(app,/document\.documentElement\.dir=state\.uiLang==='ar'\?'rtl':'ltr'/);assert.match(app,/data-ui-lang="ar"/);assert.match(app,/data-ui-lang="en"/);pass('dynamic main landmark and EN/AR direction switching');

const navIds=[...i18n.matchAll(/\['([a-z-]+)','[^']*',\[/g)].map(m=>m[1]);
assert.equal(navIds.length,27);assert.equal(new Set(navIds).size,27);for(const id of ['dashboard','coverage','sitemap','editor','chapters','pages','components','registries','navigation','appearance','localization','services','knowledge','seo','search','rootcheck','inquiry','legal','media','providers','publishing','analytics','history','users','security','operations','settings'])assert.ok(navIds.includes(id),id);pass('all 27 owner-approved workspaces are present in navigation');
assert.match(i18n,/\['Dashboard','لوحة التحكم'\]/);assert.match(i18n,/\['Visual website editor','محرر الموقع المرئي'\]/);assert.match(i18n,/\['Users & roles','المستخدمون والأدوار'\]/);assert.match(i18n,/\['Site health','صحة الموقع'\]/);pass('major CMS chrome has explicit Arabic labels');

assert.match(css,/:root\{--ui-size:15px\}/);assert.match(css,/\.nav button\{font-size:14px/);assert.match(css,/\.btn\{font-size:13px/);assert.match(css,/table\{font-size:13px\}/);assert.match(css,/\.field input,\.field textarea,\.field select\{font-size:14px/);pass('readable owner-approved general typography floor');
assert.match(css,/html\[dir=rtl\] \.app\{grid-template-columns:minmax\(0,1fr\) 270px;direction:ltr\}/);assert.match(css,/html\[dir=rtl\] \.sidebar\{[^}]*grid-column:2!important[^}]*direction:rtl/);assert.match(css,/html\[dir=rtl\] \.editorgrid>\.tree\{grid-column:3!important;direction:rtl\}/);assert.match(css,/html\[dir=rtl\] \.editorgrid>\.inspector\{grid-column:1!important;direction:rtl\}/);pass('full Arabic shell mirror and editor placement are explicit');
assert.match(css,/:focus-visible/);assert.match(css,/@media\(max-width:1050px\)/);assert.match(css,/@media\(max-width:700px\)/);pass('focus and responsive rules exist');

for(const f of ['ui/app.js','ui/modules/api.js','ui/modules/data.js','ui/modules/errors.js','ui/modules/i18n.js','ui/modules/registry.js','ui/modules/state.js','ui/modules/ui.js','ui/modules/editor-ux.js','ui/modules/workspaces/content.js','ui/modules/workspaces/editor.js','ui/modules/workspaces/media.js','ui/modules/workspaces/operations.js','scripts/local-review-env.mjs','scripts/local-server.mjs']){
 const r=spawnSync(process.execPath,['--check',path.join(root,f)],{encoding:'utf8'});assert.equal(r.status,0,`${f}: ${r.stderr}`)
}pass('all modular frontend/local-review JavaScript parses');

assert.doesNotMatch(all,/\blocalStorage\b/);assert.doesNotMatch(all,/\bsessionStorage\b/);assert.doesNotMatch(all,/\bindexedDB\b/);assert.doesNotMatch(all,/<iframe/i);assert.doesNotMatch(all,/document\.cookie\s*=/);pass('no browser persistence of CMS secrets and no arbitrary iframe UI');
assert.match(read('ui/modules/api.js'),/state\.csrf/);assert.match(read('ui/modules/api.js'),/h\['X-CSRF-Token'\]=state\.csrf/);assert.match(read('ui/modules/api.js'),/credentials:'same-origin'/);pass('connected mutations use memory-only CSRF and same-origin credentials');

for(const key of ['hero','rich_text','cards','cta','faq','root-toolbox','student-workspace','major-explorer'])assert.match(registry,new RegExp(`['\"]${key}['\"]`));assert.match(registry,/RETIRED_COMPONENTS=\['retired_legacy'\]/);assert.match(registry,/student-workspace-university-life/);assert.match(registry,/student-workspace-my-future/);assert.match(registry,/student-workspace-personal-growth/);assert.match(registry,/major-architecture-design/);assert.match(registry,/major-computer-science-engineering/);assert.match(registry,/major-medicine-health-sciences/);assert.match(registry,/major-business-law-humanities/);assert.match(registry,/major-other/);pass('component and exact semantic product registries preserved');
const chapters=[...registry.match(/CHAPTERS=\[([^\]]+)\]/s)[1].matchAll(/'([^']+)'/g)].map(x=>x[1]);assert.equal(chapters.length,20);assert.deepEqual(chapters,['hero','student-problem','student-foundation','story','human-stories','three-experiences','roots','toolbox','student-workspace','student-benefits','my-dream','major-personalization','project-to-career','human-built','knowledge','not-student','proof','faq','final-cta','footer']);pass('exact 20 frozen homepage chapters');
const akeys=[...registry.match(/ANALYTICS_KEYS=\[([^\]]+)\]/s)[1].matchAll(/'([^']+)'/g)].map(x=>x[1]);assert.equal(akeys.length,11);pass('all 11 accepted analytics families declared');

function attrs(src,name){return new Set([...src.matchAll(new RegExp(`data-${name}="([^"]+)"`,'g'))].map(m=>m[1]).filter(x=>!x.includes('${')))}
function handled(src,kind){return new Set([...src.matchAll(new RegExp(`action==='([^']+)'`,'g'))].map(m=>m[1]))}
for(const [name,src,kind] of [['content',content,'action'],['editor',editor,'editor-action'],['media',media,'media-action'],['operations',ops,'ops-action']]){
 const visible=attrs(src,kind),handlers=handled(src);for(const v of visible)assert.ok(handlers.has(v),`${name} visible action has no handler: ${v}`);pass(`${name} visible static action controls have handlers`)
}
assert.match(content,/Root Check/i);assert.match(content,/live scanner|informational|methodology/i);assert.doesNotMatch(content,/fake score/i);assert.match(media,/Vimeo/);assert.match(media,/FUTURE|disabled/i);assert.match(ops,/Roles keep editing|Add access|Available access roles/);pass('future/policy-gated capabilities are truthfully represented');


assert.doesNotMatch([content,editor,media,ops].join('\n'),/<pre\b|json-preview|Items JSON|Groups JSON|English JSON|Arabic JSON|Configuration JSON|Connected report result|Stable key|Row version|Actor ID|Correlation ID|Session ID|Query raw|Raw access|Collection mode|Provider file ID|Service host|Approved embed hosts/i);pass('normal editor workspaces do not expose raw payloads or developer identifiers');
assert.match(editorUx,/SAFE_TAGS/);assert.match(editorUx,/sanitizeRichHtml/);assert.match(editorUx,/data-rich-cmd="bold"/);assert.match(editor,/Open rich editor \/ safe HTML/);pass('safe visual rich-text editor exists and retains sanitization boundary');
assert.match(content,/data-nav-rows/);assert.match(content,/data-footer-groups/);assert.match(content,/structured-editor/);assert.match(content,/chapter-editor-card/);pass('navigation, footer, translation and chapters use human-facing structured controls');
assert.match(media,/provider-details/);assert.match(media,/media-facts/);assert.match(ops,/analytics-chart/);assert.match(ops,/revisionDiff/);pass('provider/media/analytics/revision surfaces use human-readable presentation');

console.log('UI_STATIC_TEST_PASS');
