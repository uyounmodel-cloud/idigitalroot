import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const chrome=process.env.CHROMIUM_PATH || '/usr/bin/chromium';
const base='http://127.0.0.1:4177';
const root=new URL('../',import.meta.url);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const pass=m=>console.log('PASS '+m);
function freePort(){return new Promise((resolve,reject)=>{import('node:net').then(({createServer})=>{const s=createServer();s.on('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>resolve(p));});}).catch(reject);});}
async function json(url){const r=await fetch(url);if(!r.ok)throw new Error(`HTTP ${r.status} ${url}`);return r.json();}

const server=spawn(process.execPath,['scripts/local-server.mjs'],{stdio:['ignore','pipe','pipe']});
let serverReady=false,serverOut='';server.stdout.on('data',d=>{serverOut+=String(d);if(serverOut.includes('CMS_LOCAL_SERVER_READY'))serverReady=true;});server.stderr.on('data',d=>serverOut+=String(d));
for(let i=0;i<120&&!serverReady;i++)await sleep(50);
if(!serverReady){server.kill('SIGTERM');throw new Error('local server did not start: '+serverOut.slice(-1000));}

const debugPort=await freePort();
const profile=fs.mkdtempSync(path.join(os.tmpdir(),'idr-cms-browser-'));
const browser=spawn(chrome,['--headless=new','--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--disable-background-networking','--no-first-run',`--remote-debugging-port=${debugPort}`,'--remote-debugging-address=127.0.0.1',`--user-data-dir=${profile}`,'about:blank'],{stdio:['ignore','ignore','pipe']});
let browserErr='';browser.stderr.on('data',d=>browserErr+=String(d));
let version;for(let i=0;i<150;i++){try{version=await json(`http://127.0.0.1:${debugPort}/json/version`);break}catch{await sleep(100)}}
if(!version?.webSocketDebuggerUrl){browser.kill('SIGKILL');server.kill('SIGTERM');throw new Error('Chrome DevTools endpoint not ready: '+browserErr.slice(-1000));}
if(typeof WebSocket==='undefined')throw new Error('Node WebSocket API unavailable');
const ws=new WebSocket(version.webSocketDebuggerUrl);await new Promise((res,rej)=>{ws.addEventListener('open',res,{once:true});ws.addEventListener('error',rej,{once:true});});
let seq=0;const pending=new Map();const runtimeErrors=[];let sid='';let bridgeCookie='';
function send(method,params={},sessionId){return new Promise((resolve,reject)=>{const id=++seq;pending.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params,...(sessionId?{sessionId}:{})}));});}
async function bridge(payload){
  let q;try{q=JSON.parse(payload)}catch(e){runtimeErrors.push('bridge request JSON: '+e.message);return}
  try{
    const u=new URL(q.url);if(u.origin!==base)throw new Error(`bridge origin denied: ${u.origin}`);
    const headers={...(q.headers||{}),origin:base,referer:base+'/'};if(bridgeCookie)headers.cookie=bridgeCookie;
    const init={method:q.method||'GET',headers,redirect:'manual'};if(!['GET','HEAD'].includes(init.method)&&q.body!==undefined&&q.body!==null)init.body=q.body;
    const r=await fetch(q.url,init);const setCookie=r.headers.get('set-cookie');if(setCookie)bridgeCookie=setCookie.split(';',1)[0];const body=await r.text();const h={};for(const [k,v] of r.headers)h[k]=v;
    const result={id:q.id,ok:r.ok,status:r.status,statusText:r.statusText,headers:h,body};
    await send('Runtime.evaluate',{expression:`globalThis.__cmsBridgeResolve(${JSON.stringify(JSON.stringify(result))})`,awaitPromise:true},sid);
  }catch(e){
    const result={id:q.id,error:e?.message||String(e)};runtimeErrors.push('CDP local service bridge: '+result.error);
    await send('Runtime.evaluate',{expression:`globalThis.__cmsBridgeResolve(${JSON.stringify(JSON.stringify(result))})`,awaitPromise:true},sid).catch(()=>{});
  }
}
ws.addEventListener('message',ev=>{const m=JSON.parse(String(ev.data));if(m.method==='Runtime.exceptionThrown'){const d=m.params?.exceptionDetails;runtimeErrors.push(d?.exception?.description||d?.text||'Runtime exception');}if(m.method==='Runtime.bindingCalled'&&m.params?.name==='cmsBridge')void bridge(m.params.payload);if(m.id&&pending.has(m.id)){const {resolve,reject}=pending.get(m.id);pending.delete(m.id);m.error?reject(new Error(m.error.message)):resolve(m.result);}});
const {targetId}=await send('Target.createTarget',{url:'about:blank'});({sessionId:sid}=await send('Target.attachToTarget',{targetId,flatten:true}));
await send('Page.enable',{},sid);await send('Runtime.enable',{},sid);await send('Runtime.addBinding',{name:'cmsBridge'},sid);await send('Page.bringToFront',{},sid);

const rawHtml=fs.readFileSync(new URL('../ui/index.html',import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../ui/styles.css',import.meta.url),'utf8');
const appJs=fs.readFileSync(new URL('../ui/app.js',import.meta.url),'utf8');
const html=rawHtml.replace(/<link rel="stylesheet" href="\/styles\.css">/,'').replace(/<script type="module" src="\/app\.js"><\/script>/,'').replace('</head>',`<style>${css.replace(/<\/style/gi,'<\\/style')}</style></head>`);
const bridgeBootstrap=`(()=>{let n=0;const p=new Map();globalThis.__cmsBridgeResolve=s=>{const r=JSON.parse(s),x=p.get(r.id);if(!x)return;p.delete(r.id);if(r.error){x.reject(new Error(r.error));return}x.resolve({ok:r.ok,status:r.status,statusText:r.statusText,headers:new Headers(r.headers),json:async()=>JSON.parse(r.body),text:async()=>r.body,arrayBuffer:async()=>new TextEncoder().encode(r.body).buffer})};globalThis.fetch=(input,init={})=>new Promise((resolve,reject)=>{const id=String(++n);p.set(id,{resolve,reject});const hs=init.headers instanceof Headers?Object.fromEntries(init.headers.entries()):(init.headers||{});const url=new URL(String(input),'${base}/').href;cmsBridge(JSON.stringify({id,url,method:init.method||'GET',headers:hs,body:init.body??null}))})})()`;
async function ev(expr){const r=await send('Runtime.evaluate',{expression:expr,awaitPromise:true,returnByValue:true},sid);if(r.exceptionDetails)throw new Error(r.exceptionDetails.text||'Runtime.evaluate exception');return r.result?.value;}
async function wait(expr,ms=15000){const end=Date.now()+ms;let last;while(Date.now()<end){try{last=await ev(expr);if(last)return last}catch{}await sleep(100);}let diag='';try{diag=await ev(`JSON.stringify({href:location.href,ready:document.readyState,loginError:document.querySelector('#loginError')?.textContent||'',shellHidden:document.querySelector('#shell')?.hidden,hasHandler:typeof document.querySelector('#loginButton')?.onclick})`);}catch{}throw new Error(`wait timeout: ${expr}; last=${JSON.stringify(last)}; diag=${diag}; runtimeErrors=${runtimeErrors.join(' | ')}`);}
async function loadUi(){const ft=await send('Page.getFrameTree',{},sid);await send('Page.setDocumentContent',{frameId:ft.frameTree.frame.id,html},sid);await ev(bridgeBootstrap);await ev(appJs);await wait(`typeof document.querySelector('#loginButton')?.onclick==='function'`);}
const keySpec={Enter:{key:'Enter',code:'Enter',vk:13,text:'\r'},Tab:{key:'Tab',code:'Tab',vk:9,text:''},Escape:{key:'Escape',code:'Escape',vk:27,text:''}};
async function key(name){const k=keySpec[name];await send('Input.dispatchKeyEvent',{type:k.text?'keyDown':'rawKeyDown',key:k.key,code:k.code,windowsVirtualKeyCode:k.vk,nativeVirtualKeyCode:k.vk,text:k.text||undefined,unmodifiedText:k.text||undefined},sid);await send('Input.dispatchKeyEvent',{type:'keyUp',key:k.key,code:k.code,windowsVirtualKeyCode:k.vk,nativeVirtualKeyCode:k.vk},sid);}
async function viewport(w,h){await send('Emulation.setDeviceMetricsOverride',{width:w,height:h,deviceScaleFactor:1,mobile:w<600},sid);await sleep(120);}
async function noOverflow(label){const d=await ev(`({sw:document.documentElement.scrollWidth,bw:document.body.scrollWidth,w:window.innerWidth})`);assert.ok(d.sw<=d.w&&d.bw<=d.w,`${label} overflow ${JSON.stringify(d)}`);pass(`${label} no horizontal overflow — ${JSON.stringify(d)}`);}

try{
  await loadUi();await ev(`document.querySelector('#loginButton').click()`);await wait(`!document.querySelector('#shell').hidden`);await wait(`!!document.querySelector('[data-route=\"dashboard\"]')`);assert.equal(await ev(`document.querySelector('#login').hidden`),true);pass('real Chromium local protected login fixture via deterministic CDP service bridge');
  const expected={dashboard:'Dashboard',content:'Content tree / pages',editor:'Page editor',localization:'Localization',knowledge:'Knowledge / taxonomy',navigation:'Navigation / footer',seo:'SEO / public metadata',history:'History / audit',identity:'Users / roles / sessions',analytics:'Analytics',media:'Media library',providers:'Provider imports / embeds',preview:'Preview',publication:'Publication',settings:'System / settings'};
  for(const [route,h2] of Object.entries(expected)){await ev(`document.querySelector('[data-route="${route}"]').click()`);await wait(`document.querySelector('#view h2')?.textContent===${JSON.stringify(h2)}`);pass(`workspace browser-usable ${route}`);}pass('major workspaces real browser-usable');
  await ev(`document.querySelector('[data-route="content"]').focus()`);await key('Enter');await wait(`document.querySelector('#view h2')?.textContent==='Content tree / pages'`);assert.equal(await ev(`document.activeElement.id`),'main');await ev(`document.querySelector('#createBtn').focus()`);await key('Enter');await wait(`!!document.querySelector('#newKey')`);assert.equal(await ev(`document.activeElement.id`),'newKey');await key('Tab');assert.equal(await ev(`document.activeElement.id`),'newPath');await ev(`document.querySelector('#cancelCreate').focus()`);await key('Enter');await wait(`!document.querySelector('#newKey')`);pass('representative keyboard/focus navigation/form/dialog path');
  for(const w of [1440,768,390]){await viewport(w,w===390?844:900);await ev(`document.querySelector('[data-route="content"]').click()`);await wait(`document.querySelector('#view h2')?.textContent==='Content tree / pages'`);await noOverflow(`content ${w}px`);await ev(`document.querySelector('[data-route="editor"]').click()`);await wait(`document.querySelector('#view h2')?.textContent==='Page editor'`);await noOverflow(`editor ${w}px`);}pass('representative desktop/tablet/mobile widths no core overflow');
  await viewport(1440,900);await ev(`document.querySelector('[data-route="media"]').click()`);await wait(`document.querySelector('#view h2')?.textContent==='Media library'`);await ev(`document.querySelector('#uploadMedia').click()`);await wait(`document.querySelector('#status').textContent.includes('finalized as APPROVED')`);await wait(`document.querySelector('#mediaDetail').textContent.includes('QUARANTINED → VALIDATING → APPROVED')`);await wait(`document.querySelector('#mediaRows table')`);pass('C81 browser media quarantine → validation → finalization UI');
  await ev(`document.querySelector('[data-route="providers"]').click()`);await wait(`document.querySelector('#ytForm')`);await ev(`document.querySelector('#ytForm').dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}))`);await wait(`document.querySelector('#providerOut').textContent.includes('youtube-nocookie.com')`);pass('provider embed browser workflow');
  await ev(`document.querySelector('[data-route="publication"]').click()`);await wait(`document.querySelector('#prepareReady')`);await ev(`document.querySelector('#prepareReady').click()`);await wait(`document.querySelector('#status').textContent.includes('READY/VALID')`);await ev(`document.querySelector('[data-route="preview"]').click()`);await wait(`document.querySelector('#issuePreview')`);await ev(`document.querySelector('#issuePreview').click()`);await wait(`document.querySelector('#previewOut').textContent.includes('/api/preview/v1/content')`);pass('C81 exact-revision preview issuance browser workflow');
  await ev(`document.querySelector('[data-route="publication"]').click()`);await ev(`document.querySelector('#publishNow').click()`);await wait(`document.querySelector('#publicationOut').textContent.includes('eventId')`);await ev(`document.querySelector('#scheduleBtn').click()`);await wait(`document.querySelector('#publicationOut').textContent.includes('CANCELLED')`);const beforeSecond=await ev(`state.content[0].localeState.en.latestRevisionId`);await ev(`document.querySelector('#prepareReady').click()`);await wait(`state.content[0].localeState.en.latestRevisionId!==${JSON.stringify(beforeSecond)} && state.content[0].localeState.en.state==='READY'`);await ev(`document.querySelector('#publishNow').click()`);await wait(`document.querySelector('#publicationOut').textContent.includes('\"version\"')`);await ev(`document.querySelector('#rollbackBtn').click()`);await wait(`document.querySelector('#publicationOut').textContent.includes('ROLLBACK')`);await ev(`document.querySelector('#historyBtn').click()`);await wait(`document.querySelector('#publicationOut').textContent.includes('ROLLBACK')`);pass('C82 publish schedule/cancel rollback/history browser workflow');
  for(const route of ['media','providers','preview','publication']){await ev(`document.querySelector('[data-route="${route}"]').click()`);await sleep(100);await noOverflow(`${route} advanced 1440px`);}
  await viewport(1440,900);await ev(`runE2E()`);await wait(`document.body.dataset.e2e==='PASS'`,20000);const text=await ev(`document.body.innerText`);assert.match(text,/CMS_BROWSER_E2E_PASS/);assert.doesNotMatch(text,/CMS_BROWSER_E2E_FAIL/);pass('inherited login -> content tree -> create/edit/save -> history/audit browser E2E');
  assert.equal(runtimeErrors.length,0,'uncaught runtime exceptions: '+runtimeErrors.join(' | '));pass('no uncaught browser runtime exceptions');console.log('CMS_BROWSER_TEST_PASS');
} finally {try{await send('Browser.close');}catch{}try{ws.close();}catch{}if(browser.exitCode===null)browser.kill('SIGTERM');server.kill('SIGTERM');try{fs.rmSync(profile,{recursive:true,force:true});}catch{}}
