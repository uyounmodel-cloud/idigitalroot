import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';

class Stmt{
  constructor(db,sql,params=[]){this.db=db;this.sql=sql;this.params=params}
  bind(...v){return new Stmt(this.db,this.sql,v)}
  async run(){const r=this.db.prepare(this.sql).run(...this.params);return {success:true,results:[],meta:{changes:Number(r.changes||0)}}}
  async first(){const r=this.db.prepare(this.sql).get(...this.params);return r??null}
  async all(){return {results:this.db.prepare(this.sql).all(...this.params)}}
}
export class NodeSqliteD1{
  constructor(filename=':memory:'){this.filename=filename;this.failNextBatchContains='';this.db=new DatabaseSync(filename);this.db.exec('PRAGMA foreign_keys=ON;')}
  prepare(sql){return new Stmt(this.db,sql)}
  async batch(stmts){if(this.failNextBatchContains&&stmts.some(s=>s.sql.includes(this.failNextBatchContains))){const m=this.failNextBatchContains;this.failNextBatchContains='';throw new Error('INJECTED_D1_BATCH_FAILURE:'+m)}this.db.exec('BEGIN IMMEDIATE');try{const out=[];for(const s of stmts){const r=this.db.prepare(s.sql).run(...s.params);out.push({success:true,results:[],meta:{changes:Number(r.changes||0)}})}this.db.exec('COMMIT');return out}catch(e){try{this.db.exec('ROLLBACK')}catch{}throw e}}
  async exec(sql){this.db.exec(sql);return {count:1}}
  close(){this.db.close()}
}
export function applySchema(binding){const dir=new URL('../../schema/core/migrations/',import.meta.url).pathname;for(const f of fs.readdirSync(dir).filter(x=>/^\d{4}.*\.sql$/.test(x)).sort())binding.db.exec(fs.readFileSync(path.join(dir,f),'utf8'));}
export function freshSqlitePath(prefix='idr-cms02r1-'){return path.join(fs.mkdtempSync(path.join(os.tmpdir(),prefix)),'core.sqlite')}
