import {createLocalEnv} from '../../dist/worker.js';
import {LocalR2Adapter} from '../../dist/core/advanced.js';
import {NodeSqliteD1,applySchema,freshSqlitePath} from './local-d1.mjs';
export function makeEnv(origin='http://127.0.0.1:4177',opts={}){const dbPath=opts.dbPath||freshSqlitePath();const db=opts.binding||new NodeSqliteD1(dbPath);if(!opts.binding)applySchema(db);const objects=opts.objects||new LocalR2Adapter(opts.sharedObjects);const env=createLocalEnv(origin,db,objects,opts.store);return {env,db,dbPath,objects};}
