import {ANALYTICS_REPORTS} from '../site-profile/idigitalroot/registry.js';import {CmsError,requirePermission} from '../core/security.js';import type {RequestContext} from '../core/types.js';
export interface AnalyticsQuery{reportKey:string;mode?:'aggregate'|'raw';start:string;end:string;dimensions?:string[];filters?:Record<string,string>;sort?:string;pageSize?:number}
export interface AnalyticsAdapter{query(ctx:RequestContext,q:AnalyticsQuery):Promise<unknown>;export(ctx:RequestContext,q:AnalyticsQuery):Promise<unknown>;config(ctx:RequestContext):Promise<unknown>}
export class LocalAnalyticsAdapter implements AnalyticsAdapter{
 async query(ctx:RequestContext,q:AnalyticsQuery){const def=(ANALYTICS_REPORTS as any)[q.reportKey];if(!def)throw new CmsError(400,'UNKNOWN_REPORT','Analytics report is not registered.');if(q.mode==='raw'){if(!def.rawAllowed)throw new CmsError(403,'RAW_REPORT_DENIED','Raw report is not allowed.');requirePermission(ctx,'analytics.read.raw');return {reportKey:q.reportKey,mode:'raw',rows:[{event_id:'evt_demo',route_id:'route_home',locale_code:'en',properties_json:'{}'}]}}requirePermission(ctx,'analytics.read.aggregate');return {reportKey:q.reportKey,mode:'aggregate',rows:[{window_start:q.start,window_end:q.end,dimensions_json:'{}',metric_count:3}]}}
 async export(ctx:RequestContext,q:AnalyticsQuery){requirePermission(ctx,'analytics.export');await this.query(ctx,q);return {format:'csv',rows:1,bounded:true,audited:true}}
 async config(ctx:RequestContext){requirePermission(ctx,'analytics.config.manage');return {policyGate:'OPEN',mutableInCms01:false}}
}

// P1-CMS-03 production bridge. The implementation deliberately delegates only the
// accepted P1-AN query/export/config contracts; it never accepts public request data
// or Lead/visitor identity payloads.
export interface P1AnProductionBridge{
 query(input:{actorId:string;sessionId:string;authenticated:true;requestId:string;correlationId:string},q:AnalyticsQuery):Promise<unknown>;
 export(input:{actorId:string;sessionId:string;authenticated:true;requestId:string;correlationId:string},q:AnalyticsQuery):Promise<unknown>;
 config(input:{actorId:string;sessionId:string;authenticated:true;requestId:string;correlationId:string}):Promise<unknown>;
}
export class ProductionAnalyticsAdapter implements AnalyticsAdapter{
 constructor(private bridge:P1AnProductionBridge){}
 private trusted(ctx:RequestContext){return {actorId:ctx.actor.actorId,sessionId:ctx.session.sessionId,authenticated:true as const,requestId:ctx.requestId,correlationId:ctx.correlationId}}
 async query(ctx:RequestContext,q:AnalyticsQuery){if(q.mode==='raw')requirePermission(ctx,'analytics.read.raw');else requirePermission(ctx,'analytics.read.aggregate');return this.bridge.query(this.trusted(ctx),q)}
 async export(ctx:RequestContext,q:AnalyticsQuery){requirePermission(ctx,'analytics.export');if(q.mode==='raw')requirePermission(ctx,'analytics.read.raw');else requirePermission(ctx,'analytics.read.aggregate');return this.bridge.export(this.trusted(ctx),q)}
 async config(ctx:RequestContext){requirePermission(ctx,'analytics.config.manage');return this.bridge.config(this.trusted(ctx))}
}
