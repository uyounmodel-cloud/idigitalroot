import {CmsError} from './security.js';
export interface DocumentScanner{verifyPdf(bytes:Uint8Array,sha256:string):Promise<void>}
export class ServiceDocumentScanner implements DocumentScanner{
 constructor(private service:{fetch(request:Request):Promise<Response>},private policyVersion:string){}
 async verifyPdf(bytes:Uint8Array,sha256:string){const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),15000);try{
  if(!this.policyVersion||!/^[a-f0-9]{64}$/.test(sha256))throw new CmsError(503,'SCANNER_CONFIGURATION_REQUIRED');
  const response=await this.service.fetch(new Request('https://document-scanner.internal/scan-pdf',{method:'POST',headers:{'content-type':'application/pdf','x-content-sha256':sha256},body:bytes as BodyInit,signal:ctrl.signal}));if(!response.ok)throw new CmsError(503,'SCANNER_UNAVAILABLE');
  const reader=response.body?.getReader(),chunks:Uint8Array[]=[];let size=0;try{if(reader)while(true){const part=await reader.read();if(part.done)break;size+=part.value.byteLength;if(size>16384){await reader.cancel();throw new CmsError(503,'SCANNER_UNAVAILABLE')}chunks.push(part.value)}}finally{reader?.releaseLock()}
  const raw=new Uint8Array(size);let offset=0;for(const chunk of chunks){raw.set(chunk,offset);offset+=chunk.byteLength}const verdict=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(raw));
  if(!verdict||verdict.sha256!==sha256||verdict.policyVersion!==this.policyVersion||verdict.verdict!=='CLEAN'||verdict.activeContent!==false||verdict.embeddedFiles!==false||verdict.externalActions!==false)throw new CmsError(409,'DOCUMENT_NOT_APPROVED');
 }catch(error){if(error instanceof CmsError)throw error;throw new CmsError(503,'SCANNER_UNAVAILABLE')}finally{clearTimeout(timer)}}
}
