export type Permission =
  'content.read'|'content.edit'|'navigation.edit'|'seo.edit'|'translations.edit'|'media.manage'|'preview.use'|
  'publication.publish'|'publication.unpublish'|'publication.schedule'|'publication.cancel'|'publication.rollback'|
  'config.providers.manage'|'config.global.manage'|'audit.read'|'identity.read'|'identity.invite'|'identity.deprovision'|
  'roles.assign'|'sessions.revoke'|'security.recovery'|'analytics.read.aggregate'|'analytics.read.raw'|'analytics.export'|'analytics.config.manage';
export type Scope={kind:'global'}|{kind:'locale',localeCode:string}|{kind:'content',contentEntityId:string};
export type ActorState='pending_activation'|'active'|'disabled';
export type TranslationState='MISSING'|'DRAFT'|'NEEDS_REVIEW'|'READY'|'PUBLISHED'|'OUTDATED'|'ARCHIVED';
export interface AccessPrincipal{providerKey:'cloudflare_access'|'local_fixture';issuer:string;subject:string;email:string;expiresAt:string;issuedAt?:string;type:'app'}
export interface Actor{actorId:string;displayName:string;email:string;state:ActorState;rowVersion:number;roles:RoleGrant[]}
export interface RoleGrant{roleKey:string;scope:Scope;permissions:Permission[];revokedAt?:string}
export interface Session{sessionId:string;actorId:string;identityKey:string;tokenSha256:string;csrfSha256:string;issuedAt:string;lastSeenAt:string;inactivityExpiresAt:string;absoluteExpiresAt:string;upstreamAccessExpiresAt:string;state:'ACTIVE'|'REVOKED'|'EXPIRED';freshAuthAt:string;reauthRequiredAt?:string;rotatedFromSessionId?:string}
export interface AuditEvent{auditId:string;actorId:string;sessionId?:string;action:string;targetType:string;targetId:string;requestId:string;correlationId:string;outcome:'SUCCESS'|'DENIED'|'FAILED';before?:unknown;after?:unknown;createdAt:string}
export interface ContentRevision{revisionId:string;entityId:string;localeCode:string;revisionNumber:number;workflowState:'DRAFT'|'NEEDS_REVIEW'|'READY'|'ARCHIVED';validationState:'PENDING'|'VALID'|'INVALID';content:Record<string,unknown>;sections:SectionInstance[];sourceRevisionId?:string;createdBy:string;createdAt:string}
export interface SectionInstance{sectionInstanceId:string;componentKey:string;ordinal:number;visible:boolean;config:Record<string,unknown>;parentSectionInstanceId?:string}
export interface ContentEntity{entityId:string;stableKey:string;entityType:'PAGE'|'KNOWLEDGE_ARTICLE'|'NAVIGATION'|'FOOTER';routeId?:string;archivedAt?:string;rowVersion:number;localeState:Record<string,{state:TranslationState;latestRevisionId?:string;rowVersion:number}>}
export interface HierarchyRow{pageEntityId:string;parentPageEntityId?:string;siblingOrdinal:number;rowVersion:number}
export interface RouteRecord{routeId:string;localeCode:string;path:string;active:boolean}
export interface Invitation{invitationId:string;actorId:string;email:string;state:'PENDING'|'CONSUMED'|'REVOKED'|'EXPIRED';createdAt:string;expiresAt:string;consumedAt?:string}
export interface TaxonomyTerm{termId:string;vocabularyKey:string;stableKey:string;parentTermId?:string;siblingOrdinal:number;state:'ACTIVE'|'ARCHIVED';labels:Record<string,{label:string;slug:string}>}
export interface RequestContext{requestId:string;correlationId:string;actor:Actor;session:Session;principal:AccessPrincipal}
