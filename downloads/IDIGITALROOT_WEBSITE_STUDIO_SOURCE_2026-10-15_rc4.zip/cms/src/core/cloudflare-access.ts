import {CmsError,type AccessVerifier} from './security.js';
import type {AccessPrincipal} from './types.js';

/** Verify the Access signature and configured application audience before mapping a CMS identity. */
export class CloudflareAccessVerifier implements AccessVerifier {
 private keys:JsonWebKey[]=[];private until=0;private loading:Promise<void>|null=null;
 constructor(private issuer:string,private audience:string,private transport:typeof fetch=fetch){
  const url=new URL(issuer);
  if(url.protocol!=='https:'||!/^[-a-z0-9]+\.cloudflareaccess\.com$/.test(url.hostname)||url.pathname!=='/'||url.search||url.hash||url.username||url.password||!audience)throw new Error('ACCESS_CONFIGURATION_INVALID');
  this.issuer=url.origin;
 }
 private async refresh(){
  if(this.loading)return this.loading;
  this.loading=(async()=>{const ctrl=new AbortController();const timeout=setTimeout(()=>ctrl.abort(),4000);try{const r=await this.transport(this.issuer+'/cdn-cgi/access/certs',{signal:ctrl.signal,redirect:'error'});if(!r.ok)throw new CmsError(503,'ACCESS_VERIFICATION_UNAVAILABLE');const reader=r.body?.getReader(),chunks:Uint8Array[]=[];let size=0;try{if(reader)while(true){const part=await reader.read();if(part.done)break;size+=part.value.byteLength;if(size>65536){await reader.cancel();throw new CmsError(503,'ACCESS_VERIFICATION_UNAVAILABLE')}chunks.push(part.value)}}finally{reader?.releaseLock()}const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.byteLength}const raw=new TextDecoder('utf-8',{fatal:true}).decode(bytes);const data=JSON.parse(raw);if(!Array.isArray(data.keys)||data.keys.length>32)throw new CmsError(503,'ACCESS_VERIFICATION_UNAVAILABLE');this.keys=data.keys.filter((k:any)=>k.kty==='RSA'&&k.alg==='RS256'&&k.use==='sig'&&typeof k.kid==='string');this.until=Date.now()+60000;}finally{clearTimeout(timeout)}})();
  try{await this.loading}finally{this.loading=null}
 }
 async verify(request:Request):Promise<AccessPrincipal>{
  try{
   const jwt=request.headers.get('cf-access-jwt-assertion');if(!jwt||jwt.length>16384)throw new CmsError(401,'ACCESS_REQUIRED');
   const parts=jwt.split('.');if(parts.length!==3||parts.some(p=>!p||!/^[A-Za-z0-9_-]+$/.test(p)))throw new CmsError(401,'ACCESS_INVALID');
   const decode=(v:string)=>Uint8Array.from(atob(v.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));
   const header=JSON.parse(new TextDecoder().decode(decode(parts[0])));const claims=JSON.parse(new TextDecoder().decode(decode(parts[1])));
   if(header.alg!=='RS256'||typeof header.kid!=='string'||header.kid.length>256||header.jku||header.jwk||header.x5u||header.crit)throw new CmsError(401,'ACCESS_INVALID');
   if(Date.now()>=this.until)await this.refresh();let jwk=this.keys.find((k:any)=>k.kid===header.kid);if(!jwk)throw new CmsError(401,'ACCESS_INVALID');
   const key=await crypto.subtle.importKey('jwk',jwk,{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);
   if(!await crypto.subtle.verify('RSASSA-PKCS1-v1_5',key,decode(parts[2]),new TextEncoder().encode(parts[0]+'.'+parts[1])))throw new CmsError(401,'ACCESS_INVALID');
   const now=Math.floor(Date.now()/1000);const aud=Array.isArray(claims.aud)?claims.aud:[claims.aud];
   if(claims.iss!==this.issuer||!aud.includes(this.audience)||claims.type!=='app'||!Number.isInteger(claims.iat)||!Number.isInteger(claims.exp)||claims.exp<=now||claims.iat>now+30||claims.exp<=claims.iat||claims.nbf!==undefined&&(!Number.isInteger(claims.nbf)||claims.nbf>now+30)||typeof claims.sub!=='string'||!claims.sub||claims.sub.length>256||typeof claims.email!=='string'||claims.email.length>320||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(claims.email))throw new CmsError(401,'ACCESS_INVALID');
   return {providerKey:'cloudflare_access',issuer:this.issuer,subject:claims.sub,email:claims.email,issuedAt:new Date(claims.iat*1000).toISOString(),expiresAt:new Date(claims.exp*1000).toISOString(),type:'app'};
  }catch(error){if(error instanceof CmsError)throw error;throw new CmsError(401,'ACCESS_INVALID')}
 }
}
