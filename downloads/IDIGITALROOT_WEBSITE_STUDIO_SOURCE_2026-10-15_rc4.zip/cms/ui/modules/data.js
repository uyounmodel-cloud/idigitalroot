import {api,request,ApiError} from './api.js';
import {state,currentEntity} from './state.js';

export async function loadContent(filters={}){
 const q=new URLSearchParams({sort:filters.sort||'stableKey',limit:String(filters.limit||50)});
 if(filters.search)q.set('search',filters.search);if(filters.locale)q.set('locale',filters.locale);if(filters.state)q.set('state',filters.state);if(filters.offset!=null)q.set('offset',String(filters.offset));
 let data=await api.get('/api/cms/v1/content?'+q);let rows=[...(data.rows||[])];
 if(filters.offset==null&&filters.limit==null){let pages=1;while(rows.length<Number(data.total||rows.length)&&pages<20){q.set('offset',String(rows.length));const next=await api.get('/api/cms/v1/content?'+q);if(!next.rows?.length)throw new ApiError('CONTENT_PAGE_INCONSISTENT','Content pagination did not complete safely.',409);rows.push(...next.rows);pages++}if(rows.length<Number(data.total||rows.length))throw new ApiError('CONTENT_LIST_LIMIT','Use a content filter to narrow this list.',413)}
 state.content=rows;data={...data,rows};
 if(!state.selectedEntityId||!state.content.some(x=>x.entityId===state.selectedEntityId))state.selectedEntityId=state.content.find(x=>x.entityType==='PAGE')?.entityId||state.content[0]?.entityId||null;
 return data;
}
export async function loadTree(){state.tree=await api.get('/api/cms/v1/tree');return state.tree}
export async function loadHistory(entityId=state.selectedEntityId){if(!entityId){state.history=[];return []}state.history=await api.get(`/api/cms/v1/content/${encodeURIComponent(entityId)}/history`);return state.history}
export function latestHistory(locale=state.selectedLocale){return state.history.find(x=>(x.locale_code||x.localeCode)===locale)||null}
export async function loadRevisionDetail(entityId=state.selectedEntityId,locale=state.selectedLocale){
 if(!entityId)return null;await loadHistory(entityId);const h=latestHistory(locale);if(!h)return {content:{},sections:[],revision:null};const rid=h.revision_id||h.revisionId;
 const issued=await api.post('/api/cms/v1/preview/issue',{entityId,revisionId:rid,locale,ttlSeconds:60});
 try{const d=await request(issued.previewPath,{publicRequest:true});return {content:d.content||{},sections:d.sections||[],revision:h,preview:issued}}finally{try{await api.post('/api/cms/v1/preview/revoke',{token:issued.token})}catch{}}
}
export async function loadLocales(){state.locales=await api.get('/api/cms/v1/locales');return state.locales}
export async function loadMedia(filters={}){const q=new URLSearchParams({limit:String(filters.limit||50),offset:String(filters.offset||0),sort:filters.sort||'createdAt',dir:filters.dir||'desc'});if(filters.q)q.set('q',filters.q);if(filters.state)q.set('state',filters.state);const x=await api.get('/api/cms/v1/media?'+q);state.media=x.rows||[];return x}
export async function loadProviders(){state.providers=await api.get('/api/cms/v1/providers');return state.providers}
export async function loadImports(){state.imports=await api.get('/api/cms/v1/imports');return state.imports}
export async function loadPublication(){state.publicationQueue=await api.get('/api/cms/v1/publication/queue?limit=100');state.publicationHealth=await api.get('/api/cms/v1/operations/publication-health');return {queue:state.publicationQueue,health:state.publicationHealth}}
export async function loadAnalyticsReports(){state.analyticsReports=await api.get('/api/cms/v1/analytics/reports');return state.analyticsReports}
export async function loadActors(){state.actors=await api.get('/api/cms/v1/actors');return state.actors}
export async function loadSessions(){state.sessions=await api.get('/api/cms/v1/sessions');return state.sessions}
export async function loadAudit(filters={}){const q=new URLSearchParams();for(const [k,v] of Object.entries(filters))if(v)q.set(k,String(v));state.audit=await api.get('/api/cms/v1/audit?'+q);return state.audit}
export async function loadServices(){state.services=await api.get('/api/cms/v1/services');return state.services}
export async function loadTaxonomy(){state.taxonomy=await api.get('/api/cms/v1/taxonomy');return state.taxonomy}
export async function loadRedirects(locale){const q=locale?'?locale='+encodeURIComponent(locale):'';state.redirects=await api.get('/api/cms/v1/redirects'+q);return state.redirects}
export async function ensureProductProfile(){return api.post('/api/cms/v1/products/ensure-profile',{})}
export async function findEntityByStableKey(key){if(!state.content.length)await loadContent();return state.content.find(x=>x.stableKey===key)||null}
export async function getGlobalCopy(key,locale='en'){
 await loadContent();const e=state.content.find(x=>x.stableKey===key&&x.entityType==='GLOBAL_PUBLIC_COPY');if(!e)return {entity:null,content:{},rowVersion:1};const h=await api.get(`/api/cms/v1/content/${encodeURIComponent(e.entityId)}/history`);const r=h.find(x=>(x.locale_code||x.localeCode)===locale);return {entity:e,content:r?.content||{},rowVersion:e.localeState?.[locale]?.rowVersion||1,revision:r||null};
}
export async function getEntityDetail(entityId,locale='en'){const e=state.content.find(x=>x.entityId===entityId);const h=await api.get(`/api/cms/v1/content/${encodeURIComponent(entityId)}/history`);const r=h.find(x=>(x.locale_code||x.localeCode)===locale);const detail=r?await loadRevisionDetail(entityId,locale):{content:{},sections:[]};return {entity:e,history:h,revision:r,content:detail.content||r?.content||{},sections:detail.sections||[],rowVersion:e?.localeState?.[locale]?.rowVersion||1}}
export function getCurrentEntity(){return currentEntity()}
