import {state} from './state.js';
export const tr=(en,ar)=>state.uiLang==='ar'?ar:en;
const N=[
 [['Overview','نظرة عامة'],[['dashboard','◫',['Dashboard','لوحة التحكم']],['coverage','✓',['CMS features','ميزات نظام الإدارة']],['sitemap','⌘',['Website map','خريطة الموقع']]]],
 [['Website','الموقع'],[['editor','◉',['Visual website editor','محرر الموقع المرئي']],['chapters','§',['Homepage sections','أقسام الصفحة الرئيسية']],['pages','≡',['Pages','الصفحات']],['components','▦',['Section library','مكتبة الأقسام']],['registries','◎',['Product content','محتوى المنتج']],['navigation','☰',['Navigation & footer','التنقل والتذييل']],['appearance','A',['Typography & appearance','الخطوط والمظهر']]]],
 [['Content','المحتوى'],[['localization','文',['Languages & translation','اللغات والترجمة']],['services','◇',['Services','الخدمات']],['knowledge','⌁',['Knowledge Center','مركز المعرفة']],['seo','⌕',['SEO & redirects','SEO وإعادة التوجيه']],['search','⌕',['Public search','البحث العام']],['rootcheck','✓',['Root Check','فحص الجذر']],['inquiry','⑧',['Inquiry form','نموذج الاستفسار']],['legal','⚖',['Legal & system pages','الصفحات القانونية والنظامية']]]],
 [['Media','الوسائط'],[['media','▧',['Media library','مكتبة الوسائط']],['providers','↗',['Imports & embeds','الاستيراد والتضمين']]]],
 [['Publish & measure','النشر والقياس'],[['publishing','↥',['Publishing','النشر']],['analytics','◒',['Analytics','التحليلات']],['history','◷',['Activity history','سجل النشاط']]]],
 [['Administration','الإدارة'],[['users','♙',['Users & roles','المستخدمون والأدوار']],['security','⌾',['Sessions & security','الجلسات والأمان']],['operations','⚡',['Site health','صحة الموقع']],['settings','⚙',['Site settings','إعدادات الموقع']]]]
];
export function navItems(){return N.map(([g,items])=>[tr(...g),items.map(([id,ico,l])=>[id,ico,tr(...l)])])}
const M={
 dashboard:[['Dashboard','لوحة التحكم'],['A clear overview of content, publishing, media and site health.','نظرة واضحة على المحتوى والنشر والوسائط وصحة الموقع.']],
 coverage:[['CMS features','ميزات نظام الإدارة'],['Everything available for managing this public website.','كل ما هو متاح لإدارة هذا الموقع العام.']],
 sitemap:[['Website map','خريطة الموقع'],['Public pages and URLs managed by this website.','الصفحات العامة وروابطها التي يديرها هذا الموقع.']],
 editor:[['Visual website editor','محرر الموقع المرئي'],['Edit the page while seeing it in the approved public-site design.','عدّل الصفحة وأنت تراها ضمن تصميم الموقع العام المعتمد.']],
 chapters:[['Homepage sections','أقسام الصفحة الرئيسية'],['Open any protected homepage section in the visual editor.','افتح أي قسم محمي من الصفحة الرئيسية في المحرر المرئي.']],
 pages:[['Pages','الصفحات'],['Create, edit, move, duplicate, archive and restore website pages.','أنشئ وعدّل وانقل وكرر وأرشف واستعد صفحات الموقع.']],
 components:[['Section library','مكتبة الأقسام'],['The section types editors may add to supported pages.','أنواع الأقسام التي يمكن للمحررين إضافتها إلى الصفحات المدعومة.']],
 registries:[['Product content','محتوى المنتج'],['Manage the website presentation of Personal Root, Toolbox, Workspace and Majors.','أدر عرض الجذر الشخصي والأدوات ومساحة الطالب والتخصصات على الموقع.']],
 navigation:[['Navigation & footer','التنقل والتذييل'],['Manage menu labels, destinations and footer links.','أدر تسميات القوائم ووجهاتها وروابط التذييل.']],
 appearance:[['Typography & appearance','الخطوط والمظهر'],['Choose from approved fonts and readable design settings.','اختر من الخطوط المعتمدة وإعدادات التصميم المقروءة.']],
 localization:[['Languages & translation','اللغات والترجمة'],['Manage website languages and translate content side by side.','أدر لغات الموقع وترجم المحتوى جنباً إلى جنب.']],
 services:[['Services','الخدمات'],['Manage public service names, descriptions and availability.','أدر أسماء الخدمات العامة وأوصافها وتوفرها.']],
 knowledge:[['Knowledge Center','مركز المعرفة'],['Manage articles, guides and their categories.','أدر المقالات والأدلة وتصنيفاتها.']],
 seo:[['SEO & redirects','SEO وإعادة التوجيه'],['Manage search titles, descriptions and safe redirects.','أدر عناوين البحث والأوصاف وإعادة التوجيه الآمنة.']],
 search:[['Public search','البحث العام'],['Preview what visitors can find in published website content.','عاين ما يستطيع الزوار العثور عليه في محتوى الموقع المنشور.']],
 rootcheck:[['Root Check','فحص الجذر'],['Manage Root Check information while the live scanner remains unavailable.','أدر معلومات فحص الجذر بينما يبقى الفاحص الحي غير متاح.']],
 inquiry:[['Inquiry form','نموذج الاستفسار'],['Manage the presentation of the protected eight-step inquiry journey.','أدر عرض رحلة الاستفسار المحمية المكونة من ثماني خطوات.']],
 legal:[['Legal & system pages','الصفحات القانونية والنظامية'],['Manage versioned legal pages and supported system messages.','أدر الصفحات القانونية بإصدارات ورسائل النظام المدعومة.']],
 media:[['Media library','مكتبة الوسائط'],['Upload, review, describe, preview, replace and archive website media.','ارفع وراجع ووصف وعاين واستبدل وأرشف وسائط الموقع.']],
 providers:[['Imports & embeds','الاستيراد والتضمين'],['Import approved media sources and add supported video embeds.','استورد مصادر الوسائط المعتمدة وأضف تضمينات الفيديو المدعومة.']],
 publishing:[['Publishing','النشر'],['Preview, publish, schedule, unpublish and restore earlier published content.','عاين وانشر وجدول وألغِ النشر واستعد محتوى منشوراً سابقاً.']],
 analytics:[['Analytics','التحليلات'],['Understand website activity through clear charts, totals and tables.','افهم نشاط الموقع من خلال رسوم وإجماليات وجداول واضحة.']],
 history:[['Activity history','سجل النشاط'],['Review important CMS actions and their outcomes.','راجع إجراءات نظام الإدارة المهمة ونتائجها.']],
 users:[['Users & roles','المستخدمون والأدوار'],['Manage CMS users and the access they are allowed.','أدر مستخدمي نظام الإدارة والصلاحيات المسموحة لهم.']],
 security:[['Sessions & security','الجلسات والأمان'],['Review active CMS sessions and revoke access when needed.','راجع جلسات نظام الإدارة النشطة وألغِ الوصول عند الحاجة.']],
 operations:[['Site health','صحة الموقع'],['See publishing, media and import issues that need attention.','اطلع على مشكلات النشر والوسائط والاستيراد التي تحتاج انتباهاً.']],
 settings:[['Site settings','إعدادات الموقع'],['Manage public brand information and enabled website features.','أدر معلومات العلامة العامة وميزات الموقع المفعلة.']]
};
export const META=new Proxy({}, {get(_t,p){const v=M[p]||M.dashboard;return [tr(...v[0]),tr(...v[1])]}});
export function refreshText(){return META[state.workspace]||META.dashboard}
