import {state} from './state.js';
const E={
 LOCALE_NOT_PUBLISHABLE:['Review the saved draft first using “Review complete — ready to publish”, then restore an earlier version. Reviewing alone does not publish the draft.','راجع المسودة المحفوظة أولاً باستخدام «اكتملت المراجعة — جاهز للنشر»، ثم استعد نسخة سابقة. المراجعة وحدها لا تنشر المسودة.'],
 PREVIEW_REVISION_REQUIRED:['Save a draft in this language before opening its preview.','احفظ مسودة بهذه اللغة قبل فتح المعاينة.'],
 PUBLICATION_VERSION_CONFLICT:['The published page changed while you were reviewing. Close this window, refresh and review again.','تغيرت الصفحة المنشورة أثناء المراجعة. أغلق هذه النافذة وحدّث الصفحة وراجع مجدداً.'],
 OWNER_LEGAL_DECISION_REQUIRED:['This document still needs a recorded owner decision for the exact English and Arabic versions.','لا يزال هذا المستند يتطلب قراراً موثقاً من المالك للنسختين الإنجليزية والعربية المحددتين.'],
 SCANNER_UNAVAILABLE:['Document scanning is unavailable. The file remains private.','فحص المستندات غير متاح. يبقى الملف خاصاً.'],
 DOCUMENT_NOT_APPROVED:['The document did not satisfy the approved scanning policy. It remains private.','لم يستوفِ المستند سياسة الفحص المعتمدة. يبقى خاصاً.'],
 MANAGED_DRIVE_AUTHORIZATION_REQUIRED:['Google Drive needs a managed connection from your authorized administrator. No access token is needed in this screen.','يتطلب Google Drive ربطاً يديره المسؤول المخوّل. لا حاجة إلى إدخال رمز وصول هنا.'],
 DEDICATED_EDITOR_REQUIRED:['Use the dedicated settings, navigation, service or product editor for this item.','استخدم محرر الإعدادات أو التنقل أو الخدمة أو المنتج المخصص لهذا العنصر.'],
 INQUIRY_VERSION_CONFLICT:['Another presentation was published. Reload and review before publishing again.','نُشر عرض آخر. أعد التحميل والمراجعة قبل النشر مجدداً.'],
 INQUIRY_OPTIONS_REQUIRED:['Keep at least one available choice for each required question.','أبقِ خياراً متاحاً واحداً على الأقل لكل سؤال إلزامي.'],
 ROW_VERSION_CONFLICT:['Someone changed this item after you loaded it. Reload the latest revision, review the changes, then try again.','قام شخص آخر بتعديل هذا العنصر بعد فتحه. أعد تحميل أحدث إصدار وراجعه ثم حاول من جديد.'],
 INVALID_SORT:['That sort option is not supported. Choose one of the available sort fields.','خيار الترتيب هذا غير مدعوم. اختر حقلاً من الخيارات المتاحة.'],
 CSRF_REJECTED:['Your secure editing token is no longer valid. Refresh the secure session before trying again.','رمز التحرير الآمن لم يعد صالحاً. جدّد الجلسة الآمنة ثم حاول من جديد.'],
 ORIGIN_REJECTED:['The request did not come from the approved CMS origin. Reopen the CMS from its normal address.','الطلب لم يأتِ من عنوان نظام الإدارة المعتمد. أعد فتح النظام من عنوانه الطبيعي.'],
 REAUTH_REQUIRED:['This action needs a fresh sign-in before it can continue.','هذا الإجراء يحتاج إلى تسجيل دخول حديث قبل المتابعة.'],
 FRESH_AUTH_REQUIRED:['This privileged action needs fresh authentication.','هذا الإجراء المميز يحتاج إلى مصادقة حديثة.'],
 ACCESS_FRESHNESS_REQUIRED:['Please refresh your secure sign-in before continuing.','يرجى تحديث تسجيل الدخول الآمن قبل المتابعة.'],
 ACCESS_STALE:['Your upstream sign-in is too old for this action. Sign in again.','تسجيل الدخول الخارجي قديم جداً لهذا الإجراء. سجّل الدخول من جديد.'],
 COMPONENT_DENIED:['That section type is not active in the approved component registry.','نوع القسم هذا غير فعال في سجل المكوّنات المعتمد.'],
 REDIRECT_CONFLICT:['That redirect conflicts with an existing route or redirect. Review the source path and try again.','إعادة التوجيه تتعارض مع مسار أو إعادة توجيه موجودة. راجع مسار المصدر وحاول من جديد.'],
 EXTERNAL_REDIRECT_HOST_DENIED:['External redirect hosts are not approved in the current Phase 1 profile. Use an internal path.','لا توجد نطاقات خارجية معتمدة لإعادة التوجيه في ملف المرحلة الأولى الحالي. استخدم مساراً داخلياً.'],
 MEDIA_REQUIRED:['Choose a media item first.','اختر عنصراً من الوسائط أولاً.'],
 MEDIA_STATE_INVALID:['This media item is not in the required lifecycle state for that action.','عنصر الوسائط ليس في الحالة المطلوبة لهذا الإجراء.'],
 MEDIA_VALIDATION_FAILED:['The media file did not pass validation. Review its format and metadata.','لم يجتز ملف الوسائط التحقق. راجع الصيغة والبيانات الوصفية.'],
 SCANNER_REQUIRED:['This document type requires a scanner capability that is not enabled for production yet.','هذا النوع من المستندات يتطلب قدرة فحص غير مفعلة للإنتاج بعد.'],
 FORBIDDEN:['Your current role or scope does not allow this action.','دورك أو نطاق صلاحيتك الحالي لا يسمح بهذا الإجراء.'],
 SESSION_REQUIRED:['Your CMS session has ended. Sign in again.','انتهت جلسة نظام الإدارة. سجّل الدخول من جديد.'],
 SESSION_EXPIRED:['Your CMS session has expired. Sign in again.','انتهت صلاحية جلسة نظام الإدارة. سجّل الدخول من جديد.'],
 NOT_FOUND:['The requested CMS item could not be found. Refresh the workspace and try again.','تعذر العثور على عنصر نظام الإدارة المطلوب. حدّث المساحة وحاول من جديد.'],
 DANGLING_ROUTE:['That navigation destination does not point to an active public route.','وجهة التنقل لا تشير إلى مسار عام فعال.'],
 LEGAL_APPROVAL_REQUIRED:['This legal content still requires external approval before publication.','هذا المحتوى القانوني ما زال يحتاج إلى موافقة خارجية قبل النشر.'],
 PUBLICATION_DEPENDENCY_INVALID:['Publication is blocked because a required dependency is not valid yet.','النشر محجوب لأن أحد الاعتمادات المطلوبة غير صالح بعد.'],
 MALFORMED_JSON:['The CMS received an invalid data payload. Reload the form and try again.','استلم نظام الإدارة بيانات غير صالحة. أعد تحميل النموذج وحاول من جديد.']
};
export function friendlyError(err){
 const row=E[err?.code];
 if(row)return {title:state.uiLang==='ar'?'تعذر إكمال الإجراء':'Action could not be completed',message:row[state.uiLang==='ar'?1:0],code:err.code,recoverable:true};
 const fallback=state.uiLang==='ar'?'لم نتمكن من تأكيد النتيجة. أبقِ هذه الصفحة مفتوحة وحاول مجدداً.':'We could not confirm the result. Keep this page open and try again.';
 return {title:state.uiLang==='ar'?'خطأ في الخدمة':'Service error',message:fallback,code:err?.code||'SERVICE_ERROR',recoverable:true};
}
