import {state,resetSensitive} from './state.js';
export class ApiError extends Error{constructor(code,message,status,requestId){super(message||code);this.code=code||'SERVICE_ERROR';this.status=status||500;this.requestId=requestId||''}}
function localHeaders(){return state.localMode?{'x-local-access-fixture':'root'}:{}}
export async function requestFull(path,{method='GET',body,headers={},publicRequest=false,skipCsrf=false}={}){
 const h={...localHeaders(),...headers};
 const mut=!['GET','HEAD','OPTIONS'].includes(method.toUpperCase());
 if(mut&&!skipCsrf&&!publicRequest){if(!state.csrf)throw new ApiError('CSRF_REJECTED','Secure editing token is not available.',401);h['X-CSRF-Token']=state.csrf}
 let payload;
 if(body!==undefined){h['content-type']='application/json';payload=typeof body==='string'?body:JSON.stringify(body)}
 let r;
 try{r=await fetch(path,{method,headers:h,credentials:'same-origin',body:payload})}catch(e){throw new ApiError('NETWORK_ERROR',e?.message||'Network error',0)}
 let j=null;const ct=r.headers.get('content-type')||'';try{j=ct.includes('json')?await r.json():await r.text()}catch{}
 if(!r.ok){const code=j?.error?.code||`HTTP_${r.status}`;const message=j?.error?.message||r.statusText||'Service request failed';if(r.status===401&&['SESSION_REQUIRED','SESSION_EXPIRED','ACCESS_EXPIRED'].includes(code))resetSensitive();throw new ApiError(code,message,r.status,j?.requestId)}
 if(mut&&j?.data?.entityId&&/^\/api\/cms\/v1\/(?:global-copy|products|services|navigation|footer|seo)\//.test(path)){state.selectedEntityId=j.data.entityId;if(body?.locale)state.selectedLocale=body.locale;state.savedDraft={entityId:j.data.entityId,locale:body?.locale||state.selectedLocale,workspace:state.workspace};}
 return {data:j?.data!==undefined?j.data:j,response:r};
}
export async function request(path,opts={}){return (await requestFull(path,opts)).data}
export const api={
 get:(p,o={})=>request(p,{...o,method:'GET'}),post:(p,b,o={})=>request(p,{...o,method:'POST',body:b}),patch:(p,b,o={})=>request(p,{...o,method:'PATCH',body:b}),put:(p,b,o={})=>request(p,{...o,method:'PUT',body:b})
};
export async function establishSession(){
 const endpoint=state.localMode?'/api/cms/v1/local/login':'/api/cms/v1/session/establish';
 const data=await request(endpoint,{method:'POST',body:state.localMode?{}:{returnTo:location.pathname},skipCsrf:true});
 state.actor=data.actor;state.csrf=data.csrfToken||'';state.secureSession=true;return data;
}
export async function logout(){try{if(state.actor)await api.post('/api/cms/v1/logout',{})}finally{resetSensitive()}}
