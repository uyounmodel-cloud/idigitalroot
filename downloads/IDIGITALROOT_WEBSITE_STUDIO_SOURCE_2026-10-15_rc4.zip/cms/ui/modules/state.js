export const state={
 uiLang:'en',previewLang:'en',workspace:'dashboard',device:'desktop',inspector:'content',actor:null,csrf:'',localMode:false,secureSession:false,
 dirty:false,navOpen:false,previewVisible:false,editorPane:'section',studioPreview:null,
 content:[],tree:[],selectedEntityId:null,selectedLocale:'en',selectedSectionId:null,history:[],locales:[],media:[],providers:[],imports:[],
 publicationQueue:null,publicationHealth:null,analyticsReports:[],analyticsReportKey:'overview',actors:[],sessions:[],audit:[],services:[],taxonomy:[],redirects:[],
 searchResults:null,lastPreview:null,lastMedia:null,dashboardAnalytics:null,brandSettings:null,inquiryDefinition:null,dialogReturnFocus:null,working:false,bootstrapComplete:false
};
export function resetSensitive(){state.csrf='';state.actor=null;state.secureSession=false;state.lastPreview=null;state.studioPreview=null;state.working=false;state.dirty=false}
export function isRtl(){return state.uiLang==='ar'}
export function currentEntity(){return state.content.find(x=>x.entityId===state.selectedEntityId)||state.content[0]||null}
export function currentLocaleState(entity=currentEntity()){return entity?.localeState?.[state.selectedLocale]||null}
