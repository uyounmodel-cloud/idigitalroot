// Generated from the accepted iDigitalRoot site-profile registry for P1-CMS-04.
export const COMPONENTS=[
 'hero','rich_text','rich-content','image','gallery','video-embed','cards','cta','feature-cards','audience-cards','service-cards','pricing-comparison','faq','case-study','evidence-metric','process-timeline','downloadable-resource','article-research-feed','contact','personal-root-atlas','root-toolbox','student-workspace','major-explorer','root-convergence','illustrative-people-stories','brand-manifesto','managed-services','knowledge-preview','final-cta','footer','student-problem','student-foundation','story','human-stories','three-experiences','roots','toolbox','student-benefits','my-dream','major-personalization','project-to-career','human-built','knowledge','not-student','proof','signature-ticker'
];
export const RETIRED_COMPONENTS=['retired_legacy'];
export const CHAPTERS=['hero','student-problem','student-foundation','story','human-stories','three-experiences','roots','toolbox','student-workspace','student-benefits','my-dream','major-personalization','project-to-career','human-built','knowledge','not-student','proof','faq','final-cta','footer'];
export const PRODUCT_GROUPS={
 personalRoots:['personal-root-website','personal-root-portfolio','personal-root-cv','personal-root-digital-card','personal-root-qr-codes','personal-root-links','personal-root-achievements','personal-root-contact','personal-root-health'],
 rootToolbox:['root-toolbox-cv-studio','root-toolbox-portfolio-builder','root-toolbox-digital-card','root-toolbox-qr-studio','root-toolbox-link-hub','root-toolbox-achievement-kit','root-toolbox-career-kit','root-toolbox-email-signature','root-toolbox-project-share','root-toolbox-personal-brand-kit','root-toolbox-contact-card','root-toolbox-root-export'],
 studentWorkspace:['student-workspace-university-life','student-workspace-my-future','student-workspace-personal-growth'],
 majors:['major-architecture-design','major-computer-science-engineering','major-medicine-health-sciences','major-business-law-humanities','major-other']
};
export const DESIGN={
 fontFamilies:['idr-latin-ui','idr-latin-serif','idr-arabic-ui','idr-arabic-kufi','idr-arabic-naskh'],
 fallbacks:['system-ui-tahoma-arial'],weights:[400,500,600,700,800,900],body:[16,17,18],lineHeight:[1.6,1.7],heading:['signature-large','balanced'],nav:[15,16],
 roles:{latinUi:['idr-latin-ui'],latinAccent:['idr-latin-serif'],arabicUi:['idr-arabic-ui'],arabicDisplay:['idr-arabic-kufi'],arabicEditorial:['idr-arabic-naskh']}
};
export const RUNTIME_KEYS=['public.inquiry.enabled','public.knowledge.enabled','public.search.enabled'];
export const PRIMARY_ROUTES=['/','/personal','/students','/student/toolbox','/student/workspace','/student/majors','/not-a-student'];
export const SUPPORTING_ROUTES=['/why-idigitalroot','/what-you-get','/services','/how-we-build','/knowledge','/knowledge/insights','/knowledge/guides','/knowledge/digital-future','/knowledge/research','/knowledge/stories','/knowledge/news','/company/about','/company/trust','/contact','/pricing','/legal/terms','/legal/privacy','/legal/cookies','/search','/root-check','/root-check/methodology','/inquiry','/inquiry/received','/client-login'];
export const ANALYTICS_KEYS=['overview','content_routes','acquisition','audience_technology','coarse_geography','engagement_custom','internal_search','inquiry_funnel','performance_web_vitals','public_runtime_health','bot_abuse'];

// Generated from the canonical server capability registry; checked by integration-security.
export const COMPONENT_RULES={
  "hero": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 1
  },
  "rich_text": {
    "allowedOn": [
      "PAGE",
      "KNOWLEDGE_ARTICLE"
    ],
    "maxInstances": 12
  },
  "rich-content": {
    "allowedOn": [
      "PAGE",
      "KNOWLEDGE_ARTICLE"
    ],
    "maxInstances": 12
  },
  "image": {
    "allowedOn": [
      "PAGE",
      "KNOWLEDGE_ARTICLE"
    ],
    "maxInstances": 24
  },
  "gallery": {
    "allowedOn": [
      "PAGE",
      "KNOWLEDGE_ARTICLE"
    ],
    "maxInstances": 4
  },
  "video-embed": {
    "allowedOn": [
      "PAGE",
      "KNOWLEDGE_ARTICLE"
    ],
    "maxInstances": 8
  },
  "cards": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 8
  },
  "cta": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 8
  },
  "feature-cards": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "audience-cards": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "service-cards": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "pricing-comparison": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 2
  },
  "faq": {
    "allowedOn": [
      "PAGE",
      "KNOWLEDGE_ARTICLE"
    ],
    "maxInstances": 4
  },
  "case-study": {
    "allowedOn": [
      "PAGE",
      "KNOWLEDGE_ARTICLE"
    ],
    "maxInstances": 8
  },
  "evidence-metric": {
    "allowedOn": [
      "PAGE",
      "KNOWLEDGE_ARTICLE"
    ],
    "maxInstances": 16
  },
  "process-timeline": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "downloadable-resource": {
    "allowedOn": [
      "PAGE",
      "KNOWLEDGE_ARTICLE"
    ],
    "maxInstances": 12
  },
  "article-research-feed": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "contact": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 2
  },
  "personal-root-atlas": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 2
  },
  "root-toolbox": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 2
  },
  "student-workspace": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 2
  },
  "major-explorer": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 2
  },
  "root-convergence": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 2
  },
  "illustrative-people-stories": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 8
  },
  "brand-manifesto": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 2
  },
  "managed-services": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 2
  },
  "knowledge-preview": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "final-cta": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 1
  },
  "footer": {
    "allowedOn": [
      "FOOTER",
      "PAGE"
    ],
    "maxInstances": 1
  },
  "student-problem": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "student-foundation": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "story": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "human-stories": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "three-experiences": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "roots": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "toolbox": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "student-benefits": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "my-dream": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "major-personalization": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "project-to-career": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "human-built": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "knowledge": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "not-student": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "proof": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "signature-ticker": {
    "allowedOn": [
      "PAGE"
    ],
    "maxInstances": 4
  },
  "retired_legacy": {
    "allowedOn": [],
    "maxInstances": 0
  }
};
