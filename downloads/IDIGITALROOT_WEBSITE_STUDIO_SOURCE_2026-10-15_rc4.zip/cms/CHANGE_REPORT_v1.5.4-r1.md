# CMS review candidate v1.5.4-r1

Base: owner-approved connected CMS v1.5.3, SHA-256 62f9e7441372b825d4e8535febdf7679d09d9a39464a8f63843f1eadd5c6d257. The base ZIP is preserved. This successor is CANDIDATE, not owner-approved.

Bounded UI correctness changes: preserve Arabic page sections when saving translation; retrieve exact revision sections through the existing protected preview contract; use the defined editing locale instead of an undefined state property; keep replacement dialogs visible after successful confirmation; honor form validity and re-enable a rejected confirmation; resolve homepage chapter selection by component/instance; load content across existing API pages and refresh product records after initialization; correct locale-aware date formatting; associate fields with labels; correct representative contrast/target sizes and remove missing-favicon diagnostics.

No backend TypeScript, compiled backend, migrations, provider setup or deployment is changed. Scope remains single-site. Multi-edition implementation, remaining frontend binding issues and full integrated security/QA/release gates remain open.
