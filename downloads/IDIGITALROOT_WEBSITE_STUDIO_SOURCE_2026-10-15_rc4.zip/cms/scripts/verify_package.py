from pathlib import Path
import hashlib,sys,re
root=Path(__file__).resolve().parents[1]
sums=root/'SHA256SUMS.txt'
if not sums.is_file(): print('PACKAGE_FAIL missing SHA256SUMS.txt');sys.exit(1)
rows=[]
for n,line in enumerate(sums.read_text('utf-8').splitlines(),1):
    if not line.strip(): continue
    m=re.fullmatch(r'([0-9a-f]{64})  (.+)',line)
    if not m: print('PACKAGE_FAIL malformed checksum row',n);sys.exit(1)
    h,rel=m.groups()
    p=Path(rel)
    if p.is_absolute() or '..' in p.parts or rel.startswith(('/', '\\')):
        print('PACKAGE_FAIL unsafe path',rel);sys.exit(1)
    target=root/p
    if not target.is_file() or target.is_symlink(): print('PACKAGE_FAIL missing/non-regular',rel);sys.exit(1)
    got=hashlib.sha256(target.read_bytes()).hexdigest()
    if got!=h: print('PACKAGE_FAIL checksum',rel,got,h);sys.exit(1)
    rows.append(rel)
actual=[]
for p in root.rglob('*'):
    if p.is_symlink(): print('PACKAGE_FAIL symlink',p.relative_to(root));sys.exit(1)
    if p.is_file() and p.name!='SHA256SUMS.txt': actual.append(p.relative_to(root).as_posix())
if sorted(rows)!=sorted(actual):
    print('PACKAGE_FAIL exact file set mismatch')
    print('missing rows',sorted(set(actual)-set(rows)))
    print('extra rows',sorted(set(rows)-set(actual)))
    sys.exit(1)
print('PACKAGE_INTEGRITY_PASS',len(rows),'files')
