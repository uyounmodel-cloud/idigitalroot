import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {handleCmsRequest} from '../dist/worker.js';
import {handleRequest as handlePublicRequest} from '../../backend/dist/worker.js';
import {handleAnalyticsRequest} from '../../analytics/dist/worker.js';
import {replayConversionOutbox} from '../../analytics/dist/analytics/outbox.js';
import {renderPrivatePreview} from '../../scripts/preview-renderer.mjs';
import {seedIntegratedPublicContent} from '../../scripts/seed-integrated.mjs';
import {buildLocalReviewEnvironment} from './local-review-env.mjs';

const __dirname=path.dirname(fileURLToPath(import.meta.url));const root=path.resolve(__dirname,'..');const uiRoot=path.join(root,'ui');const port=Number(process.env.CMS_LOCAL_PORT||4177);if(!Number.isInteger(port)||port<1024||port>65535)throw new Error('CMS_LOCAL_PORT must be a valid local port');const origin=`http://127.0.0.1:${port}`;const bindHost=process.env.CMS_LOCAL_BIND_HOST||'127.0.0.1';
const {env,coreDb,analyticsDb,bucket,verifier,principal,paths}=buildLocalReviewEnvironment(origin);
seedIntegratedPublicContent(coreDb);
for(const table of ['analytics_events','analytics_rollups','analytics_rollup_cursors','analytics_consent_receipts','analytics_sessions'])analyticsDb.db.exec(`DELETE FROM ${table}`);
const sessionMap=new Map();
const publicOrigin=process.env.IDR_PUBLIC_ORIGIN||'http://127.0.0.1:4400';
const counters=new Map();const limiter=max=>({async limit({key}){const now=Date.now();const old=counters.get(key);const cur=!old||now-old.at>60000?{at:now,n:0}:old;cur.n++;counters.set(key,cur);if(counters.size>10000)counters.clear();return {success:cur.n<=max}}});
const inquiryLimiter=limiter(10),analyticsLimiter=limiter(120);
const analyticsEnv={ANALYTICS_DB:analyticsDb,CORE_DB:coreDb,PUBLIC_ORIGINS:[publicOrigin],VISITOR_HMAC_SECRET:crypto.randomBytes(32).toString('hex'),SEARCH_HMAC_SECRET:crypto.randomBytes(32).toString('hex'),ENVIRONMENT_KEY:'LOCAL_INTEGRATED',ANALYTICS_RATE_LIMITER:analyticsLimiter};
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml'};
function cookies(v=''){const out={};for(const p of v.split(';')){const [k,...r]=p.trim().split('=');if(k)out[k]=r.join('=')}return out}
function headersFrom(req){const h=new Headers();for(const [k,v] of Object.entries(req.headers))if(v!==undefined)h.set(k,Array.isArray(v)?v.join(', '):v);return h}
async function requestBody(req){const chunks=[];for await(const c of req)chunks.push(c);return Buffer.concat(chunks)}
function realSessionFrom(req){const local=cookies(req.headers.cookie||'').idr_local_review_sid;return local?sessionMap.get(local):null}
function copyResponse(res,out,{localCookie}={}){const h=Object.fromEntries(out.headers);delete h['set-cookie'];if(localCookie)h['set-cookie']=localCookie;res.writeHead(out.status,h);return out.arrayBuffer().then(b=>res.end(Buffer.from(b)))}
async function localLogin(req,res){
  verifier.fixtures.root=principal();
  const r=new Request(origin+'/api/cms/v1/session/establish',{method:'POST',headers:{'x-local-access-fixture':'root','content-type':'application/json',origin},body:'{}'});
  const out=await handleCmsRequest(r,env);const txt=await out.text();if(!out.ok){res.writeHead(out.status,{'content-type':'application/json'});res.end(txt);return}
  const sc=out.headers.get('set-cookie')||'';const real=/__Host-idr_cms_sid=([^;]+)/.exec(sc)?.[1];if(!real)throw new Error('local production-shaped session cookie missing');const token=crypto.randomBytes(24).toString('hex');sessionMap.set(token,real);
  res.writeHead(200,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','set-cookie':`idr_local_review_sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=28800`});res.end(txt);
}
async function cmsProxy(req,res,url){
  if(url.pathname==='/api/cms/v1/local/login'&&req.method==='POST')return localLogin(req,res);
  verifier.fixtures.root=principal();const h=headersFrom(req);h.set('x-local-access-fixture','root');
  const real=realSessionFrom(req);if(real)h.set('cookie',`__Host-idr_cms_sid=${real}`);else h.delete('cookie');
  if(!['GET','HEAD','OPTIONS'].includes(req.method||'GET'))h.set('origin',origin);
  const b=await requestBody(req);const r=new Request(origin+url.pathname+url.search,{method:req.method,headers:h,body:['GET','HEAD'].includes(req.method||'GET')?undefined:b,duplex:'half'});const out=await handleCmsRequest(r,env);
  if(url.pathname==='/api/cms/v1/logout'&&req.method==='POST'){const local=cookies(req.headers.cookie||'').idr_local_review_sid;if(local)sessionMap.delete(local);return copyResponse(res,out,{localCookie:'idr_local_review_sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0'})}
  return copyResponse(res,out);
}
async function publicProxy(req,res,url){
  const h=headersFrom(req);const b=await requestBody(req);const r=new Request(origin+url.pathname+url.search,{method:req.method,headers:h,body:['GET','HEAD'].includes(req.method||'GET')?undefined:b,duplex:'half'});const out=await handlePublicRequest(r,{CORE_DB:coreDb,PUBLIC_ORIGIN:publicOrigin,ENVIRONMENT_KEY:'LOCAL_INTEGRATED',RATE_LIMIT_HASH_SALT:'local-integrated',PUBLIC_MEDIA_BUCKET:bucket,INQUIRY_RATE_LIMITER:inquiryLimiter});if(req.method==='POST'&&out.ok)await replayConversionOutbox(coreDb,analyticsDb,25);return copyResponse(res,out);
}
async function analyticsProxy(req,res,url){const h=headersFrom(req);const b=await requestBody(req);const out=await handleAnalyticsRequest(new Request(publicOrigin+url.pathname,{method:req.method,headers:h,body:b,duplex:'half'}),analyticsEnv);return copyResponse(res,out)}
async function staticFile(res,url){
  let rel=url.pathname==='/'?'index.html':url.pathname.replace(/^\//,'');const file=path.resolve(uiRoot,rel);if(!(file===uiRoot||file.startsWith(uiRoot+path.sep))){res.writeHead(403);res.end('forbidden');return}try{const b=await fs.readFile(file);res.writeHead(200,{'content-type':types[path.extname(file)]||'application/octet-stream','cache-control':'no-store'});res.end(b)}catch{res.writeHead(404,{'content-type':'text/plain; charset=utf-8'});res.end('not found')}
}
const server=http.createServer(async(req,res)=>{try{const url=new URL(req.url||'/',origin);if(url.pathname==='/preview'&&req.method==='GET'){const check=new Request(origin+'/api/preview/v1/content'+url.search);const out=await handleCmsRequest(check,env);if(!out.ok)return await copyResponse(res,out);const data=(await out.json()).data;const html=await renderPrivatePreview(data,coreDb,handlePublicRequest,{CORE_DB:coreDb,PUBLIC_ORIGIN:publicOrigin,ENVIRONMENT_KEY:'LOCAL_INTEGRATED',PUBLIC_MEDIA_BUCKET:bucket});res.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'private, no-store','x-robots-tag':'noindex, nofollow','referrer-policy':'no-referrer','content-security-policy':"default-src 'self'; script-src 'none'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'none'"});return res.end(html)}if(url.pathname.startsWith('/preview-assets/')&&req.method==='GET'){const name=url.pathname.slice(16);if(!/^[A-Za-z0-9_.-]+\.css$/.test(name)){res.writeHead(404);return res.end()}const css=await fs.readFile(path.join(root,'../website/dist/client/_astro',name));res.writeHead(200,{'content-type':'text/css','cache-control':'no-store'});return res.end(css)}if(url.pathname.startsWith('/api/cms/')||url.pathname.startsWith('/api/preview/'))return await cmsProxy(req,res,url);if(url.pathname==='/api/analytics/v1/events')return await analyticsProxy(req,res,url);if(url.pathname.startsWith('/api/public/'))return await publicProxy(req,res,url);return await staticFile(res,url)}catch(e){console.error('LOCAL_SERVER_ERROR',e);res.writeHead(500,{'content-type':'application/json; charset=utf-8'});res.end(JSON.stringify({ok:false,error:{code:'LOCAL_REVIEW_SERVER_ERROR',message:'Local review server could not complete the request.'}}))}});
server.listen(port,bindHost,()=>{console.log('CMS_LOCAL_SERVER_READY');console.log('CMS_LOCAL_SERVER_URL',origin);console.log('CMS_REVIEW_CANDIDATE','v1.5.5-integrated-candidate');console.log('CMS_LOCAL_REVIEW_CORE_D1',paths.corePath);console.log('CMS_LOCAL_REVIEW_ANALYTICS_D1',paths.analyticsPath)});
function close(){server.close(()=>{try{coreDb.close()}catch{}try{analyticsDb.close()}catch{}process.exit(0)})}
process.on('SIGTERM',close);process.on('SIGINT',close);
