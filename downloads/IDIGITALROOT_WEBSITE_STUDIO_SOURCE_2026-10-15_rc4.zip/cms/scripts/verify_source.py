from pathlib import Path
import hashlib,re,sys,json
root=Path(__file__).resolve().parents[1]
# Security and scope static checks
bad_patterns=[r'account_id\s*=\s*["\'][0-9a-f]{20,}',r'database_id\s*=\s*["\'][0-9a-f-]{20,}',r'api[_-]?token\s*=\s*["\'][^<\s]{12,}',r'wrangler\s+(deploy|d1\s+create|r2\s+bucket\s+create)',r'tenant_id',r'<textarea[^>]*(javascript|css|source)']
text='\n'.join(p.read_text('utf-8',errors='ignore') for p in root.rglob('*') if p.is_file() and p.suffix in {'.ts','.js','.mjs','.md','.json','.html','.css'})
for pat in bad_patterns:
    if re.search(pat,text,re.I): print('STATIC_FAIL',pat);sys.exit(1)
# exact migration hashes from accepted DATA-02 lineage; self-contained in sealed source
expected={
'schema/core/migrations/0001_core_registry.sql':'bbfeaca5a70d5ac5e13b5917f7de2a1eb6d857ad8e6b0c1debb36cd8be60315a',
'schema/core/migrations/0002_auth_rbac_seams.sql':'ccd4e878df1635b7756dc4b934871162a3b1509ce1fdd3ff0baa3baf0802bc87',
'schema/core/migrations/0003_routes_and_content_entities.sql':'416dce1173c103ea5f01efba9d225f9857ec5551bfc2759cacd6a722ee505647',
'schema/core/migrations/0004_content_revisions_and_sections.sql':'8afad9495802af85fc0312b17d57d6a66c9753a6878ac963a4055d90da129949',
'schema/core/migrations/0005_media_and_embed_registry.sql':'8daf78187c5f237111a7a1048ac6b1e80fc00e07b5c551b61b641cece9b72f4a',
'schema/core/migrations/0006_publication_schedule_idempotency.sql':'865a26138fc72ecb0cb9dca08ad24cf20d49815043d061c3f5224a1b691cdee3',
'schema/core/migrations/0007_inquiry_and_lead.sql':'5ea7c12cde8d20a6e3f52e5340abd9bf35f4ad50cf6086d5ad30c88d306b11cf',
'schema/core/migrations/0008_retention_policy_and_audit.sql':'3b75ceb8b0c4259c7757758779bba57bd8e52c8c9f9766520754b68e729cdae8',
'schema/core/migrations/0009_integrity_triggers.sql':'134226ff1a4fe6d7d608d8237626e0c9ff0f53a95dddc7f589d9f6bd6ee69ac3',
'schema/core/migrations/0010_registry_seed.sql':'eb3898df4a58409de32456c99e5541092dd2f44990589dc6e22df0ad8a15d583',
'schema/core/migrations/0011_publication_guard_closure.sql':'c1ea22d6730d32f3de61f9dec3eb82f01949c64e30303a3e8b31f5575204ea9d',
'schema/core/migrations/0012_auth_physical_alignment.sql':'64e71eae24d9c6c6a8ea279269ac71faf7b7ae93732db2a9b0e99848ccdcaedc',
'schema/core/migrations/0013_cms_extensions_and_analytics_seam.sql':'c4cad248d3d4ee8aaca2b87029517ffd1db08f0f73f432fa4a9bc19b9344bd33',
'schema/core/migrations/0014_permissions_roles_retention_registry.sql':'dfab0df6c6b436b4b97dfa0d5419a94f1adf08dd5f6309cb752cc564666c0ad1',
'schema/core/migrations/0015_preview_capability_persistence.sql':'b8987aaba83bca3b0c445f61b69418d78997d6ec22a8d7d62eb827e2ccd1d102',
'schema/core/migrations/0016_http_redirect_and_final_registry_closure.sql':'c503555f67999744331f509e2e7ce54b077b25033117e5623f5a2ca913690d48',
'schema/analytics/migrations/0001_analytics_schema.sql':'930f20b7a825d29cab6ceb3d45c8c70a75199d1f8222b38b498267cbb6aa74ee',
'schema/analytics/migrations/0002_analytics_registry_seed.sql':'478563180a82260093a4f9f10728bc77591d30c15aa345607c3041889226e852',
}
for rel,h in expected.items():
    got=hashlib.sha256((root/rel).read_bytes()).hexdigest()
    if got!=h: print('MIGRATION_HASH_FAIL',rel,got,h);sys.exit(1)
# P1-CMS-03 preserves 0001-0015 and adds exactly 0016.
core=sorted((root/'schema/core/migrations').glob('*.sql'))
analytics=sorted((root/'schema/analytics/migrations').glob('*.sql'))
if len(core)!=16 or core[-1].name!='0016_http_redirect_and_final_registry_closure.sql' or len(analytics)!=2:
    print('MIGRATION_SHAPE_FAIL');sys.exit(1)
m15=core[-2].read_text('utf-8')
if 'preview_capabilities' not in m15 or re.search(r'\b(raw_?token|bearer_?token)\b',m15,re.I):
    print('PREVIEW_MIGRATION_FAIL');sys.exit(1)
repo=(root/'src/core/repository.ts').read_text('utf-8')
adv=(root/'src/core/advanced.ts').read_text('utf-8')
worker=(root/'src/worker.ts').read_text('utf-8')
for needle in ['class D1AdvancedRepository','private p(sql:string','db.batch','preview_capabilities','publication_events','publication_pointers','publication_schedules','idempotency_records','audit_events']:
    if needle not in repo: print('REPOSITORY_SEAM_FAIL',needle);sys.exit(1)
for needle in ['class R2BindingAdapter','FixedGoogleDriveHttpClient','validateJpeg','validatePng','MEDIA_NOT_VALIDATED','SCANNER_REQUIRED']:
    if needle not in adv: print('ADVANCED_GUARD_FAIL',needle);sys.exit(1)
for needle in ['createProductionEnv','CORE_DB','MEDIA_BUCKET','PREVIEW_SECRET','new R2BindingAdapter','new D1AdvancedRepository']:
    if needle not in worker: print('WORKER_BINDING_SEAM_FAIL',needle);sys.exit(1)
# Production construction must use physical D1/R2 authority and no MemoryStore core authority.
prod=worker[worker.index('export function createProductionEnv'):]
if 'LocalR2Adapter' in prod: print('PRODUCTION_LOCAL_R2_FAIL');sys.exit(1)
if 'new MemoryStore' in prod or 'mirrorRevision(' in worker: print('PRODUCTION_MEMORY_AUTHORITY_FAIL');sys.exit(1)
core_d1=(root/'src/core/core-d1.ts').read_text('utf-8')
for needle in ['class D1CoreCmsService','cms_external_identities','cms_session_security','actor_role_scopes','audit_events','content_revisions','page_hierarchy','db.batch','private p(sql:string']:
    if needle not in core_d1: print('CORE_D1_SEAM_FAIL',needle);sys.exit(1)
ui_auth_text='\n'.join(p.read_text('utf-8',errors='ignore') for p in (root/'ui').rglob('*.js'))
for needle in ['__Host-idr_cms_sid','SameSite=Strict','X-CSRF-Token','/api/cms/v1/session/establish','new D1CoreCmsService']:
    if needle not in worker and needle not in ui_auth_text: print('AUTH_FLOW_SEAM_FAIL',needle);sys.exit(1)
if any(int(p.name[:4])>16 for p in (root/'schema/core/migrations').glob('*.sql') if p.name[:4].isdigit()): print('MIGRATION_AFTER_0016_FORBIDDEN');sys.exit(1)

# R3 production contract-parity static controls.
security=(root/'src/core/security.ts').read_text('utf-8')
if "request.headers.get('x-idr-csrf')" in security or "request.headers.get('x-csrf-token')" in security:
    print('R3_CSRF_HELPER_HEADER_FALLBACK_FAIL');sys.exit(1)
if "env.LOCAL_TEST_MODE?request.headers.get('x-idr-csrf'):null" not in worker:
    print('R3_LOCAL_CSRF_GATE_FAIL');sys.exit(1)
prod=worker[worker.index('export function createProductionEnv'):]
if 'LOCAL_TEST_MODE:true' in prod:
    print('R3_PRODUCTION_LOCAL_MODE_FAIL');sys.exit(1)
if "const orderBy:Record<string,string>={stableKey:" not in core_d1 or "if(!order)throw new CmsError(400,'INVALID_SORT')" not in core_d1:
    print('R3_SORT_ALLOWLIST_FAIL');sys.exit(1)
list_block=core_d1[core_d1.index('async listContent'):core_d1.index('async tree')]
if "ORDER BY ${order}" not in list_block or "${q.sort}" in list_block or "ORDER BY ${sort}" in list_block:
    print('R3_SORT_SQL_SHAPE_FAIL');sys.exit(1)
if list_block.count('const where=')!=1 or list_block.count('WHERE ${where}')!=2:
    print('R3_FILTER_TOTAL_PARITY_FAIL');sys.exit(1)
closure=(root/'src/core/approved-scope.ts').read_text('utf-8')
for needle in ['class ApprovedScopeService','bulkPages','createLocale','saveFooter','createTaxonomyTerm','createRedirect','publicationQueue','publicationHealth','auditFiltered','saveGlobalCopy','ensureProductRecords','createService','saveInquiryDefinition']:
    if needle not in closure: print('P1CMS03_CLOSURE_SEAM_FAIL',needle);sys.exit(1)
if 'ProductionAnalyticsAdapter' not in (root/'src/analytics/adapter.ts').read_text('utf-8'): print('P1CMS03_ANALYTICS_ADAPTER_FAIL');sys.exit(1)
print('SOURCE_STATIC_PASS',len(expected),'accepted migration hashes + P1-CMS-03 closure guards')
