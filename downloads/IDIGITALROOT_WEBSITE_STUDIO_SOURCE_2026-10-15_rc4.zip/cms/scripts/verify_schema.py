from pathlib import Path
import sqlite3,tempfile,sys,hashlib
root=Path(__file__).resolve().parents[1]
core=sorted((root/'schema/core/migrations').glob('*.sql'))
analytics=sorted((root/'schema/analytics/migrations').glob('*.sql'))
if len(core)!=16 or core[-1].name!='0016_http_redirect_and_final_registry_closure.sql': raise SystemExit('core migration shape mismatch')
if len(analytics)!=2: raise SystemExit('analytics migration count mismatch')

def apply(db, files):
    db.execute('PRAGMA foreign_keys=ON')
    for p in files: db.executescript(p.read_text())

def checks(db,label):
    if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok': raise SystemExit(label+' integrity failed')
    fk=db.execute('PRAGMA foreign_key_check').fetchall()
    if fk: raise SystemExit(label+' foreign key failed '+repr(fk[:3]))

# Fresh exact 0001-0016 apply.
db=sqlite3.connect(':memory:');apply(db,core);checks(db,'fresh');
cols={r[1] for r in db.execute("PRAGMA table_info(preview_capabilities)")}
need={'token_hash','environment_key','entity_id','revision_id','locale_code','actor_id','session_id','purpose','created_at','expires_at','revoked_at','row_version'}
if cols!=need: raise SystemExit('preview table columns mismatch')
if 'token' in cols or 'raw_token' in cols: raise SystemExit('raw preview token column forbidden')

# P1-CMS-03 redirect + registry closure.
if db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='http_redirects'").fetchone() is None: raise SystemExit('redirect table missing')
if db.execute("SELECT count(*) FROM component_families WHERE component_key IN ('rich-content','video-embed','personal-root-atlas','major-explorer','rich_text','cards') AND code_registered=1").fetchone()[0]!=6: raise SystemExit('component registry closure missing')
if db.execute("SELECT code_registered FROM component_families WHERE component_key='retired_legacy'").fetchone()!=(0,): raise SystemExit('retired registry marker missing')
print('CORE_FRESH_SCHEMA_PASS',len(core))

# Exact accepted 0001-0015 -> 0016 upgrade, stable registry IDs, and migration-runner rerun contract.
up=sqlite3.connect(':memory:');apply(up,core[:-1]);checks(up,'pre-upgrade')
def snapshot(conn):
    out={}
    for t in ['locales','component_registry','permissions','roles','retention_classes','embed_providers']:
        try: out[t]=conn.execute(f'SELECT * FROM {t} ORDER BY 1').fetchall()
        except sqlite3.OperationalError: out[t]=[]
    return out
before=snapshot(up);up.executescript(core[-1].read_text());after=snapshot(up)
for table in ['locales','permissions','roles','retention_classes','embed_providers']:
    if before.get(table)!=after.get(table): raise SystemExit('stable accepted registry rows changed during 0016 upgrade: '+table)
checks(up,'upgrade-0016')
print('CORE_UPGRADE_0016_PASS')

an=sqlite3.connect(':memory:');apply(an,analytics);checks(an,'analytics');print('ANALYTICS_SCHEMA_PASS',len(analytics))
