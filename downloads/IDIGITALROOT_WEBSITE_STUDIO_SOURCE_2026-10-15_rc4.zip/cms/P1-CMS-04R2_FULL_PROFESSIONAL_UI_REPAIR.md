# P1-CMS-04R2 — Full Professional Editor-UI Repair

## Trigger

During owner review of the connected CMS, the owner made the governing presentation requirement explicit:

> The CMS must be professional, simple and clear for ordinary public-website content editors. Pages must display human page names rather than keys such as `page.hero`; analytics must display charts/tables rather than JSON; ordinary workflows must not look like a developer CMS.

The owner also confirmed that this CMS core is intended to become the reusable template/core for future public websites, so the human-facing editor boundary must be solved generically rather than only for one iDigitalRoot screen.

## Repair rule

The accepted backend, D1/R2/Analytics/service contracts and migration lineage remain authoritative. P1-CMS-04R2 repairs the presentation layer comprehensively:

- human labels instead of internal keys;
- normal forms instead of raw structured payload editing;
- charts/tables/metrics instead of report JSON;
- readable statuses/dates/actions instead of enum/ID dumps;
- protected internal identifiers retained only in DOM datasets/service calls when required by the accepted API;
- no fake success and no weakening of policy/security gates.

## Full-workspace presentation audit

The complete 27-workspace navigation set is covered by static/browser acceptance. Representative repairs include:

1. **Dashboard** — human website metrics and recent activity.
2. **CMS features** — capability cards in editorial language.
3. **Website map** — human page names and public URLs.
4. **Visual Website Editor** — human page/section names, normal content fields, design selectors, media controls, WYSIWYG/safe-source rich editing.
5. **Homepage sections** — editor cards without exposing frozen section IDs.
6. **Pages** — human page names and EN/AR publication states; internal stable keys hidden.
7. **Section library** — human section names/descriptions rather than component identifiers.
8. **Product content** — human content groups and editing actions.
9. **Navigation** — structured menu rows; no JSON textarea.
10. **Appearance** — normal design/font/brand controls.
11. **Languages & translation** — side-by-side English/Arabic fields.
12. **Services** — human service names/forms; internal keys derived automatically.
13. **Knowledge** — titles and content types; internal keys derived automatically.
14. **SEO & redirects** — human SEO fields and redirect types.
15. **Search** — human search management/results.
16. **Root Check** — truthful informational/policy-gated presentation.
17. **Inquiry form** — normal form-definition controls.
18. **Legal** — normal content editing.
19. **Media** — human media cards, metadata, source/service facts and protected preview.
20. **Imports & embeds** — provider cards and ordinary import/video actions; provider configuration payloads hidden.
21. **Publishing** — human content names, languages, statuses, schedules and version comparison.
22. **Analytics** — report tabs, summary cards, charts and tables; raw report JSON hidden from ordinary presentation.
23. **Activity history** — human user/action/content names and dates; no actor/correlation IDs.
24. **Users & roles** — friendly role names and access-area controls.
25. **Security** — human signed-in-session view without session IDs.
26. **Site health** — human content/status health presentation.
27. **Settings** — ordinary website settings while protected system settings remain bounded.

## Reusable-core rule

The generic CMS core may store structured keys and typed payloads internally, but site profiles supply the human labels, allowed components/fields and website-specific content structure. A future public website should reuse the same professional editor shell without exposing its editors to implementation identifiers.

## Stale-runtime prevention

Owner review now carries a visible `OWNER REVIEW BUILD v1.5.3` marker. The next bounded review package uses an isolated local port and fails closed if that port is unavailable, preventing an older local server from being mistaken for the new build.

## Preserved technical/security boundaries

- No backend/schema authority redesign.
- Core migrations remain exactly 0001–0016.
- Analytics migrations remain exactly 0001–0002.
- No migration 0017+.
- No browser-side direct D1/R2 access.
- No arbitrary JavaScript/CSS/iframe execution.
- Rich source is sanitized and server validation remains authoritative.
- No production/provider mutation.
- No production deployment authority.
- No fake-success mutation behavior.
- Future/policy-gated actions remain truthful.

## Verification additions

Static/browser acceptance rejects ordinary-workspace presentation of raw payload/developer identifiers, verifies all visible static action families have handlers, verifies all 27 workspaces load, confirms page creation through the real connected service, verifies navigation/footer/translation/media/provider/analytics/publishing/security workflows, verifies rich-content sanitization, and preserves English LTR / Arabic RTL placement and responsive behavior.
