# P1-CMS-04R3 — Real Browser Module-Graph Repair

## Trigger

Owner review build v1.5.2 reached HTTP 200 but rendered a blank page in the real Windows browser. The prior browser acceptance harness bundled UI modules into one script, so it did not exercise native ES-module import/export resolution.

## Root cause

Two owner-UI refactors accidentally renamed imported data helpers without changing their real exports:

- `loadLocales` was imported/called as `loadLanguages` in `ui/modules/workspaces/content.js`.
- `loadRevisionDetail` was imported/called as `loadVersionDetail` in `ui/modules/workspaces/editor.js`.

Real browsers fail the module graph before `ui/app.js` can render the login screen when an imported named export does not exist.

## Repair

The two imports/call sites were restored to the real accepted helper names. No backend service, schema, migration, compiled backend authority, D1/R2/Analytics contract, permission, or publication behavior was changed.

A new `tests/ui-real-module-graph.test.mjs` gate now imports the actual browser module graph with native ES-module resolution and requires resolution to reach the expected DOM boundary. This fails closed on missing/renamed exports before the release can be sealed.

## Result

Connected owner-review source is now **v1.5.3**. The professional-editor UI from v1.5.2 is preserved, with the real-browser module graph repaired and explicitly tested.
