import {verifyRequestContext} from '../website/.fe02-build/request-context.js';
import {handleAnalyticsRequest} from '../analytics/dist/worker.js';
import {runScheduledAnalytics} from '../analytics/dist/scheduled/jobs.js';
export default {async fetch(request,bindings){
 if(!bindings.ANALYTICS_RATE_LIMITER)return new Response(JSON.stringify({ok:false,code:'ABUSE_PROTECTION_UNAVAILABLE'}),{status:503,headers:{'content-type':'application/json','cache-control':'no-store'}});
 const visitor=await verifyRequestContext(request,bindings.PUBLIC_API_CONTEXT_SECRET,bindings.PUBLIC_ORIGIN);if(!visitor)return new Response(JSON.stringify({ok:false,code:'ABUSE_CONTEXT_REJECTED'}),{status:403,headers:{'content-type':'application/json','cache-control':'no-store'}});const h=new Headers(request.headers);h.set('cf-connecting-ip',visitor);request=new Request(request,{headers:h});return handleAnalyticsRequest(request,{...bindings,PUBLIC_ORIGINS:[bindings.PUBLIC_ORIGIN]});
},async scheduled(_event,bindings){const end=new Date();end.setUTCMinutes(0,0,0);const start=new Date(end.getTime()-3600000);return runScheduledAnalytics(bindings.ANALYTICS_DB,bindings.CORE_DB,start.toISOString(),end.toISOString());}};
