import {ServiceDocumentScanner} from '../cms/dist/core/document-scanner.js';
import legalAuthority from './LEGAL_APPROVALS.json';
import {handleRequest as publicHandler} from '../backend/dist/worker.js';
import {getInquiryDefinition} from '../backend/dist/services/inquiry.js';
import {protectedPreview} from './private-preview.mjs';
import {createProductionEnv,handleCmsRequest} from '../cms/dist/worker.js';
import {CloudflareAccessVerifier} from '../cms/dist/core/cloudflare-access.js';
import {ProductionAnalyticsAdapter} from '../cms/dist/analytics/adapter.js';
import {CoreAuthorizationVerifier} from '../analytics/dist/analytics/auth.js';
import {queryAnalytics,exportAnalytics,requireAnalyticsConfig} from '../analytics/dist/analytics/reports.js';
const verifiers=new Map();
function environment(bindings,override){
 let accessVerifier=override;
 if(!accessVerifier){const key=bindings.ACCESS_ISSUER+'|'+bindings.ACCESS_AUDIENCE;if(!verifiers.has(key)){if(verifiers.size>=8)verifiers.clear();verifiers.set(key,new CloudflareAccessVerifier(bindings.ACCESS_ISSUER,bindings.ACCESS_AUDIENCE))}accessVerifier=verifiers.get(key);}
 const authz=new CoreAuthorizationVerifier(bindings.CORE_DB);
 const ctx=c=>({...c,environmentKey:bindings.ENVIRONMENT_KEY});
 const analytics=new ProductionAnalyticsAdapter({query:(c,q)=>queryAnalytics(bindings.ANALYTICS_DB,bindings.CORE_DB,authz,ctx(c),q),export:(c,q)=>exportAnalytics(bindings.ANALYTICS_DB,bindings.CORE_DB,authz,ctx(c),q),async config(c){await requireAnalyticsConfig(authz,ctx(c));return {environment:bindings.ENVIRONMENT_KEY,policyGate:'OPEN',collectionMode:'OFF_BY_DEFAULT'}}});
 if(!bindings.PREVIEW_SECRET||bindings.PREVIEW_SECRET.length<32)throw Error('CMS_PREVIEW_CONFIGURATION_REQUIRED');
 const env=createProductionEnv({CORE_DB:bindings.CORE_DB,MEDIA_BUCKET:bindings.MEDIA_BUCKET,PREVIEW_SECRET:bindings.PREVIEW_SECRET,CMS_ORIGIN:bindings.CMS_ORIGIN,accessVerifier,analytics,legalApprovals:legalAuthority.ownerDecisionReference?legalAuthority.documents:{},documentScanner:bindings.PDF_SCAN_SERVICE&&bindings.PDF_SCAN_POLICY_VERSION?new ServiceDocumentScanner(bindings.PDF_SCAN_SERVICE,bindings.PDF_SCAN_POLICY_VERSION):undefined});if(bindings.DRIVE_AUTHORIZATION_SERVICE)env.driveTokenProvider=async()=>{const r=await bindings.DRIVE_AUTHORIZATION_SERVICE.fetch(new Request('https://drive-authorization.internal/token',{method:'POST'}));if(!r.ok)throw Error('DRIVE_AUTHORIZATION_UNAVAILABLE');const data=await r.json();if(typeof data.accessToken!=='string'||data.accessToken.length>4096)throw Error('DRIVE_AUTHORIZATION_UNAVAILABLE');return data.accessToken};env.inquiryDefinitionReader=(locale,versionId)=>getInquiryDefinition(bindings.CORE_DB,locale,versionId);return env;
}
export async function handleCmsWorker(request,bindings,verifierOverride){
 try{const url=new URL(request.url);if(/^\/media\/[A-Za-z0-9._:-]{1,160}$/.test(url.pathname)){url.pathname='/api/public/v1'+url.pathname;return publicHandler(new Request(url),{CORE_DB:bindings.CORE_DB,PUBLIC_MEDIA_BUCKET:bindings.MEDIA_BUCKET});}if(url.pathname==='/preview'||url.pathname.startsWith('/preview-media/'))return await protectedPreview(request,bindings,environment(bindings,verifierOverride));if(url.pathname.startsWith('/api/cms/')||url.pathname.startsWith('/api/preview/'))return await handleCmsRequest(request,environment(bindings,verifierOverride));await environment(bindings,verifierOverride).accessVerifier.verify(request);const out=await bindings.ASSETS.fetch(request);const h=new Headers(out.headers);h.set('cache-control','no-store');h.set('x-content-type-options','nosniff');h.set('referrer-policy','no-referrer');h.set('x-frame-options','DENY');h.set('content-security-policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");return new Response(out.body,{status:out.status,headers:h});}
 catch{return new Response(JSON.stringify({ok:false,error:{code:'CMS_UNAVAILABLE'}}),{status:503,headers:{'content-type':'application/json','cache-control':'no-store'}})}
}
export async function runCmsScheduled(bindings){if(bindings.ENABLE_SCHEDULED_PUBLICATION!=='true')return {status:'DISABLED'};const env=environment(bindings,{verify:async()=>{throw Error('SCHEDULED_EVENT_HAS_NO_BROWSER_PRINCIPAL')}});return env.advanced.runScheduled((actorId,entityId,locale)=>env.service.scheduledActor(actorId,entityId,locale))}
export default {fetch:(request,bindings)=>handleCmsWorker(request,bindings),scheduled:(_event,bindings)=>runCmsScheduled(bindings)};
