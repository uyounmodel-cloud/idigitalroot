import { exact, integer, strings, text, validateContext } from '../../../contracts/v1/authority-context.mjs';
import { modelOnly, outcome } from '../../../contracts/v1/outcomes.mjs';

const policies = Object.freeze({
  'staff.configure': ['SuperAdmin', ['enabled', 'reason']],
  'payment.pending': ['OperationsManager', ['evidenceReference']],
  'project.update': ['ProjectProductionStaff', ['stage', 'comment']],
  'billing.verify': ['BillingStaff', ['evidenceReference']],
  'support.message': ['SupportStaff', ['message']],
  'commercial.draft': ['OperationsManager', ['amount', 'currency', 'terms', 'inclusions']],
  'operations.correct': ['OperationsManager', ['reason', 'correction']],
  'operations.correct.review': ['SuperAdmin', ['reason']],
});
export function evaluateAdmin(context, request, scope, now) {
  const identity = validateContext(context, 'ADMIN_STAFF', 'admin-model', now);
  if (identity.kind !== 'ModelOnly') return identity;
  if (!exact(request, ['operation', 'accountId', 'rootId', 'objectId', 'fields', 'expectedVersion', 'digest']) ||
      !['operation', 'accountId', 'rootId', 'objectId', 'digest'].every(k => text(request[k])) ||
      !strings(request.fields) || !integer(request.expectedVersion) ||
      !exact(scope, ['testOnly', 'accountId', 'rootId', 'objectId', 'version', 'assignees',
        'capabilities', 'evidenceMakerId', 'acceptedQuote', 'stepUp']) || scope.testOnly !== true ||
      !['accountId', 'rootId', 'objectId', 'evidenceMakerId'].every(k => text(scope[k])) ||
      !integer(scope.version) || !strings(scope.assignees) || !strings(scope.capabilities) ||
      typeof scope.acceptedQuote !== 'boolean' || !exact(scope.stepUp,
        ['subjectId', 'operation', 'digest', 'version', 'expiresAt'])) return outcome('Deny', 'VALIDATION_ERROR');
  if (![context, request].every(x => x.accountId === scope.accountId && x.rootId === scope.rootId) ||
      request.objectId !== scope.objectId || !scope.assignees.includes(context.subjectId)) return outcome('Deny', 'NOT_FOUND_SCOPED');
  const rule = Object.hasOwn(policies, request.operation) ? policies[request.operation] : null;
  // No wildcard role, production capability, publication, recovery or customer consent.
  if (!rule || rule[0] !== context.role || !scope.capabilities.includes(`TEST_ONLY:${request.operation}`) ||
      !request.fields.every(k => rule[1].includes(k))) return outcome('Deny', 'FORBIDDEN');
  if (request.expectedVersion !== scope.version) return outcome('Conflict', 'VERSION_CONFLICT');
  const step = scope.stepUp;
  if (step.subjectId !== context.subjectId || step.operation !== request.operation ||
      step.digest !== request.digest || step.version !== scope.version || !integer(step.expiresAt) ||
      step.expiresAt <= now) return outcome('Deny', 'REAUTH_REQUIRED');
  if (['billing.verify', 'operations.correct.review'].includes(request.operation) &&
      scope.evidenceMakerId === context.subjectId) return outcome('Deny', 'FORBIDDEN');
  if (request.operation === 'billing.verify' && scope.acceptedQuote !== true) return outcome('Deny', 'FORBIDDEN');
  return modelOnly(); // In particular, billing.verify does NOT produce Paid.
}
