import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateClient } from '../../client/src/authorization/policy-model.mjs';

const now = 100;
function fixture(role = 'Owner', operation = 'tool.read') {
  const context = { testOnly: true, evidence: 'MODEL_ONLY', namespace: 'CLIENT_HUMAN', subjectId: 'member-a',
    sessionId: 'synthetic-session', accountId: 'account-a', rootId: 'root-a', credentialEpoch: 1, authzEpoch: 2,
    assurance: 'SYNTHETIC_PASSWORD_AND_WEBAUTHN', audience: 'client-model', expiresAt: 110, role };
  const epoch = { ownership: 2, grant: 3, membership: 4, guardian: 5, privacy: 6 };
  const fields = { 'tool.read': ['title', 'content'], 'tool.mutate': ['content'], 'share.create': ['itemVersion', 'recipient'],
    'export.create': ['itemVersion', 'format'], 'project.approve': ['artifactHash', 'artifactVersion'],
    'quote.accept': ['quoteHash', 'termsVersion'], 'support.message': ['message'], 'renewal.read': ['period', 'status'] };
  const request = { operation, accountId: 'account-a', rootId: 'root-a', objectId: 'item-a',
    fields: fields[operation], expectedVersion: 2, expectedEpochs: { ...epoch }, category: 'study', purpose: 'study-help', phase: 'EXECUTION' };
  const state = { testOnly: true, accountId: 'account-a', rootId: 'root-a', objectId: 'item-a',
    recordSubjectId: role === 'Guardian' ? 'minor-a' : 'member-a', version: 2,
    category: 'study', readers: ['member-a'], writers: ['member-a'],
    member: { subjectId: 'member-a', role, current: true, expiresAt: 110 },
    admin: { availability: 'CURRENT', current: true, accountId: 'account-a', rootId: 'root-a', checkedAt: now,
      expiresAt: 110, live: true, websiteActive: true, packCount: 1, barrier: 'ACTIVE' },
    epochs: { ...epoch }, barrier: 'ACTIVE', stepUp: null, guardian: null, minor: role === 'Minor' };
  if (role === 'Guardian' || role === 'Minor') state.guardian = {
    testOnly: true, verified: true, revoked: false, subjectId: role === 'Guardian' ? 'member-a' : 'guardian-a',
    minorId: role === 'Minor' ? 'member-a' : 'minor-a', organizationId: 'account-a', rootId: 'root-a',
    categories: ['study'], purpose: 'study-help', expiresAt: 110, age: 15 };
  if (['project.approve', 'quote.accept'].includes(operation)) state.stepUp = {
    subjectId: 'member-a', operation, objectId: 'item-a', version: 2, expiresAt: 110 };
  return { context, request, state };
}
const evaluate = f => evaluateClient(f.context, f.request, f.state, now);
function check(r, kind, reason) {
  assert.deepEqual(r, { kind, ...(reason ? { reason } : {}), model: 'MODEL_ONLY', authentication: 'NOT_AUTHENTICATED' });
}
for (const role of ['Owner', 'Collaborator', 'Guardian', 'Minor']) test(`${role} scoped read is MODEL_ONLY / NOT_AUTHENTICATED`, () => {
  const f = fixture(role); const before = JSON.stringify(f); check(evaluate(f), 'ModelOnly'); assert.equal(JSON.stringify(f), before);
});
for (const operation of ['tool.mutate', 'share.create', 'export.create', 'project.approve', 'quote.accept']) {
  test(`owner ${operation} bounded model case`, () => check(evaluate(fixture('Owner', operation)), 'ModelOnly'));
}
const negatives = [
  ['another account', f => { f.request.accountId = 'account-b'; }, 'Deny', 'NOT_FOUND_SCOPED'],
  ['second Root same account', f => { f.request.rootId = 'root-b'; }, 'Deny', 'NOT_FOUND_SCOPED'],
  ['foreign item', f => { f.request.objectId = 'item-b'; }, 'Deny', 'NOT_FOUND_SCOPED'],
  ['private staff-note property', f => { f.request.fields.push('staffPrivateNote'); }, 'Deny', 'FORBIDDEN'],
  ['customer cannot overpost role', f => { f.request.role = 'Owner'; }, 'Deny', 'VALIDATION_ERROR'],
  ['unknown function', f => { f.request.operation = 'commercial.publish'; }, 'Deny', 'FORBIDDEN'],
  ['prototype function', f => { f.request.operation = 'constructor'; }, 'Deny', 'FORBIDDEN'],
  ['revoked membership', f => { f.state.member.current = false; }, 'Deny', 'NOT_FOUND_SCOPED'],
  ['membership expiry boundary', f => { f.state.member.expiresAt = now; }, 'Deny', 'NOT_FOUND_SCOPED'],
  ['foreign member', f => { f.state.member.subjectId = 'member-b'; }, 'Deny', 'NOT_FOUND_SCOPED'],
  ['role disagreement', f => { f.state.member.role = 'Collaborator'; }, 'Deny', 'NOT_FOUND_SCOPED'],
  ['object reader absent', f => { f.state.readers = ['member-b']; }, 'Deny', 'FORBIDDEN'],
  ['different record category', f => { f.request.category = 'finance'; }, 'Deny', 'NOT_FOUND_SCOPED'],
  ['stale object version', f => { f.request.expectedVersion = 1; }, 'Conflict', 'VERSION_CONFLICT'],
  ['missing Admin grant', f => { f.state.admin.availability = 'MISSING'; }, 'Deny', 'ENTITLEMENT_UNVERIFIABLE'],
  ['Admin unavailable', f => { f.state.admin.availability = 'UNAVAILABLE'; }, 'Pending', 'AUTHORITY_UNAVAILABLE'],
  ['Admin projection not current', f => { f.state.admin.current = false; }, 'Deny', 'ENTITLEMENT_UNVERIFIABLE'],
  ['cached grant checked one tick ago', f => { f.state.admin.checkedAt = now - 1; }, 'Deny', 'ENTITLEMENT_UNVERIFIABLE'],
  ['expired Admin grant', f => { f.state.admin.expiresAt = now; }, 'Deny', 'ENTITLEMENT_UNVERIFIABLE'],
  ['Admin wrong account association', f => { f.state.admin.accountId = 'account-b'; }, 'Deny', 'NOT_FOUND_SCOPED'],
  ['Admin wrong Root association', f => { f.state.admin.rootId = 'root-b'; }, 'Deny', 'NOT_FOUND_SCOPED'],
  ['website not Live', f => { f.state.admin.live = false; }, 'Deny', 'ENTITLEMENT_UNVERIFIABLE'],
  ['website expired', f => { f.state.admin.websiteActive = false; }, 'Deny', 'ENTITLEMENT_UNVERIFIABLE'],
  ['no active pack', f => { f.state.admin.packCount = 0; }, 'Deny', 'ENTITLEMENT_UNVERIFIABLE'],
  ['two simultaneous packs', f => { f.state.admin.packCount = 2; }, 'Deny', 'ENTITLEMENT_UNVERIFIABLE'],
  ['staff is not Client', f => { f.context.namespace = 'ADMIN_STAFF'; f.context.role = 'SupportStaff'; }, 'Deny', 'NAMESPACE_MISMATCH'],
  ['workload cannot be owner', f => { f.context.namespace = 'WORKLOAD'; f.context.role = 'CLIENT_SERVICE'; }, 'Deny', 'NAMESPACE_MISMATCH'],
];
for (const [name, change, kind, reason] of negatives) test(name, () => {
  const f = fixture(); change(f); check(evaluate(f), kind, reason);
});
for (const epoch of ['ownership', 'grant', 'membership', 'guardian', 'privacy']) test(`stale ${epoch} epoch denied`, () => {
  const f = fixture(); f.state.epochs[epoch] += 1; check(evaluate(f), 'Deny', 'EPOCH_MISMATCH');
});
for (const phase of ['EXECUTION', 'DELIVERY']) {
  for (const authority of ['client', 'admin']) {
    for (const barrier of ['REVOKING', 'TRANSFER_PENDING', 'RECONCILE_REQUIRED']) {
      test(`${phase}: ${authority} ${barrier} refuses new admission`, () => {
        const f = fixture(); f.request.phase = phase;
        if (authority === 'client') f.state.barrier = barrier; else f.state.admin.barrier = barrier;
        check(evaluate(f), 'Deny', 'BARRIER_ACTIVE');
      });
    }
  }
}
test('execution model outcome does not carry authority to later delivery', () => {
  const f = fixture(); check(evaluate(f), 'ModelOnly');
  f.request.phase = 'DELIVERY'; f.state.admin.current = false; check(evaluate(f), 'Deny', 'ENTITLEMENT_UNVERIFIABLE');
});
for (const role of ['Collaborator', 'Guardian', 'Minor']) {
  for (const operation of ['project.approve', 'quote.accept']) test(`${role} cannot supply owner ${operation}`, () => {
    check(evaluate(fixture(role, operation)), 'Deny', 'FORBIDDEN');
  });
}
for (const [name, change] of [
  ['not independently verified', g => { g.verified = false; }],
  ['revoked', g => { g.revoked = true; }],
  ['expired', g => { g.expiresAt = now; }],
  ['wrong organization', g => { g.organizationId = 'account-b'; }],
  ['wrong Root', g => { g.rootId = 'root-b'; }],
  ['wrong category', g => { g.categories = ['finance']; }],
  ['wrong purpose', g => { g.purpose = 'marketing'; }],
  ['outside minor age range', g => { g.age = 18; }],
  ['younger than allowed minor', g => { g.age = 12; }],
  ['different guardian', g => { g.subjectId = 'guardian-b'; }],
]) test(`guardian ${name} denies`, () => {
  const f = fixture('Guardian'); change(f.state.guardian); check(evaluate(f), 'Deny', 'FORBIDDEN');
});
test('minor cannot substitute another minor relationship', () => {
  const f = fixture('Minor'); f.state.guardian.minorId = 'minor-b'; check(evaluate(f), 'Deny', 'FORBIDDEN');
});
test('guardian cannot read another minor record using a valid unrelated grant', () => {
  const f = fixture('Guardian'); f.state.recordSubjectId = 'minor-b'; check(evaluate(f), 'Deny', 'FORBIDDEN');
});
test('minor cannot self-assert independent guardian', () => {
  const f = fixture('Minor'); f.state.guardian.subjectId = 'member-a'; check(evaluate(f), 'Deny', 'FORBIDDEN');
});
test('organization owner is not blanket guardian of minor records', () => {
  const f = fixture(); f.state.minor = true; check(evaluate(f), 'Deny', 'FORBIDDEN');
});
test('owner approval requires action-specific step-up', () => {
  const f = fixture('Owner', 'project.approve'); f.state.stepUp.operation = 'tool.read'; check(evaluate(f), 'Deny', 'REAUTH_REQUIRED');
});
test('owner approval cannot reuse old artifact version', () => {
  const f = fixture('Owner', 'project.approve'); f.state.stepUp.version = 1; check(evaluate(f), 'Deny', 'REAUTH_REQUIRED');
});
test('owner approval cannot reuse expired step-up', () => {
  const f = fixture('Owner', 'quote.accept'); f.state.stepUp.expiresAt = now; check(evaluate(f), 'Deny', 'REAUTH_REQUIRED');
});
for (const operation of ['support.message', 'renewal.read']) test(`${operation} not sold-pack locked`, () => {
  const f = fixture('Owner', operation); f.state.admin.live = false; f.state.admin.websiteActive = false;
  f.state.admin.packCount = 0; check(evaluate(f), 'ModelOnly');
});
