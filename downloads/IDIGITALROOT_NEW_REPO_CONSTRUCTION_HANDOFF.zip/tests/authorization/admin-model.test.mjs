import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateAdmin } from '../../admin/src/authorization/policy-model.mjs';

const now = 100;
const bundles = [
  ['SuperAdmin', 'staff.configure', 'enabled'],
  ['OperationsManager', 'payment.pending', 'evidenceReference'],
  ['ProjectProductionStaff', 'project.update', 'stage'],
  ['BillingStaff', 'billing.verify', 'evidenceReference'],
  ['SupportStaff', 'support.message', 'message'],
];
function fixture(role = 'OperationsManager', operation = 'payment.pending', field = 'evidenceReference') {
  const context = { testOnly: true, evidence: 'MODEL_ONLY', namespace: 'ADMIN_STAFF', subjectId: 'staff-a',
    sessionId: 'synthetic-session', accountId: 'account-a', rootId: 'root-a', credentialEpoch: 1, authzEpoch: 2,
    assurance: 'SYNTHETIC_PASSWORD_AND_WEBAUTHN', audience: 'admin-model', expiresAt: 110, role };
  const request = { operation, accountId: 'account-a', rootId: 'root-a', objectId: 'object-a', fields: [field], expectedVersion: 2, digest: 'synthetic-digest-reference' };
  const scope = { testOnly: true, accountId: 'account-a', rootId: 'root-a', objectId: 'object-a', version: 2,
    assignees: ['staff-a'], capabilities: [`TEST_ONLY:${operation}`], evidenceMakerId: 'different-staff', acceptedQuote: true,
    stepUp: { subjectId: 'staff-a', operation, digest: request.digest, version: 2, expiresAt: 110 } };
  return { context, request, scope };
}
const evaluate = f => evaluateAdmin(f.context, f.request, f.scope, now);
function check(r, kind, reason) {
  assert.deepEqual(r, { kind, ...(reason ? { reason } : {}), model: 'MODEL_ONLY', authentication: 'NOT_AUTHENTICATED' });
}
for (const [role, operation, field] of bundles) {
  test(`${role} assigned function is MODEL_ONLY / NOT_AUTHENTICATED`, () => {
    const f = fixture(role, operation, field); const before = JSON.stringify(f);
    check(evaluate(f), 'ModelOnly'); assert.equal(JSON.stringify(f), before);
  });
  test(`${role} cannot overpost forbidden field`, () => {
    const f = fixture(role, operation, field); f.request.fields.push('Paid'); check(evaluate(f), 'Deny', 'FORBIDDEN');
  });
  test(`${role} has no unassigned function`, () => {
    const f = fixture(role, operation, field); f.scope.capabilities = []; check(evaluate(f), 'Deny', 'FORBIDDEN');
  });
  test(`${role} cannot take another bundle function even with synthetic capability`, () => {
    const other = bundles.find(b => b[0] !== role);
    const f = fixture(role, other[1], other[2]); check(evaluate(f), 'Deny', 'FORBIDDEN');
  });
}
for (const [name, change, kind, reason] of [
  ['unknown publication has no grant even SuperAdmin', f => { f.context.role = 'SuperAdmin'; f.request.operation = 'commercial.publish'; f.scope.capabilities = ['TEST_ONLY:commercial.publish']; }, 'Deny', 'FORBIDDEN'],
  ['prototype function denied', f => { f.request.operation = 'toString'; }, 'Deny', 'FORBIDDEN'],
  ['staff cannot accept quote as customer', f => { f.request.operation = 'quote.accept'; }, 'Deny', 'FORBIDDEN'],
  ['staff cannot approve customer project', f => { f.request.operation = 'project.approve'; }, 'Deny', 'FORBIDDEN'],
  ['SuperAdmin cannot bypass Billing function', f => { f.context.role = 'SuperAdmin'; f.request.operation = 'billing.verify'; }, 'Deny', 'FORBIDDEN'],
  ['wrong account', f => { f.request.accountId = 'account-b'; }, 'Deny', 'NOT_FOUND_SCOPED'],
  ['same account foreign Root', f => { f.request.rootId = 'root-b'; }, 'Deny', 'NOT_FOUND_SCOPED'],
  ['foreign object', f => { f.request.objectId = 'object-b'; }, 'Deny', 'NOT_FOUND_SCOPED'],
  ['staff not assigned object', f => { f.scope.assignees = ['staff-b']; }, 'Deny', 'NOT_FOUND_SCOPED'],
  ['request role injection', f => { f.request.role = 'SuperAdmin'; }, 'Deny', 'VALIDATION_ERROR'],
  ['stale expected version', f => { f.request.expectedVersion = 1; }, 'Conflict', 'VERSION_CONFLICT'],
  ['expired action step-up', f => { f.scope.stepUp.expiresAt = now; }, 'Deny', 'REAUTH_REQUIRED'],
  ['changed action digest', f => { f.scope.stepUp.digest = 'different'; }, 'Deny', 'REAUTH_REQUIRED'],
  ['step-up from other actor', f => { f.scope.stepUp.subjectId = 'staff-b'; }, 'Deny', 'REAUTH_REQUIRED'],
  ['step-up for other function', f => { f.scope.stepUp.operation = 'staff.configure'; }, 'Deny', 'REAUTH_REQUIRED'],
  ['Client cannot become staff', f => { f.context.namespace = 'CLIENT_HUMAN'; f.context.role = 'Owner'; }, 'Deny', 'NAMESPACE_MISMATCH'],
  ['workload cannot become staff', f => { f.context.namespace = 'WORKLOAD'; f.context.role = 'ADMIN_SERVICE'; }, 'Deny', 'NAMESPACE_MISMATCH'],
]) test(name, () => { const f = fixture(); change(f); check(evaluate(f), kind, reason); });
test('Billing checker cannot verify own evidence', () => {
  const f = fixture('BillingStaff', 'billing.verify'); f.scope.evidenceMakerId = 'staff-a'; check(evaluate(f), 'Deny', 'FORBIDDEN');
});
test('Billing cannot verify without accepted quote', () => {
  const f = fixture('BillingStaff', 'billing.verify'); f.scope.acceptedQuote = false; check(evaluate(f), 'Deny', 'FORBIDDEN');
});
test('nonfinancial correction checker must differ from maker', () => {
  const f = fixture('SuperAdmin', 'operations.correct.review', 'reason'); f.scope.evidenceMakerId = 'staff-a'; check(evaluate(f), 'Deny', 'FORBIDDEN');
});
test('explicit synthetic commercial draft capability is not publication', () => {
  const f = fixture('OperationsManager', 'commercial.draft', 'amount'); check(evaluate(f), 'ModelOnly');
  f.request.fields.push('published'); check(evaluate(f), 'Deny', 'FORBIDDEN');
});
test('real-looking capability is not TEST_ONLY draft permission', () => {
  const f = fixture('OperationsManager', 'commercial.draft', 'amount'); f.scope.capabilities = ['commercial.draft']; check(evaluate(f), 'Deny', 'FORBIDDEN');
});
test('sparse property list cannot bypass field validation', () => {
  const f = fixture(); f.request.fields = Array(1); check(evaluate(f), 'Deny', 'VALIDATION_ERROR');
});
