import test from 'node:test';
import assert from 'node:assert/strict';
import { validateEnvelope, compareReplay } from '../../contracts/v1/envelope.mjs';
import { validateContext, currentReply } from '../../contracts/v1/authority-context.mjs';
import { outcome, quoteBlocker } from '../../contracts/v1/outcomes.mjs';

const now = 100;
const context = () => ({ testOnly: true, evidence: 'MODEL_ONLY', namespace: 'CLIENT_HUMAN',
  subjectId: 'owner-a', sessionId: 'synthetic-session', accountId: 'account-a', rootId: 'root-a',
  credentialEpoch: 2, authzEpoch: 3, assurance: 'SYNTHETIC_PASSWORD_AND_WEBAUTHN',
  audience: 'client-model', expiresAt: 110, role: 'Owner' });
const profile = () => ({ operation: 'tool.read', schemaId: 'tool-reference.v1', producerId: 'client-model',
  audience: 'client-model', purpose: 'private-read', namespace: 'CLIENT_HUMAN', payloadFields: ['itemVersion'] });
const envelope = () => ({ commandId: 'command-1', operation: 'tool.read', contractVersion: 'idr.contract.v1',
  schemaId: 'tool-reference.v1', producerId: 'client-model', audience: 'client-model', purpose: 'private-read',
  issuedAt: 90, expiresAt: 110, nonce: 'synthetic-nonce', correlationId: 'correlation-1', causationId: 'cause-1',
  actor: context(), accountId: 'account-a', rootId: 'root-a', objectId: 'item-a',
  expectedVersions: { object: 1, ownership: 1, membership: 1, guardian: 0, entitlement: 1, price: 0, terms: 0 },
  payloadDigest: 'a'.repeat(64), payload: { itemVersion: '1' } });
function diagnostic(result, kind, reason) {
  assert.deepEqual(result, { kind, ...(reason ? { reason } : {}), model: 'MODEL_ONLY', authentication: 'NOT_AUTHENTICATED' });
  assert.equal(Object.isFrozen(result), true);
}
test('valid envelope is MODEL_ONLY / NOT_AUTHENTICATED, never caller proof', () => {
  diagnostic(validateEnvelope(envelope(), profile(), now), 'ModelOnly');
});
const invalidEnvelopes = [
  ['unsupported version', e => { e.contractVersion = 'idr.contract.v2'; }, 'CONTRACT_UNSUPPORTED'],
  ['unknown top field', e => { e.Paid = true; }, 'VALIDATION_ERROR'],
  ['missing nonce', e => { delete e.nonce; }, 'VALIDATION_ERROR'],
  ['unknown nested payload field', e => { e.payload.owner = 'intruder'; }, 'VALIDATION_ERROR'],
  ['unknown expected epoch', e => { e.expectedVersions.superuser = 1; }, 'VALIDATION_ERROR'],
  ['missing expected version', e => { delete e.expectedVersions.ownership; }, 'VALIDATION_ERROR'],
  ['negative epoch', e => { e.expectedVersions.membership = -1; }, 'VALIDATION_ERROR'],
  ['future issuedAt', e => { e.issuedAt = 101; }, 'VALIDATION_ERROR'],
  ['expiry boundary', e => { e.expiresAt = 100; }, 'VALIDATION_ERROR'],
  ['malformed digest', e => { e.payloadDigest = 'not-a-digest'; }, 'VALIDATION_ERROR'],
  ['numeric payload', e => { e.payload.itemVersion = 1; }, 'VALIDATION_ERROR'],
  ['oversized bounded payload', e => { e.payload.itemVersion = 'x'.repeat(257); }, 'VALIDATION_ERROR'],
  ['wrong producer', e => { e.producerId = 'PUBLIC_INTAKE'; }, 'NAMESPACE_MISMATCH'],
  ['wrong audience', e => { e.audience = 'admin-model'; }, 'NAMESPACE_MISMATCH'],
  ['wrong purpose', e => { e.purpose = 'publish'; }, 'NAMESPACE_MISMATCH'],
  ['wrong schema', e => { e.schemaId = 'unreviewed.v1'; }, 'NAMESPACE_MISMATCH'],
  ['foreign account', e => { e.accountId = 'account-b'; }, 'NOT_FOUND_SCOPED'],
  ['foreign Root', e => { e.rootId = 'root-b'; }, 'NOT_FOUND_SCOPED'],
  ['symbol overposting', e => { e[Symbol('hidden')] = true; }, 'VALIDATION_ERROR'],
];
for (const [name, change, reason] of invalidEnvelopes) test(name, () => {
  const e = envelope(); change(e); diagnostic(validateEnvelope(e, profile(), now), 'Deny', reason);
});
for (const [name, change, reason] of [
  ['Admin cannot substitute for Client', c => { c.namespace = 'ADMIN_STAFF'; c.role = 'SuperAdmin'; }, 'NAMESPACE_MISMATCH'],
  ['workload cannot substitute for human', c => { c.namespace = 'WORKLOAD'; c.role = 'CLIENT_SERVICE'; }, 'NAMESPACE_MISMATCH'],
  ['prototype namespace is unknown', c => { c.namespace = 'toString'; }, 'CONTEXT_INVALID'],
  ['unknown context field', c => { c.authenticated = true; }, 'CONTEXT_INVALID'],
  ['MODEL_ONLY tag is not enough', c => { c.testOnly = false; }, 'CONTEXT_INVALID'],
  ['email is never MFA', c => { c.assurance = 'PASSWORD_AND_EMAIL'; }, 'REAUTH_REQUIRED'],
  ['password alone denied', c => { c.assurance = 'PASSWORD_ONLY'; }, 'REAUTH_REQUIRED'],
  ['expired synthetic context', c => { c.expiresAt = 100; }, 'EXPIRED'],
]) test(name, () => {
  const c = context(); change(c); diagnostic(validateContext(c, 'CLIENT_HUMAN', 'client-model', now), 'Deny', reason);
});
test('matching workload shape is still NOT_AUTHENTICATED', () => {
  const c = { ...context(), namespace: 'WORKLOAD', role: 'CLIENT_SERVICE', assurance: 'SYNTHETIC_WORKLOAD' };
  diagnostic(validateContext(c, 'WORKLOAD', 'client-model', now), 'ModelOnly');
});
const replay = () => ({ authority: 'CLIENT', operation: 'tool.read', namespace: 'CLIENT_HUMAN',
  subjectId: 'owner-a', key: 'command-1', accountId: 'account-a', rootId: 'root-a', objectId: 'item-a', payloadDigest: 'a'.repeat(64) });
test('same replay identity models equality without durable receipt', () => diagnostic(compareReplay(replay(), replay(), true), 'ModelOnly'));
for (const key of ['authority', 'operation', 'namespace', 'subjectId', 'key', 'accountId', 'rootId', 'objectId', 'payloadDigest']) {
  test(`replay ${key} difference cannot reuse receipt`, () => {
    const next = replay(); next[key] = key === 'payloadDigest' ? 'b'.repeat(64) : 'different';
    diagnostic(compareReplay(replay(), next, true), 'Conflict', 'IDEMPOTENCY_CONFLICT');
  });
}
test('same replay after revoked read right denies disclosure', () => diagnostic(compareReplay(replay(), replay(), false), 'Deny', 'FORBIDDEN'));
test('account switch discards stale account reply', () => diagnostic(currentReply({ accountId: 'b', selectionVersion: 2 }, { accountId: 'a', selectionVersion: 1 }), 'Deny', 'STALE_ACCOUNT_REPLY'));
test('switch back to same account still discards old generation', () => diagnostic(currentReply({ accountId: 'a', selectionVersion: 3 }, { accountId: 'a', selectionVersion: 1 }), 'Deny', 'STALE_ACCOUNT_REPLY'));
test('current reply is model-only', () => diagnostic(currentReply({ accountId: 'a', selectionVersion: 3 }, { accountId: 'a', selectionVersion: 3 }), 'ModelOnly'));
for (const [name, draft, reason] of [
  ['unpublished null draft', { status: 'UNPUBLISHED_DRAFT', amount: null }, 'PRICE_UNPUBLISHED'],
  ['claimed published null', { status: 'PUBLISHED', amount: null }, 'AMOUNT_MISSING'],
  ['zero is not a free paid plan', { status: 'PUBLISHED', amount: 0 }, 'AMOUNT_MISSING'],
  ['numeric string has no implicit conversion', { status: 'PUBLISHED', amount: '123' }, 'AMOUNT_MISSING'],
  ['nonfinite amount', { status: 'PUBLISHED', amount: Infinity }, 'AMOUNT_MISSING'],
  ['NaN amount', { status: 'PUBLISHED', amount: NaN }, 'AMOUNT_MISSING'],
  ['negative amount', { status: 'PUBLISHED', amount: -1 }, 'AMOUNT_MISSING'],
  ['number cannot manufacture approved terms', { status: 'PUBLISHED', amount: 123 }, 'TERMS_UNAPPROVED'],
]) test(name, () => diagnostic(quoteBlocker(draft), 'Unquotable', reason));
test('Pending and Conflict are typed diagnostics without Paid or numeric fallback', () => {
  diagnostic(outcome('Pending', 'PENDING_CONFIRMATION'), 'Pending', 'PENDING_CONFIRMATION');
  diagnostic(outcome('Conflict', 'VERSION_CONFLICT'), 'Conflict', 'VERSION_CONFLICT');
  assert.throws(() => outcome('Paid', 'OK'), TypeError);
  assert.throws(() => outcome('toString', 'OK'), TypeError);
});
