# iDigitalRoot — continuation checkpoint for a fresh Codex session

23 October 2026 (Asia/Beirut). **HANDOFF/EXPORT COMPLETE; NO NEW IMPLEMENTATION AUTHORIZATION.** Intended new repository: uyounmodel-cloud/idigitalroot-platform, PRIVATE, NOT_CREATED/NOT_CONFIGURED by this task. No repository, Git remote, provider or deployment operation is part of the handoff.

## Exact provenance and preservation boundary

Original archive/source repository uyounmodel-cloud/idigitalroot remains at /workspace/idigitalroot, branch work, HEAD 08f614b1698dec2db657248f95ceea723ab537e7, tree dce28a4004a1d060d936e9656b5c4d589e787839, clean porcelain with all untracked files considered. All 243 tracked raw baseline hashes match evidence/provenance/P00/REPOSITORY_BASELINE.json. F1 ENTRY recorded 824 prior evidence files; all were compared byte-for-byte against their hashes again for this handoff. Copied F1 source/evidence and selected authority inputs were checked against their existing pins. Fresh exit preservation assertions are also required after ZIP assembly. These facts concern the original workspace, not a claim that a new repository already has a HEAD or 243 files.

Original master ZIP SHA256: f1ea6c341baf3c81afa5b797ed09beb9b1a400325338e8a42ed671c2a5f23b20. Original October 16 handoff SHA256: 542fbb8b076e5460ffa53569980a96edddd88db424ac9cf18aa2cdc6c1a17d5a. Originals remain archived at downloads/ in the original repository; original ZIPs/fixture code/SQL are not copied into this new construction payload. The selected verbatim original authorities and prior reading/provenance reports are included. Historical missing-binary wording predates verified local recovery; do not revive it as a current owner re-upload demand.

P01C source proposal SHA256 855353834fdf58edda1f4e0e4d678fd0fb8353607ecc23624e76c741fe887cae; governing permission contract 94d0850a32290d74f569327fcc4bc1411ffe80f9b6d1b56c46e5308307ec6466; two-D1 proposal e9a857c43a83a4f9796e6d0b6ed5944d2783c5936a54380abb2c150843be2ede. All remain unchanged. Prior F1 evidence manifest SHA256 a2b0eb663d93a1e7fcef49ecc4ecbcbbbfeb7ad7b5d984d3c25f20de273cb410. The separately published earlier F1-only review ZIP SHA256 208a9cc9b4f20077d8d2138fed60ea00901b0e30681cebb75ef4026638bdefee is provenance only; it is not nested here. No new push or publication was performed for this handoff.

SOURCE_PROVENANCE.json maps every one of the 86 copied files to its original absolute source or exact P01B archive member, byte count and raw SHA256. All copies are byte-identical. The four new handoff files are START_HERE.md, this checkpoint, SOURCE_PROVENANCE.json and root SHA256SUMS.txt. Historical files are not edited to rewrite dates, status, approvals or absolute paths. There are 90 payload files in total: 86 copies plus these four handoff files.

## Actual F1 result; things that remain unproved

Ten F1 source/document/test files are present at the correct relative paths. Existing evidence records exactly one Node v22.19.0 invocation, exit 0, 174/174 passing cases (Admin43, Client79, contracts52), zero fail/skip/cancel/todo. All positive diagnostics MODEL_ONLY / NOT_AUTHENTICATED. No test rerun, installation, benchmark or app launch took place during export. Previous limits were 60s wall +5s termination grace, 30 CPU s/process, 128 MiB V8 heap/process, <=10 MiB synthetic fixture budget, <=1,000 cases; these are historical F1 execution conditions, not permissions to run anything in a fresh environment. Actual prior timing/resource observation limits are in docs/foundation-exit.md and evidence/F1/EXIT.json.

Independent review UNASSIGNED/PENDING, not performed or accepted. No verified identity/session/WebAuthn/credential, actual current grant, real payment/Paid, persistent replay prevention, immutable approval ledger, G-RACE runtime/stream cancellation, Worker/D1/R2, real email/SSO/provider, full editor or completed product exists from F1. All 58 feature rows remain NOT_BUILT/NOT_RUN; 151 risk rows and 345 ASVS rows NOT_ASSESSED; 54 original cases NOT_RUN. No security or L3 PASS. Source-model self-review is not independent review.

## Settled decisions and precedence

Do not reopen Rounds 1–26. Preserve 77 explicit R13–R26 decision IDs and R1–R12 narrative groups without fabricating historical question IDs or exact transcripts. The full matrix has 56 REQUIRED, UX-01 PROPOSED, EXT-TEAMS PARTIAL. Four audiences/four packs, Student27unique across28positions with shared Career Kit, five staff bundles and 11 Client areas plus Inbox remain fixed.

AUTH-2026-10-22-01 is current: password AND WebAuthn for every human identity including allowed minors, independent backups and supervised recovery; email contact/notifications only, never auth/recovery proof. The new corporate Public Site has no CMS, EN/AR motion and secured wizard -> Admin lead + durable visitors@idigitalroot.com notice. Historical Public CMS/MOTION is separate, untouched. New Admin/Client D1 are physically separate; private R2 is Worker controlled; current Admin entitlement and Client rights fail closed; no cross-D1 ACID; frozen Public0001-0016/Analytics0001-0002 untouched, no public0017.

The 12 annual website packages/four packs, Billing-verified purchase clocks, no automatic charging, owner exact quote acceptance, Billing-only Paid, staff Root after Paid, two owner-only exact-version project approvals and transfer/guardian/support/correction controls are retained in full authority files. The latest direct owner decisions override only the older conflicting passages they expressly supersede. P01 original alternative comparisons and P01C then-unapproved F1 are historical, not rewritten as contemporaneous approval.

## Current hard blockers versus later gates

| Boundary | Current disposition / owner decision needed |
|---|---|
| Independent F1 review | Reviewer/function unassigned; inspect source/contracts and record independent findings before integrated reliance. No fabricated PASS or automatic rerun. |
| Next application source/schema | No current allowlist or approved executable F2 order. Each relocated source task and each Admin/Client migration/recovery lineage needs separate exact version/hash/path/activity/tool/resource approval. No SQL/migrations/database/bindings exist from F1. |
| Actual IAM/editor | Enrollment/RP/origin/password verifier/session/workload trust, accessible strong authenticators, backup independence, supervised all-factor loss/last-admin review, fresh step-up, privileged governance and ASVS applicability still require design/review and actual proof. |
| Distributed protected work | G-RACE versioning/admission/finalization/epochs/barriers/delivery/reconcile/in-flight completion require resolved semantics and separately authorized real runtime evidence; no cached projection or model fixture is current authority. |
| Quotas/files | Seven Root quota hypotheses NOT_MEASURED/NOT_APPROVED. Fixed 10/2/25MB file ceilings, <=5MB support images <=3/message, 30d/default90d/max shares, 10min timer inactivity remain; byte/expanded/parser/scan/CPU/global memory/account-D1/R2 budgets unresolved. No benchmark run. |
| Draft price editor engineering | Initial selling numbers are NOT a prerequisite once secure IAM/authorization/persistence and exact source order are approved. Null-safe unpublished draft engine remains unbuilt. No 32-price demand. |
| Real publication/quote/payment | All selling amounts null, overrides empty, 12+4 UNPUBLISHED_DRAFT; material inclusions, terms/renewal/switch/credit/refund/retirement, non-null published price book, market/tax/FX, supplier eligibility and grants/signoff required. No null-as-zero/free plan/Paid inference. |
| Real suppliers/operational release | Actual domain/hosted-mailbox/email agreements, legal/minor/retention/residency/support, measured capacities, native browser/Windows/security/restore QA, exact spend/provider/release/deploy authority are later gates. Dated Cloudflare arithmetic is not live account cost; .com/Zoho/Google rates not verified. |
| PKG-01 | Seven missing generated fixture files and old FE tsconfig mismatch remain affected-fixture acceptance blockers. No defective source copied, fixed, reused or passed; not a general scope/F1 blocker. |
| New private repository | Target name is an intent. Repository creation/privacy/access/import/remote setup/push is NOT authorized or performed by this handoff. |

Proposed page/language/mailbox/domain/revision/care inclusions and labor estimates remain proposals. Seven common quota candidates are 2GiB storage, 2,000 records, five collaborators, 50 new shares/30d, 20 active shares, 100 exports/30d and two heavy jobs. Do not convert these into seeded entitlements or promises. Actual approved contract history must remain immutable under future versioned price/inclusion edits.

## Fresh Codex session — read-only continuation procedure

1. Obtain this exact archive through an owner-approved transfer, verify its externally delivered ZIP SHA256 and CRC, then extract to an empty/new destination outside the original checkout. Reject traversal, absolute paths, duplicate members or conflicts; never overwrite an existing workspace silently. No repository creation/import/push follows without a new explicit instruction.
2. From the extracted root, verify all 89 entries in root SHA256SUMS.txt against raw bytes. The manifest excludes itself; its SHA256 is recorded in the delivered completion result. This checkpoint's own exact digest is in that root manifest. Do not treat ZIP/manifest checksum as a signature or a substitute for receiving the expected hash through a trusted owner channel.
3. Read START_HERE, this checkpoint, SOURCE_PROVENANCE, all five P01C files, complete F1 scope/source/exit/raw results/review, current AUTH addendum and P01A, complete P01B and its exact machine-readable catalogue, then discovery matrix/traceability/cumulative authority and original security/blueprints as relevant. Full immutable P01 sections H and L are included. Resolve historical conflicts by the scoped chronology above, not by executing old prompts.
4. If an owner requests the next substantive task, begin a separately requested **read-only independent F1 review** with an assigned independent reviewer; do not relabel self-review as independent. Review default denial/unknown fields/namespaces, five bundles, money/owner separation, object/property/account/Root, guardian/category/revoke/expiry, epochs/barriers/delivery/account-switch/replay and typed refusal. Record any new report outside application source under an expressly agreed output path. This handoff stops without running that review.
5. For new construction, prepare and obtain owner approval of an exact relocated work order and predecessor hashes. F2 needs actual IAM/persistence review; Admin schema and Client schema are independent approvals. Rebase historical path/tool/resource proposals explicitly; never rewrite archived F1 proof or assume its old machine binary exists. No installs/tests/builds/benchmarks/credentials/SQL/provider/database/Git/push/deploy without the separately selected activities.
6. Keep earlier evidence immutable. For later substantive work record new entry/exit inventories and actual evidence; no inherited PASS, fake Paid, email-factor downgrade, price/publication/security bypass, repeated settled discovery or demand to re-upload the master. If truly required original binary bytes are absent in the new session, report the precise missing input and use an authorized read of the original repository archive, not a substitute or invented hash.

No automatic F2, Stage02, Admin schema or Client schema. **NEXT_ACTION=OWNER_REQUEST_AND_INDEPENDENT_F1_REVIEW_PENDING; IMPLEMENTATION_SCOPE_APPROVAL=NOT_GIVEN_FOR_NEW_WORK; STOP_AFTER_HANDOFF=YES.**

## Export verification note

The first documentation validator exited 1 because it required the literal hyphenated wording "32-price" while START_HERE used "32 prices". Inspection confirmed the intended policy and unchanged source/security evidence; the checker was corrected to accept either form. No application test was run, no source/authority changed and no check was bypassed. Final ZIP/member/manifest/preservation checks must pass before delivery.

## Exact archive-relative file hashes

These 88 hashes cover every file that precedes this checkpoint, including START_HERE and SOURCE_PROVENANCE. Root SHA256SUMS.txt additionally pins this checkpoint (89 entries total). The manifest excludes its own digest to avoid recursion; its hash and the ZIP hash are supplied externally at delivery. No ZIP can contain its own final checksum as a self-verifying embedded field.

| Archive-relative path | SHA256 |
|---|---|
| SOURCE_PROVENANCE.json | 5e4c3c0dd76267df5b011b8fde9863234a72aefc169b962fa3b7fbb0ddd5088d |
| START_HERE.md | 99a39310d8a3266482e229a1e4ab53ccb67bccb59dcfc0816083d58c9a1e7c38 |
| admin/src/authorization/policy-model.mjs | 26e0f07bb2e0d7cfba89cd91e8067a8dd335d66cb76418e45a2a37bc23df9405 |
| client/src/authorization/policy-model.mjs | 0ee19e54c0d98d8668738485fc77d710215b413460029d71f7a57eb4ccbfa2cc |
| contracts/v1/authority-context.mjs | 6b838dc01d75df3cfefccfce39a077519c0af2506d1c256de03cf2ebd921b693 |
| contracts/v1/envelope.mjs | 9c7e7384b98a4f6d7ce62955d0bc418dad79973f1ac29d785a90f70c7262a921 |
| contracts/v1/outcomes.mjs | 42a57719ac864df4eedb7a518b73fca7b2308c516887b8072b4c752585d15eea |
| docs/authority/P00B/AUTHORITY_READ_ORDER_COMPLETION.md | 6a6f15c7bf4a6cbad4c5d4f1ce4cee03c0f45c2adbbcac7443b7a4dc957425d0 |
| docs/authority/P00B/P00B_EXIT_CHECKPOINT.md | e9926908cfc75abc8a0ac860356881fc85ce5400e02acd77acfb9c2bc0c28999 |
| docs/authority/P00B/SCOPE_CONFLICT_AND_SECURITY_GATES.md | afb4708a35f6e21c00fe4621524cf4c2318b7e9dc683b46446f7bf08d368b8f1 |
| docs/authority/P00B/SOURCE_ARCHIVE_ANOMALY_TRIAGE.md | 96137fc40a107f9e8d79d105f499c0e7aef2d4453ed106ea972a93ba3aa14ad8 |
| docs/authority/P01/P01_EXIT_CHECKPOINT.md | 1219120c45936353bbbcb29c9e9e549d858eff99f869a85c5dcf9705763eeddb |
| docs/authority/P01/SCOPE_FREEZE_REVIEW.md | 5357e0943eb24b85cdd8b9ac489db31a410f344197ca962d5b51c2c07b3d9472 |
| docs/authority/P01A/P01A_AUTH_SCOPE_RECONCILIATION.md | 84a3044ea2b0f53c11902999c743189e4b9dc0b1f5473437a81983c762ed858c |
| docs/authority/P01A/P01A_EXIT_CHECKPOINT.md | 3d439859e8f5b6cf2980e66673311baefb63ffe715a9ed52bcbed95ecd287c5c |
| docs/authority/P01A/P01A_SCOPE_FREEZE_DECISION_SHEET.md | 6456727c59d3cfb6a499ec5dd8745d04d55431057b776835a0fb9e6a336ec503 |
| docs/authority/P01A/owner-inputs/IDIGITALROOT_ADMIN_CLIENT_AUTHORITATIVE_WORKING_SCOPE_v0.5_2026-10-22.md | 642fe1d7fa66af4a9ad412b8915a498b49f330ae00b4922e12158bc2a58727fa |
| docs/authority/P01A/owner-inputs/IDIGITALROOT_OWNER_AUTH_DECISION_ADDENDUM_2026-10-22.md | a2cac7d03e5edcde052a7ada9569ec1bc2a3ea4cfc74edc05f0b87f034d7cbfd |
| docs/authority/P01A/owner-inputs/IDIGITALROOT_SCOPE_FREEZE_NEXT_GATES_2026-10-22.md | 48c5a2033c6ba731305a8956e0fa30a22c65bd2cc6fa7d30828c69aa36060bab |
| docs/authority/P01B/P01B_CATALOGUE_AND_PRICING_CONTRACT.md | c1660665605dcc6151dea291ee876c07f4ae3408fa588c18ea59513d669fa822 |
| docs/authority/P01B/P01B_EXIT_CHECKPOINT.md | 4a591f1641a06d809f6a51b73f66b883d323493b5c87f93a4c04447c5c6f17c2 |
| docs/authority/P01B/P01B_IMPLEMENTATION_APPROVAL_BOUNDARIES.md | 77d9e9cf354dd8998d1ae59b1daea1cc2d32c3f3b691c23bdb783f1901755724 |
| docs/authority/P01B/P01B_QUOTA_AND_COST_EVIDENCE_PLAN.md | 90d0f7f7907d10b8b5da30f1ef7fedb4272967b1cdb3a09ed6e4aa4b10b4b2fa |
| docs/authority/P01B/proposal/00_READ_THIS_FIRST_COMMERCIAL_AND_ADMIN_SPEC.md | 6ba769c9ed04181d786820735c6e93c64a40ccb18acf5aa4c7b080837295a6e9 |
| docs/authority/P01B/proposal/01_PROPOSED_CATALOGUE_MACHINE_READABLE.json | d96ef2314ff41b253d0c692183a3bd9cd81d42fec20dc0415e254b301053711e |
| docs/authority/P01C/P01C_BOUNDARY_AND_PERMISSION_CONTRACTS.md | 94d0850a32290d74f569327fcc4bc1411ffe80f9b6d1b56c46e5308307ec6466 |
| docs/authority/P01C/P01C_EXIT_CHECKPOINT.md | 1e27d19239a36ba093311b0ac27a4da541f9adae3dc17b79b180aa214c8ab427 |
| docs/authority/P01C/P01C_FIRST_BOUNDED_IMPLEMENTATION_WORK_ORDER_PROPOSALS.md | 855353834fdf58edda1f4e0e4d678fd0fb8353607ecc23624e76c741fe887cae |
| docs/authority/P01C/P01C_OWNER_SCOPE_FREEZE_SUMMARY.md | cce6e2a7e61dea6e6c334a7356ff483f8b4059049a407dffd4b9b9899eb9a47a |
| docs/authority/P01C/P01C_TWO_D1_SCHEMA_AND_RECOVERY_PROPOSAL.md | e9a857c43a83a4f9796e6d0b6ed5944d2783c5936a54380abb2c150843be2ede |
| docs/authority/client-original/CLIENT_PANEL_BLUEPRINT.md | b1d00091f5739aea5d01b160f86fe2238358e2f47abc76faaa9822f5e27bc1ab |
| docs/authority/client-original/FEATURE_INVENTORY.csv | 95d8956769cca158cdf22ff71f3bda8e92da55628053cc1ad4365ac232249f5c |
| docs/authority/client-original/OWNER_REQUIREMENTS_RECORDED.md | 457eda28dc44416abd30cce4d66e15e19420c32dd6064d25f4ea678ae5a37874 |
| docs/authority/client-original/QA_AND_RELEASE_GATES.md | fbe547ce991564e86d21c7165413a1df8eb5bc415809f8f4beba000deaec40fa |
| docs/authority/client-original/SOURCES_AND_AUTHORITY.json | 7d220955ce77db8936bf40ef6239aaadd7f42e6425d2c0aeb5bc450d37094543 |
| docs/authority/discovery/00_AUTHORITATIVE_WORKING_SCOPE_v0.4.md | c9b922aded2eca50a2f6f85a62732ef566eb8580a23c830553d8c88e5b2d5afe |
| docs/authority/discovery/IDIGITALROOT_ADMIN_CLIENT_UNIFIED_SCOPE_RECONCILED_v0.3_2026-10-21.md | 7e1e8d3b9179428dd78fb09175c723cb935393ae1391df5487b4943f6155b51c |
| docs/authority/discovery/IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md | 10f8d349590b35d5cdd8d24aae6d51bec88f538c37e9b7a7006907b10dcf15ab |
| docs/authority/discovery/IDIGITALROOT_DECISION_TRACEABILITY_R13_R26_2026-10-21.csv | a12b561f1751f30f97090bf7e658ff95807b27ed03ddeee1251e3fda5feb43d5 |
| docs/authority/discovery/IDIGITALROOT_FEATURE_ACCEPTANCE_MATRIX_2026-10-21.csv | 8f777a5532b47bd52f26b28697261b6268e261bb50ac2aa3a19f8130553887da |
| docs/authority/discovery/IDIGITALROOT_VERIFICATION_AND_CONFLICT_CLOSURE_2026-10-21.md | 7c8ed097306b3dd34adeb9909e6e6e04d969c28be9610e0c64cd0fe49146826c |
| docs/authority/discovery/IDIGITALROOT_VERIFIED_DISCOVERY_BUNDLE_MANIFEST_2026-10-21.json | 9d05d16ca2348d23ca43ed936f48631fc4021a522be4bf98e9320aa3d4efd662 |
| docs/authority/master/OWNER_DECISIONS_2026-10-14.md | b142790e8429f9d7a33b93900ea2523ebf4dded6aa9f77dcdf283cc2e34ec4b3 |
| docs/authority/master/blueprints/iDigitalRoot_Admin_Operations_Dashboard_Final_Technical_Blueprint_v1.0.md | 8e2a00873a4638fd9ddb65ccf6411289e70d6beb80347a71904d2f2420b07cd6 |
| docs/authority/master/blueprints/iDigitalRoot_Client_Account_Dashboard_Final_Technical_Blueprint_v1.0.docx.txt | a48df93e3949e6f8cdc63a576228f552af786bbc0939369bc0b6937a5395a870 |
| docs/authority/master/blueprints/iDigitalRoot_Cross_Platform_Admin_Control_Localization_and_Rich_Media_Extension_v1.0.md | d4f83db110b582aa4104f3f00c0cad59879c37d527b2cf6f5136681e94553ab6 |
| docs/authority/master/blueprints/iDigitalRoot_Full_Solution_Developer_Blueprint_Requirements_v0.1.md | f519d98825140c1d4a610146359de3518edf2d9a2c3298b5d966a89a1a1643bb |
| docs/authority/master/blueprints/iDigitalRoot_Public_Website_Lead_Inquiry_Extension_v1.1.md | df43dc094d57d5a63311a013bc1b00a4ccda9e65310d73475c66562964906e47 |
| docs/authority/master/system-definitions/CLIENT_PUBLIC_WEBSITE_FACTORY_TECHNICAL_BLUEPRINT_v1.0.md | 28369f2da418f406d18c43c7b3ecbe40ecaf866a1cc9a3efc3c11ecb375e5180 |
| docs/authority/master/system-definitions/CLIENT_WEBSITE_CMS_TECHNICAL_BLUEPRINT_v1.0.md | 47f772592b429069ac46008bfe53bb71f8960da7a1f1a264eb9de904d16f8ea1 |
| docs/authority/master/system-definitions/CROSS_SYSTEM_IDENTITY_SSO_AND_AUTHORIZATION.md | 47af8e5b28d59f1d9aad3aea0f1ec16615823d661cc9ddbbe3fb07cc13557e19 |
| docs/authority/master/system-definitions/FULL_SOLUTION_TARGET_ARCHITECTURE_v1.0.md | c8dda8d6db8939efabef2fcc640b33626c071fe28ba9da37bcabfb84070ecc79 |
| docs/authority/master/system-definitions/LOCALIZATION_CONTENT_MEDIA_AND_DESIGN_SYSTEM.md | 1e713a5d155ddee222caa7c11ec69ee851147b0e2999cf44bc3dff101f7bac5a |
| docs/authority/master/system-definitions/SYSTEM_01_PUBLIC_WEBSITE_STUDENT.md | afdf2da0bcf1ef2d3f48ad34feb80487fd5d20f5c747742f1b8b8e4888c8febe |
| docs/authority/master/system-definitions/SYSTEM_02_PUBLIC_WEBSITE_CMS.md | f4394d3c47fa3f72816721cc1a43637d5e407f434256b07951357e185fadc5c6 |
| docs/authority/master/system-definitions/SYSTEM_03_CLIENT_PANEL.md | 9aae8ed78ff9f5536b89d976164b7b8de12215954bebdb3d5f10b35fba62969a |
| docs/authority/master/system-definitions/SYSTEM_04_ADMIN_OPERATIONS_PANEL.md | 99698f521798cbf6e957a6adc01554313cc84b3cffbacb47d55101bcdab95ebd |
| docs/authority/master/system-definitions/SYSTEM_05_CLIENT_WEBSITE_CMS.md | bfb26a15d4f91edd2b90e766040c9536e5d6b37e0818ef70dcd30d31f2c9a141 |
| docs/authority/master/system-definitions/SYSTEM_06_CLIENT_PUBLIC_WEBSITE_FACTORY.md | 650ba5af973b81cb932f4c3f9a75cf188aa409c7fd80fe041c39abd1bafaf7ab |
| docs/authority/master/system-definitions/SYSTEM_BOUNDARIES_AND_DATA_OWNERSHIP.md | c81a2c320a2ec7e40bb085637020c05eeb3f958f4ec548b7274f744949e3fb99 |
| docs/foundation-exit.md | 73dd11787175d89100c88f237617eefefb01b855345a2786c043448450d2ee18 |
| docs/foundation-scope.md | 36639d1498586ad2acfbd9add1317888d55de0ead187c331651f0bd240794588 |
| docs/security/DEFINITION_OF_DONE_AND_RELEASE_GATES.md | 2c213ae67cfc0a0babccfe6ab5c71e458823f2f89827fb4ba358f40526ee5df5 |
| docs/security/client/CLIENT_PANEL_ASVS_5_0_0_REGISTER.csv | 06359e7d6ab9d514eab9f7a5c3bc06af78f21c994df8e07a45732ef1e0c3a31b |
| docs/security/client/CLIENT_PANEL_SECURITY_REQUIREMENTS.md | 0d05441ab28a3093413b93c98efc0a07fd409cde5ce5f32cf132ff4ca1b7607f |
| docs/security/client/CLIENT_PANEL_SECURITY_RISK_REGISTER.csv | 689590c6de7247a8d3f7d1e809ac35d53c6df3a7c25d8a10a2a90ab6fd5c6af9 |
| docs/security/client/CLIENT_PANEL_SECURITY_TEST_PLAN.csv | 99cc5d3dad41c76c836c2efbe36e68e1a0fe9d9e072e01d8a6bd3f25465a2a9c |
| docs/security/client/CLIENT_PANEL_THREAT_MODEL.md | 16c7c3ce07fb8aa5f57abba5d4872c4c422c551575cf0a34f7952afb37b1cdb9 |
| docs/security/master/INCIDENT_LOGGING_MONITORING_BACKUP_DR.md | fed8149fe0447e8ef92fb71807a1da7a4150c1b28c6724ab2f0f0181d73978ce |
| docs/security/master/SECURE_SDLC_SUPPLY_CHAIN.md | 26ec3e21f75ee5f0431aa237f79c9d6c24ad89c443c93d62f7fa67e7e2956e54 |
| docs/security/master/SECURITY_ACCEPTANCE_GATES.md | 7e579e3230129efe384e950c98a0dd0eb29d00e4d5f69ee517325ffceb8924fb |
| docs/security/master/SECURITY_ARCHITECTURE_AND_THREAT_MODEL.md | 9e1fb5469efa893db354dcd9b705c98dfbd78fa189c76bb2194adb9e4a085022 |
| docs/security/master/SECURITY_MASTER_BASELINE.md | 8aa235fa5d42bdabe69c1d76b1b83e3d306a5397de994da8b707a3b28e6d8cc1 |
| docs/security/master/SECURITY_STANDARDS_REFERENCE.md | 0ecbe3b6b4db9c4a045fff9816b46b8b678d8760783fd6dc757616fd9fce78de |
| docs/security/master/SECURITY_TEST_MATRIX.csv | 2efa07445b5e61ab0638429409a652672117ec38f47d099dda48dff5bb67d293 |
| evidence/F1/ENTRY.json | 94be465431d05075f5e911e414796596a0142e1fe04a602e087b4cd9aacd2767 |
| evidence/F1/EXIT.json | 521b8ef44f47ba420b2f8fb03272eefd50220966eb75a806d0830bff1c1681f9 |
| evidence/F1/INDEPENDENT_REVIEW.md | a3342718eecadd9c6f8696f9a8886c3730e15a5cd23da48d026d6d929add950b |
| evidence/F1/SHA256SUMS.txt | a2b0eb663d93a1e7fcef49ecc4ecbcbbbfeb7ad7b5d984d3c25f20de273cb410 |
| evidence/F1/model-tests.log | e45a4050a83067dbf5ddcf4fa4072cac8049425087a143a5182de5d515541d7e |
| evidence/provenance/P00/FROZEN_MIGRATION_COMPARISON.json | 7693e240a467e2c8a7e820893f062151b5c59c9008e0b7e3662d1bb9f252b5b9 |
| evidence/provenance/P00/READING_COVERAGE.md | ef3b271ba0ff61947d6eeceb9031672b63955f11931f4b08051c2bfd910df2f6 |
| evidence/provenance/P00/REPOSITORY_BASELINE.json | db2d6684aaa2e566a935184ce5edbea78ab1b26454752188e9575122fc0c1252 |
| evidence/provenance/P00/REPOSITORY_FINAL_VERIFICATION.json | 0d86aa98115561f4021cb412b15e774b23164a70555e7e661d209a646e080290 |
| evidence/provenance/P00/SOURCE_PREFLIGHT_REPORT.md | 7105a7e7050ce7a87fb1af86354046b2261037c12ebaf072f50a74a0e86aea26 |
| tests/authorization/admin-model.test.mjs | 4411299961311473106a2f070300b810536136abc096b713b050936594a82b85 |
| tests/authorization/client-model.test.mjs | ba4cca667fd047b2fb312a9af33bcbb7a0020ba65416ca480f80faace7eecda4 |
| tests/contracts/envelope-model.test.mjs | 7821e7c20de686f2565d90a8e470cd914ffb0dcbf29016bb28750b281b121d54 |
