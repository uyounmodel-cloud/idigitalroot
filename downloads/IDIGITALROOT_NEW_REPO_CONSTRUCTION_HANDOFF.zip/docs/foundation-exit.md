# IDR-F1-v1.0 — bounded model exit report

**23 October 2026 · PREPARED_FOR_INDEPENDENT_REVIEW · MODEL_ONLY / NOT_AUTHENTICATED.** Exactly the ten authorized candidate files were created outside the preserved checkout. F1 model construction and its approved tests are complete; integrated IAM, authentication, price editor and application actions are NOT_IMPLEMENTED. Stop after F1.

## Actual verification

One invocation of the literal Section 2 command ran from /workspace/idigitalroot-next-candidate with the pinned Node v22.19.0. Underlying command exit **0**. All **174 tests passed**, with **0 failed, cancelled, skipped or todo**. Three exact files: Admin 43 cases, Client 79 cases, envelope/context/outcomes 52 cases. Positive authorization/envelope/replay/selection diagnostics bear MODEL_ONLY / NOT_AUTHENTICATED; no test establishes a verified caller, permission, settlement or business success.

Raw results: /workspace/idigitalroot-p01c-f1-evidence/model-tests.log. Node TAP duration 347.278372ms; tool-reported wall elapsed 0.328805401s. These are separate reported clock measurements, not a benchmark. The command completed normally without timeout, CPU-limit signal or heap error. Configured limits: timeout 60s plus 5s TERM grace; inherited ulimit CPU 30s/process; Node --max-old-space-size=128 MiB/process, sequential runner. CPU consumption and peak RSS were not separately instrumented; heap flag is not a total RSS cap. No ceiling was expanded. All fixtures are inline synthetic values; the three complete test-source files total 23,350 bytes (<10 MiB), no file fixtures. Reviewed bounded case count 174 (<1,000), no stress loops. No source-side I/O, network/services, process spawning, key generation or persistence.

## Scoped cases and outcome limits

- Envelope v1, exact/nested fields, unknown versions, expiry, producer/audience/purpose, namespace, account/Root, digest reference and expected-version validation; workload cannot impersonate a human. Synthetic correct contexts remain NOT_AUTHENTICATED.
- Each five staff bundles: assigned narrow function, wrong field/capability/role negatives. No SuperAdmin override. Publication and customer acceptance/approval deny. Billing checker differs from evidence maker and requires synthetic accepted-quote evidence; no Paid output. Correction checker separation, explicit TEST_ONLY draft capability and action-bound step-up references.
- Owner/collaborator/guardian/minor scopes; two accounts and multiple Roots, foreign object/property rejection, current membership and reader/writer assignments. Guardian grant binds minor record, organization, Root, category, purpose, age, revocation and expiry. Collaborator/guardian/minor cannot supply owner consent. Exact version/action-specific synthetic step-up negatives.
- Missing/stale/expired/unavailable Admin grant, ownership/grant/member/guardian/privacy epoch mismatches; local/Admin revocation, transfer and reconcile barriers deny at execution and delivery. Earlier execution diagnostic cannot authorize later disclosure. Unavailable authority is typed Pending, never successful admission. Support/renewal are not sold-pack locked.
- Account switch/reselection drops stale replies. Replay identity/digest changes conflict and revoked read rights deny redisclosure; no durable replay prevention is claimed. Typed Pending/Conflict/Unquotable, null/zero/nonfinite/string/negative amount rejection with no zero/Paid fallback. Commercial publication/actual quote creation always blocked.

These are pure predicate/model tests, not runtime concurrency, streams, D1/Worker/R2, session revocation, cryptographic assurance, legal guardian proof, immutable approval ledger or L3/ASVS acceptance. Full model interfaces and omissions are in foundation-scope.md. Actual credentials, sessions, WebAuthn verification, trusted workload adapters, event persistence, enrollment/recovery, broker/consumers, providers and editor are absent. The original 151 risks, 345 ASVS rows and 54 original cases retain NOT_ASSESSED/NOT_RUN statuses. PKG-01 findings remain unchanged. Catalogue prices remain null/unpublished and quotas unmeasured.

## Preservation and helper history

Original branch work; HEAD 08f614b1698dec2db657248f95ceea723ab537e7; tree dce28a4004a1d060d936e9656b5c4d589e787839. Clean porcelain incl all untracked paths, all 243 original tracked raw hashes and all 824 inventoried previous evidence files preserved. Master/archive/frozen migrations and pinned P01C documents unchanged. Fresh raw preservation assertions also run when finalizing EXIT.json and SHA256SUMS.txt; no Git mutation.

Read-only/document helpers had three transparent nonzero outcomes before test execution: rg found no AGENTS file; an optional historical /tmp inventory was absent; an overly strict environment check rejected a set NODE_PATH. Direct comparison to the pinned P01C 807-file map replaced the absent scratch dependency. Explicit ESM relative/node: imports ignore NODE_PATH; NODE_OPTIONS/NODE_V8_COVERAGE were absent. No source command or test ran on the failed pre-execution check. These were checker assumptions, not integrity mismatches, missing pinned tools or model-test failures. Corrected assertions passed. No test rerun or masked exit.

Self-review before execution checked all ten authored files and imports. Prototype-named policy lookup, sparse property lists and guardian-to-record association were tightened before the single run. Independent reviewer **UNASSIGNED/PENDING**; no independent PASS or security acceptance. Remaining F1 review must examine default denial, boundaries, fixture assumptions and original policy preservation, not just green tests.

## Exact source hashes

| Candidate-relative file | SHA256 |
|---|---|
| admin/src/authorization/policy-model.mjs | 26e0f07bb2e0d7cfba89cd91e8067a8dd335d66cb76418e45a2a37bc23df9405 |
| client/src/authorization/policy-model.mjs | 0ee19e54c0d98d8668738485fc77d710215b413460029d71f7a57eb4ccbfa2cc |
| contracts/v1/authority-context.mjs | 6b838dc01d75df3cfefccfce39a077519c0af2506d1c256de03cf2ebd921b693 |
| contracts/v1/envelope.mjs | 9c7e7384b98a4f6d7ce62955d0bc418dad79973f1ac29d785a90f70c7262a921 |
| contracts/v1/outcomes.mjs | 42a57719ac864df4eedb7a518b73fca7b2308c516887b8072b4c752585d15eea |
| docs/foundation-scope.md | 36639d1498586ad2acfbd9add1317888d55de0ead187c331651f0bd240794588 |
| tests/authorization/admin-model.test.mjs | 4411299961311473106a2f070300b810536136abc096b713b050936594a82b85 |
| tests/authorization/client-model.test.mjs | ba4cca667fd047b2fb312a9af33bcbb7a0020ba65416ca480f80faace7eecda4 |
| tests/contracts/envelope-model.test.mjs | 7821e7c20de686f2565d90a8e470cd914ffb0dcbf29016bb28750b281b121d54 |

This report's own final hash is in the external SHA256SUMS.txt and EXIT.json to avoid self-referential hashing. The manifest covers all ten candidate files and four other evidence files; its own SHA256 is supplied with delivery. No hashes are invented before file creation.

## Five evidence files and stop

/workspace/idigitalroot-p01c-f1-evidence/ENTRY.json records raw entry inventories, input/tool pins, limits and self-review. model-tests.log is the unmodified runner log. EXIT.json records actual test command/exit, hashes, preservation and omissions. INDEPENDENT_REVIEW.md explicitly records the unassigned function and pending review. SHA256SUMS.txt pins the created outputs except itself.

No dependency installation, new SQL/migration/database, real authentication, Worker/API, server/browser launch, provider/payment/email/DNS/cloud action, Git mutation, spend or deployment occurred. No F2, Admin schema or Client schema was started. Separate exact owner work orders and independent review remain required; this report grants no subsequent activity.

SOURCE_CREATION=COMPLETED_FOR_F1_ALLOWLIST_ONLY
TEST_EXECUTION=COMPLETED_FOR_APPROVED_F1_COMMAND_ONLY
INDEPENDENT_REVIEW=UNASSIGNED/PENDING
NEXT_STAGE=F1_OWNER_AND_INDEPENDENT_REVIEW_PENDING
STOP_AFTER_F1=YES
