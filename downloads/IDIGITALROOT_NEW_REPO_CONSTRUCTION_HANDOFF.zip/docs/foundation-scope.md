# IDR-F1-v1.0 — isolated policy-model foundation

Owner authorization received 23 October 2026 for exactly ten candidate files and five external evidence files. This records the later explicit approval of F1; the pinned P01C proposal remains immutable and historically unapproved when written.

**MODEL_ONLY / NOT_AUTHENTICATED.** This candidate is a nonintegrated deterministic policy model. Passing structure or a synthetic assertion never establishes identity, a session, actual permission, Paid, consent, Live, delivery or publication. No production authorization adapter exists. No password/WebAuthn verification or real IAM/editor is built.

## Binding inputs

| File under /workspace/idigitalroot-p01c-read-only-2026-10-22/ | SHA256 |
|---|---|
| P01C_FIRST_BOUNDED_IMPLEMENTATION_WORK_ORDER_PROPOSALS.md | 855353834fdf58edda1f4e0e4d678fd0fb8353607ecc23624e76c741fe887cae |
| P01C_BOUNDARY_AND_PERMISSION_CONTRACTS.md | 94d0850a32290d74f569327fcc4bc1411ffe80f9b6d1b56c46e5308307ec6466 |
| P01C_TWO_D1_SCHEMA_AND_RECOVERY_PROPOSAL.md | e9a857c43a83a4f9796e6d0b6ed5944d2783c5936a54380abb2c150843be2ede |

The external ENTRY.json records 39 selected input hashes, original 243-path raw baseline, 824 preserved earlier evidence files, tool hash and destination inspection. Historical checkout stays branch work, HEAD 08f614b1698dec2db657248f95ceea723ab537e7, tree dce28a4004a1d060d936e9656b5c4d589e787839. All five staff bundles remain separate; SuperAdmin has no customer-consent/Billing/private-data override. Password AND WebAuthn for all humans is fixed by AUTH-2026-10-22-01; email is contact/notice only. Synthetic assurance is a fixture string, never evidence that factors were verified.

## Model interfaces and limits

All functions take caller-supplied synthetic values and deterministic integer time. Exact field schemas reject overposting. Context separates ADMIN_STAFF, CLIENT_HUMAN and WORKLOAD; role, namespace, assurance and expiry are structural checks only. Profile arguments are test-selected schemas, not downloaded or caller-approved production configuration.

Envelope validation models v1 command structure, expected versions, payload field/length limits, digest references and namespace/account/Root consistency. It does not calculate/canonicalize/verify a digest, signature or one-use nonce. compareReplay conservatively compares authority/actor/operation/key/account/Root/object/digest identities and checks a synthetic current-read-right flag. Different identities cannot reuse a receipt; no dedupe receipt or nonce store exists. Event/outbox/inbox persistence is outside F1.

Admin fields are requested input/output PROPERTY NAMES, not actual command payload values. Each operation uses a narrow role, assignment and explicit TEST_ONLY capability, expected version and action-specific synthetic step-up reference. Billing checker differs from evidence maker; acceptedQuote is only a model flag. The result does not record settlement or produce Paid. commercial.draft is an isolated capability predicate, not an editor or amount validator. Publication, recovery, customer acceptance and every unlisted staff operation deny.

Client checks one selected account/Root/object, exact property names, membership, reader/writer assignments, synthetic Admin association/currentness, epochs, barriers, object version and guardian category/purpose/age/revoke/expiry. Guardian and allowed-minor models do not establish lawful relationship or contracting capacity. Owner-only approval tests model role/action/object/version freshness; artifact hashes, immutable approvals and real step-up verification are future work. Support/renewal are not sold-pack locked but still scoped/current-authority checked. Unlisted functions deny. ACCOUNT_SWITCH response selection checks account plus generation.

Execution and delivery each re-evaluate the same pure predicate with fresh synthetic inputs. checkedAt must equal fixture time; this strict model equality is not a production freshness window or concurrency guarantee. Model state is NOT an actual current Admin admission or Client authorization. No linearizability, in-flight cancellation, cross-D1 ACID, restore, real privacy or distributed G-RACE proof is claimed. Credential/authz epoch fields are validated as references, not checked against a session registry. Object association/readers are explicitly supplied fixtures, not trusted database truth.

outcomes are bounded immutable diagnostic values: Deny, Pending, Conflict, Unquotable, ModelOnly. Every value bears MODEL_ONLY / NOT_AUTHENTICATED. No success/Paid/zero fallback. quoteBlocker always blocks real quoting; unpriced/draft/null/zero/noninteger values cannot become a sale. Synthetic numerical examples in tests are not catalogue prices. All actual 12+4 documentary proposals remain unpublished/null with empty country overrides; quotas NOT_MEASURED/NOT_APPROVED.

## Execution boundary

Only the literal command in Section 2 of the pinned order may run the three named Node tests, from this candidate directory. Node raw SHA256 596b5144ff242737f1c1be6a5f0ccb3907dbba2482344143cb1a6898633402a9; required version v22.19.0. Ceilings: 60s wall + 5s TERM grace, 30 CPU seconds per process, 128 MiB V8 heap per Node process (not total RSS), ≤10 MiB inline fixtures and ≤1,000 deterministic cases. No load/stress loops. Imports only node:test/node:assert/strict and these enumerated pure modules. No I/O, network, clock/random sources, subprocesses, workers, persistence or credentials in authored JavaScript. Node's sequential test-runner processes are the only permitted children.

No dependency, manifest, SQL/migration/database, Worker/API/server/browser, real auth/provider/payment/email/DNS/cloud action, Git mutation, build, benchmark or deployment. Existing source, migrations, reports and archives remain untouched. The 151 risks, 345 ASVS rows and 54 original cases remain NOT_ASSESSED/NOT_RUN; these new model tests do not alter them. No inherited PKG-01 PASS, L3 or security acceptance. Independent review is UNASSIGNED/PENDING; implementation self-review cannot replace it. Stop after F1; F2/Admin schema/Client schema remain unauthorized.
