# iDigitalRoot — Scope-freeze readiness after authentication decision

**22 October 2026 · OWNER REVIEW / DOCUMENTATION ONLY · NOT FROZEN · NO IMPLEMENTATION AUTHORITY**

## Scope evidence and gate board

| Gate | Current state | Owner/engineer next action |
|---|---|---|
| P00 master ZIP and required authority reading | **CLOSED as reported by Codex P00/P00B/P01** | Preserve SHA pin and recheck checkout at future work-order entry |
| P01 scope / feature traceability | **REVIEWED, NOT FROZEN** | Retain all 58 feature rows, 77 precise R13–R26 records, earlier grouped R1–R12, this new AUTH decision |
| AUTH-2026-10-22-01 | **DECIDED** | Update all active planning refs: password + WebAuthn MFA, email contact/notifications only |
| Detailed Admin/Client IAM and recovery design | **PROPOSED / TBD** | Produce bounded roles, enrollment, recovery, step-up and abuse-case contracts; security applicability review before approval |
| New separate Admin/Client D1 lineages + recovery | **NOT APPROVED** | Complete field/schema/migration/rollback/restore specs with frozen public 0001–0016 / analytics 0001–0002 untouched |
| Website catalogue | **STRUCTURE DECIDED, PRICES TBD** | Owner approves 12 annual site package prices and 12 renewal prices one by one plus scope/allowances; no invented values |
| Tool packs | **STRUCTURE DECIDED, PRICES TBD** | Approve four pack monthly/annual values and paid switch rules |
| Common quotas and costs | **NOT MEASURED** | Propose numbers and benchmark/cost plan; existing import ceilings and image limits retained |
| Public new no-CMS / legacy Public CMS boundary | **DECIDED, NEW SOURCE NOT BUILT** | Separate reviewed WO-PUBLIC-NEW; preserve old CMS/MOTION source, secure wizard → Admin leads + visitors email |
| Historic fixture anomalies | **PKG-01 OPEN for affected acceptance** | Separate authorized repair/repro scope, no silent manifest mutation |
| Eight-market legal/provider/security/release | **BLOCKED_RELEASE** | Defer live services until actual legal/provider/staffing/restore/evidence gates clear |
| Overall construction/deployment authorization | **NOT GIVEN** | Explicitly approve one exact-version work order only after scope and affected local gates close |

## Commercial decision sheet — amounts deliberately blank

**Twelve website packages:** Students, Professionals, Entrepreneurs, Businesses × Entry, Growth, Premium. For each row owner approval is required for initial **annual** website price; annual **renewal** price; domain/mail allowance and actual tier deliverables. The first paid year includes website build + matching audience pack; the verified purchase time starts the annual website year and 12-month pack-inclusion clock, even if launch is delayed.

**Four paid tool packs:** Student, Professional, Entrepreneur, Business. For each pack approve monthly and annual prepaid rates, renewal handling, switch charge/credit/proration, grace/suspension behavior. One active pack per Root; only Live + website-plan-active + Admin-verified pack enables tools.

No price, exchange rate, tax, storage quota, backup cost or provider fee is invented in this document.

### Proposed owner price-entry matrix — no guessed amounts

| Audience family | Tier | Initial annual price | Year-two annual renewal | Included website scope/domain/mail allowance | Owner decision |
|---|---|---|---|---|---|
| Student | Entry | **TBD** | **TBD** | **TBD** | NOT_APPROVED |
| Student | Growth | **TBD** | **TBD** | **TBD** | NOT_APPROVED |
| Student | Premium | **TBD** | **TBD** | **TBD** | NOT_APPROVED |
| Professional | Entry | **TBD** | **TBD** | **TBD** | NOT_APPROVED |
| Professional | Growth | **TBD** | **TBD** | **TBD** | NOT_APPROVED |
| Professional | Premium | **TBD** | **TBD** | **TBD** | NOT_APPROVED |
| Entrepreneur | Entry | **TBD** | **TBD** | **TBD** | NOT_APPROVED |
| Entrepreneur | Growth | **TBD** | **TBD** | **TBD** | NOT_APPROVED |
| Entrepreneur | Premium | **TBD** | **TBD** | **TBD** | NOT_APPROVED |
| Business | Entry | **TBD** | **TBD** | **TBD** | NOT_APPROVED |
| Business | Growth | **TBD** | **TBD** | **TBD** | NOT_APPROVED |
| Business | Premium | **TBD** | **TBD** | **TBD** | NOT_APPROVED |

### Proposed tool-pack price-entry matrix

| Audience tool pack | Monthly prepaid price | Annual prepaid price | Paid-switch charge/credit policy | Owner decision |
|---|---|---|---|---|
| Student | **TBD** | **TBD** | **TBD** | NOT_APPROVED |
| Professional | **TBD** | **TBD** | **TBD** | NOT_APPROVED |
| Entrepreneur | **TBD** | **TBD** | **TBD** | NOT_APPROVED |
| Business | **TBD** | **TBD** | **TBD** | NOT_APPROVED |

### Measurements and engineering cost proposal — no invented numbers

| Cost/limit candidate | Approved numerical baseline? | Evidence needed before numerical proposal |
|---|---|---|
| Office import type limit / batch size | **YES:** 10 MB DOCX/XLSX/PPTX; 2 MB CSV/ICS; 25 MB batch | Measured decoding/decompression/CPU/R2 costs and exact decimal/binary interpretation remain OPEN |
| Support images per case message | **YES:** JPEG/PNG/WebP only; 5 MB each and max 3 | Scanner and memory/CPU/storage tests remain OPEN |
| Root private R2 storage / original attachments | NO | Representative data, retention/snapshot assumptions, measured storage and operation costs |
| Max files, share links, concurrent exports per Root | NO | Representative concurrency/race and authorization tests, generated-output costs |
| Export sizes, document generation and job timeouts | NO | Workload benchmark with worst-case DOCX/XLSX/PPTX/PDF and price breakdown |
| Email events and support notifications | NO | Allowed volumes, abuse limits, approved mail vendor actual price schedule |
| Preview artifacts and media quotas | NO | Source/media examples, preservation periods, object-store and access operation costs |
| WebAuthn authenticators per identity / renewal & recovery load | NO | Threat model, usability/availability/accessibility requirements, operational overhead |
| Retry/dead-letter/backup data and archive restore size | NO | Failure simulation, 90-day copy capacity and monthly restore test budget |

Numbers in a table marked NO must be submitted as **measured/costed proposals**, not treated as approved quotas or unlimited allowances.


## Final scope-freeze sequence — no repeated discovery questions

1. Fold `AUTH-2026-10-22-01` into Codex P01's complete review, section H/L decision sheet and exact current scope (read-only documentation task). Mark older email-OTP normal login as historical/superseded; do not rewrite archived master sources.
2. Collect one **single review set**: complete role/method/endpoint/action/permission matrix, WebAuthn enrollment/backup/recovery and sensitive step-up flow, service-to-service trust, two-D1 independent schema/restore plan, bounded test/evidence list. Label every engineering proposal vs owner decision.
3. Propose **costed** numeric common quotas after evidence; any measurement requiring local execution must be separately authorized. Bring **price entry sheets** to owner for one-by-one approval before their affected local implementation.
4. Have owner review one scope freeze sheet with explicit included/excluded features and per-work-order boundaries. Do not imply approval from “continue”, this decision or receipt of a report.
5. Only after gates and exact-version authorization, issue limited source work orders and separately authorized schema tasks; staging/providers/deployment require later independent approval.

## Scope consistency guarantees

- Admin owns staff IAM, commercial/Roots/projects/entitlements/support/approval evidence; Client owns customer IAM/guardian/membership and private workspaces. Authentication decision does not merge the two D1 databases or grant staff general read access to customer private tools.
- Four audiences, Student 12+16 positions (Career Kit shared), 11 Client areas, five roles, live Root/pack gating and guardian privacy remain unchanged.
- Two exact-version account-owner-only project approvals, both-owner Root transfers, Ops/Super Admin maker-checker, image-only support, Office originals, 30/90-day shares and existing file ceilings remain unchanged.
- P01 is a **read-only owner-review draft**; not a final approved implementable contract or test PASS.
