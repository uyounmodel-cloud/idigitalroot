# iDigitalRoot — Combined Admin + Client Implementation Scope (Owner Review Draft)

**Consolidated working scope v0.5 · updated 22 October 2026 · NOT APPROVED · NOT IMPLEMENTED · NO DEPLOYMENT AUTHORIZED**

This corrected consolidated document synthesizes the verified **Client Panel handoff v1.2**, explicit owner answers **Rounds 1–26**, the **22 October owner WebAuthn MFA decision**, and the **20 October public no-CMS motion-site requirement**; it does not supplant the original full Client/Admin blueprints, the seven verbatim master security authorities, the original master companion, or the frozen public/CMS contracts. It is a **review candidate for scope freeze**, not a request for implementation permission. No source code, migrations, fixtures, Cloudflare resources, live customers or public/CMS data were changed to prepare it.

**Active latest owner decision:** `AUTH-2026-10-22-01` (password + WebAuthn for every Admin/Client identity; email for contact/notifications only). Historical 1–26 choice of email-code normal MFA is preserved as superseded, **not active**. This is not approval to implement.

**Status vocabulary:** `DECIDED` = explicit owner decision or source constraint; `PROPOSED` = implementation approach pending scope approval; `TBD` = a real unanswered variable; `BLOCKED_LOCAL` = prerequisite to source work; `BLOCKED_RELEASE` = required before affected public service/release; `NOT_RUN`/`NOT_MEASURED` = no supporting operational evidence. Proposals are never owner approvals.

> **CURRENT VERSION AND SOURCE PRECEDENCE (documentation authority only).** This v0.5 supersedes earlier consolidated drafts v0.1–v0.4 **as the working scope draft**, not the original authority. For conflicting statements: (1) later explicit owner decisions in their relevant scope, especially the 20 October public no-CMS request; (2) binding unchanged original master security/environment/data isolation; (3) verified historical project/source evidence in its original product/version context; (4) assistant-generated engineering proposals. Prior docs remain preserved for audit but are **not** independent permission to implement. This draft is NOT owner-approved for construction.

## 1. Authority, integrity and current phase

- Verified small attached handoff: `IDIGITALROOT_CLIENT_PANEL_BLUEPRINT_AND_AI_HANDOFF_2026-10-16_v1.2.zip`; **ZIP CRC PASS; 74/74 SHA256SUMS matches**. Its original full Client text export, original Admin, system/data/identity boundaries, seven original security files and current status documents are included. New risk and ASVS registers begin **NOT_ASSESSED_CLIENT_PANEL**.
- Commercial discovery v0.14 was an immutable input (SHA256 `53215766d65d05ebac531584ccfe1abc2d444efff0a69114186612767104bdcf`); companion v0.15 separately records Round 26.
- **Original master verification (updated evidence, not rerun here):** Codex read-only stages P00/P00B/P01 report exact raw SHA256 `f1ea6c341baf3c81afa5b797ed09beb9b1a400325338e8a42ed671c2a5f23b20` for `downloads/IDIGITALROOT_CODEX_MASTER_HANDOFF_2026-10-14_v1.1.zip`; P00 recorded `PASS_FULL_BINARY_HASH_AND_NESTED_CRC` (99 ZIPs, 3,445 entries including directories); P00B recorded completion of required master authority reading. This resolves the **prior missing-binary and authority-reading documentary gates** based on Codex evidence. Exact source checkout/commit and hashes must be revalidated at any future source-work entry. The seven missing generated fixture outputs and original FE test-fixture `tsconfig` mismatch remain separately documented and block affected legacy-fixture acceptance until properly remediated/tested. No local implementation permission follows from source verification.
- Public MOTION01/CMS is a **local review candidate**, not completed production release. Public Core D1 migrations **0001–0016** and Analytics **0001–0002** remain frozen. Its 32-step historical report is not a Client/Admin test PASS. The current real source and CMS integration contract need direct inspection before an integration implementation.
- All Cloudflare production/staging resources, spend, secrets, provider configuration, remote DNS and deployment require **separate action-specific authorization** after local review. Existing authentication is not authority for mutation.

## 2. Product and delivery scope — decided vs not delivered

**DECIDED (latest owner public-website direction, 20 October 2026):** One motion-rich bilingual English/Arabic public corporate site addressing all four audience groups (Students; Employees & Professionals; Entrepreneurs & Startups; Businesses & Organizations), **without a CMS for this new public site**. Its only visitor-submission feature is a **fully secured request wizard**: persist/handoff the legitimate request into the separate Admin qualification queue and arrange a durable transactional notification to **`visitors@idigitalroot.com`** (real delivery requires a reviewed provider). **DECIDED platform boundaries:** internal Admin, Client Account and every independent client website CMS remain separate. The pre-existing Public CMS and MOTION01 artifacts are historical/under-review source authorities, **not** an authorization to add a CMS to the newly requested public marketing site, delete an existing product, or deploy. The new public-site direction is a separate scope/integration contract, not silently part of the combined Admin/Client implementation permission. One commercial client account may own many independent Digital Roots, users may belong to multiple accounts; audience is presentation, not a security role/entitlement. One complete **local** review candidate shall include a real combined Admin and Client implementation and all four audience packs. Internal vertical slices, tests and reversible local fixes may be sequenced during later approved implementation, even though the owner wants one formal comprehensive review candidate. **No approval to create that candidate has been given.**

**DECIDED no-substitution rules:** full Student Toolbox 12 and Student Workspace 16 positions (Career Kit one shared capability = 27 unique capabilities); no reduced student launch; functional Professional profile, four Entrepreneur additions and two Business additions. No AI chatbot/LLM reliance or paid social/analytics API in v1. No raw DNS, server, secrets or infrastructure dashboard for ordinary customers. No generic file vault or automatic unrestricted CMS publishing. Data never moves from private tools to public site implicitly.

### 2.0 Latest public-site direction and historical Public CMS reconciliation — critical correction

**Decided by owner (20 October 2026; supersedes earlier *future-public-site CMS* assumptions only):** Create a motion-rich **EN/LTR + AR/RTL** public marketing site for all four audiences, **with no CMS**. Its only public submission is a fully secured request wizard delivering inquiries to `visitors@idigitalroot.com`. **Decided in Round 21:** a secure reviewed lead handoff feeds Admin's authoritative qualification queue. These are complementary outcomes, not two independent activation paths. Proposed reliable integration: accept/store a validated lead once through the authorized public-to-Admin boundary, enqueue idempotent email delivery, expose Pending/retry/failure to staff, and never mark a customer Paid/Active from a wizard submission. Do not assume the email provider exists, store credentials in the browser, or count a sent email as proof of account activation.

**Historical authority preservation:** The separately approved older Public Website CMS UI/source and MOTION01 review candidate are not deleted, overwritten or retroactively disapproved. They do not impose a CMS on the new website. Existing Public Core D1 0001–0016 and Analytics D1 0001–0002 remain unchanged. Whether legacy artifacts are reused, archived or retired is a **separate source/release task**, not an implicit modification. The new public marketing site is outside the Admin/Client app implementation authorization unless expressly added to the final bounded work order.

**Not yet engineered or tested:** Wizard abuse/rate limits, bot mitigation, validated input and file policy (no attachment feature assumed), CSRF/origin/CSP, email header injection prevention, HTML output escaping, durable queue/idempotency, consent/privacy text, accessibility/reduced-motion alternatives, and supplier delivery/error monitoring. All need review against the actual site source and original security baseline. This is a **scope correction**, not an implementation claim.

### 2.1 Audiences, capabilities and accepted output direction

| Audience | Included in proposed full local candidate | Existing constraint |
|---|---|---|
| Student Toolbox: 12 positions | CV Studio; Portfolio Builder; Digital Card; QR Studio; Link Hub; Achievement Kit; **Career Kit**; Email Signature; Project Share; Personal Brand Kit; Contact Card; Root Export | Actual editing/save/preview, valid files, narrow public sharing and authorized export. |
| Student Workspace: 16 positions | My Semester; Study Planner; Exam Countdown; Project Desk; Study Timer; Goals; Application Tracker; **Career Kit (same engine)**; Cover Letter Guide; Skills Passport; Career Roadmap; Learning Log; Experience Journal; Research Shelf; Campus Calendar; Student Budget | All majors receive complete scope; shared calendar/timer, per-currency budget and private academics. |
| Professional | Shared CV/portfolio/achievements/Career Kit, Application Tracker, Cover Letter Guide, Skills Passport, Career Roadmap, Goals, Learning Log and reviewed professional evidence | Shared engine where appropriate, no duplicated conflicting data. |
| Entrepreneur | Venture Profile & Brand Brief; Offer Planner; Pitch One-Pager; Launch Planner plus relevant existing Toolbox reuses | Saved structured plans, useful printable outputs; not a CRM or AI advisor. |
| Business | Digital Asset Register; Marketing/Content Request Briefs plus Root/care operations and reviewed shared brand/link tools | Asset references only, not a credential vault; real staff request handoff. |

**Functional specifics DECIDED:** coordinated course/exam/study/campus calendar with validated ICS; persistent Study Timer automatically pauses on 10-minute credible inactivity, keeps history of user corrections; currency-specific manual Student Budget (no banking and no fabricated exchange rate); Career Kit opportunity-specific immutable CV/portfolio/achievements/contact/optional-cover-letter snapshot with PDF/DOCX; private Portfolio with CMS handoff only when a real CMS exists; Research Shelf links/citations/notes/tags without arbitrary server fetching; private-by-default expiring sharing (30 days default, 90 days max), immediate revocation on account/guardian/entitlement changes; Root Export structured records plus **explicitly selected permitted** Office originals. Broader DOCX/XLSX/PPTX/CSV/ICS import/export compatibility subject to individual tool allowlists, scanning and verified parser support. Source Office originals retained private, not exposed as generic vault objects.

### 2.2 Real client routes and screens — route strings PROPOSED, grouping DECIDED

11 main areas are **DECIDED**, not the old seven-area proposal: **Home, Roots, Projects, Tools, Domains, Email, Services, Billing, Renewals, Support, Account**. Notifications use a separate Inbox. Actual URL paths, nested names and component identities are `PROPOSED` until existing repository routing is read.

| Area | Required real screens/actions (DECIDED functional content) |
|---|---|
| Home | Real attention alerts, active Roots, tasks/approvals, verified subscriptions, recent activity; no fabricated health or progress. |
| Roots | Owned Roots, active stage, profile, service association, live link and conditional Open Website Admin only when a real compatible CMS consumer is present; transfer requests. |
| Projects | Versioned typed onboarding drafts/autosave/resume/submission, stage/milestone history, protected local preview, comments, design/content owner approval then final project owner approval. |
| Tools | Pack-entitled Root selector; four audience workspaces, all stated real tools, saves/conflicts, validated exports/imports, private share grants, privacy/history. |
| Domains | Domain and renewal metadata, ownership/transfer assistance, no raw DNS or registrar secrets. |
| Email | Real mailbox metadata, vetted webmail/setup paths and support requests; no credentials exposed; provider provisioning gated. |
| Services | Versioned catalogue, scoped service/feature requests, plan/add-on status. |
| Billing | Quotes/accepted contract versions, external payment evidence status, invoices/downloads, credits/adjustments only if authorized. |
| Renewals | Independent website annual terms and tool monthly/annual terms, dates, warnings, manual owner acceptance, immediate tool lock on expiry. |
| Support | Complete authorized threaded cases, images only, safe case reference, staff reply and status history. |
| Account | Profile, email contact verification, password, WebAuthn factor enrollment/challenges, supervised recovery, active sessions, collaborator invitation/role, guardian visibility, multi-account switching. |

**UX acceptance:** native English LTR and Arabic RTL, responsive tablet/mobile/desktop, keyboard, screen reader and WCAG 2.2 AA target, meaningful failure/empty/loading messages, reduced motion; calm operational interface, not an animated marketing copy. No fake dashboard or clickable no-op control.

### 2.3 Admin staff roles and real operational screens

Five DECIDED roles: **Super Admin** (staff IAM/config/security), **Operations Manager** (lead qualification, authorized client/Root management, projects, may issue quotes and record **Pending** payment evidence), **Project/Production Staff** (versioned intake/project stages/previews/QA), **Billing Staff** (independently verifies payments, refunds/reconciliation and authoritative Paid state), **Support Staff** (case response, narrowly authorized temporary customer-approved workspace access). Least-privilege permissions are per operation/object/account/Root and individual identity. Mandatory MFA for all customers and staff.

Admin minimum screens: staffing roles and security audit; lead qualification/duplicates; versioned 12-plan catalogue and four packs; versioned quotes and invitations; payment-evidence intake plus independent Billing verification; authoritative Roots, ownership, project stages, four onboarding template families, exact-version preview/approval ledger and transfers; support inbox/thread/assignment/priority; domain/mail metadata and transfer-review tasks; entitlements and manual renewals; notifications and delivery failures; Operations-led event reconciliation with **maker Operations / checker Super Admin** for allowlisted non-financial record corrections; private/security audit with restricted payloads; reports on Pending/failure states. Staff workflow is not a bare DB editor or public CMS admin screen.

## 3. Real end-to-end workflows and state invariants

1. **Public visitor** uses the new **motion-rich EN/AR, no-CMS** public site's secured request wizard -> reviewed authenticated handoff -> authoritative Admin lead queue, with durable idempotent email notice to `visitors@idigitalroot.com` after request acceptance (email provider `BLOCKED_RELEASE`). No automated activated user and no invented delivery success. Existing historical Public CMS/MOTION01 source remains untouched.
2. **Admin staff** qualifies request -> staff creates immutable quote/version using approved prices -> **account owner accepts** exact terms. Billing verifies external payment independently; Operations may record evidence only as Pending Verification. No client-supplied paid/price/status is trusted.
3. **Authorized staff** creates the Root **only after verified purchase**, exactly once under idempotency. Client account receives an invitation after staff qualification/accepted quote; user activates verified customer login. Customer IAM stays with Client D1, staff IAM with Admin D1.
4. **Client onboarding** chooses one of four versioned starter blueprint families; server validated drafts/autosave/resume/conflict control, idempotent submission. Staff updates authoritative stage and produces exact-version protected preview releases.
5. **Account owner** records two immutable, independently verified approvals: design/content version followed by final-project version. Authorized collaborators may view/comment on previews; staff cannot impersonate approvals. No approval implies deployment authorization.
6. **Site goes Live** only after genuine local/remote evidence and separate release authority. First website package is prepaid annual, including initial build and a real domain + hosted mailbox; matching audience pack included at no additional charge for first 12 months, both clocks begin at verified purchase, and **no construction-delay extension**. Tool access remains locked until Root is actually live and website plan and tool entitlement are both active.
7. **Commercial state**: at most one active pack per Root; owner may pay to switch midyear (old history retained), other paid packs independent of website family. No automatic renewal; website annual only, tool pack monthly/annual. Separate expiry, default immediate tool lock. Manual versioned owner acceptance and independently verified payment required for renewal.
8. **Support**: authorized Client message -> single Admin-owned thread -> assignment, region/tier calendar, client reply, image-only attachments, event notification and terminal closure; no staff-only note leaks.
9. **Root transfer**: both account owners + staff consent; transfer eligible remaining services and legitimate Root-owned records with checked minor/individual constraints; old invoice stays with old contracting account and support history stays there; revoke old access/SSO/shares/previews, preserve immutable project approvals, new owner approves unfinished work; provider-specific domain/mail transfers reviewed manually. Partial cross-DB transfer stays Pending and fail closed.
10. **Authentication/recovery — 22 October supersession**: password **plus WebAuthn MFA** for every staff member, customer, collaborator and guardian; stronger renewed WebAuthn/security-key verification for privileged/sensitive operations; independently registered backup authenticators, supervised lost-factor recovery, special guardian checks, strong audit and rate limits. Email is contact verification/notification only and **never** an authentication factor, MFA fallback, password-reset authentication shortcut or recovery substitute. Detailed enrollment/recovery controls remain engineering contracts subject to security assessment.

## 4. Data authority, storage and proposed service architecture

**DECIDED: two physically distinct Cloudflare D1 databases with separate independent migration lineages.** Do not merge Admin and Client authorities. Cloudflare Workers is the runtime; private R2 is Worker-controlled and never receives browser credentials. A separate Public Core/Analytics remains frozen; each client website CMS remains site isolated.

| Entity/domain | Authority | Allowed consumer and anti-drift rule |
|---|---|---|
| Staff identity, roles and privileged action approvals | Admin D1 | Admin only; no Client impersonation of staff identity. |
| Public lead/qualification and staff acceptance | Admin D1 (after secure public handoff) | No direct anonymous Client-account activation. |
| Catalogue, quote, contract, invoice, payment verification, renewal and active pack entitlement | Admin D1 | Client queries authoritative current grant; no stale projected Paid/Active authorization. |
| Digital Root, Root ownership/project stage, protected preview release/version and owner approval evidence | Admin D1 | Client receives strictly scoped data/authorized commands through versioned service API. |
| Support case, messages, staff assignments and staff-only notes | Admin D1 | Client sees only customer-safe projection; attachment reads scoped. |
| Customer identity, password/session, WebAuthn challenge/credential records, strong authenticator and revocation | Client D1 | Admin staff operations use authenticated service contract; customer passwords not copied. |
| Commercial account membership, collaborator role assignments, guardian/revocable category grants | Client D1 | Roots/ownership checked with Admin authority as applicable; account switch cannot change object grants. |
| Private tool/workspace item, versions, shares/exports, permitted originals metadata | Client D1 + private R2 objects | Every item bound to originating Root and account; entitlement requires fresh Admin decision; R2 access server-side only. |
| Individual client website CMS content/media/site users/site analytics | Independent CMS, own isolation | No general central mirroring or direct DB reach-through. |

**PROPOSED service boundary:** typed/versioned authenticated Worker-to-Worker operations (after source/runtime review); per-operation signatures/service identities and audience enforcement; Admin/Client data-transfer objects with version/hash/correlation/idempotency keys; transactional within-own-D1 outbox and inbox/consumer-deduplication tables; retry with bounded backoff, dead-letter visibility and Operations-led reconciliation; forward-only compensating steps for cross-DB transfers. No distributed ACID or direct D1-to-D1 joins. Unknown, stale, replayed, invalid signature, disabled identity, wrong Root or pending confirmation MUST reject protected actions.

### 4.1 Conceptual DFD (not implemented)

```mermaid
flowchart LR
  Visitor[Visitor] --> Public[EN/AR Motion Public Site - No CMS / Secure Request Wizard]
  Public --> Lead[Authenticated Lead Handoff]
  Lead --> Admin[Admin Worker and API]
  Admin --> Notice[Transactional notice job: visitors@idigitalroot.com / provider TBD]
  Staff[Staff with MFA] --> Admin
  Admin --> AD1[(Admin D1
Authoritative Commerce/Roots/Projects/Support)]
  ClientUser[Customer/Guardian/Collaborator] --> Client[Client Worker and API]
  Client --> CD1[(Client D1
Identity/Memberships/Private Workspace)]
  Admin <-->|Versioned authenticated APIs and durable events
Pending/fail-closed| Client
  Client --> R2[(Private R2 originals and exports)]
  Admin --> R2
  Client --> Broker[One-time scoped CMS SSO broker]
  Broker --> A[Test Site A Consumer]
  Broker --> B[Test Site B Consumer]
```

**Threat boundaries:** unauthenticated public input, Public-to-Admin lead, staff-to-Admin privileged, customer-to-Client customer session, Admin-to-Client cross-service, Worker-to-D1 per-db permissions, Worker-to-R2 private objects, SSO-to-independent-site. DFD is PROPOSED; it must be updated from actual repository schemas and code before scope freeze.

### 4.2 Isolated migration task — requires explicit scope approval

**Admin D1 proposal**: staff users/roles/MFA/audit; leads; plan versions and catalog; quote versions/contracts/invoices/payment evidence/independent verification; accounts operational projections; authoritative Roots/ownership and project stages; onboarding template versions and submissions; previews/hashes/two approval milestones; entitlements/renewals; support cases/messages/assignments/staff notes; domain/mail metadata; ledger/outbox/inbox/reconciliation; privileged audit/notification state.

**Client D1 proposal**: customers/authenticators/session/challenges; accounts/memberships/guardians/revocable grants; site-scoped workspace items and versions, share grants/export jobs; retained-file metadata and quarantine flags; client notifications and customer-safe activity, cross-service inbox/deduplication. Table names, key design, indices, FK/check constraints, retention/backup and transaction sequencing remain ENGINEERING PROPOSALS, not committed migrations.

**Migration gate**: owner explicitly approves isolated migration task and lineage/recovery plan with no public `0017` and byte-identical Public Core0001–0016/Analytics0001–0002. Perform migration/rollback/forward recovery only on new synthetic local databases after implementation authorization; no owner live data touched.

### 4.3 Protected private R2 contract

Private objects indexed by account/Root/owner/record, object type, verified content hash, scan/quarantine state, allowed use, linked permission/entitlement, version, retention class and lifecycle. Existing original Office files retained privately; only safe verified types; Office DOCX/XLSX/PPTX max **10 MB each**, CSV/ICS **2 MB each**, batch **25 MB**; images for support JPEG/PNG/WebP max **5 MB each**, **3/message**; no SVG/PDF/GIF/Office support-case upload. Contextual output safety, decompression bombs, malicious embedded Office relationships/macros/formula injection, spoofed MIME, infected/polyglot files, scanning outage, oversized batch and cross-Root retrieval all fail closed. Support/Office previews served safely on isolated origin with correct cache/content-disposition controls. Actual scanner selection is not approved.

### 4.4 CMS SSO scope restriction

Construct only a genuine signed/tamper-evident, short-lived, single-use, site/audience/user/purpose-bound SSO broker **and two isolated local test consumers**. Verify issuance against Admin authoritative site/state, Client identity/permission and current commercial grant; atomic nonce redemption at target consumer; fail on replay, race, expiry, disabled user, wrong site/audience, missing key or transferred Root. No reusable credential/token in URL or direct R2 access. Broker tests **do not prove an actual client CMS is delivered**; live Open Website Admin UI unavailable until a real compatible CMS integration and separate release authorization.

## 5. Security, privacy and operational controls (mandatory planning constraints)

- Original master `04_SECURITY/` contains **seven** verbatim files; the owner's 151-title security inventory is minimum coverage. Assess **345 ASVS v5.0.0 requirements**, strong applicable L2 plus applicable L3 for privileged/high-impact functions; OWASP Top 10:2025, API Top 10:2023 and final NIST SP 800-218 SSDF v1.1. Every new Client/Admin item begins `NOT_ASSESSED`/`NOT_RUN`—do not inherit MOTION01 PASS.
- Per-feature assets, actors, entry points, DFD/trust boundaries, property/function/object authorization, abuse and failure modes, cryptography/key management, storage isolation, input/output safety, CSP/security headers, CSRF/CORS, abuse-cost limits, auditable changes, concurrency and race tests.
- **Owner-decided 22 October: mandatory password + WebAuthn MFA for every staff and customer identity (including collaborators and guardians)**. Use independent, origin/RP-bound WebAuthn challenges with user verification, safe enrollment and authenticator revocation; step up again using phishing-resistant WebAuthn/security key for privileged/high-impact operations. Provide independently pre-registered backup authenticators and supervised lost-all-factors recovery with separation of duties, stronger guardian controls and security/audit notifications. Email can verify a contact address and carry notifications only; **no email code, link or mailbox possession may authenticate a session, satisfy MFA or replace a lost factor**. Session controls and WebAuthn details require an exact reviewed design and executed evidence; no security PASS is inferred.
- Client collaborators can receive configurable limited roles and access Roots within the authorized account, but **only account owner** approves quotes and the two project versions. A user may belong to multiple accounts without sharing membership privileges across them.
- Owner requested read access to all adult members' account-bound records subject to explicit notices/valid lawful basis. **Minors 13–17** use verified guardian-managed student accounts and revocable per-category grants to named organizations; no unrestricted organization-owner access to minor private data. Legal/gender/age-market differences remain BLOCKED_RELEASE pending expert country review.
- **Retention:** owner prefers indefinite normal workspace retention and no voluntary deletion; legal access/correction/deletion/portability/guardian rights must still be honored where required. Include specific request workflow, lawful holds, deletion propagation to copied records and 90-day backup lifecycle, separate financial/audit class retention. No blanket promise of indefinite lawful storage in all eight markets.
- **Residency:** verified processing region subject to Lebanon/Iraq/Bahrain/Kuwait/Oman/Qatar/Saudi/UAE-specific restrictions; no unsupported country-in-country storage claim. Unsupported market/provider operations fail closed and block affected release.
- **Support:** market-specific business-hour schedules, tier response matrix, priority categories; provisional engineering baseline, not approved SLA. Staff Support may see private workspace data only via temporary customer-authorized support sessions, category/scope restrictions and audit.
- **Recovery:** backup all platform-owned D1/R2/workspaces/config/audit evidence; **90-day protected recovery copies and monthly actual restore exercises**. RPO <=24h and RTO <=48h are DESIGN TARGETS, NOT VERIFIED. External domain/mail provider restoration governed by separate approved contracts. ZIP/repo is not live data backup.
- **Email:** provider-independent adapter with deterministic local-only test driver; production supports invitation/contact verification, activation notices, recovery-status/security alerts, staff/client support and public-lead notifications. **Email is not an authentication factor or fallback; no email-login OTP requirement remains.** A real reviewed provider and delivery tests are required for customer-facing email features before affected live release. No SMS scope and no real messages sent in this planning phase.
- EN/AR accessibility, CPU/memory/storage cost budgeting, SBOM/locks/provenance, independent manual review, safe limited staff repair (Operations proposes, Super Admin approves allowlisted non-financial corrections), no raw secrets in audit or source.


## 5A. Owner authentication supersession — 22 October 2026 (AUTH-2026-10-22-01)

**DECIDED; documentation only; supersedes R2/R3 normal-login email-code MFA, not the requirement for MFA or email communications.** Every new iDigitalRoot Admin and Client identity — staff in five roles, customer owners, collaborators, guardians — authenticates using **password + WebAuthn (passkey or security key) as a separate second factor**. Required for ordinary login, with renewed strong WebAuthn/security-key step-up for sensitive/high-impact functions. Both identity authorities remain separate (Admin D1 for staff; Client D1 for customers); the legacy Public CMS identity contract remains independently preserved.

- **Email has no authentication authority.** Address verification/invitations/security/support/lead notifications may use email; no email OTP or magic-link factor for login, MFA fallback, step-up, privilege restoration, or substitute for a lost WebAuthn factor. Password reset by itself does not confer an authenticated or privileged session. The production email adapter remains necessary for its approved communications, not as a dependency for routine MFA.
- **Backup & supervised recovery.** Allow separately registered independent backup WebAuthn authenticators; protect enrollment/replacement/removal and all-lost recovery against account takeover, colluding support staff, social engineering and guardian impersonation. Privileged resets require verified identity, separation of duties, time-bound limited privileges, revocation of affected sessions/credentials and immutable audit. The precise proofing/hold/cooling-off/review thresholds are **ENGINEERING PROPOSED/TBD** and must be tested.
- **WebAuthn technical contracts (ENGINEERING PROPOSED, NOT yet implemented):** server-created unpredictable single-use challenge, per-app RP ID and origin allowlist, credential binding to correct user and service, replay/race resistance, cryptographic assertion validation, user-verification requirement subject to reviewed accessible alternatives, independent factor enrollment, loss/revocation, anti-enumeration, rate limits, device and authenticator diversity, safe account switching and session rotation; no insecure browser-only check. Step-up must be bound to exact action, actor, account, Root and review version where applicable.
- **Security authority:** October 16 unchanged ASVS v5 register `V6.3.6` Level 3 says: “Verify that email is not used as either a single-factor or multi-factor authentication mechanism.” This owner choice **removes the identified product-policy conflict** for new Admin/Client login paths. `V6.3.6` **remains `NOT_ASSESSED_CLIENT_PANEL`**, as do other ASVS rows; no tested Level 3 compliance or implementation PASS is claimed. Original seven security authorities and any applicable stronger requirements remain binding.
- **Review targets:** routine login, invitation activation/first WebAuthn enrollment, already signed-in factor registration, second-device backup, step-up for quote acceptance/project approval/Root transfer/financial and privileged actions, account-member/guardian safety, session/MFA revocation, lost-all-device recovery, disabled authenticator, replay/phishing/binding races, email provider outage.

**Remaining auth technical gate:** map roles/routes/action assurance levels, enrollment/recovery and exact security tests into the separate Admin/Client identity contracts; this is scope-review work, **not source-work permission**. All build, schema, provider and release gates remain open.

## 6. Eight-market support — DECIDED model; individual targets still PROPOSED

| Market | Proposed service days | Proposed local-time support window |
|---|---|---|
| Lebanon | Monday–Friday | 09:00–17:00 |
| Iraq | Sunday–Thursday | 09:00–17:00 |
| Bahrain | Sunday–Thursday | 09:00–17:00 |
| Kuwait | Sunday–Thursday | 09:00–17:00 |
| Oman | Sunday–Thursday | 09:00–17:00 |
| Qatar | Sunday–Thursday | 09:00–17:00 |
| Saudi Arabia | Sunday–Thursday | 09:00–17:00 |
| UAE | Monday–Friday | 09:00–17:00 |

| First human response priority | Entry | Growth | Premium |
|---|---|---|---|
| Critical | 4 business hours | 2 business hours | 1 business hour |
| High | 1 business day | 4 business hours | 2 business hours |
| Normal | 2 business days | 1 business day | 4 business hours |
| Low | 4 business days | 2 business days | 1 business day |

Hours/holidays/staff coverage, service credits and final legal wording are not approved or verified. Never publish this proposal as an active contractual SLA.

## 7. Commerce, plans and quota evidence

**DECIDED commercial topology:** 4 audience plan families x Entry/Growth/Premium = **12 website plans**. Paid first-year **annual website construction package includes creation**, registered domain and actual hosted mailbox and managed care; three tiers vary website complexity and service support. Included matching audience pack at no additional pack fee for **12 months starting verified purchase**, with **no construction delay extension**. Other audience pack only via paid explicit switch; at most one per Root. Paid standalone tool pack monthly/annual, manually renewed; no automatic charge. Contract base USD, approved country-specific quotes/FX/taxes, fixed tier amounts TBD; website + tool renewal periods independent. Owner chooses commercial prices **one by one**. No invented revenue or free domain/mail cost.

**Quota states:** fixed provisional max per import/support file in §4.3; all other numeric ceilings `TBD` until costed/benchmarked and owner approves. The common technical ceilings across tiers cover stored originals/derived objects, object counts, concurrent parsing, emails, API and export usage, share counts, throttling, per-Root size and backup/restore overhead. **Measured results = NONE; NOT_MEASURED.**

### 7.1 Unit-cost inputs — external official references, not platform measurement

At 21 Oct 2026, official documentation reports:

| Meter | Published pricing input | Not yet known |
|---|---|---|
| R2 Standard storage | $0.015 / GB-month | Actual average GB-months including retained originals, generated exports, 90-day copies; account allocation |
| R2 Standard Class A / B operations | $4.50 / million A; $0.36 / million B | Requests per import/download/share/backup, rounding and tier selection |
| D1 paid account storage | First 5 GB included; $0.75 / GB-month after included | Combined Admin/Client/published DB usage and restore amplification |
| D1 paid account operations | Rows read first 25B/month included; then $0.001/million. Rows written first 50M/month included; then $1/million | Actual rows scanned/written under indexes and jobs |
| Workers | Plan-, request- and CPU-dependent | Actual requests/CPU and plan; not measured |

Sources: [D1](https://developers.cloudflare.com/d1/platform/pricing/), [R2](https://developers.cloudflare.com/r2/pricing/), [Workers](https://developers.cloudflare.com/workers/platform/pricing/). Charges, rounding and included amounts apply at **account level**, not once per Digital Root. Values require reconfirmation when approving a commercial offer; email/mailboxes, registrar fees, scanner, staffing, tax and provider setup can dominate baseline infrastructure unit costs.

**PROPOSED measurement work order after explicit authorization:** use synthetic representative records; capture read/write/CPU/memory, parser/virus-scan throughput and worst-case expansion, storage after backups, email throughput and SLA labor; model per-Root and shared costs using variable customer count and 95th-percentile usage; propose numerical quota table with cost exposure, headroom, fail-closed limits, abuse tests and owner approval. Before these measurements, no numeric Root-storage/monthly-export quota should be claimed costed or approved. If the fixed-price-before-implementation choice (R10-05) requires those measurements before source work, the dependency stays **BLOCKED_LOCAL** rather than inventing values.

## 8. Proposed implementation sequencing — one complete review candidate

No execution is authorized. If and only if scope + isolated migrations + original master authority are approved, propose the following reversible local sequence:

1. Sealed source inspection, preservation of current owner changes, exact lock/toolchain and security analysis; original master/AGENTS.md; read-only existing Cloudflare/Wrangler identity verification; isolate synthetic datasets.
2. Approve and create **separate** Admin/Client local migration lineages, least-privilege Worker binding contract, full feature/DFD/risk mapping, secure identity and auditing foundation.
3. Working cross-system vertical slice: public lead -> qualification -> accepted immutable quote -> verified external payment -> invitation -> activation/login/MFA -> staff Root creation -> versioned intake -> protected preview -> two owner approvals -> authoritative support case. Include delayed/reordered/outage flows.
4. Plans/entitlements/renewals/quotas, domain/email metadata, notifications, truthful Root Health, owner transfers, two local SSO consumers, complete staff counterpart screens.
5. All four workspace packs; all Student 12+16 positions operational; validated import/export/Office originals, calendar/timer, independent strong privacy and child grants.
6. Official Workers-compatible build and **actual local workerd + two D1 + private R2**; browser EN/AR/keyboard/WCAG2.2AA/manual responsive/console; race, replay, malicious import, provider outage and privilege-abuse tests. Do not mark unrun tests PASS.
7. Reproduce on fresh immutable source extraction, Windows+WSL as relevant, sealed source ZIP, SHA, manifest, pinned lockfiles/toolchain, SBOM/provenance, changes, risk/ASVS/feature/test matrices, owner guide, known failures and open provider/market gates.
8. **Only after separately approved environment/action/spend** consider staging/provider integration or release. Local scope approval does not confer that authority.

## 9. Acceptance test contracts and honest gate reporting

Use original `QA_AND_RELEASE_GATES.md` Q0–Q13 and `authority/master/04_SECURITY/SECURITY_ACCEPTANCE_GATES.md` S1–S*. New tests are NOT_RUN now. Required acceptance must include:

- Multiple users and accounts/Roots, staff IAM isolation, account switching, collaborator permissions, adult owner vs guardian minor-category visibility, revoked member/guardian and cross-Root export denial.
- Password + WebAuthn for **all** identities; challenge origin/RP ID/user-verification binding, credential registration/substitution, multiple devices, backed-up factors, privileged step-up, authenticators revoked/lost, supervised recovery and guardian controls; phishing/replay/race tests, fixation/CSRF/session rotation and security notices. Email outage must not turn into an MFA bypass; distinguish blocked invitations/contact/notifications from already-enrolled login.
- Admin authority on entitlements, immediate lock on plan expiry/verification outage, one pack per Root under concurrent purchase/switch, simultaneous verified payment and event redelivery, pending/fail-closed states and Ops/Super Admin maker-checker.
- Protected preview wrong viewer/site, expiry and artifact supersession, two distinct immutable owner approvals and no implication of deployment authority; secure two-site SSO ticket one-use atomic race tests.
- Real Support cases and private image uploads malicious file/polyglot, quarantine outage and case transfer/privacy; no leaking staff-only notes, originals or billing across customer scopes.
- All 27 unique Student capabilities/28 menu positions plus Professional/Entrepreneur/Business functionality, real save/resume/version/change collision, correctly formatted DOCX/PDF/XLSX/PPTX/CSV/ICS where specified, no automatic CMS publishing; scan, archive bomb and formula-injection tests; numeric permitted-size boundary tests.
- Verified private R2/dual-D1 backup/restore, monthly test evidence, RPO/RTO calculations (not claimed until executed), broken external provider states, locale/holiday SLA arithmetic; WCAG2.2AA and EN/AR real browser acceptance.
- Map all 151 risk titles, applicable 345 ASVS rows and the handoff adversarial test matrix to actual evidence, with written N/A rationales and owner-approved residual deviations. Unit tests alone cannot mean secure.

**Required statuses** `PASS`, `FAIL`, `BLOCKED` for executed gates and `NOT_RUN`/`NOT_ASSESSED` for planning. No passing status or deployment claim is currently made.

## 10. Blocking register — separate local implementation vs live commercial release

| Gate | Blocking item | Status and resolution requirement |
|---|---|---|
| L1 | Full original master companion and relevant authority reading | `DOCUMENTARY GATE CLOSED per Codex P00/P00B/P01`: verified master SHA256/CRC/manifests and required A–G authority bodies read, with disclosed iterative order. Still recheck actual HEAD/hash/working tree at any future task entry; legacy fixture acceptance PKG-01 remains open. No authorization to source-edit. |
| L-AUTH | Normal login MFA versus applicable ASVS L3 | `POLICY DECIDED 2026-10-22`: password + WebAuthn for all new staff/customer identities, no email auth factor. Detailed enrollment/step-up/recovery controls and ASVS test evidence `TBD/NOT_ASSESSED`; no implementation authorization. |
| L2 | Owner's one bounded implementation scope approval | `NOT_APPROVED`: scope draft itself is not authorization; final matrix and technical change bounds must be accepted explicitly. |
| L3 | Two isolated Admin/Client migration tasks and lineages | `NOT_APPROVED`: require deliberate task/lineage + recovery and frozen public migration proof. |
| L4 | Fixed plan monetary values and proposed numerical quota matrix | `BLOCKED_LOCAL (dependent modules)`: per R10-05 prices and limits must be approved before dependent local construction. R26-02 measurement evidence remains NOT_MEASURED. |
| L5 | New no-CMS public motion site + actual lead integration | `REQUIRES_INSPECTION`: current MOTION01/historical Public CMS and new no-CMS direction must be reconciled with exact source and a separate bounded public-site work order; secure Admin intake and durable notice to `visitors@idigitalroot.com` must be contracted without touching old CMS or frozen schemas by inference. |
| R1 | Paid real transactional-email service and hosted mailboxes/domain registration | `BLOCKED_RELEASE`: real providers, secure credentials, service terms, verification, supported markets and spend authorization. Locally only deterministic fixtures until then. |
| R2 | Minor/guardian, owner-read, no discretionary deletion/indefinite retention, eight-country privacy | `BLOCKED_RELEASE`: country-specific legal and rights-processing contracts before handling real persons, especially minors. |
| R3 | Residency/local jurisdiction provider feasibility | `BLOCKED_RELEASE`: official supported Cloudflare placement & legal cross-border basis; no invented sovereign/local data location. |
| R4 | Actual independent client CMS and Open Website Admin integration | `BLOCKED_LIVE_FEATURE`: only two local test consumers are in current approved planning scope. |
| R5 | Production health/backup/incident/security/restore/independent QA | `NOT_VERIFIED`: real provider evidence, RPO/RTO restoration, independent assessment and all release gates. |
| R6 | Staging/production/DNS/secrets/provider action or spending | `SEPARATE AUTHORITY REQUIRED`: no permission now or from later mere local scope approval. |

## 11. Owner review checkpoint and next decisions

**Decision count:** explicit owner policy choices through Round 26 preserved in companion cumulative v0.15. This is a synthesized outline, so proposed engineering methods remain subject to final approval. No attempt was made to change previous approved policies silently.

**Conflict audit outcome:** earlier references to a required *Public CMS for the newly requested motion marketing site* are **SUPERSEDED** by the owner's 20 October no-CMS instruction. The older independently approved CMS artifact is preserved unchanged as historical authority. This does **not** cancel the approved need for per-client **website CMS** systems later. No delivery provider or live public integration is validated. The original master archive's full bytes remain independently unverified even though its existence and copied internal authority files have been validated.

**Focus of remaining discovery, without repeated questioning:** precise approved prices (owner one by one), measured/costed common numeric quotas, exact approved two-D1 migration scope and event contracts following actual source inspection, legal-child/retention risk review for target markets, and provider-specific release arrangements. At scope-freeze time present an exact-version bounded work proposal covering features, screens, roles, data flows, threat model, migration lineage, tests, exclusions and remaining later-release items; then request ONE explicit authorization for reversible local implementation. Do not seek that authorization while critical dependencies are still missing.


## Appendix A. Exact 58-row original feature inventory — no silent omissions

This inventory is an **authority/coverage checklist**, not a claim that any module works. All original IDs remain traceable. `REQUIRED` reflects the existing baseline or subsequent owner-approved first-release expansion; `PROPOSED` means the original suggestion has not been explicitly owner-approved; `PARTIAL` identifies a narrower approved concept than the original future extension. Each row requires an independent feature-level test/evidence ID during implementation; this appendix alone does not provide one.

| Original ID | Feature / menu entry | Scope review | Notes |
|---|---|---|---|
| `CORE-01` | Activation & login | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-02` | Profile | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-03` | Security & sessions | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-04` | Home & attention | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-05` | My Digital Roots | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-06` | New Root & onboarding | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-07` | Project progress | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-08` | Previews & approvals | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-09` | Launch & live history | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-10` | Open Website Admin | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-11` | Domains | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-12` | Professional email | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-13` | Service catalogue & entitlements | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-14` | Quotes & billing | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-15` | Renewals & changes | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-16` | Requests & support | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-17` | Notifications | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-18` | Root Health | REQUIRED | Never manufacture green Root Health; stale/unknown indicators required. |
| `CORE-19` | Social profile links | REQUIRED | Manual validated social/profile links; no social API/analytics. Ensure standalone acceptance. |
| `CORE-20` | Privacy/export/closure | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `CORE-21` | Priority campaigns | REQUIRED | Admin-configured campaigns must never outrank actionable operational notices. Explicit test needed. |
| `CORE-22` | Localization & accessibility | REQUIRED | Original mandatory baseline; functional and security acceptance pending. |
| `UX-01` | Workspace favourites / personal home layout | PROPOSED | Not an explicit owner approval; do not silently include as required. |
| `TOOL-01` | CV Studio | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `TOOL-02` | Portfolio Builder | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `TOOL-03` | Digital Card | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `TOOL-04` | QR Studio | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `TOOL-05` | Link Hub | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `TOOL-06` | Achievement Kit | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `TOOL-07` | Career Kit | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `TOOL-08` | Email Signature | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `TOOL-09` | Project Share | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `TOOL-10` | Personal Brand Kit | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `TOOL-11` | Contact Card | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `TOOL-12` | Root Export | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `STU-01` | My Semester | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `STU-02` | Study Planner | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `STU-03` | Exam Countdown | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `STU-04` | Project Desk | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `STU-05` | Study Timer | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `STU-06` | Goals | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `STU-07` | Application Tracker | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `STU-08` | Cover Letter Guide | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `STU-09` | Skills Passport | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `STU-10` | Career Roadmap | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `STU-11` | Learning Log | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `STU-12` | Experience Journal | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `STU-13` | Research Shelf | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `STU-14` | Campus Calendar | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `STU-15` | Student Budget | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `NAV-CAREER-KIT` | Career Kit — Workspace entry | REQUIRED | Owner requires full 12+16 menu coverage; Career Kit shared; not implemented. |
| `ENT-01` | Venture Profile & Brand Brief | REQUIRED | Owner-approved first-release audience extension; not implemented. |
| `ENT-02` | Offer Planner | REQUIRED | Owner-approved first-release audience extension; not implemented. |
| `ENT-03` | Pitch One-Pager | REQUIRED | Owner-approved first-release audience extension; not implemented. |
| `ENT-04` | Launch Planner | REQUIRED | Owner-approved first-release audience extension; not implemented. |
| `BUS-01` | Digital Asset Register | REQUIRED | Owner-approved first-release audience extension; not implemented. |
| `BUS-02` | Marketing / Content Request Briefs | REQUIRED | Owner-approved first-release audience extension; not implemented. |
| `EXT-TEAMS` | Business team seats & delegated roles | PARTIAL | Limited collaborators across authorized account Roots approved; exact enterprise seat billing/delegation not approved. |

## Appendix B. Authority and content-verification boundary

- The full original master ZIP is **confirmed to exist** at `uyounmodel-cloud/idigitalroot:downloads/IDIGITALROOT_CODEX_MASTER_HANDOFF_2026-10-14_v1.1.zip`, Git blob SHA `850baa1cfb3db0d4f15a18f6667b8a2abbce676e` (Git blob hash, **not** the expected ZIP SHA256).
- The October 16 handoff records the expected ZIP SHA256 `f1ea6c341baf3c81afa5b797ed09beb9b1a400325338e8a42ed671c2a5f23b20`. The available GitHub reader confirmed filename/blob identity but did **not** return binary ZIP bytes; independent full-ZIP SHA/CRC/manifest verification is **NOT_RUN / BLOCKED**, rather than PASS.
- Independently verified from the mounted October 16 handoff: ZIP CRC PASS, 74/74 `SHA256SUMS.txt` entries matching, 55/55 original `copiedAuthorityFiles` checksums matching, original original Client/Admin foundation and seven security authorities present. The *historical* report in the bundle claims the October 14 master integrity PASS over 3,417 nested entries, but that historical claim is **not** a new independent run against the full master ZIP.
- This synthesis is not a mathematical proof that every sentence of every chat or the inaccessible full master is perfectly represented; **do not claim perfect** until an exact versioned per-decision/per-feature acceptance matrix, source inspection and independent master-byte check close.

---

**No code, migration, provider, infrastructure, spending, account or deployment authorization is granted by this document.**


## Appendix C. Explicit conflict resolution — active policy versus historical authority

This appendix is **authoritative for this planning draft only**, subject to owner review. References to an original feature or current mock-up do not confer deployment permission.

| Case | Earlier evidence / possible confusion | Later owner decision and active treatment | Release / delivery consequence |
|---|---|---|---|
| PUBLIC-01 | 14-Oct historical public front end was coupled to an approved dedicated Public CMS | 20-Oct **new public motion site** is EN/AR, four audiences, **NO CMS**, with secure request wizard; store/forward lead safely into Admin and notify `visitors@idigitalroot.com`. Original Public CMS remains a separate historical artifact | Do not retrofit/decommission historic CMS, mutate frozen public schema or assume new site deployed; source inspection and separate public-site work approval |
| ROLL-01 | Student-first, Admin→Client sequential roadmap and Business future product | Later owner R1 approved **Admin + Client together** in one full first release and **all four audience packs**, not student-only | Internal staged tests permitted; no student-only substituted final release |
| ARCH-01 | Historical architecture's generic platform D1 implied a central account store | R21–R23 require **two separate D1**, Admin authoritative for staff, commercial/entitlement, Roots, projects, approvals, support; Client for customer identity/guardians/memberships/private tools | New independent migration lineages; versioned authenticated contracts; zero cross-DB atomicity assumption |
| PROMO-01 | Earlier family-independent pack or possible unspecified free service | New paid **annual** website construction includes matching **one audience pack for 12 months**, clock from verified purchase; no construction-time extension | Paid alternate pack switch permitted; price/credit treatment TBD, never unapproved free pack |
| PLAN-01 | Earlier possible monthly/annual website plans | No monthly website-creation plan; **initial annual paid package**, thereafter annual service renewals; monthly/annual **tool packs** remain | Distinguish quote/invoice and no automatic renewals |
| DOM-01 | Domain forwarding or complimentary giveaway may appear in older drafts | Domain and actual hosted mailbox are included **within paid plan** with progressive tier allowances | Real provider verification and future costs required; no placeholders described as delivered |
| PRIV-01 | Broad organization-owner access to student records | Minors 13–17 require guardian management; named organization/root/categories/purpose/expiry, revocable grants; legally required rights prevail | No unrestricted owner access to child data; country-by-country legal release gate |
| RET-01 | Indefinite work retention and no customer discretionary deletion | Preferred product policy only **where lawful**, with compulsory legal access/correction/deletion/guardian requests implemented | Data-deletion propagation and 90-day backup policy must be tested with applicable legal holds |
| FILE-01 | Imported Office documents formerly proposed discard | Original Office import **retained privately** after safe checks, selected authorized origins can join structured Root Export | Not generic vault; quarantined and scanned, download rights enforced |
| SUP-01 | R24 choice letter initially 'images and PDFs' | Owner wrote additional **'images'**; interpreted and confirmed later as **images only**. R25 restricts JPEG/PNG/WebP, 5 MB max, 3/message | No PDFs/GIF/SVG/Office in support; Office imports independently permitted |
| APPR-01 | One overall project approval or owner/collaborator conflation | **Two** hash/version-bound owner decisions (design/content and final), admin ledger; collaborators may preview/comment but cannot approve | Protected local previews are not production release permission |
| TRANS-01 | Automated Root reassignment might copy all histories | Both account owners + staff verify; eligible services/records only; old invoices/support cases preserved with source account, restricted minors/personal never auto-transferred | Manually review domain/mail provider moves; revoke old access; new owner decides unfinished work |
| CMS-01 | 'Open Website Admin' appears in mandatory Client menu | Broker + 2 isolated local consumers are current testing boundary; full **per-client CMS is NOT BUILT** | Show truthful unavailable/dependency state; cannot claim live CMS access |
| OPS-01 | Operations may submit evidence for payment | Billing independently changes Paid/entitlement; Operations may propose allowlisted **nonfinancial** corrections with Super Admin second-person review | Never allow Ops to self-approve or forge Paid, customer consent, identity, Root transfer |
| SUPPORT-01 | Regional/tier matrix was supplied as recommended option | R26 approved it as **provisional engineering baseline, not customer contract** | Staffing, calendars, legal holidays and costs before SLA publication |
| QUOTA-01 | Example storage/cost tiers might be mistaken for agreed values | Only explicitly approved 10/2/25 MB import and support JPEG/PNG/WebP limits are numeric baselines; all other technical quotas **measured/costed PROPOSAL ONLY** | No guessed 'unlimited' claims or fictitious measured runtime tests |
| EMAIL-01 | Production email could be treated as optional because there is a test adapter | First-release transactional email is required; R26 selects provider-independent interface + deterministic LOCAL fake **only for tests**; 22 Oct decision removes email as an MFA factor | Real contact/invitation/notification/lead delivery blocked without provider; authenticated login must use password + WebAuthn and never email fallback |
| SECURITY-01 | Historical public MOTION01 checks marked PASS | Client/Admin new risk/ASVS/test register starts NOT_ASSESSED/NOT_RUN | Original 151 risk titles, 345 ASVS rows, 54 cases need independent evidence; no inherited PASS |

## Appendix D. Decision/feature coverage and preflight proof boundaries

- **Exact explicit decision IDs:** R13-01..R26-04 as enumerated in the accompanying `IDIGITALROOT_DECISION_TRACEABILITY_R13_R26_2026-10-21.csv`; all IDs are present in the archived cumulative `v0.15` source and not silent default choices. Rounds 1–12 are reconstructed as **narrative decision groups** from the preceding user discussion; do not fabricate question IDs, option letters or exact verbatim text where not preserved in the consolidated documents.
- **Feature-level authority:** Every `FEATURE_INVENTORY.csv` ID is reproduced in Appendix A. All 58 IDs require individual acceptance evidence; `UX-01` remains **PROPOSED**, and `EXT-TEAMS` is only partially accepted. The 12 Toolbox + 16 Student Workspace positions share one Career Kit = 27 unique capabilities.
- **Original master binary (superseded warning):** The previous GitHub binary-reader limitation was resolved in the Codex repository workspace. Codex P00 reported full raw original master SHA256/CRC and 99 nested ZIP scans; P00B finished required authority reading; P01 rechecked the raw SHA. These are **Codex-reported evidence**, not a fresh run inside this ChatGPT container. Original source remains unchanged; the eight legacy-fixture metadata/output anomalies remain disclosed.
- **Scope completeness standard:** Internal documentary cross-reference and consistency checks may pass; that means the **draft is consistent with the verified available sources**, not that every unseen file, unspecified commercial number, legal obligation or future product requirement has been independently resolved. Each release and source-work gate stays separate.

## Appendix E. Final owner-review checklist (no repeated discovery questions)

| Gate | Currently accepted | Still needed | Current status |
|---|---|---|---|
| Main product architecture | Both Admin+Client, 4 audiences, roles/screens and 2 D1 authority split | Review exact versioned API and state diagram from inspected code/source | DRAFT |
| Feature list | 58 original inventory rows traced; 27 distinct Student capabilities | Per-feature executable positive/negative acceptance suites | NOT_RUN |
| Commercial | 12 website offers + 4 tool packs; offer structure and clocks | Owner prices one at a time, paid pack switch pricing, measured quotas, tax/provisioning contract | BLOCKED_AFFECTED_SCOPE |
| Original master | Full raw master SHA/CRC/nested scans and required authority reading recorded by Codex P00/P00B/P01 | Repeat pinned checkout integrity on later source-work entry; maintain separate PKG-01 fixture remediation gate | VERIFIED_AS_REPORTED; PKG-01 OPEN |
| Public site | Latest bilingual motion, no-CMS, request wizard and secure lead/email handoff | Inspect actual source and authorize bounded separate public-site implementation | SCOPE_CONFLICT_RESOLVED_DOC_ONLY |
| Security/legal | Original standards, guardian and retention policy stated | Eight-market lawful basis, residency, minors, independent 151/345/54 assessments | BLOCKED_LIVE |
| Provider + operation | Email/domain/mailbox and support/backup architecture | Vendors, credentials/permission approvals, costs, real restore and delivery tests | BLOCKED_LIVE |
| Construction | Documentation-only working specification | Explicit final implementation scope approval and exact preflight source checks | NOT_AUTHORIZED |


## Appendix F. Non-optional read-only master ZIP preflight at the source gate

An execution agent with the repository checked out must run the bundled `IDIGITALROOT_MASTER_ZIP_PREFLIGHT_READ_ONLY.py` against `downloads/IDIGITALROOT_CODEX_MASTER_HANDOFF_2026-10-14_v1.1.zip` using the expected original SHA256 (`f1ea6c341baf3c81afa5b797ed09beb9b1a400325338e8a42ed671c2a5f23b20`). The script checks the entire ZIP's SHA256 plus CRC for nested ZIP members, produces machine-readable PASS/FAIL output and never extracts, executes, writes or deploys anything. **Do not run source changes if the original master file is missing, its hash differs, the nested archive check fails, or its contents reveal an unresolved authority conflict.**

The full original October 14 ZIP preflight **was subsequently executed by Codex P00** with a matching raw SHA and nested ZIP integrity result; P00B and P01 confirmed the master raw SHA. It was **not independently rerun inside this ChatGPT environment**. Do not mislabel the smoke test as original-master verification. The owner is **not** assigned a manual verification chore.


## Appendix G. Codex execution-package status (documentation-only)

This version corrects the stale v0.2 header in the archived v0.3 working draft and adds this pointer; it does not change any original owner policy. `IDIGITALROOT_CODEX_EXECUTION_PREPARATION_v0.1_2026-10-21.zip` is a **future execution-instruction proposal**, not local-implementation authority. Its step prompts are valid only after the preflight, scope, commercial/quota and isolated-migration gates explicitly pass. The original October 14 master ZIP is not present in this package and must not be represented as verified. An autonomous Codex task must stop before altering files if a required source is missing, approval is not on record, or the current repository differs from the attested checkpoint. The latest public no-CMS marketing website needs its own bounded source task and does not silently authorize modifying a previously approved legacy CMS.
