# iDigitalRoot — Owner Authentication Decision and Security Reconciliation

**AUTH-2026-10-22-01 · 22 October 2026 · OWNER DECIDED · DOCUMENTATION-ONLY · NO IMPLEMENTATION APPROVAL**

## 1. Exact owner decision

> Approve password + WebAuthn MFA for all users, independent backup authenticators and supervised recovery; email for contact verification and notifications only.

This decision **supersedes only the previous routine password + email-code MFA mechanism** recorded in discovery R2/R3 and repeated through earlier specs. All other Rounds 1–26 decisions remain operative unless directly contradicted by this authentication change. Old documents are immutable historical evidence; their login-email-OTP text is no longer active implementation authority.

## 2. Precise security interpretation

| Requirement | Governing status | Contract / constraint |
|---|---|---|
| Normal login for staff and customers | **DECIDED** | Password AND a successfully validated WebAuthn factor; no email-based auth factor |
| Owners, collaborators, guardians, all five staff roles | **DECIDED** | No separate low-security login class; enforce account/Root-specific authorization beyond MFA |
| High-risk operations | **DECIDED** (strong step-up); detail **PROPOSED** | Recheck phishing-resistant WebAuthn/security key on protected actions, with fresh authorization binding |
| Independent backup factors | **DECIDED** (availability); enrollment protocol **TBD** | Support separate pre-registered authenticators; no email-only bypass |
| Lost-all-factor supervised recovery | **DECIDED** (policy); workflow **TBD** | Independent identity verification, multiple authorized approvers for privileged cases, restricted reinstatement, rate limits, security notice, revocation and audit |
| Email | **DECIDED** | Address/contact verification, account invitations and security/transactional/support notifications; never login OTP, magic-link MFA, recovery factor, or privileged session grant |
| Admin vs Client authentication authority | **PRESERVED DECIDED** | Admin D1 owns staff identity/strong factors; Client D1 owns customer/guardian/member identity/factors; never duplicate credentials across |
| Legacy Public CMS / 2 local SSO consumers | **PRESERVED BOUNDARY** | Preserve historical CMS WebAuthn/Access contract independently; no fake live CMS integration |
| Login provider outage | **ENGINEERING CONTRACT** | Email outage may block email-delivered invitations/notices but not permit MFA downgrade; WebAuthn outage fails closed |
| ASVS security acceptance | **NOT_ASSESSED** | Architecture must be reviewed and exercised against 345-row ASVS register/151 risks/54 tests as applicable; no inherited PASS |

## 3. Original authority evidence

- Original verified October 16 handoff: `SECURITY/CLIENT_PANEL_ASVS_5_0_0_REGISTER.csv`, row `req_id=V6.3.6`, `versioned_id=v5.0.0-6.3.6`, `L=3`: **“Verify that email is not used as either a single-factor or multi-factor authentication mechanism.”** Its status remains `NOT_ASSESSED_CLIENT_PANEL`. The unchanged master security baseline, threat model, and acceptance gates remain binding.
- Codex P00B `SCOPE_CONFLICT_AND_SECURITY_GATES.md`, section *Email authentication / ASVS gate*: explicitly identified the older email-code MFA choice as an unresolved owner/security conflict.
- Codex P01 `SCOPE_FREEZE_REVIEW.md`, as quoted in the uploaded P01 review excerpt (A. one-page explanation): identified authentication as the principal remaining owner policy choice. The accessible P01 pasted text cuts off during section D; this addendum **does not claim to have reviewed unseen section H or L**. A later P01 reconciliation may use the complete report from the same Codex workspace.
- User's direct 22 October decision governs new Admin/Client authentication. It is an owner product-policy decision, **not** a completed threat assessment or source permission.

## 4. Proposed engineering checks — NOT implementation

1. Separate staff/client WebAuthn RP ID/origin/credential trust boundaries; signed assertions and single-use server challenges; user-verification and CSRF/session defenses.
2. Review invitation onboarding without introducing email-as-MFA: contact proof alone cannot activate a logged-in session until password + WebAuthn enrollment and verification are complete.
3. Factor registration/remove/replace requires fresh authentication, step-up and owner notice; backup authenticators are genuinely independently registered rather than duplicate OTP via email.
4. Owner-only quote and two immutable project approvals, destination/origin owner Root transfer consent, Operations/Super Admin maker-checker, guardian grants and support access require action-bound identity and permission checks.
5. Recovery must not let an email inbox, Helpdesk agent or guardian-by-self-assertion issue an authenticated replacement factor or access token. Lost-all-factor flows are permission restricted with a documented independent review and audit.
6. Test attempted email-OTP fallback, WebAuthn challenge replay, origin mismatch, credential substitution, revoked member, account switch, multiple tabs, pending entitlement, lost-factor recovery, and privilege escalation. Keep test states `NOT_RUN` until executed.

## 5. Updated gate classification

- **CLOSED — owner security choice:** password + WebAuthn for all new Admin/Client users. The previous email-factor policy conflict is resolved as a **requirements decision**.
- **OPEN — technical auth architecture:** detailed WebAuthn enrollment, RP/origin, secure authenticator lifecycle, step-up, supervised recovery and admin/client API contracts.
- **OPEN — security proof:** ASVS applicability/evidence, risk tests, independent QA, operational browser/support compatibility.
- **OPEN — scope freeze:** approved 12 annual website plan prices/renewals; four pack prices/term-switch details; measured/costed non-file quotas, two independent D1 lineage specs; any specific bounded source work orders.
- **OPEN — external release:** country-specific legal/minor/privacy/retention/residency, actual provider agreements and costs, local+provider QA, restore evidence, spend/deploy authority.
- **OPEN — historical source fixture acceptance:** seven missing generated backend test outputs and one historical FE fixture tsconfig mismatch remain covered by distinct PKG-01 gate, not waived by this auth decision.

## 6. Non-authorization

`IMPLEMENTATION_SCOPE_APPROVAL = NOT_GIVEN`

`PERMISSION_TO_MODIFY_SOURCE = NO`

`PERMISSION_TO_CREATE_MIGRATIONS = NO`

`PERMISSION_TO_PROVISION_OR_DEPLOY = NO`

This addendum and updated scope change documentation only. No repo, original ZIP, manifests, registered credentials, runtime configuration, external provider or production data was modified.
