# IDR-P01A — Scope-freeze decision sheet

22 October 2026. **OWNER SCOPE-FREEZE REVIEW PENDING. Overall scope NOT_APPROVED. Implementation, schema and deployment authority NOT_GIVEN.** Authentication mechanism AUTH-2026-10-22-01 is DECIDED; this does not freeze or approve the remaining proposal.

## 1. Decision continuity and authority

Use the direct P01A instruction for present permissions. Use AUTH-2026-10-22-01 for its narrow mechanism supersession, the attached v0.5 draft/addendum for current documentary reconciliation, unchanged P01 for scope/traceability and P00/P00B for exact source/authority provenance. Embedded future-work prompts are references, not commands. Do not rewrite P01 H/L as though policy approval existed when authored. The historical H2 comparison and L authentication-choice request are superseded; no need to choose email or a waiver now.

Recorded decision: **password + WebAuthn MFA for all new staff/customer/owner/collaborator/guardian identities; independent backup authenticators and supervised recovery; email contact/notifications only.** No email login, factor fallback or lost-factor shortcut. Technical enrollment/recovery/assurance details remain proposed/TBD and all security proof NOT_ASSESSED/NOT_RUN.

The following settled requirements are retained without new questions:

| Settled boundary | Preserved requirement / evidence limit |
|---|---|
| Delivery/product boundary | Distinct new EN/AR, motion-rich, four-audience public company site with NO CMS; secure request wizard → authenticated Admin lead and durable visitors@idigitalroot.com notice intent. One complete intended local Admin+Client four-pack review. Preserve historical Public CMS/MOTION and later isolated independent client CMS/factory. New solution NOT_BUILT / NOT_RUN. |
| Feature scope | 58 original feature IDs: 56 REQUIRED, UX-01 PROPOSED, EXT-TEAMS PARTIAL limited collaborators. Full Student 12 Toolbox +16 Workspace positions =27 distinct tools through one Career Kit. Professional reuse, four Entrepreneur additions, two Business additions. No reduced student replacement. |
| Roles/navigation | Five individual staff bundles: Super Admin, Operations Manager, Project/Production Staff, Billing Staff, Support Staff. Eleven Client areas (Home, Roots, Projects, Tools, Domains, Email, Services, Billing, Renewals, Support, Account) plus separate Inbox. Multi-account/Root context is not authority. |
| Data/entitlement | Two physically separate NEW Admin/Client D1 authorities; schema/recovery still unapproved. Admin owns staff/commercial/Paid/Root/project/approval/support truth; Client owns customer/membership/guardian/private tool truth. Private Worker-controlled R2; no browser credentials; current Admin grant required, fail closed; no cross-D1 atomicity claim. |
| Purchase/terms | 12 annual website packages; initial creation plus real domain and hosted mailbox; matching pack included for12months. Both clocks start verified purchase, no construction-delay extension. Four tool packs monthly/annual prepaid; one active pack/Root; paid alternate-pack switching, no automatic renewal. Tool access only with genuinely Live Root + active website plan + valid Admin pack. |
| Finance/approval | Owner accepts exact versioned quote/terms. Operations only Pending payment evidence; independent Billing verifies Paid; staff Root creation once after verified purchase. Two immutable exact-version owner-only project approvals (design/content then final); collaborators may view/comment if granted. No approval authorizes deployment. |
| Transfer/correction | Both owners plus staff consent to exact eligible Root-transfer manifest; original invoices/support history stay at origin; retain immutable approvals and destination owner unfinished-work decision. Revoke old grants/SSO/shares/previews/jobs. Operations proposes allowlisted nonfinancial correction; distinct Super Admin checks. No Paid/consent/IAM/ownership rewrite. |
| Privacy/support | Minor13–17 guardian-managed scope; named organization/Root/category/purpose/expiry and revocation, lawful adult owner-read only. Temporary named customer-consented supervised support; no general impersonation. Retention preference yields to mandatory rights/holds/deletion and backup propagation; no unlimited guardian or organization-owner read. |
| Fixed intake/share/time baselines | DOCX/XLSX/PPTX10MB each; CSV/ICS2MB; batch25MB. Support JPEG/PNG/WebP only5MB each/max3 per message; no PDF/SVG/GIF/Office support upload. Originals private with explicit download/export grants. Shares default30days/max90days. Study Timer credible inactivity pause10minutes, no fabricated closed-tab time; corrections retained. MB convention and parser/resource budgets still TBD. |
| Calendar/output/recovery | Coordinated course/exam/study/campus calendar and validated ICS; per-currency Budget without invented FX; opportunity-specific Career Kit immutable PDF/DOCX snapshot.90-day platform recovery copies/monthly restore exercises; RPO≤24h/RTO≤48h are unverified objectives. Provisional regional support model is not a customer SLA. |
| Frozen legacy/runtime | Cloudflare Workers/D1/private R2 and owner Windows+Ubuntu/WSL retained. Public Core0001–0016 and Analytics0001–0002 unchanged, no public0017. Historical public v4.3/CMS UXv4.1/connected CMSv1.5.3 approvals are version-specific; original FEv1.1.1 and MOTION remain candidates; no inherited Admin/Client acceptance. |

## 2. Remaining true owner decisions — no repeated discovery

| Decision still needed | Engineering preparation / owner input | Gate |
|---|---|---|
| Actual commercial amounts and inclusions | Owner enters/approves each initial annual and annual renewal price, each pack monthly/annual price, exact deliverables/domain/mail allowances, currency/tax/FX and offer conditions. Engineering supplies dated costs and versioned terms; nothing numeric is invented here. | PRICE-01 / R10-05 before dependent local construction; live supplier/legal details also release-gated. |
| Material term/switch/refund policies | Owner approves paid-switch amount, remaining complimentary credit/term alignment, proration, refunds/cancellation/downgrade/grace, renewal and failed settlement handling. Keep decided no-free-switch/no-auto-renew/no-delay-extension/one-pack rules. | Before affected commercial state-transition construction. |
| Meaningful common quotas after evidence | Engineering proposes measured/costed Root/item/storage/file/export/share/job/mail/concurrency/retention ceilings and safe parser/scan budgets; owner approves concrete price/capacity tradeoffs. Do not ask owner to invent technical numbers or loosen fixed ceilings. | QUOTA-01 NOT_MEASURED; no measurement execution authorized now; dependent local modules blocked. |
| Material privacy/assurance UX tradeoff if design reveals one | No new authentication-method choice is pending. Engineering must design backup independence, recovery proofing/approvers and accessible WebAuthn; bring only material cost/availability/privacy tradeoffs, not routine implementation parameters. No weaker-factor option is assumed. | AUTH design review before affected IAM construction; independent assessment still required. |
| Exact bounded future source and separate schema work orders | After relevant prerequisites close, owner may separately authorize exact document version/hash, work order, path list and each Admin/Client lineage/recovery task. Scope-document approval alone is not instruction to create source or SQL. | L2 / DATA-01/02: NOT_APPROVED; Stage02 NOT_STARTED. |
| Actual vendors/market/support commitments | At affected release gates choose reviewed providers/budgets/allowances and legally reviewed supported-market, guardian, retention, residency and support terms; approve actual deliverability/restore/security/QA evidence and release actions separately. | BLOCKED_RELEASE; if a contract changes a local module, resolve that dependency earlier. No current sending, provider setup, spending or deployment authority. |

Engineering work still owed: formal G-RACE semantics, exact operation/permission/envelope contracts, challenge/session/step-up/recovery parameters, SSO transport/TTL/key policy, schemas/constraints/recovery, supported output/parser/scanner design, EN/AR/a11y, complete risk-to-control/test mapping. These are not renewed Rounds1–26 or a request for owner cryptographic design. No method, provider, numeric quota or exception has been silently selected by this sheet.

## 3. Website package price-entry sheet

All amount/allowance/approval cells below are deliberately blank. Blank means TBD / NOT_APPROVED, never zero, free, unlimited or an accepted quote. Monetary base is the previously decided USD model with reviewed versioned country quotations; no FX/tax rate is supplied. Initial and renewal are **annual website service**, not monthly creation. Initial includes creation, real domain and hosted mailbox plus matching pack for12months; verified purchase starts both clocks.

| Website package | Initial annual owner price | Annual renewal owner price | Domain/mail/tier deliverables & terms version | Owner approval/reference |
|---|---|---|---|---|
| Student — Entry | ________ | ________ | ________ | ________ |
| Student — Growth | ________ | ________ | ________ | ________ |
| Student — Premium | ________ | ________ | ________ | ________ |
| Professional — Entry | ________ | ________ | ________ | ________ |
| Professional — Growth | ________ | ________ | ________ | ________ |
| Professional — Premium | ________ | ________ | ________ | ________ |
| Entrepreneur — Entry | ________ | ________ | ________ | ________ |
| Entrepreneur — Growth | ________ | ________ | ________ | ________ |
| Entrepreneur — Premium | ________ | ________ | ________ | ________ |
| Business/Organization — Entry | ________ | ________ | ________ | ________ |
| Business/Organization — Growth | ________ | ________ | ________ | ________ |
| Business/Organization — Premium | ________ | ________ | ________ | ________ |

## 4. Four tool-pack price-entry sheet

Monthly and annual amounts are prepaid tool-pack prices, separate from the annual website-service structure. Record exact switch/credit/term and renewal policy; no second active pack, free switch or automatic charge is assumed.

| Audience tool pack | Monthly prepaid owner price | Annual prepaid owner price | Paid-switch / credit / proration / refund terms version | Owner approval/reference |
|---|---|---|---|---|
| Student | ________ | ________ | ________ | ________ |
| Professional | ________ | ________ | ________ | ________ |
| Entrepreneur | ________ | ________ | ________ | ________ |
| Business | ________ | ________ | ________ | ________ |

Unpriced service/tier inclusions, add-ons, domains/mailbox provisioning/renewal, care, tax/currency rules, legal contract identity and cancellation/grace conditions need exact versioned approval at their dependency gates. A locally invented price fixture is not approved commercial truth.

## 5. Engineering quota/cost method — proposed, NOT_MEASURED

This section defines a future measurement method, not a benchmark run or quota recommendation. No tool, install, build, resource or paid provider is invoked now. Common technical ceilings stay meaningful and costed; no tier-specific exceptions or unlimited allowance is invented.

| Candidate cost/limit | Proposed future bounded method | Recorded metrics / decision boundary |
|---|---|---|
| Identity/WebAuthn/recovery | Synthetic staff/owner/collaborator/minor/guardian scenarios across supported accessible devices; registration/assertion/session-state sizes, concurrent challenges and abuse, recovery reviewer load and notifications; include independent failure domains. | Latency/CPU/memory/state reads/writes per ceremony, authenticator/session count proposal, operational review effort; RP/UV/backup/recovery security proof. No credentials generated now. |
| D1 / Root / memberships / tool records | Versioned synthetic workload with multiple accounts/Roots, item revisions, history, authorization reads, outbox/inbox/dedupe and forced partial-state scenarios. Include grant verification on every protected action. | Rows/bytes/read/write cost, concurrency and lock/conflict behavior, retention/backup growth. No stale-grant cache to save cost; exact limits TBD. |
| R2 originals, media, previews and outputs | Representative permitted types and long histories, lifecycle/retention classes, tenant separation and selected-original exports; account for temporary/quarantine/orphan objects. | Stored GiB-month, object operations/transfer, copies and reclaim delay; safe count/size/retention proposal. No storage or file-count number has been measured. |
| Import/scan/parser | Bounded synthetic clean and hostile DOCX/XLSX/PPTX, CSV/ICS and image corpus; measure compressed vs expanded size, rows/assets, CPU/wall/memory, quarantine/scan failure and egress denial. | Keep10/2/25MB and support5MB/max3 ceilings. Define decimal/binary bytes, expanded limits and safe worker isolation before execution; fail closed on unknown/malformed/timeout. No scanner/vendor selected. |
| Export/document/share/calendar/timer | Representative Career Kit PDF/DOCX, QR/interoperability, Budget precision, ICS/timezones, concurrent exports/shares/revokes, timer two-tab/offline/clock behavior and abort/delivery authorization. | Peak memory/CPU, output size, queue depth, jobs/Root/time budget, signed-access lifetime and operation costs; preserve share30/90days and timer10minutes; quotas not inferred from these policies. |
| Notifications/support/provider adapters | Future deterministic LOCAL driver may measure dedupe/retry/dead-letter/volume and Pending outcomes; separately review actual approved provider prices, abuse caps and human support capacity. | Per-event/storage/retry costs and staffing/country-calendar assumptions. Local fake delivery is not email Sent or live provider proof; no sending now. |
| Backup/restore/audit/revocation | Future isolated synthetic dual-D1 + R2/config/audit recovery exercise; coherent boundary, key absence, deleted/revoked identity replay, outbox gaps and independent witness. | 90-day copy capacity and monthly exercise cost; measured RPO/RTO compared with objectives≤24h/≤48h, not promised. Actual restore NOT_RUN. |

For a separately authorized measurement: pin source/locks/runtime, corpus hashes, exact command/config, synthetic data path, resource caps, UTC/date/timezone, underlying exit code and raw sanitized artifacts; distinguish successful, failed, skipped, unavailable and unrun cases. Include normal, peak/concurrent, hostile expansion, dependency-outage/replay/race and cancellation/delivery observations. Determine supported capacity from observed safe envelopes and independently reviewed abuse headroom; do not fabricate percentile/throughput samples.

Proposed cost worksheet: sum (measured D1 reads/writes/storage × dated approved unit rates) + (R2 stored/copy/quarantine/output bytes and operations × rates) + Worker/parser/scan/job compute + notification vendor fees + registrar/hosted mailbox costs + independently costed backup/restore/logging/support labor, then explicit contingency assumptions. Preserve units, billing region, taxes/FX source, dated vendor contract, free-tier assumptions and actual inclusions. No rates, estimate totals, sample quotas or staffing promises are supplied; provider facts have not been fetched. Present evidence, uncertainty and security floor to owner for versioned approval before dependent construction.

## 6. Gate separation and exact stopping state

| Gate class | State | Required next evidence / separate authority |
|---|---|---|
| Documentary entry/master/reading | Reverified preservation; prior required authority reading retained with P00B limits | Exact checkout/master/P01 source hashes verified; do not reopen obsolete missing-master issue. No source permission follows. |
| AUTH owner policy | DECIDED AUTH-2026-10-22-01 | No fresh authentication-choice question or email-factor waiver. Technical design/compatibility/security mapping remains NOT_ASSESSED / NOT_RUN. |
| Pre-local scope and IAM/contracts | NOT_APPROVED / affected work BLOCKED_LOCAL | Review P01A plus complete scope, assurance/recovery and G-RACE/SSO/output/state contracts. Receive a later bounded source work order; no Stage02 by receipt/continue. |
| Pre-local prices/quotas R10-05 | TBD / NOT_MEASURED; dependent local modules BLOCKED_LOCAL | Owner approves actual price/term schedule and measured/costed ceilings; separate permission to execute measurement needed. |
| Separate Admin and Client schemas | DATA-01/02 NOT_APPROVED | Review each independent lineage, exact files/entities/keys/constraints/recovery and synthetic target. Explicit separate creation approval before migration files; no public0017. |
| Distinct new public website | WO-PUBLIC-NEW NOT_APPROVED | Separate source/content/lead/notice contract work order; no CMS retrofit or legacy deletion. |
| Legacy PKG-01 | OPEN; affected nested fixture acceptance FAIL | Seven generated dist entries absent from nested integrity declarations; original FE tsconfig mismatch historical relative to current matching MOTION. Separate successor packaging/reproduction/repair authority; no manifest repair or harmlessness claim. Does not block this documentary review or automatically require importing the fixture. |
| Future local acceptance | NOT_BUILT / NOT_RUN / NOT_ASSESSED | Actual authorized Worker/two-D1/privateR2, all required feature/EN/AR/browser/output/failure tests, independent151risk/345ASVS/54case evidence and owner Windows/WSL reproduction. No inherited public PASS. |
| Later live/provider/legal/operations release | BLOCKED_RELEASE / NOT_VERIFIED | Approved real mail/domain/mailbox/scan/payment methods, eight-market legal/guardian/retention/residency, support capacity/calendar/SLA, actual security/QA/restore/deletion/recovery evidence; provider/budget credentials handled only under separate authorization. |
| Staging/production/spend/provider mutation | NOT_AUTHORIZED | Exact environment/source/actions/budget/release permission later; connection or document approval is not deployment authority. |

## 7. Exact R13–R26 continuity ledger

All77 precise original records are retained below with their unchanged source pointers. Read R13 inclusion/selection through its recorded R14/R15 qualifications and all other original precedence in P01 annex2; this table neither resets history nor substitutes topic labels for the complete decision bodies. R16-02/R17-05 independent backup/supervised reset remain active; R17-06/R26-03 communications remain active. Only older routine email-code authentication text, including its R1–R12 narrative provenance, is superseded by AUTH-2026-10-22-01. Every original implementation/evidence state stays NOT_BUILT / NOT_TESTED.

| Exact decision ID | Preserved topic | Unchanged commercial v0.15 source pointer | Current documentary treatment |
|---|---|---|---|
| R13-01 | First-year tool-pack inclusion | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L36 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R13-02 | Tier differences: complexity and managed care | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L37 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R13-03 | Progressive domain/mail services | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L38 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R13-04 | Pack selection independent of audience | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L39 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R13-05 | Common tier technical quotas | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L40 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R13-06 | Research-based pricing approach | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L41 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R14-01 | Matching year-one pack included with paid package | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L21 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R14-02 | Initial build included in package | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L20 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R14-03 | Annual website creation, not monthly | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L20 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R14-04 | Real tier-included domain and hosted email | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L22 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R14-05 | Owner sets price values individually later | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L41 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R15-01 | Included pack must match website family | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L21 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R15-02 | Promotional year starts at verified purchase | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L21 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R15-03 | Paid pack switch allowed during promo | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L21 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R15-04 | Year-two website service renewal | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L64 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R15-05 | Registered domain and hosted mailbox | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L22 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R15-06 | Annual paid website clock starts at verified purchase | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L25 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R16-01 | No construction delay extension | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L25 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R16-02 | Independent backup authenticator and supervised recovery | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L157 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R16-03 | Verified regional processing, no false residency guarantee | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L159 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R16-04 | RPO 24h and RTO 48h goals | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L161 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R16-05 | Business-hours support | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L163 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R17-01 | Different regional support calendars | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L163 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R17-02 | Tier-differentiated support targets | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L174 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R17-03 | Backup all platform-owned state | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L161 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R17-04 | 90-day copies and monthly restore tests | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L176 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R17-05 | Pre-registered authenticators and supervised reset | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L157 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R17-06 | Portal inbox plus transactional email | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L178 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R18-01 | Unified Student calendar | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L215 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R18-02 | Durable Study Timer recovery | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L216 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R18-03 | Currency-specific Student Budget | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L217 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R18-04 | Retain original Office imports | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L218 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R18-05 | Guardian category-based revocable grants | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L219 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R18-06 | Separate design/content and final owner approvals | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L220 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R19-01 | Automatic idle pause | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L251 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R19-02 | Career Kit opportunity-specific snapshot | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L252 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R19-03 | Private Portfolio, later CMS integration | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L253 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R19-04 | Structured Research Shelf, no generic vault | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L254 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R19-05 | Narrow download rights for retained Office originals | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L255 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R19-06 | Exactly two owner project approvals | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L256 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R20-01 | Study Timer idle threshold: 10 minutes | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L292 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R20-02 | Student session corrections with history | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L293 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R20-03 | Complete Career Kit application package | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L294 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R20-04 | Shares default 30 days, max 90 | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L295 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R20-05 | Root Export selected eligible originals | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L296 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R20-06 | 10MB Office, 2MB CSV/ICS, 25MB batch | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L109 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R21-01 | Separate Admin and Client D1 | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L317 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R21-02 | Secure public lead handoff | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L318 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R21-03 | Staff creates Root only after verified purchase | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L319 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R21-04 | Complete threaded support | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L320 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R21-05 | Controlled cross-account Root transfer | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L321 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R21-06 | Versioned protected project preview | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L322 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R22-01 | Admin is Root/project authority | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L385 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R22-02 | Client customer IAM, Admin staff IAM | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L386 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R22-03 | Durable events and Pending/fail-closed states | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L387 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R22-04 | Admin owns support thread | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L388 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R22-05 | Transfer eligible Root-owned services and work | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L389 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R22-06 | Protected local previews | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L390 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R23-01 | Admin owns paid entitlements | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L404 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R23-02 | Admin owns exact-version approval ledger | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L405 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R23-03 | Both owners plus staff approve transfer | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L472 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R23-04 | Owner and authorized collaborator preview read | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L473 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R23-05 | Operations-led reconciliation | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L474 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R24-01 | Fail closed if Admin entitlement cannot be verified | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L543 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R24-02 | Transfer eligible remaining services; original invoices stay | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L544 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R24-03 | Preserve approval history; revoke old access; destination owner unfinished work | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L545 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R24-04 | Support images only (owner clarified) | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L546 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R24-05 | Two-person controlled nonfinancial Operations corrections | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L547 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R25-01 | JPEG/PNG/WebP support, 5MB each max 3 per message | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L603 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R25-02 | Operations proposes, Super Admin reviews | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L604 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R25-03 | Historical support cases stay with origin account | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L605 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R25-04 | Manual provider review for domain/mail transfer | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L606 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R25-05 | Prepare 8-country provisional support matrix | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L607 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R26-01 | Regional support proposal provisional only | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L699 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R26-02 | Measured and costed technical quota proposals | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L700 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R26-03 | Provider-independent email interface plus deterministic local adapter | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L701 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |
| R26-04 | Legally mandatory data rights; no discretionary deletion where lawful | IDIGITALROOT_COMMERCIAL_SPEC_DISCOVERY_DRAFT_v0.15_2026-10-21.md:L702 | PRESERVED; apply AUTH-2026-10-22-01 only to contradictory routine email-factor mechanism |

R1–R12 remain their documented narrative groups: complete combined four-pack delivery; owner-only approvals and individual staff/collaborator/multi-account rights; Live+website+pack gate and manual Billing; guardian/privacy/retention/support safeguards; mandatory MFA now with its expressly replaced mechanism; price/limit prerequisite R10-05. No question IDs, option letters or verbatim transcript are fabricated. Full original narratives and qualifiers remain in commercial v0.15 and P01 annex2, unchanged.

## 8. Review record — no implementation approval requested or implied

Authentication decision: **AUTH-2026-10-22-01 RECORDED AS GIVEN**; not a blank choice to ask again.

Overall scope/version/hash reviewed: ____________________  
Commercial schedule and material terms approved version/reference, or pending: ____________________  
Measured/costed quota proposal approved version/reference, or pending: ____________________  
Material requested amendments: ____________________  
Owner name/date/reference for scope-document review only: ____________________

These blank fields record no approval. Future source work order and independent Admin/Client schema authorization are separate later instructions; no source paths are approved here. Next action is owner scope-freeze review of the reconciled documents and remaining genuine decisions at their gates. No Stage02 or work order has started.

PERMISSION_TO_MODIFY_SOURCE=NO
IMPLEMENTATION_SCOPE_APPROVAL=NOT_GIVEN
NEXT_STAGE=OWNER_SCOPE_FREEZE_REVIEW_PENDING
