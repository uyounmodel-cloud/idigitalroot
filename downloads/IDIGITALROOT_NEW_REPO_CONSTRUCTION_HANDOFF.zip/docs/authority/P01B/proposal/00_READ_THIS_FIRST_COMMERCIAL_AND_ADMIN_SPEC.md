# iDigitalRoot — P01B Commercial Catalogue, Editable Pricing & Technical-Limit Proposal

**22 October 2026 · Documentation-only engineering proposal · NOT OWNER-APPROVED · NO CODE/MIGRATION/PROVIDER/DEPLOYMENT AUTHORITY**

## 0. New owner clarification / immediate scope correction

The owner has explicitly clarified: **all selling prices are meant to be editable through iDigitalRoot's Staff Admin panel at any time**. This resolves the unnecessary process assumption that *specific hard-coded dollar prices must be chosen before building the catalogue and pricing-management infrastructure*. It **does not** erase the earlier requirement that a quoted/accepted real offer has an approved non-null price and terms; no invoice, Paid status or Root may be created from draft/null values. It does not grant source implementation permission. Owner-controlled editable pricing is a **required capability of the future Admin product**.

Therefore split gates:
- `PRICE-ENGINEERING`: a versioned catalogue, price editor, quote engine, entitlement clocks and safe null-state logic **can be scoped/designed/implemented under a future separate exact-path approval even if customer selling prices are TBD**.
- `PRICE-COMMERCIAL-PUBLISH`: an actual public offer, owner quote, paid switch or renewal cannot be transacted until its approved site/pack price, currency/tax/region, contents, supplier eligibility and effective terms exist in a **published immutable price-book version**. `null` is not zero.
- `COST/QUOTA`: suggested ceilings and capacity tests require evidence/approval before affected heavy-workload features and promises are enabled. A pricing UI must not bypass technical hard ceilings or ASVS/guardian safeguards.

**Source precedence:** owner's latest clarification supersedes only the inference that fixed monetary amounts must be filled before code for the Admin editor can begin. The long-standing requirement for staff-configurable versioned approved commercial terms and independently verified payment remains unchanged. This is a catalogue proposal; specific page counts, languages, mailboxes, build hours, care hours and site inclusions are NOT a new owner decision.

## 1. Owner-decided invariants (do not change)

- Four families Student, Professional, Entrepreneur, Business/Organization, each in Entry, Growth, Premium => **12 annual website plans**; first paid year includes site creation once, a real eligible registered domain and real hosted mailbox allowances; later annual renewal covers ongoing service (no second site creation). Growth/Premium extend website complexity/managed-care rather than creating different hard technical quotas.
- Four separate audience tool packs, no tools-only account. Matching pack included for first 12 months from **Billing-verified purchase**; construction delay **does not extend** that entitlement. Actual tool use also needs Root `LIVE` and active website + pack entitlement. One active audience pack per Root, switching paid/verified; inactive old workspace history retained private/inaccessible; website/pack independently expire. No auto charge/renewal; manual quoted renewal.
- Account owner approves quote/terms; Operations may record Pending money evidence, **Billing independently verifies Paid**; authorized staff creates Root only afterward. No site preview or design approval authorizes deployment. Accepted quotes, existing invoices and finance audit remain immutable; price edits apply prospectively.
- Client Admin data authority: separate new Admin D1 authoritative for plan versions, prices, quotes, payments, approved entitlements, Roots, support. Client D1 authoritative for customer identity, membership, guardian and private workspaces. Private R2 by scoped Worker. Frozen legacy public Core 0001–0016 / Analytics 0001–0002 never modified by this proposal.
- Staff and customers use password **plus WebAuthn MFA**; email is verification and notices, not sign-in factor. Super Admin commercial price changes need fresh step-up; no customer self-creation and no browser-defined prices.
- Distinct new public EN/AR corporate site **NO CMS**, secure lead wizard → authenticated Admin qualification + notification to `visitors@idigitalroot.com`; preserved old Public CMS and later independent client website CMSs are separate boundaries. Existing CMS not quietly substituted for future customer websites.

## 2. Concrete website tier specification — engineering proposal, not approved offer

All tiers use the same common private-workspace technical resource candidate ceilings (section 5), security controls, data rights, audit, and all features of the *matching audience pack* during its entitled period. The following are **business website deliverable ceilings** and **planning estimates**, not tested Worker/D1 limits, nor a promise of live customer CMS today.

| Proposed inclusion | Entry | Growth | Premium |
|---|---:|---:|---:|
| Informational content pages within contracted site | up to 5 | up to 10 | up to 20 |
| Website languages at initial build | 1 | up to 2 | up to 2 |
| Real hosted mailbox accounts included | 1 | 2 | 3 |
| Eligible standard domain registrations/year | 1 | 1 | 1 |
| Design revision cycles in initial delivery | 1 | 2 | 3 |
| Monthly managed-care labor budget **planning proposal** | 0.5 h | 1 h | 2 h |
| Initial site creation included | Yes | Yes | Yes |
| Matching audience pack first 12 months | Yes | Yes | Yes |
| Provisional first human response, Critical | 4 business h | 2 business h | 1 business h |
| Provisional first human response, High | 8 business h | 4 business h | 2 business h |
| Provisional first human response, Normal | 16 business h | 8 business h | 4 business h |
| Provisional first human response, Low | 32 business h | 16 business h | 8 business h |

**Interpretation & caveats:** (i) page = intentionally published informational route/content item at handoff, not private tool screen; duplication/translation semantics must be specified in versioned quote, (ii) website languages are not the Client/Admin interface EN/AR requirement, which remains independent, (iii) no unreviewed ecommerce, appointment booking, transactional payment, arbitrary CMS plugin, AI generation, large integrations or industry regulatory claims included automatically; such needs become scoped additional services, (iv) real domain TLD eligibility/pricing and real mailbox vendor must be checked before offer publication, (v) site CMS/factory integration is a later delivery dependency, so these are **catalogue definitions**, not built products, (vi) care excludes unlimited redesign/content and 24/7 on-call, (vii) the response table is the previously discussed **provisional** business-hour-only baseline, not a committed SLA.

### Market-aware service calendars (provisional, not publishable commitments)

- Lebanon, UAE: **Mon–Fri 09:00–17:00** local; Iraq, Bahrain, Kuwait, Oman, Qatar, Saudi Arabia: **Sun–Thu 09:00–17:00** local. Holiday calendars, staff coverage, DST and escalation staffing require verification; no 24/7 or guaranteed resolution time.

## 3. The complete 12-plan catalogue

Each row is an actual **proposed selectable draft in Admin**, initialized unpublished with `initial_price_usd=null` and `annual_renewal_price_usd=null`. Suggested page concepts are not claims that customer CMS currently exists, nor a condition that every page must be created regardless of customer needs.

| Catalogue code | Website deliverable focus | Preliminary build-hour estimate (NOT MEASURED) |
|---|---|---:|
| `WEB_STUDENT_ENTRY` | Credible first educational/personal presence with a focused portfolio. Example content: Home / introduction, About & educational background, Skills / achievements. | 6 h |
| `WEB_STUDENT_GROWTH` | Richer evidence, structured projects and bilingual-ready personal profile. Example content: Home, About & education, Portfolio index. | 12 h |
| `WEB_STUDENT_PREMIUM` | Advanced portfolio/case-study hierarchy, polished editorial/motion treatment and complex structured content. Example content: Advanced personal identity home, Education & qualifications, Portfolio categories. | 25 h |
| `WEB_PROFESSIONAL_ENTRY` | Concise professional identity and contact website. Example content: Home / positioning, Expertise, Experience & credentials. | 8 h |
| `WEB_PROFESSIONAL_GROWTH` | Detailed expertise and proof of work with structured case studies. Example content: Home, Professional profile, Services / expertise. | 16 h |
| `WEB_PROFESSIONAL_PREMIUM` | Multi-service professional presence, complex conversion-oriented content and polished case-study system. Example content: Conversion-oriented home, Multiple expertise areas, Service detail pages. | 28 h |
| `WEB_ENTREPRENEUR_ENTRY` | Launch-ready brand story and service/offer explanation. Example content: Home / venture story, What we offer, Founder / team story. | 10 h |
| `WEB_ENTREPRENEUR_GROWTH` | Deeper offer structure, market story and launch content. Example content: Home, Problem / mission, Offer / product. | 20 h |
| `WEB_ENTREPRENEUR_PREMIUM` | Advanced narrative, multiple offers, structured launch campaigns and stronger on-site conversion storytelling. Example content: Launch-oriented home, Product/offer categories, Individual offer details. | 35 h |
| `WEB_BUSINESS_ENTRY` | Professional basic institutional presence with validated organization details. Example content: Home, About organization, Services / products overview. | 12 h |
| `WEB_BUSINESS_GROWTH` | Multi-service company storytelling, case studies and trust information. Example content: Home, About, Service categories. | 26 h |
| `WEB_BUSINESS_PREMIUM` | Complex corporate information architecture, multilingual polish, case studies and structured service hierarchy. Example content: Advanced organization home, Company/about, Multiple service lines. | 45 h |

The level ceiling table controls all 12 website packages. A staff-created quote must list the exact requested page/feature scope, design version, accepted language(s), source materials and out-of-scope requests. No arbitrary content/user-generated uploads appear merely because a page template exists. Formal two-stage project approvals remain separate from ordinary design-revision allowances.

## 4. Four audience tool packs — independently priced and entitlement-controlled

| Pack | Full scope | Monthly price | Annual price |
|---|---|---|---|
| `PACK_STUDENT` | All 12 Student Toolbox and 16 Student Workspace positions (27 distinct capabilities, one shared Career Kit), all majors; validated PDF/DOCX/ICS where scoped; private storage, revision, export, sharing controls. | `null` / unpublished | `null` / unpublished |
| `PACK_PROFESSIONAL` | Curated professional reuse of relevant existing Toolbox/Career Kit, CV, portfolio, achievements, applications, career roadmap, goals, skills and learning tools. No duplicated personal record engines. Exact pack visibility configuration reviewed. | `null` / unpublished | `null` / unpublished |
| `PACK_ENTREPRENEUR` | Four bounded founder tools plus entitlement-controlled reuse of reviewed brand, portfolio, links, digital card, QR and export capabilities. Not CRM/accounting/autonomous builder. | `null` / unpublished | `null` / unpublished |
| `PACK_BUSINESS` | Digital Asset Register and Marketing/Content Request Briefs plus reviewed shared company brand/link and core care screens. No credential vault or live website CMS replacement. | `null` / unpublished | `null` / unpublished |

**DO NOT divide the Student feature scope by website tier.** Student has 12 Toolbox positions + 16 Workspace positions = 27 unique capabilities with one Career Kit engine. All majors entitled to the complete pack. Professional reuses approved existing capabilities; Entrepreneur adds ENT-01..04; Business adds BUS-01..02. `UX-01` remains PROPOSED and `EXT-TEAMS` remains PARTIAL; do not silently promote them into standalone paid products. Only a Root with a valid paid website and matching first-year or later paid pack may use private tools.

## 5. Common technical quotas — numerical *starting hypotheses*, not measured or approved

R26-02 asked for **measured and costed numerical proposals**. Without authorized runtime/load/abuse tests, the only truthful deliverable here is a **benchmark target** followed by the measured approval gate. These examples are not provider limits and must never be published to customers or seeded as paid entitlements before evidence.

| Per-Root common candidate | Numerical hypothesis | Gate |
|---|---:|---|
| Root-bound private R2 originals/output storage | 2 GiB | benchmark storage growth, versioning, encryption/access, backup and retention amplification |
| Private structured tool records | 2,000 | D1 query/write/cross-tenant/race test, D1 shared-database growth |
| Limited named collaborators | 5 | staff/privacy/guardian rights and WebAuthn onboarding tests; not enterprise seat billing |
| New shares per rolling 30 days | 50 | abuse, capability TTL, revoke racing, download auth |
| Concurrent active shares | 20 | expiry/revocation/indexing tests |
| Document/Root exports per rolling 30 days | 100 | PDF/DOCX CPU, R2, queues, scan and memory test |
| Heavy import/export jobs in flight per Root | 2 | capacity/timeout/fairness/denial of wallet tests |

Owner-decided fixed limits must not be weakened: Office DOCX/XLSX/PPTX 10 MB/file; CSV/ICS 2 MB/file; combined batch 25 MB; support **JPEG/PNG/WebP** 5 MB each and max 3/message; share default 30 days/max 90; Study Timer inactivity 10 min. Define decimal-vs-binary convention before enforcing. Independently cap decompressed rows/assets/CPU/memory/time, quotas and malware exposure. Fail closed if scan/verification unavailable. **Never quota human authentication/guardian recovery/essential notices into account lockout; protect those via abuse controls with safe fallback.** These sample Root quotas remain identical across Entry/Growth/Premium; service/deliverable allowances distinguish tiers.

Important scale warning: D1 is capped at **10 GB for each database** on Workers Paid. Because Admin D1 and Client D1 are shared authorities, "2,000 records per Root" alone is not a safe promise for an arbitrary number of Roots; planning must model customer count, retention, indexes and future shard/migration options *without silently adding new D1s*. (Official documentation referenced below.)

## 6. Cost evidence and useful unit economics (research snapshot, not purchase permission)

**Official reference prices accessed on 22 October 2026 (USD, published list rate; exact fees can change by region/account/contract):**

- Cloudflare Workers Paid baseline **$5/month per account**, 10M worker requests + 30M CPU-ms included/month; overage $0.30/million requests and $0.02/million CPU-ms. **Not** $5/Root. Source: https://developers.cloudflare.com/workers/platform/pricing/
- Cloudflare D1 Workers Paid: 25B rows read, 50M written/month and 5 GB storage included (account/plan billing), thereafter listed usage rates; each D1 database max **10 GB**. Sources: https://developers.cloudflare.com/d1/platform/pricing/ and https://developers.cloudflare.com/d1/platform/limits/
- R2 Standard: **$0.015/GB-month**, Class A $4.50/million, Class B $0.36/million; Standard free tier 10 GB-month, 1M A, 10M B account/month, subject to eligibility. Source: https://developers.cloudflare.com/r2/pricing/
- Cloudflare Registrar reference **.com $10.46 initial and renewal/year** in current domain price table; other TLDs differ, availability and registrar eligibility must be checked. Source: https://pricing.registrar.cloudflare.com/
- Real mailbox reference: Zoho Mail Lite **$1/user/month billed annually** for a 5 GB tier as listed; Google Workspace Business Starter **$7/user/month** on annual commitment as published, different actual features and regional fees. Sources: https://www.zoho.com/mail/zohomail-pricing.html and https://workspace.google.com/pricing
- **Cloudflare Email Routing / transactional Email Sending is not a hosted user mailbox.** Do not substitute inbound forwarding or transactional notifications for the customer-owned real mailboxes. Source: https://developers.cloudflare.com/email-service/

**Illustrative 100-Root shared R2 scenario, NOT a benchmark:** at a hypothetical 2 GiB full storage allocation per Root, 100 Roots total ≈ 214.75 decimal GB before versioning/backup; with the 10 GB monthly free tier applied fully to Standard storage, estimated billed storage ≈ (214.75 − 10)×$0.015 = **$3.07/month**, excluding operations, second copies, scan/quarantine, metadata, retention, tasks and provider/account allocation. This demonstrates that custom website labour and hosted mailbox can dominate storage cost; it is not the true total monthly operation cost and not a quota endorsement.

**Illustrative annual direct external supplier floor at reference prices** (one .com + mail accounts only, no staff labour, taxes, support, backups or shared platform cost): Entry 1 mailbox ≈ **$22.46/year**; Growth 2 ≈ **$34.46/year**; Premium 3 ≈ **$46.46/year** using the Zoho $1/user/month annual example. Alternative using Google Starter $7/user/month annual: Entry ≈ **$94.46**, Growth ≈ **$178.46**, Premium ≈ **$262.46** annually. Actual chosen mailbox/domain vendor may be incompatible, ineligible or more costly; do not publish those as included fees until selected. The numbers are illustrative arithmetic, not the profit margin or a selling-price recommendation.

**Internal cost model — required Admin reporting inputs, not invented owner wage rates:**

`initial_total_cost = (estimated_build_hours × approved_loaded_hourly_cost) + domain_first_year_cost + mailbox_first_year_cost + allocated_shared_platform_cost + setup/support/security/legal/tax_cost + contingency`

`annual_renewal_total_cost = (monthly_care_hours × 12 × approved_loaded_hourly_cost) + domain_renewal_cost + mailbox_renewal_cost + annual_allocated_platform/backup/support/QA_cost + contingency`

`target_sell_price = cost_total / (1 − target_gross_margin)` where margin and hours are *scenario variables*, never default owner commercial truth.

**Example of transparent internal scenario only:** If a Student Entry build requires a hypothetical 6h, labour is hypothetically $20/h and monthly care 0.5h, then first-year build labour $120 and care labour $120, plus reference .com + 1 Zoho Lite mailbox $22.46 = **$262.46 first-year direct model before** shared infrastructure, backups, legal/security, overhead, contingency and any margin. This is **not** a proposed live website package selling price; multiplying one generic unit rate by every market or audience would be unsound.

## 7. Future Admin — change every price, safely

### 7.1 Screens and permissions (engineering proposal)

1. **Catalogue**: 4 audience families × 3 tier plan cards, 4 tool packs, per-feature/versioned inclusions, country/state publication status and effective windows. Plan ID/code immutable; no deletes of referenced versions. **No CMS for the company's new public site**.
2. **Price book editor**: USD base and optional market-specific approved overrides LB/IQ/BH/KW/OM/QA/SA/AE. Initial site, annual renewal, monthly/annual pack and paid-switch/custom service line items editable. Taxes/FX computed from separately approved dated sources/rules (not browser-generated conversion or blind spot FX).
3. **Price proposal & publish**: permitted staff creates proposed version, saves Draft, sees independent evidence of cost and impact; restricted commercial publish under assigned Super Admin with **fresh WebAuthn step-up**, immutable publish audit, optional second review for material changes. Owner Super Admin can edit prices from Admin; no customer-facing unapproved values. Price publication authority and dual-control policy require exact future approval; Operations nonfinancial maker/checker is not automatically price authority.
4. **Effective time / rollback**: publish signed version with `effective_from`, optional `effective_until`; overlap prevention, monotonic versioning, optimistic lock, conflict checks. Rollback = issue a new version using older values, never mutate an old published version. Reason/diff/approver/time/correlation recorded.
5. **Preview impact**: estimate new-quote amounts, compare old/new, see open pending quotes and contracted legacy prices (no retroactive changes). Prohibit active price changes from altering accepted orders, receipts, invoices, paid terms, historical renewal obligations or pending payment evidence.
6. **Quote service**: quote is an immutable price snapshot with currency, tax, service items, inclusions, website + pack clocks, owner account + Root request, terms version, expiry. On expiry/change produce a new quote requiring new owner acceptance, independent Billing verify and audit; do not alter a paid invoice.
7. **First publication and safety**: all 16 catalogue items start `UNPUBLISHED_DRAFT` with nullable monetary fields; no accidental $0, `NaN` or missing market fallback. Cannot publish plan unless initial/renewal values and deliverables are complete and supplier eligibility/currency/terms validated. No customer checkout, no auto-renewal, no direct client mutation of price.
8. **Quote-price/read consistency**: concurrency/effective-date test; plan withdrawn between draft quote and owner acceptance follows versioned expiry/approval policy; no double Root creations on repeated Paid events; Admin failures → `Pending` or deny. Cross-D1 eventual events never grant paid entitlement on Client projection alone.

### 7.2 Pricing state machine and accounting examples (proposed)

`DRAFT -> REVIEW_PENDING -> APPROVED -> PUBLISHED -> RETIRED`; publication permitted only with approved values, same-site version and step-up, no actor can change historical quote fields by price mutation. `PUBLISHED -> PUBLISHED` is forbidden as an in-place edit; create next `DRAFT`. Finance movement is a separate verifiable ledger.

| Scenario | Expected outcome |
|---|---|
| Draft website price is null | Staff sees "Price not published"; cannot issue binding quote or claim free |
| Owner changes Student Entry initial USD amount | Future new quotes use new published version and effective date; existing accepted quotes/invoices unchanged |
| Owner changes Student Entry annual renewal | Existing already-contracted renewal obligations preserved; future renewal offers use explicitly accepted new price/terms, not stealth repricing |
| Market override exists but is Draft | Not publicly quotable in that market; strict documented fallback only if explicitly approved by region policy |
| Owner switches pack while matching first year is active | New paid quote with exact term/credit/switch rules; only after accepted+verified Paid does alternate pack activate, prior inaccessible records retained |
| Staff Operations records proof of money | Payment remains Pending; cannot create Root or grant entitlement until separate Billing verifies |
| Website goes Live late | Matching pack term still expires from original verified purchase; no unauthorized extension |
| Price version concurrent update | Save fails with revision conflict; no lost update |
| Admin unavailable | Client tool access fails closed; no stale entitlement, no buyer-set amount |

## 8. Cross-system contract and release boundaries

`Admin D1`: plan, price book/version, markets/currency/tax policy, quote, offer acceptance, verified payment, paid entitlements, Root/site, renewal, support, delivery audit. `Client D1`: customer identity/membership/guardian and Root-bound private workspace, no prices-as-truth. Runtime must server-authenticate requests, verify object/field/role/action authorization, version/idempotency/freshness, and audit every price mutation; no worker/CMS direct writes into the wrong database. Public wizard cannot publish plans or set Paid. Proposed new DB entities/versions still **UNAPPROVED migrations**.

`PROVIDER SEPARATION`: provider-independent transactional email interface and deterministic local adapter until reviewed live provider; actual customer mailbox accounts supplied by separate approved real provider; domain registrar/provider check; tests for no-provider, mail delay, failed provisioning and regional ineligibility must show Pending/blocked, not Delivered/Active. No pricing, platform cost number or mock provider is a deployment promise.

`SERVICE & PRIVACY`: regional proposed support hours only; legal review across Lebanon/Iraq/six GCC; lawful minors/guardian and privacy rights override preferred no discretionary erasure; safe retention and approved backups are separate release gates. Existing historically delivered public source and CMS untouched. Legacy fixture anomaly PKG-01 stays documented and is not an Admin catalogue prerequisite; if legacy fixture is reused for acceptance it must be fixed in a separately authorized versioned work order.

## 9. Proposed bounded next Codex task (READ ONLY)

P01B should reconcile this price-editing clarification with original R10-05/PRICE-01 as a **split engineering/publication gate**, verify all plan and pack identities and exact decision status, and propose immutable publication, quote/payment/account/root, grandfathering and renewal contracts. It may propose Admin schema specs and test matrix but must NOT create or apply any schema/source, run provider actions or claim tested quotas. Owner's "prepare them" here authorizes **proposal documentation**, not a blank authorization to execute implementation stage 02.

**Acceptance checks for that review:** exactly 12 plans+4 packs, no missing plan family/tier, all prices null/unpublished, no "free by default", immutable accepted price snapshots, safe future editable controls, live Root + active site + valid pack checks, separated Admin/Client authority, no guessed domain/mailbox service, measurable common quotas, every owner-decided import/security limit preserved, no source work. End with an owner-ready scope/approval page containing no re-asked rounds, and a properly bounded implementation-stage proposal. If a future owner approves a source work order, the first slice may build the *catalogue editor and its safety contracts* without publishing unapproved prices or requiring production providers.
