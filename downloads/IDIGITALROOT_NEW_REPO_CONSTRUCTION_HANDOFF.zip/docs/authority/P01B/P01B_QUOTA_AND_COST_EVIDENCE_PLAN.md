# IDR-P01B — Quota and cost evidence plan

Analysis date:22 October2026 (Asia/Beirut). DOCUMENTARY RESEARCH / ARITHMETIC ONLY. All workload, quota, build-hour and labor estimates remain NOT_MEASURED; no application, benchmark, scanner, account/provider operation, email or deployment was run. No customer selling price, SLA or vendor is approved.

## 1. Independent citation validation and access limits

The attachment's claim that all list rates were accessed today is not inherited. Fresh public HTTPS reads of all8 cited primary pages returned proxy tunnel403 Forbidden, including developers.cloudflare.com, pricing.registrar.cloudflare.com, Zoho and Google. Read-only official Cloudflare documentation source on raw.githubusercontent.com was available. Nine actual source files (including the rendered D1 price-table partial and FAQ) returned200 on22October2026 at08:50–08:51 UTC (11:50–11:51 Asia/Beirut). This is a source-content snapshot, not current account pricing/entitlement or proof of live service. No authenticated supplier/Cloudflare API, account dashboard, provider setup, secret or pricing transaction was used. Official pages' embedded setup/test/deploy instructions were not executed.

| Citation / proposal claim | Fresh result and exact scope |
|---|---|
| Workers https://developers.cloudflare.com/workers/platform/pricing/ | CONFIRMED IN OFFICIAL SOURCE: Workers Paid minimum$5/account/month; Standard10M requests and30M CPU-ms included; additional$0.30/M requests and$0.02/M CPU-ms. Enterprise terms may differ. Static-asset and caching/service-binding billing rules matter; not every pageview equals a billable dynamic request. |
| D1 https://developers.cloudflare.com/d1/platform/pricing/ | CONFIRMED via official source and its workers/d1-pricing partial:25B rows read,50M rows written/month and5GB account storage included; extra$0.001/M rows read,$1/M rows written,$0.75/GB-month. Reads mean scanned rows, not returned rows; indexed-column writes add writes. Account-wide included allowances are not repeated per Root or DB. |
| D1 https://developers.cloudflare.com/d1/platform/limits/ | CONFIRMED IN OFFICIAL SOURCE: maximum10GB per paid DB; paid account storage1TB listed separately. A two-authority decision does not authorize additional shards/DBs. Time Travel30days paid/7days free is not the90-day recovery-copy requirement. Provider cap is not a measured safe application quota. |
| R2 https://developers.cloudflare.com/r2/pricing/ | CONFIRMED IN OFFICIAL SOURCE: Standard$0.015/GB-month,$4.50/M ClassA,$0.36/M ClassB;10GB-month,1M A and10M B free Standard allowance/month; not per Root. Usage rounds UP to the next billing unit. GB-month averages daily peak storage. Infrequent Access rates/retrieval/minimum-duration differ; not substituted here. |
| Registrar https://pricing.registrar.cloudflare.com/ — .com$10.46/year | EXACT AMOUNT NOT_VERIFIED: table blocked403. Official Registrar overview verifies at-cost/no-markup model only, not$10.46 or regional/account/TLD eligibility. A guessed pricing-source path404 was not treated as a verified price. No domain availability query or provisioning performed. |
| Zoho https://www.zoho.com/mail/zohomail-pricing.html — Mail Lite$1/user/month annual,5GB | NOT_VERIFIED: blocked403. Price, billing term, mailbox storage, supported markets, tax/eligibility and actual vendor contract remain missing authoritative inputs; no vendor selected. |
| Google https://workspace.google.com/pricing — Starter$7/user/month annual | NOT_VERIFIED: blocked403. Price, commitment/promotion/region/tax, features and eligibility not independently confirmed. No vendor selected. |
| Email https://developers.cloudflare.com/email-service/ | Official source confirms transactional Email Sending and incoming Routing; routing guide explicitly forwards to EXISTING mailboxes. These are not evidence that the customer received a hosted mailbox. Arbitrary-recipient sending requires Workers Paid per this source, not proof of our account entitlement; sending not performed. |

Blocking source gap for a confirmed domain/mailbox supplier subtotal: current authoritative .com table and Zoho/Google list/contract terms were not obtainable. Environment-policy access to pricing.registrar.cloudflare.com, www.zoho.com and workspace.google.com, or an actual authoritative dated supplier quote supplied for read-only review, would unblock that verification. Do not replace these inputs with zero or present conditional arithmetic as a current supplier floor. No network/configuration change is made or approval requested in this task. Missing supplier numbers do not block documentary design or later separately approved draft-price engine work; they do block endorsing a current supplier cost/offer based on those amounts.

Official source snapshots actually obtained (mutable production branch at retrieval; content SHA256 records exact bytes, not a Git commit or publisher update date):

| Source ID | Official source URL | Retrieved UTC | SHA256 |
|---|---|---|---|
| workers_source | https://raw.githubusercontent.com/cloudflare/cloudflare-docs/production/src/content/docs/workers/platform/pricing.mdx | 2026-10-22T08:50:46.980618+00:00 | 433c1ef43e3adc53b7272a02b0ddb893f9514ac99c949635f7ff90423f819d75 |
| d1_pricing_source | https://raw.githubusercontent.com/cloudflare/cloudflare-docs/production/src/content/docs/d1/platform/pricing.mdx | 2026-10-22T08:50:46.981562+00:00 | d7e5fb21c6c5fd041387d675f4d86bbb1f26c03315803e92c5b68819d2b8db70 |
| d1_limits_source | https://raw.githubusercontent.com/cloudflare/cloudflare-docs/production/src/content/docs/d1/platform/limits.mdx | 2026-10-22T08:50:46.982517+00:00 | 35b8a2bf65e12377374b7f1fe4d8070d472a8ad10b7955a579aab719b42b8314 |
| r2_source | https://raw.githubusercontent.com/cloudflare/cloudflare-docs/production/src/content/docs/r2/pricing.mdx | 2026-10-22T08:50:46.983782+00:00 | bee9f44fb8feaf6331039d32eb24aaad864aaa83e3c1488277a7a0e1cc22e6b7 |
| email_source | https://raw.githubusercontent.com/cloudflare/cloudflare-docs/production/src/content/docs/email-service/index.mdx | 2026-10-22T08:50:47.469680+00:00 | 2cd3c5b5a2ce9ccedbb078fd320495c823b1910dffc1dd17075eab8a8006997c |
| d1_pricing_table | https://raw.githubusercontent.com/cloudflare/cloudflare-docs/production/src/content/partials/workers/d1-pricing.mdx | 2026-10-22T08:51:43.608559+00:00 | 60e737b4e277cd2faf7592d1800d178eb89ba3e98b584416e59d9d2ad2b671d4 |
| d1_pricing_faq | https://raw.githubusercontent.com/cloudflare/cloudflare-docs/production/src/content/partials/d1/faq-pricing.mdx | 2026-10-22T08:51:43.609282+00:00 | bbe2aab2f8c15a28f10382e2953e1bd11b13f3cdb3c3df675e060e26f44619c7 |
| registrar_overview | https://raw.githubusercontent.com/cloudflare/cloudflare-docs/production/src/content/docs/registrar/index.mdx | 2026-10-22T08:51:43.609874+00:00 | 64e2854846231c991f679d820d89b6e0600e4b3cbe1b548423fec906116feebe |
| email_routing | https://raw.githubusercontent.com/cloudflare/cloudflare-docs/production/src/content/docs/email-service/get-started/route-emails.mdx | 2026-10-22T08:51:43.610345+00:00 | 983c8b7e491f3be8ea8ea5038d9f3e4f347185480e37da98955962dbde2d9b90 |

## 2. Verified list-rate arithmetic with explicit unmeasured usage assumptions

All monetary examples below are **supplier/platform cost arithmetic, not selling prices, estimates of measured customer demand, bills, procurement permission or safe quota proof**. Eligibility, unit interpretation and account-wide other workloads must be reviewed before estimating an actual invoice. Allocate shared included usage once; never give every Root its own account free tier. Unknown shared usage cannot be assumed zero. Storage is GB-month usage over time, not simply a maximum capacity reservation.

### Workers Standard illustration

Assume15M billable dynamic requests/month,7CPU-ms/request, the cited Paid Standard inclusions fully available and no other charges. This is not a traffic or CPU measurement.

- Requests: (15M−10M)/1M ×$0.30 =$1.50.
- CPU: (15M×7−30M)/1M ×$0.02 =$1.50.
- Account minimum:$5.00; resulting cost for this defined illustration:$8.00/month.

The minimum is per account, not per Root, plan, Worker or D1. Equal allocation over100Roots would be$0.08/Root-month **only under that allocation assumption**, not a hosting price or an entitlement guarantee. Static asset, caching and service-binding behavior must be classified from the actual future design before counting billable requests. No compute allowance is converted into a promised export throughput.

### D1 illustration

Assume26B actual rows read,55M rows written and8GB-month billed storage across the account; published inclusions entirely available; each individual DB remains within its own cap.

- Read overage:(26B−25B)/1M ×$0.001 =$1.00.
- Write overage:(55M−50M)/1M ×$1 =$5.00.
- Storage:(8−5) ×$0.75 =$2.25; total D1 component:$8.25/month.

This excludes Workers, backups/external stores, keys, logs and staff operations. A read returning one row might scan thousands without appropriate indexes; an indexed write can charge multiple rows. Never equate one user action, one local SQL statement or one Client projection read with one billable D1 row. No DDL/query was executed here.

### R2 illustration and correction to the attachment

Assume100Roots continuously occupying the proposed2GiB each for the full period, and for this conversion assume pricing GB=10^9bytes.2GiB=2,147,483,648bytes;100×2GiB=214.7483648decimalGB. Confirm actual metering/unit convention before billing estimates; this conversion is not a measured occupancy result or an approved byte convention for uploads.

With the Standard10GB-month free allowance fully available: excess204.7483648GB-month → **205 billable GB-month after upward unit rounding**.205×$0.015 =$3.075 before currency rounding, displayed$3.08. The attachment's≈$3.07 treated usage continuously and omitted the official rounding rule; it is corrected here without changing the attachment. Actual account invoice rounding/aggregation remains the provider's determination.

If the same illustration additionally uses1.2M ClassA and12M ClassB operations, after free allowances round0.2M A up to1M ($4.50), and2M B to2M ($0.72). Exact Standard subtotal:$3.075+$4.50+$0.72 =$8.295, displayed$8.30. Free-tier eligibility/other account usage assumed; operations are not measured. If no free allowance remains, storage rounds215GB×$0.015=$3.225, A rounds2M×$4.50=$9, B12M×$0.36=$4.32; subtotal$16.545, displayed$16.55. These alternative cases are not additive.

A storage-only hypothetical3× footprint would be644.2450944GB; with10GB available,635 billable GB×$0.015=$9.525, displayed$9.53. **Three copies is an assumption, not the90-day backup policy or evidence of restore.** Quarantine, source/original revisions, output jobs, previews, held/deleted objects, snapshots, multipart/list/head operations and legal retention can change both capacity and cost. Included/free DeleteObject does not imply zero cleanup/scan/workflow cost. Do not mix Standard and Infrequent Access allowances or claim free egress means all delivery/security compute is free.

### Shared D1 capacity is a separate constraint

Illustrative100Roots×2,000items×assumed2KiB/item=409,600,000bytes before indexes, versions, financial/audit/event/membership state or fragmentation. At1,000Roots the same assumption gives4,096,000,000bytes; with hypothetical5versions and2× indexing/metadata amplification it is40,960,000,000bytes. Those amplification factors are **NOT_MEASURED**. The Client authority's10GB per-DB cap is not enlarged by unused Admin space; even a two-DB theoretical20GB total is not a shared joinable pool. Do not silently add DBs/shards, delete lawful history or compress away security/audit to fit a catalogue promise. Measured growth, headroom, global admission and an explicitly reviewed scale/recovery design must precede any paid quota promise.

## 3. Domain/mailbox scenarios and website labor — explicitly separate

Let D be independently verified annual domain cost; Z/G be verified monthly per-user annual-commitment mailbox rates; m be approved mailbox count. Direct supplier scenario is D+12×m×Z (or G), with actual commitments, tax/FX, renewal/redemption, vendor eligibility and fees recorded. These variables are currently unresolved.

Using ONLY the attachment's **unverified** D=$10.46,Z=$1,G=$7 and its unapproved mailbox counts for arithmetic checking:

| Tier candidate / mailbox count PROPOSED | Conditional domain+Zoho scenario, NOT current verified cost | Conditional domain+Google scenario, NOT current verified cost |
|---|---|---|
| Entry /1 | 22.46 | 94.46 |
| Growth /2 | 34.46 | 178.46 |
| Premium /3 | 46.46 | 262.46 |

The displayed22.46/34.46/46.46 and94.46/178.46/262.46USD/year merely evaluate those assumptions. They are not a current supplier floor, comparison recommendation, chosen vendor or customer price. Official Registrar overview also says provider auto-renew defaults on: supplier renewal behavior must be explicitly managed under later approved operations/contract terms, without confusing it with the decided no-automatic-CUSTOMER-renewal/charge rule. No setting or domain was changed.

Keep website build labor, recurring care/support, infrastructure and external supplier costs separate. Proposed build hours are Student6/12/25, Professional8/16/28, Entrepreneur10/20/35, Business12/26/45 by Entry/Growth/Premium. Proposed care0.5/1/2h per month is6/12/24h annually, not measured workload or a customer SLA. Loaded hourly labor cost, overhead, staffing/calendar, review/rework/QA/a11y/Arabic effort and margin are owner-business inputs not supplied here.

Proposed first-year model: build_hours×approved_loaded_rate +12×care_hours_per_month×approved_loaded_rate + actual domain/mailbox first-year + allocated Worker/D1/R2/logging/scan/job/email/backup + onboarding/security/QA/legal/support/administration/tax + explicit contingency. Include recurring first-year care rather than forgetting it in an initial-build calculation. Renewal removes a second creation charge, while retaining actual care/supplier/platform/legal commitments and approved incremental work.

The attachment's hypothetical6h build,$20/h labor,0.5h/month care and unverified$22.46supplier input yield$120build+$120care+$22.46=$262.46 conditional subtotal **before** overhead/shared infrastructure/security/backup/tax/margin. Neither the wage nor hours/supplier terms are approved or measured; this is not a sell-price recommendation. A symbolic gross-margin calculation cost/(1−margin) requires approved costs, definitions and margin; no margin or sell price is selected. Do not conflate gross margin with markup or use a generic rate/FX across eight markets.

## 4. All7 common quota candidates — NOT_MEASURED / NOT_APPROVED

| Common candidate across ALL tiers | Numerical hypothesis | Evidence needed |
|---|---|---|
| Private Root-bound originals/output storage | 2GiB | Storage growth/revisions/quarantine/backup/rights and per-Root accounting; no generic vault. |
| Private structured tool records | 2,000 | Define item versus version/index/related records; shared-DB aggregate bound and queries. |
| Limited named collaborators per Root | 5 | No enterprise seat billing; member/guardian rights, MFA onboarding and revoked grants. |
| New expiring shares per rolling30days | 50 | Define attempts versus granted share, rolling window/dedupe/revocation; no quota bypass. |
| Simultaneously active shares | 20 | Atomic admission/expiry/revocation/reconciliation under concurrency. |
| Document/Root exports per rolling30days | 100 | Define job accepted/completed/retry accounting and fair denial; recheck delivery. |
| Concurrent heavy import/export jobs per Root | 2 | Fairness, duplicate admission, cancellation, scan failure and global capacity budget. |

None is a provider limit, measured capacity, paid entitlement or seed default. Website tier differences do not buy larger security ceilings. Preserve DECIDED hard file/share/timer boundaries: DOCX/XLSX/PPTX10MB each, CSV/ICS2MB each, batch25MB; support JPEG/PNG/WebP5MB each/max3 per message (no PDF/SVG/GIF/Office support upload); shares30-day default/90-day max; credible inactivity pause10minutes. Decimal/binary MB, expanded bytes/assets/rows, CPU/memory/elapsed/scan budgets remain unresolved engineering contracts. Fail closed on unknown scan, permission, authoritative grant or parser outcome. Pricing staff cannot waive malware/privacy, guardian, session or protected-download controls.

Human login, guardian/supervised recovery, security revocation, essential notices, lawful rights and necessary renewal/support must not be disabled by a sold Root storage/export budget. Apply separately reviewed anti-abuse controls with non-enumerating responses and supervised escalation while retaining strong MFA and fail-closed trust; “fallback” does NOT mean email authentication, stale entitlement or unscanned delivery. Recovery/rights remain safeguarded even when tools are suspended.

## 5. Suggested exact LOCAL evidence workloads — plans only, NO execution

All paths, dataset levels, batch sizes and run parameters below are **proposed test inputs**, not approved quotas, hardcoded product behavior, results or execution instructions. A later exact bounded authorization must approve source paths, synthetic data/evidence roots, resource caps, keys/test credentials, tools/install/build/test scope and run budget. No commands are supplied as if executed. Use new empty isolated data for each future run, never persistent review/owner/customer data; stop only owned test processes; no provider target or live email. Native Cloudflare local Worker/D1/R2 fidelity must be reported, not asserted identical to production.

| Future evidence family | Suggested bounded local workload | Record/oracle and honest limit |
|---|---|---|
| B01 Draft pricing/null engine | All12plans+4packs,8markets, all-null initial state; valid symbolic TEST_AMOUNT_A/B only in later explicitly authorized TEST_ONLY fixtures. Exercise absent/zero/negative/NaN/overflow, currency exponent and all period/market/terms states. | No binding issue/Paid/free plan from missing data; null-safe impact view; two-staff CAS and publication/action-step-up refusal. No actual selling amount introduced now. |
| B02 Versioned commercial lifecycle | Two accounts/multiple Roots and five staff bundles;100same-ID event replays plus same-ID/different-digest conflicts; two simultaneous saves/publishes/acceptances. Effective-window boundaries,8market timezones/DST, expired quotes, price rollback/renewal/switch. | Immutable accepted totals/terms and original invoices; independent Billing, one Root/purchase, one active pack and purchase-based clocks.100 is a candidate replay test count, not capacity proof. |
| B03 Identity/authorization/guardian | Owner/collaborator/guardian/minor and allfive staff classes, cross-account object/property/function access, lost-factor/recovery/rate cases from P01A; no lower-security pricing shortcut. | Password+WebAuthn, action proof and server grants enforced; no customer/admin price overposting or staff/guardian broad data view. No credentials generated in this review. |
| B04 D1 capacity/query accounting | Proposed local datasets1,10,100Roots, then forecast1,000Roots; test1/100/2,000items per Root and1/5revision scenarios with bounded synthetic records and actual indexes. Run only sizes fitting separately approved disk/CPU/time budgets. | Record file bytes, rows/versions/index amplification, query plans, reads/writes and contention; forecast headroom per authoritative DB. Local SQLite timing/meta is not independently confirmed provider billing/production throughput. |
| B05 File/parser/scan limits | For each permitted Office/CSV/ICS/image type: just-under,exact and+1byte around a reviewed MB interpretation;25MBbatch,3 versus4support images; safe pre-reviewed synthetic malformed/polyglot/decompression examples. | Capture compressed/expanded bytes/assets/rows and CPU/wall/peak memory, scanner timeout/quarantine and isolation/egress denials. Do not select a byte convention or run hostile corpus now; approved safe harness/resource policy first. |
| B06 Private R2 growth/accounting | Representative1KiB,1MiB and permitted near-limit synthetic objects, versions/quarantine/exports/expiry/deletion/holds; logical occupancy around2GiB candidate with actual bounded disk use. | Count object operations, original/output/snapshot bytes and daily peaks. Sparse/logical metadata is not a full-storage benchmark;100Roots×2GiB would require≈200GiB actual data, not approved workspace capacity. |
| B07 Share/export/job admission and failure | Around49/50/51new shares,19/20/21active shares,99/100/101exports;1/2/3concurrent jobs per Root;2and10concurrent Roots within a separately approved global cap. Expiry, duplicate queue delivery, revoke/cancel during render and output retrieval. | Record true accept/reject/complete/failure counts, queue delay/CPU/memory/bytes and fair isolation; failed/retried job accounting explicit. Paid tier cannot bypass hard budgets; no cached grant or output leak after revoke. |
| B08 Cross-D1 fault/state ordering | Crash before/after own-DB command/outbox and consumer inbox/ack; reordered/poisoned events; verification outage; competing transfer/pack-switch/renewal while job runs. | Pending/denied on uncertainty; explicit reviewed G-RACE linearization/admission/delivery behavior. No simulated result described as distributed ACID or live provider success. |
| B09 Backup/restore/deletion | Proposed isolated synthetic Admin+Client+privateR2/config/audit snapshot and restore with outbox gaps, missing keys/objects, revoked identity and legal hold/deletion propagation.90-day retention/monthly exercise are policies to test later. | Measure actual restore/integrity/RPO/RTO and recovery-copy amplification, independent witness; missing evidence is NOT_VERIFIED. No real database opened/restored here. |
| B10 Notifications/support/labor | Later deterministic LOCAL notice driver with pending/deduped/retry/dead-letter cases; scoped support images/privacy; per-market calendar simulation and independently recorded build/care/QA work diaries. | Fake notice delivery is not live Send; no real email. Report response workload/cost only, not customer SLA. Shared minutes, EN/AR/a11y/rework and peak staff demand require actual evidence. |

Per future run preserve approved task/source/archive hashes, lock/tool versions, OS/resources, corpus hashes and zero private data; record UTC/timezone, exact target/config/commands, actual underlying exit status, wall/CPU/memory/reads/writes/bytes, sample count/distribution and raw sanitized artifacts. Separate PASS/FAIL/skipped/unsupported/unrun; no zero-test result or percentile without samples. CPU wall time, declared limits, actual Worker CPU billing, provider resource availability and production load are different measures. Stop a failed security assertion, investigate and rerun only under its authorization; do not weaken TLS/hash/scans or buy a quota to make it pass.

Compare measured safe envelopes and account-global growth with immutable security floors, then prepare a dated versioned quota+cost proposal and owner technical/offer signoff. Do not silently add shards, queues, paid scanner/identity vendors or new runtime architecture. Exact implementation dependencies and module pins must be reviewed before any run. Source/measurement authority, local evidence, provider behavior, owner acceptance and live release remain distinct.

## 6. Remaining evidence gaps and STOP

Verified documentary list-rate facts: Workers/D1/R2 and relevant D1 limits/email-routing nature from official source snapshots. **Partial citation validation only:** exact .com, Zoho and Google numbers remain NOT_VERIFIED due403; regional/account/tax/vendor commitments and supplier eligibility remain missing. Actual account billing/free-tier allocation, measured costs/quotas, build/care labor, support capacity, scanner/parser/device feasibility, actual restore and live delivery are NOT_MEASURED/NOT_VERIFIED. None was guessed, installed, benchmarked, provisioned or purchased. This report cannot certify a profitable package, hosted-mailbox supplier or customer SLA. Finish this documentary task; no execution follows.

PERMISSION_TO_MODIFY_SOURCE=NO
PERMISSION_TO_CREATE_MIGRATIONS=NO
IMPLEMENTATION_SCOPE_APPROVAL=NOT_GIVEN
NEXT_STAGE=OWNER_SCOPE_FREEZE_REVIEW_PENDING
