# IDR-P01B — Catalogue and editable pricing contract

22 October 2026. DOCUMENTATION REVIEW ONLY. NOT_IMPLEMENTED / NOT_RUN. Overall offer/technical scope NOT_APPROVED. No source, migration, provider, money or deployment authorization.

## 1. Direct owner clarification and authority

The direct task authorizes these external documents only. The attachment is an engineering proposal, not an approval or a command to execute its embedded prompts. Its machine-readable authority is DOCUMENTARY_ENGINEERING_PROPOSAL_NOT_OWNER_APPROVED; owner_approval=null. Both supplied principal documents were read and compared. All12 website plans and4 packs have null selling prices, empty country_prices and UNPUBLISHED_DRAFT status. Their future Admin selectability is a proposed design, not an existing screen or database seed.

DECIDED NOW: individual selling prices must remain editable through Staff Admin. Missing approved amounts must not block design, or later separately authorized construction, of a safe draft-price management engine. PRICE-ENGINEERING and PRICE-COMMERCIAL-PUBLISH are separate. Editing “at any time” means authorized creation/change of a draft and prospective price versions, never rewriting an accepted contract or bypassing publication. No initial amount, provider, quota, page count or care promise is approved by this clarification. P01/P01A historical statements are preserved; only the overbroad reading of PRICE-01/R10-05 that required numerical selling prices before the editor could be built is superseded. Publication/money, technical-limit evidence and source-work authorization gates survive.

DECIDED AND PRESERVED: four families × Entry/Growth/Premium =12 annual website plans, not36 plans;4 audience packs; one complete intended Admin+Client/four-pack local review; Student12Toolbox+16Workspace positions=27 distinct tools via shared Career Kit; all58 feature IDs (56 REQUIRED/UX-01 PROPOSED/EXT-TEAMS PARTIAL). Initial website creation, eligible real domain and real hosted mailbox service, matching pack included12months, both clocks from Billing-verified purchase, no construction-delay extension. Live Root + active website + valid current Admin pack + permissions required for tools; one active pack/Root, paid verified switch, manual renewal/no automatic customer charge. No tools-only account or free-by-null plan.

DECIDED: owner accepts exact quote; Operations records Pending evidence, independent Billing verifies Paid; staff creates Root only afterward, once. Two immutable owner-only design/content and final project approvals; neither authorizes deployment. Both-owner+staff Root transfer, origin invoice/support history, guardian/minor13–17 privacy, temporary supervised support, lawful rights/deletion exceptions and Operations-maker/distinct-SuperAdmin-checker nonfinancial correction remain unchanged. Admin owns staff/commercial/Root/project/approval/support truth; Client owns customer/member/guardian/private workspaces. Private R2 via narrowly authenticated Workers. Password+WebAuthn MFA for everyone under AUTH-2026-10-22-01; email contact/notifications only. Public Core0001–0016 / Analytics0001–0002 frozen, no public0017. Historical Public CMS/MOTION and later isolated client CMS/factory are preserved; the DISTINCT new EN/AR public company site has NO CMS and only its secured request-wizard handoff/notice boundary.

## 2. Common tier inclusions — PROPOSED, not customer promises

The following numbers are copied from the proposal. Offer signoff, technical feasibility, real provider eligibility and cost evidence remain required. They are website deliverable/managed-labor candidates, not private-workspace technical quotas. All tiers retain the full entitled matching pack and security/privacy floor.

| Proposed inclusion | Entry | Growth | Premium |
|---|---|---|---|
| Informational pages at contracted handoff | up to5 | up to10 | up to20 |
| Initial website languages | 1 | up to2 | up to2 |
| Real hosted mailbox accounts | 1 | 2 | 3 |
| Eligible standard domain allowance | 1 | 1 | 1 |
| Initial design revision cycles | 1 | 2 | 3 |
| Monthly care labor budget, NOT_MEASURED | 0.5h | 1h | 2h |
| Initial creation once / matching pack included12months | preserved decided structure | same | same |

Proposed domain count1 concerns the contracted domain; annual renewal must specify renewal of that same domain, not promise a newly registered domain each year. TLD eligibility, registration/renewal/redemption, registrant ownership, actual mailbox storage/accounts and supplier terms remain TBD. Forwarding or transactional email is not a hosted user mailbox. No vendor is selected. Language/page translation counting and whether a detail template represents multiple pages must be explicit in the versioned quote. Client/Admin native EN/AR and the new corporate site's EN/AR remain independent requirements, unaffected by a client website's proposed language allowance. Independent client CMS is a later real delivery dependency; these definitions do not deliver it. Revision-cycle allowances do not replace either immutable project approval. Care is bounded proposed labor, not unlimited redesign/content,24/7 staffing, resolution/uptime guarantee or SLA.

Provisional first-human-response table (business hours only, NOT a published commitment):

| Priority | Entry | Growth | Premium |
|---|---|---|---|
| Critical | 4h | 2h | 1h |
| High | 8h | 4h | 2h |
| Normal | 16h | 8h | 4h |
| Low | 32h | 16h | 8h |

Provisional calendars: Lebanon Asia/Beirut and UAE Asia/Dubai Mon–Fri09:00–17:00; Iraq Asia/Baghdad, Bahrain Asia/Bahrain, Kuwait Asia/Kuwait, Oman Asia/Muscat, Qatar Asia/Qatar, Saudi Arabia Asia/Riyadh Sun–Thu09:00–17:00. Actual holidays, DST, staffing, escalation, cost and legal support terms are unverified. Nothing here is a customer response/resolution or availability promise.

## 3. Exact12 draft plan identities and complete proposed content inventories

Plan codes and EN/AR names below are proposal identities; future stable identity/version policy needs review. Every row has initial_price_usd=null, annual_renewal_price_usd=null, approved_offer_terms_version=null, country_prices={}, UNPUBLISHED_DRAFT. Initial and renewal terms are12months under the decided annual model, with the corresponding family pack included for the first12months. Every numerical build-hour entry is NOT_MEASURED and not a quote, wage or delivery deadline. All suggested pages are editorial concepts requiring customer scoping, lawful material and evidence for claims; not a requirement to create unused pages.

### WEB_STUDENT_ENTRY — Student Entry / الطالب — الأساسية

Credible first educational/personal presence with a focused portfolio.

PROPOSED: ≤5 pages; ≤1 initial language(s); 1 hosted mailbox(es); 1 eligible standard domain; 1 revision cycle(s); 0.5h/month care; 6h preliminary build estimate, NOT_MEASURED. Scope type: informational managed website, initial creation once; reviewed eligible standard TLD only.

Complete suggested sections: Home / introduction; About & educational background; Skills / achievements; Selected projects or portfolio; Contact.

### WEB_STUDENT_GROWTH — Student Growth / الطالب — النمو

Richer evidence, structured projects and bilingual-ready personal profile.

PROPOSED: ≤10 pages; ≤2 initial language(s); 2 hosted mailbox(es); 1 eligible standard domain; 2 revision cycle(s); 1.0h/month care; 12h preliminary build estimate, NOT_MEASURED. Scope type: informational managed website, initial creation once; reviewed eligible standard TLD only.

Complete suggested sections: Home; About & education; Portfolio index; Individual project profiles; Skills / awards; CV / experience; Contact; Optional academic showcase; Study or experience timeline; Updates / news.

### WEB_STUDENT_PREMIUM — Student Premium / الطالب — المتميزة

Advanced portfolio/case-study hierarchy, polished editorial/motion treatment and complex structured content.

PROPOSED: ≤20 pages; ≤2 initial language(s); 3 hosted mailbox(es); 1 eligible standard domain; 3 revision cycle(s); 2.0h/month care; 25h preliminary build estimate, NOT_MEASURED. Scope type: informational managed website, initial creation once; reviewed eligible standard TLD only.

Complete suggested sections: Advanced personal identity home; Education & qualifications; Portfolio categories; Detailed project/case-study pages; Skills & achievements; Research/publications showcase; Experience timeline; CV; Community/extracurricular highlights; Media/testimonials with evidence; Opportunities/contact; Other reviewed pages up to tier ceiling.

### WEB_PROFESSIONAL_ENTRY — Professional Entry / المحترف — الأساسية

Concise professional identity and contact website.

PROPOSED: ≤5 pages; ≤1 initial language(s); 1 hosted mailbox(es); 1 eligible standard domain; 1 revision cycle(s); 0.5h/month care; 8h preliminary build estimate, NOT_MEASURED. Scope type: informational managed website, initial creation once; reviewed eligible standard TLD only.

Complete suggested sections: Home / positioning; Expertise; Experience & credentials; Selected work; Contact.

### WEB_PROFESSIONAL_GROWTH — Professional Growth / المحترف — النمو

Detailed expertise and proof of work with structured case studies.

PROPOSED: ≤10 pages; ≤2 initial language(s); 2 hosted mailbox(es); 1 eligible standard domain; 2 revision cycle(s); 1.0h/month care; 16h preliminary build estimate, NOT_MEASURED. Scope type: informational managed website, initial creation once; reviewed eligible standard TLD only.

Complete suggested sections: Home; Professional profile; Services / expertise; Case studies; Experience; Credentials; Selected media / talks; Testimonials with evidence; Contact; Insights / updates.

### WEB_PROFESSIONAL_PREMIUM — Professional Premium / المحترف — المتميزة

Multi-service professional presence, complex conversion-oriented content and polished case-study system.

PROPOSED: ≤20 pages; ≤2 initial language(s); 3 hosted mailbox(es); 1 eligible standard domain; 3 revision cycle(s); 2.0h/month care; 28h preliminary build estimate, NOT_MEASURED. Scope type: informational managed website, initial creation once; reviewed eligible standard TLD only.

Complete suggested sections: Conversion-oriented home; Multiple expertise areas; Service detail pages; Case study categories; Detailed case studies; Credentials & recognitions; Speaking / publications; Testimonials with consent; Insights; Professional contact; Other reviewed pages up to tier ceiling.

### WEB_ENTREPRENEUR_ENTRY — Entrepreneur Entry / رائد الأعمال — الأساسية

Launch-ready brand story and service/offer explanation.

PROPOSED: ≤5 pages; ≤1 initial language(s); 1 hosted mailbox(es); 1 eligible standard domain; 1 revision cycle(s); 0.5h/month care; 10h preliminary build estimate, NOT_MEASURED. Scope type: informational managed website, initial creation once; reviewed eligible standard TLD only.

Complete suggested sections: Home / venture story; What we offer; Founder / team story; Progress / milestones; Contact.

### WEB_ENTREPRENEUR_GROWTH — Entrepreneur Growth / رائد الأعمال — النمو

Deeper offer structure, market story and launch content.

PROPOSED: ≤10 pages; ≤2 initial language(s); 2 hosted mailbox(es); 1 eligible standard domain; 2 revision cycle(s); 1.0h/month care; 20h preliminary build estimate, NOT_MEASURED. Scope type: informational managed website, initial creation once; reviewed eligible standard TLD only.

Complete suggested sections: Home; Problem / mission; Offer / product; Use cases; Founder / team; Milestones; Proof / testimonials with evidence; FAQ; Updates; Contact.

### WEB_ENTREPRENEUR_PREMIUM — Entrepreneur Premium / رائد الأعمال — المتميزة

Advanced narrative, multiple offers, structured launch campaigns and stronger on-site conversion storytelling.

PROPOSED: ≤20 pages; ≤2 initial language(s); 3 hosted mailbox(es); 1 eligible standard domain; 3 revision cycle(s); 2.0h/month care; 35h preliminary build estimate, NOT_MEASURED. Scope type: informational managed website, initial creation once; reviewed eligible standard TLD only.

Complete suggested sections: Launch-oriented home; Product/offer categories; Individual offer details; Use cases; Founder/team; Traction / evidence; Case studies; FAQ; Media / press; Launch updates; Contact; Other reviewed pages up to tier ceiling.

### WEB_BUSINESS_ENTRY — Business/Organization Entry / شركة أو مؤسسة — الأساسية

Professional basic institutional presence with validated organization details.

PROPOSED: ≤5 pages; ≤1 initial language(s); 1 hosted mailbox(es); 1 eligible standard domain; 1 revision cycle(s); 0.5h/month care; 12h preliminary build estimate, NOT_MEASURED. Scope type: informational managed website, initial creation once; reviewed eligible standard TLD only.

Complete suggested sections: Home; About organization; Services / products overview; Trust / credentials; Contact.

### WEB_BUSINESS_GROWTH — Business/Organization Growth / شركة أو مؤسسة — النمو

Multi-service company storytelling, case studies and trust information.

PROPOSED: ≤10 pages; ≤2 initial language(s); 2 hosted mailbox(es); 1 eligible standard domain; 2 revision cycle(s); 1.0h/month care; 26h preliminary build estimate, NOT_MEASURED. Scope type: informational managed website, initial creation once; reviewed eligible standard TLD only.

Complete suggested sections: Home; About; Service categories; Service detail pages; Industries; Case studies; Team / leadership; Trust / certifications; Locations or coverage; Contact.

### WEB_BUSINESS_PREMIUM — Business/Organization Premium / شركة أو مؤسسة — المتميزة

Complex corporate information architecture, multilingual polish, case studies and structured service hierarchy.

PROPOSED: ≤20 pages; ≤2 initial language(s); 3 hosted mailbox(es); 1 eligible standard domain; 3 revision cycle(s); 2.0h/month care; 45h preliminary build estimate, NOT_MEASURED. Scope type: informational managed website, initial creation once; reviewed eligible standard TLD only.

Complete suggested sections: Advanced organization home; Company/about; Multiple service lines; Service detail pages; Industry pages; Case studies; Leadership / team; Locations / coverage; Compliance / trust claims with proof; Insights / news; Careers informational page; Contact; Other reviewed pages up to tier ceiling.

No unreviewed ecommerce, booking, payment integration, arbitrary plugin/CMS, AI generation, regulatory claim or large third-party integration is included automatically. Additional needs require a bounded separately quoted service, not a silently enlarged tier. No fake testimonials, certifications or traction. No automatic public exposure of private Portfolio/Research/other tool records.

## 4. Exact4 draft audience packs

All monthly_prepaid_price_usd=null, annual_prepaid_price_usd=null, country_prices={}, UNPUBLISHED_DRAFT. One valid active pack per Root; no automatic renewal. Included matching first-year pack is a contractual inclusion in the paid website purchase, NOT a separately published zero-price pack. Alternative paid switch needs an accepted approved quote and verified settlement with exact credit/term policy; old pack data remains private and inactive under preserved retention/rights rules, not deleted or freely reusable across Roots.

### PACK_STUDENT — Student

All 12 Student Toolbox and 16 Student Workspace positions (27 distinct capabilities, one shared Career Kit), all majors; validated PDF/DOCX/ICS where scoped; private storage, revision, export, sharing controls.

Complete capability inventory: CV Studio; Portfolio Builder; Digital Card; QR Studio; Link Hub; Achievement Kit; Career Kit (shared); Email Signature; Project Share; Personal Brand Kit; Contact Card; Root Export; Semester; Study Planner; Exam Countdown; Project Desk; Study Timer; Goals; Application Tracker; Cover Letter Guide; Skills Passport; Career Roadmap; Learning Log; Experience Journal; Research Shelf; Campus Calendar; Student Budget.

### PACK_PROFESSIONAL — Professional

Curated professional reuse of relevant existing Toolbox/Career Kit, CV, portfolio, achievements, applications, career roadmap, goals, skills and learning tools. No duplicated personal record engines. Exact pack visibility configuration reviewed.

Complete capability inventory: CV and portfolio reuse; Achievements/evidence; Career Kit; Applications and cover letter; Skills Passport; Career Roadmap; Goals and Learning Log; Professional digital card, links and contacts; Exports/shares.

### PACK_ENTREPRENEUR — Entrepreneur

Four bounded founder tools plus entitlement-controlled reuse of reviewed brand, portfolio, links, digital card, QR and export capabilities. Not CRM/accounting/autonomous builder.

Complete capability inventory: Venture Profile & Brand Brief; Offer Planner; Pitch One-Pager; Launch Planner; Reviewed shared identity and brand tools.

### PACK_BUSINESS — Business/Organization

Digital Asset Register and Marketing/Content Request Briefs plus reviewed shared company brand/link and core care screens. No credential vault or live website CMS replacement.

Complete capability inventory: Digital Asset Register; Marketing / Content Request Briefs; Reviewed shared brand/QR/link tools; Multi-Root core views and service requests.

Student tools are not split by website tier or major; Career Kit is the same engine in both menu positions. Professional exact reuse/visibility configuration still needs review; no duplicated record engines. Entrepreneur includes ENT-01..04 and reviewed reuse; Business BUS-01..02 and reviewed reuse. No CRM/accounting/autonomous website builder, generic vault or working client CMS is implied. UX-01 remains proposed and full enterprise team-seat expansion is not approved.

## 5. Future Admin screens, roles and logical operations — all PROPOSED

The owner-decided capability is staff-editable selling prices. Exact grants and dual-review policy below are engineering proposals; customer account-owner status does not confer Staff Admin commercial authority. Super Admin does not automatically override independent Billing, client consent or separation of duties. All mutations require server-side object/property/function scope, current staff identity, fresh WebAuthn step-up where sensitive, version/CAS, idempotency and audit. No email factor or helpdesk bypass.

| Proposed screen / logical operation | Proposed staff access | Controls / refusal |
|---|---|---|
| Catalogue and plan/pack detail; draft inclusions | Explicit commercial.read / commercial.draft capability assigned after review; Operations may propose scope, not independently publish | Stable product identity separate from content/offer revision;12/4 completeness; archived referenced versions undeletable. Care/page/mailbox proposals cannot be labeled DECIDED or publicly sold without signoff. |
| Price book and country matrix; save draft / copy version | Authorized commercial drafter; publish capability distinct | Initial site, annual renewal, monthly/annual pack, paid switch and custom service variants; USD base or explicitly approved market overrides; null allowed in draft. Expected revision rejects lost update; typed reason for unquotable fields. |
| Cost evidence / technical safety dashboard | Restricted commercial/Billing reviewers; customer-safe projections only | Dated source rates/evidence, units and unmeasured assumptions; no credentials/private staff costs exposed to Client. Selling-price changes cannot edit technical security ceilings or mark benchmarks passed. |
| Review / approve / publish / effective schedule / withdraw | Proposed restricted commercial.publish grant assigned to authorized Super Admin; separate reviewer for material changes proposed, not decided | Owner commercial signoff reference, actual terms/supplier eligibility and fresh action-bound WebAuthn; record reviewer if required; no maker can bypass approved review policy. Review applicability of ASVS V2.3.5 multi-user control before implementation. |
| Impact preview / prospective rollback | Read impact within scope; authorized publisher creates successor | Show new/future quote and renewal impacts versus protected accepted contracts. Rollback copies values into a NEW version; no rewrite/delete of published history; never renew or charge from a price schedule. |
| Quote desk / reissue / acceptance history | Operations with explicit issue grant; customer owner separately accepts | Server chooses exact published variant/market/effective version; immutable amount/inclusions/tax/terms/expiry/recipient snapshot. Draft/null cannot issue binding quote. No staff impersonation of owner; changed quote requires new acceptance. |
| Payment evidence / verification / invoice / receipt | Operations Pending evidence only; independent Billing verifies settlement, actor independence preserved | No browser-defined price/Paid; settle against exact accepted quote/currency. Mismatch, missing settlement or repeated events remain Pending/denied. Price edit is not financial correction; record new corrective evidence under reviewed policy. |
| Renewals and paid pack-switch desk | Authorized Operations prepares, owner accepts, independent Billing verifies | Approved new offer and exact dates/credit/proration; no stealth repricing, autocharge, duplicate active packs or restart from delayed go-live. Changed vendor cost alone does not change a contract. |
| Audit / reconciliation / regional availability | Authorized audit/operations roles by scope; nonfinancial maker/checker remains separate | Append-oriented actor/reason/version/diff/proof/correlation; no token/credential/PII dumps. Reconcile authoritative Admin outbox and Client dedupe; no direct cross-DB truth editing. |

Proposed state vocabulary: DRAFT → REVIEW_PENDING → APPROVED → PUBLISHED → RETIRED/WITHDRAWN. A price-bearing PUBLISHED revision cannot be edited in place. APPROVED and PUBLISHED are application business states to be proven later, not statuses assigned to this package. A scheduled revision is invisible/unquotable until its reviewed effective window. Prevent overlapping active variants for the same product/period/market/currency; immutable publish receipt, expected revision, unique idempotency key and digest prevent split-brain edits. Signing/version digests, key lifecycle and exact schema remain design proposals, not a generated signing key or approved cryptographic mechanism.

## 6. Typed monetary and country contract — proposed safe failure

Conceptual monetary state is Unpriced(reason) OR DraftAmount(value,currency,exponent,revision) OR PublishedAmount(approved immutable price-book/terms/market/effective-window). Missing/null is not an arithmetic zero and is not a publishable value. Use reviewed integer minor-unit/decimal-safe storage, explicit currency/exponent and overflow/range rules; never binary floating-point money or a blanket two-decimal assumption. Reject negative/NaN/infinity, empty string, string-null, excessive precision, overflow and currency/term mismatch. All current site/pack offers are paid: zero is refused unless a later separately approved explicit commercial policy exists; none exists now. Approved tax exemption/zero tax, if later applicable, is explicit evidence, not a missing-rule default. Unknown tax, FX, region eligibility or expiry cannot be guessed as zero or a spot rate.

Supported-market intent is LB/IQ/BH/KW/OM/QA/SA/AE; it does not prove current supplier/legal eligibility. Distinguish website language, interface locale, customer market, price currency, tax jurisdiction and service calendar. An absent or draft country override must not silently fall back to USD; only an explicitly approved market/currency fallback rule permits that exact published variant. Pin authorized rate source, effective/valuation time, expiry, currency precision, rounding sequence, tax-inclusive/exclusive treatment and jurisdiction rule version; missing/stale policy is Unquotable. Rendering Arabic numerals/local dates cannot recalculate amounts. Staff cannot use locale selection to obtain another region's entitlement.

Suggested typed refusals: PRICE_UNPUBLISHED, AMOUNT_MISSING, TERMS_UNAPPROVED, MARKET_POLICY_MISSING, CURRENCY_UNSUPPORTED, FX_OR_TAX_UNVERIFIED, PROVIDER_ELIGIBILITY_UNVERIFIED, PRICE_VERSION_CONFLICT, QUOTE_EXPIRED, IDEMPOTENCY_CONFLICT, AUTHORIZATION_DENIED. No numeric total, Paid, Active or successful invoice follows a refusal. Publication checks are variant-aware but must establish all material contractual inclusions/initial/renewal terms, not silently omit an unpriced future obligation. No live offer/quote is enabled now.

## 7. Quote, contract, renewal and edit scenarios

Quote issuance pins product ID + inclusion revision, price-book/version/market/currency, line items/rounding/taxes, approved terms/rate sources, exact customer/account/Root request, proposed service/pack periods, accepted owner identity/action/version and expiry. Billing-verification creates the authoritative purchase timestamp: the periods actually activated must be disclosed/bound to that event, not an unreviewed go-live date or a stale quote illustration. Customer-visible dates and acknowledgment need an exact contract. Purchase/period/entitlement events are durable, idempotent and authoritative in Admin; Client projections cannot mint Paid or authorize tools from stale data. Changes within one D1 commit atomically with command/digest/outbox; consumer dedupes and acknowledges in its own DB. Cross-D1 operations are Pending/fail-closed until reviewed confirmation; no distributed transaction is asserted.

| Price edit / lifecycle scenario | Required proposed behavior |
|---|---|
| Owner edits initial Student Entry price in Admin | Save new draft, review and publish successor for future quotes; existing accepted terms/invoices/payments unchanged. No selling amount provided here. |
| Owner edits annual renewal price | Future manually accepted renewal quotes may use the new approved version; already-contracted price guarantees/renewal obligations remain as written. No permanent grandfathering or stealth change is invented. |
| Edit pack monthly/annual or switch charge | Publish exact period/country variant and credit rules; old accepted period unchanged; alternative pack activates only after owner acceptance and independent verified payment. At most one active pack, never prorate using invented arithmetic. |
| Unpublished/null amount or missing region tax/FX | Draft engine still functions; public offer, binding quote, invoice/Paid and Root activation refuse with typed Unquotable reason. No null-as-zero or unapproved currency fallback. |
| Future-effective price arrives while draft quote open | Quote draft must select/revalidate the reviewed effective version at issuance. Issued quote is immutable; edits require explicit supersession/reissue and new owner acceptance. |
| Unaccepted unexpired quote versus price retirement | Exact honor-until-expiry versus lawful withdrawal rule needs owner term approval. No automatic substitution. Already accepted rights are preserved; if unable to honor, block and expose a reviewed cancellation/reissue process rather than mutate history. |
| Accepted quote then cost/provider changes | Do not recalculate accepted money or retroactively change inclusions. Supplier inability is an operational exception/Pending matter under reviewed contract; no guessed provider completion. |
| Two staff save/publish concurrently or replay command | CAS/unique active-window constraints and same-ID/same-digest idempotency; changed digest conflicts. No last-write-wins publication or duplicate Root/purchase. |
| Operations uploads payment evidence | Pending only; Billing independently verifies exact accepted settlement once. Neither publication nor uploaded evidence grants entitlement. |
| Root launches after purchase or website/pack expires | No delay extension; active period still starts purchase. Tools remain locked unless genuinely Live + active website + current pack + permission. Renewal/support/lawful-rights paths do not require a tool entitlement bypass. |
| Pack switch or Root transfer amid jobs/expiry | Revalidate current Admin grant/ownership at operation and delivery, revoke old capabilities, bind both owners/staff consent for transfer; originals/history privacy retained. G-RACE ordering/linearization remains unresolved technical contract. |
| Rollback, invoice dispute or financial correction | New published revision for prospective rollback; append/supersede legal financial records through approved Billing correction policy, never overwrite. No existing refund/credit amount assumed. |
| Admin unavailable, stale Client projection or scanner fails | Deny protected grant/data/delivery or show truthful Pending/Unknown; never use a low/zero price, stale Paid, unscanned file or higher tier to bypass security. |

## 8. Unfinished approval and stopping boundary

Needs offer/technical signoff: all page/language/mailbox/revision/care/build-hour values and content inventories; exact Professional/shared-pack visibility and output contracts; actual terms/suppliers/TLD/mailbox eligibility; regional tax/FX and unaccepted-quote retirement policy; publication grants/dual-review and WebAuthn assurance design. Actual prices remain editable future Admin data, all null/unpublished here. Numerical common quotas are NOT_MEASURED candidates, never payable security exceptions. No catalogue JSON/database seed or application source is produced.

PRICE-ENGINEERING can be a later bounded source work order with safe unpriced drafts and deterministic TEST_ONLY money fixtures explicitly authorized then; numerical commercial selling prices and real providers are not prerequisite to that engine. This task authorizes no such work order. PRICE-COMMERCIAL-PUBLISH remains blocked for real offers/quotes/renewals/switches until exact approved numbers/terms/eligibility are published. Preserve PKG-01 separately; no historical report or manifest is repaired. STOP after the external review documents.

PERMISSION_TO_MODIFY_SOURCE=NO
PERMISSION_TO_CREATE_MIGRATIONS=NO
IMPLEMENTATION_SCOPE_APPROVAL=NOT_GIVEN
NEXT_STAGE=OWNER_SCOPE_FREEZE_REVIEW_PENDING
