# iDigitalRoot — Verification and Conflict Closure, 21 October 2026

**READ-ONLY DOCUMENTATION AUDIT · NOT IMPLEMENTATION PERMISSION**

## Direct answer

The incorrect assumption that the new bilingual motion public site needs a CMS is **resolved in the working documentation**. Every original feature ID and the explicitly recorded decision IDs from R13–R26 are now traceable, with the remaining uncertainty accurately distinguished from approvals. **The original October 14 archive's binary remains inaccessible** from this runtime: existence is verified but a fresh complete CRC/hash of its raw bytes cannot be claimed. The October 16 handoff, original source-authority copies and historical original-master scan evidence were all independently inspected.

## Verification results

| Check | Result |
|---|---|
| October 16 handoff ZIP CRC | **PASS** |
| Handoff `SHA256SUMS.txt` verified | **74/74 PASS** |
| Copied historical authority files from Oct 14 master | **55/55 PASS** |
| Original original feature IDs | **58/58 present in current v0.3** |
| Exact Round 13–26 decision IDs in cumulative v0.15 | **77/77 reference PASS** |
| Rounds 1–12 | Grouped narrative corroboration only; no fabricated exact historical choice IDs |
| Original historical master report | SHA256 `f1ea6c341baf3c81afa5b797ed09beb9b1a400325338e8a42ed671c2a5f23b20`; earlier scan reported ZIP CRC PASS, 99 nested archives, 3417 entries; **historical assertion only** |
| Original master current GitHub file | Exists (blob SHA-1 `850baa1cfb3db0d4f15a18f6667b8a2abbce676e`) |
| Original master raw binary new checksum | **BLOCKED**. GitHub connected file reader returns empty content for binary, blob reader fails UTF-8, raw download denied/unavailable; don't mark PASS. |
| New Admin/Client implemented/assessed | **NOT BUILT / NOT_RUN** |

## What was actually fixed

1. Replaced conflicting newly requested Public CMS requirement with bilingual four-audience **no-CMS** public site, validated lead submission and notification to `visitors@idigitalroot.com`. Historical approved Public CMS sources remain untouched; independent client-site CMS requirements remain future scope.
2. Added **18 explicit active-vs-historical precedence decisions** in unified scope Appendix C: including joint four-pack release vs student-first, two-D1 authority vs old shared conceptual D1, support images only, guardian data boundaries, 12-month paid construction grant clocks, 2 owner approvals, service transfer rules, separated historical support cases and invoice data, and provider-independent test email vs required real delivery.
3. Crosschecked every one of the original **58 feature inventory IDs**; distinguishes `UX-01` as PROPOSED and `EXT-TEAMS` PARTIAL, and does not pretend CMS-dependent `Open Website Admin` actually works.
4. Added **77 exact decision IDs from R13–R26** to a machine-readable traceability CSV with direct source document line references. R1–12 remain supported by decision-group summaries and original authority, **not invented exact IDs**.
5. Prepared original feature **acceptance matrix** with per-feature minimum acceptance, dependencies, `NOT_BUILT`/`NOT_RUN`, and separate owner signoff/release gates.
6. Preserved original seven security files/151 risk record targets/345 ASVS/54 test register directions and all frozen public D1 migrations; no prior PASS carried into new Admin/Client work.

## What cannot be genuinely fixed without missing evidence

**The connected GitHub reader does not deliver the full binary bytes of** `downloads/IDIGITALROOT_CODEX_MASTER_HANDOFF_2026-10-14_v1.1.zip`. The October 16 handoff explicitly labels that archive **NOT BUNDLED**, so its 55 exact copied authorities and the historical full-master PASS report do not cryptographically prove the current GitHub ZIP's SHA256. There is no accurate local substitute for fresh byte-level verification. This is an **external read-capability blocker, not a request for the owner to calculate hashes or debug the project**. The pre-source-work verification gate must retain `BLOCKED_BINARY` until an authorized binary-capable read or trusted exact-byte source is available.

Unapproved commercial prices, measured common quotas, production provider contracts, country legal reviews, data residency, and real QA/recovery remain `TBD/BLOCKED` rather than being forged into approved data.

## Source-provenance and limitation

Independent local tests: unzip CRC; checked `SHA256SUMS`; original 55 SHA256/byte counts; 58 feature IDs; explicit decision-ID references; documented policy inconsistency reconciliation. Documentation coverage is **not** complete application security evaluation or formal legal analysis. It cannot prove there is no contradiction in an unavailable file or a statement never captured in a source. The old source files are retained, not overwritten.

## Automatic preflight prepared

The package includes a read-only SHA256 and nested-ZIP CRC checker with a recorded original master SHA256. It was smoke-tested successfully against the **different** mounted October 16 handoff (2 archive layers, 426 entries). This establishes the checker is functional, not that the original October 14 master is verified. The execution agent must run it on the original after appropriate source access; no owner manual work or unsafe bypass.

## Recommended next controlled gate

Final owner review of this scope draft, then approval of **one bounded local implementation scope** once dependent prices/quantities and source preflight can be substantiated. Separate authority for providers, remote infrastructure, real customers and deployment. No changes now.
