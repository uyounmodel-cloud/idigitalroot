# iDigitalRoot — Commercial Catalogue, Entitlements and Billing Specification

**Discovery draft v0.15 · 21 October 2026 · NOT APPROVED FOR IMPLEMENTATION**

This is a documentation-only working specification. It reflects explicit owner answers through Round 25, combined with the verified attached `IDIGITALROOT_CLIENT_PANEL_BLUEPRINT_AND_AI_HANDOFF_2026-10-16_v1.2.zip` (CRC passed; 74 SHA256SUMS entries verified). It does not create application code, migrations, approved prices, provider contracts or release authority. The full original master companion remains an additional pre-source-work authority check.

## 1. Authority and notation

- **DECIDED** — explicit owner instruction or binding original constraint, as noted.
- **DRAFT PROPOSAL** — design suggestion requiring owner approval.
- **TBD** — missing commercial or operational decision.
- **BLOCKED** — dependent implementation or live release may not proceed until the specified decision/evidence is available.

Primary handoff sources: `CLIENT_PANEL_BLUEPRINT.md` §§ 2–3, 8–15, 17–18; `FEATURE_INVENTORY.csv` (58 inventory rows); `DISCOVERY_QUESTIONS.csv` (especially Q-015–Q-019, Q-027–Q-030, Q-034, Q-037); `authority/current/STUDENT_LAUNCH_SCOPE.md`; `QA_AND_RELEASE_GATES.md`. Original security baseline, master companion and current source remain binding at the appropriate gates.

## 2. Commercial principles — reconciled owner decisions

1. One Client Account may own several independent Digital Roots. Audience guides presentation, not permissions or entitlement. Accounts, staff and independent website CMSs retain their original authority boundaries.
2. Four audience-specific website plan families (Student, Professional, Entrepreneur, Business/Organization), three tiers each (Entry, Growth, Premium): **12 paid website packages**.
3. **Website creation is included in the price of the paid website package** (R14-02); there is no separately billed first-build charge in the currently selected model. **There are no monthly website-creation plans** (R14-03). Model an initial paid **annual website-creation package** and an annually renewed website-service term; exact year-two service/renewal terms and prices are TBD.
4. **Every new paid website-creation package includes its matching audience tool pack for the first 12 months at no additional tool-pack charge** (R14-01, R15-01). Student website → Student pack, Professional → Professional, Entrepreneur → Entrepreneur, Business → Business. No other service is free. **The included-pack year begins at website-package purchase, not go-live** (R15-02). A customer may make a **paid** pack switch at any time during that year (R15-03); without paying for a switch, the complimentary matching pack remains until its first-year term ends. Exact paid-switch fees, new pack term alignment and treatment of the complimentary grant after paid switching are TBD.
5. All website tiers include an **actual registered domain and actual hosted mailbox** within the *paid* website package (R14-04, R15-05). Higher tiers have progressive provider-backed allowances; approved domain extensions, mailbox count/storage, registration holder, provider, territory and recovery procedures remain TBD. A forwarding rule or placeholder account is not a hosted mailbox. Managed care and website complexity differ by tier.
6. Technical quotas (storage, upload sizes, import/export/sharing resource ceilings) use a common baseline across all tiers; exact values need review and cost verification. Website deliverable scope and managed service can vary.
7. Four sellable audience tool packs: Student (mandatory 12 Toolbox and 16 Workspace positions, 27 distinct capabilities), Professional (approved profile), Entrepreneur (four new bounded tools and reusable capabilities), Business (two new tools and reuse). **At most one active pack per Root**. The no-extra-charge year-one pack **must match** the website-plan family. A **separately paid** pack may belong to another audience family, subject to explicit owner-approved substitution and one-pack uniqueness.
8. **Tool packs may be purchased for monthly or annual prepaid terms** after the included first-year period or for an explicitly approved paid pack switch. The **initial paid website service year starts immediately on purchase**, after the accepted quote and independently verified payment (R15-06), *not at go-live*. Included-pack time also starts at purchase. Website and normal paid pack periods can be independent; no auto-renewal or unaccepted charges. Tool use still requires a **live** Root, active website plan and valid pack entitlement (R4-03). Construction time consumes the complimentary benefit; **no extension is granted for construction delays** (R16-01), even if the Root becomes live late. Customer-facing quote/onboarding terms must clearly disclose the fixed purchase-based expiration date.
9. Tool work belongs to its originating Root. Owner-authorized paid pack switches during the included year are allowed; non-paying customers retain the original family-matched pack until year one ends. Pack switching preserves previous Root-bound records without silently re-entitling retired capabilities. The paid-switch price, term and remaining complimentary value are TBD.
10. USD base catalogue with country-specific, versioned quotes for Lebanon, Iraq, Bahrain, Kuwait, Oman, Qatar, Saudi Arabia and UAE; local invoicing, taxes, foreign exchange and market eligibility remain TBD.
11. Manual invoice and verified external settlement only: Operations may submit pending evidence; independent Billing verification is required before Paid or entitlement activation. Customer account owner alone accepts quotes/contract changes and project approvals. All interactions must be server-authorized and audited.
12. Private-by-default sharing, guardian-approved minor-data categories and authorized temporary Support access still apply. Indefinite-retention/no-voluntary-deletion preference is requested but cannot override applicable rights or law; affected release controls remain BLOCKED until resolved.
13. No integrated checkout, registrar/mailbox provisioning, live provider charges, source implementation, schema migration, deployment or new resource spending is authorized by this discovery.

## 2A. Round 13 reconciled with Round 14

| Earlier answer | Current interpretation |
|---|---|
| R13-01: first-year “free bundle” | **R14-01 supersedes ambiguous wording:** the **selected tool pack** is included **at no additional charge for year one with each new paid website-creation package**; no other service is declared free. |
| R13-02: website complexity / managed care distinguishes tiers | **Unchanged DECIDED**; deliverable definitions TBD. |
| R13-03: progressive domain/email | **R14-04 clarifies:** every tier includes domain/email allowances *within the paid package*; higher tiers include more. No separate free giveaway. |
| R13-04: audience-independent pack selection | **Qualified by R15-01**: the introductory pack matches the website family; separately paid replacement packs can be from another audience, with one-active-pack uniqueness. |
| R13-05: common technical quotas | **Unchanged DECIDED**; quantitative ceilings TBD. |
| R13-06: research-backed pricing method | **Method stays selected**. R14-05 clarifies **amounts will be entered and approved one by one later**, not automatically guessed or treated as a fully approved 12-plan price list now. |
| R11-03: website plans monthly and annual | **R14-03 supersedes website side:** no monthly website-creation plan; monthly/annual choice persists for tool packs. |
| R13-01 build-fee ambiguity | **R14-02 resolves:** creation is included in the paid website package; there is no separate initial construction fee in the selected model. |

## 2B. First-year tool-pack inclusion — pricing and entitlement contract (PARTLY DECIDED)

**Owner-decided:** Each paid website-creation package includes one tool pack for its first year without an additional tool-pack fee. The website-creation package itself remains paid. The normal pack has future month/year prices only when approved, and manual renewal is required; no automatic conversion into a paid pack.

**DECIDED in Round 15:** included pack = the Root's website family; 12-month promotional clock starts at website-package purchase, not site launch; website service year also starts immediately at paid purchase; complimentary pack may be replaced early only via a paid, owner-authorized switch. The website may still be under construction and therefore ineligible to use tools during part of the benefit period. Initial website purchase follows owner-accepted quote and independent Billing payment verification; the precise effective event/timestamp must be specified consistently in terms and in the transaction contract.

**DECIDED in Round 16:** construction delay never extends the first-year tool-pack grant; start and expiry remain tied to purchase even if the Root is still under construction.

**TBD before freezing terms:** (1) what qualifies as a **paid switch** (full new pack price, fixed switch fee, credit, new term) and treatment of the old included grant; (3) original benefit on cancellation/suspension and Root ownership transfer; (4) whether new paid pack periods start at switching or another contract date; (5) first-year end reminders; (6) quote presentation, tax/accounting treatment and exceptional refunds; (7) provider-backed domain/mailbox service entitlements and separate annual renewal obligations. No website-creation monthly plan is authorized.

**Safety rules:** Assign a separate versioned `included_pack_grant` to the exact Root, account, signed accepted website creation order and pack version, with one-active-pack uniqueness. Record the included grant against the immutable website-package purchase event only after owner acceptance and independent payment verification; prohibit tool use until the Root is live. Require idempotent issuance and audited expiry, renewal and replacement. A zero additional pack charge cannot be forged into a zero website price or a perpetual entitlement.

## 2C. Round 15 decision ledger — explicit owner answers

| ID | Owner choice | Binding discovery interpretation | Open boundary |
|---|---|---|---|
| R15-01 | B: Complimentary pack matches website family | Family-matched pack only for first 12 months of each newly purchased annual website-creation package | No complimentary alternate-family selection |
| R15-02 | B: Clock starts with website purchase | Promotional year starts at purchase, not site go-live | Purchase/effective timestamp must be contract-defined and consistent with Billing verification |
| R15-03 | C: "anytime if paid, or else it will be untill first year ends" | Customer may pay to switch audience packs any time; otherwise family-matched included pack stays through its year | Exact switch charge, new term, handling of unused grant and old-work access TBD |
| R15-04 | A: Renewal covers continued website service and managed care | Annual renewal does not repeat ordinary initial creation | Care hours, provider obligations and major redesign/change pricing TBD |
| R15-05 | A: Registered domain + hosted mailbox | These are real tier-included provider services, not mere placeholders or forwarding-only products | Actual provider, counts/storage/registration rights and restoration TBD |
| R15-06 | B: Pay after quote acceptance; term begins immediately | Paid first website service year starts on the eligible paid purchase event, including during construction | Exception/refund and late-delivery terms TBD |

**Reconciliation notes:** (i) R15-01 narrows R13-04 **only for the complimentary first-year benefit**: paid pack purchases can still cross audience families. (ii) R15-02/R15-06 are consistent with annual paid website packages, but must not bypass the prior R4-03 rule prohibiting tool use until a site is live. (iii) R15-03 allows a paid early switch, not a free early switch; no price/credit is presumed. (iv) R15-05 changes the unresolved "mailbox or forwarding" choice to actual mailbox service. (v) Domain and mailbox setup must never be presented as done until real external-provider verification after separately approved provider actions.

## 3. Website creation catalogue — 12 paid annual variants

Website-creation packages have **no monthly purchase term**. Initial-year website creation is included in the package charge. The subsequent annual website-service renewal price is separate and is also unapproved. **All prices below are TBD, never USD 0/unlimited. The included matching pack is priced as an explicit no-additional-charge contractual benefit, not as a free website or a perpetual grant.**

| Provisional catalogue ID | Family | Tier | Initial paid year incl. creation (USD) | Next annual service renewal (USD) | Included year-one pack | Domain/email and care bundle | Technical quota |
|---|---|---|---|---|---|---|---|
| SITE-STU-E | Student | Entry | TBD | TBD | Student matching pack, 12 months, no extra pack charge | Registered domain + hosted mailbox; allowances TBD | COMMON-BASE TBD |
| SITE-STU-G | Student | Growth | TBD | TBD | Student matching pack, 12 months, no extra pack charge | Registered domain + hosted mailbox; allowances TBD | COMMON-BASE TBD |
| SITE-STU-P | Student | Premium | TBD | TBD | Student matching pack, 12 months, no extra pack charge | Registered domain + hosted mailbox; allowances TBD | COMMON-BASE TBD |
| SITE-PRO-E | Professional | Entry | TBD | TBD | Professional matching pack, 12 months, no extra pack charge | Registered domain + hosted mailbox; allowances TBD | COMMON-BASE TBD |
| SITE-PRO-G | Professional | Growth | TBD | TBD | Professional matching pack, 12 months, no extra pack charge | Registered domain + hosted mailbox; allowances TBD | COMMON-BASE TBD |
| SITE-PRO-P | Professional | Premium | TBD | TBD | Professional matching pack, 12 months, no extra pack charge | Registered domain + hosted mailbox; allowances TBD | COMMON-BASE TBD |
| SITE-ENT-E | Entrepreneur | Entry | TBD | TBD | Entrepreneur matching pack, 12 months, no extra pack charge | Registered domain + hosted mailbox; allowances TBD | COMMON-BASE TBD |
| SITE-ENT-G | Entrepreneur | Growth | TBD | TBD | Entrepreneur matching pack, 12 months, no extra pack charge | Registered domain + hosted mailbox; allowances TBD | COMMON-BASE TBD |
| SITE-ENT-P | Entrepreneur | Premium | TBD | TBD | Entrepreneur matching pack, 12 months, no extra pack charge | Registered domain + hosted mailbox; allowances TBD | COMMON-BASE TBD |
| SITE-BUS-E | Business | Entry | TBD | TBD | Business matching pack, 12 months, no extra pack charge | Registered domain + hosted mailbox; allowances TBD | COMMON-BASE TBD |
| SITE-BUS-G | Business | Growth | TBD | TBD | Business matching pack, 12 months, no extra pack charge | Registered domain + hosted mailbox; allowances TBD | COMMON-BASE TBD |
| SITE-BUS-P | Business | Premium | TBD | TBD | Business matching pack, 12 months, no extra pack charge | Registered domain + hosted mailbox; allowances TBD | COMMON-BASE TBD |

**Provisional catalogue IDs are not approved technical API identifiers.** Build/revision/language/service complexity, domain and mailbox counts, provider coverage and care commitments are not yet set. The website package is not a monthly SaaS website-creation offer, and the first-year pack does not make the paid website free. Annual renewals pay for continued website service/managed care rather than repeating ordinary initial creation (R15-04); detailed domain/mail/support inclusions and numerical prices remain TBD.

## 4. Tool-pack catalogue — four sellable packs, with year-one inclusion

| Provisional pack ID | Capabilities | Normal paid monthly USD | Normal paid annual USD | First eligible year with a new paid website |
|---|---|---|---|---|
| PACK-STU | Full Student Toolbox 12 + Workspace 16 positions (27 capabilities; one shared Career Kit) | TBD | TBD | Included for first 12 months only with Student website creation; paid switch possible |
| PACK-PRO | Approved full Professional profile and shared engines | TBD | TBD | Included for first 12 months only with Professional website creation; paid switch possible |
| PACK-ENT | Four Venture/Offer/Pitch/Launch additions plus approved reuse | TBD | TBD | Included for first 12 months only with Entrepreneur website creation; paid switch possible |
| PACK-BUS | Asset Register + Marketing/Content Request Briefs plus approved reuse | TBD | TBD | Included for first 12 months only with Business website creation; paid switch possible |

One active pack per Root. The first-year included pack must match the website family. Cross-audience replacement is possible through an owner-approved **paid** switch during the benefit year; without payment the included pack remains until the first-year term ends. Exact switch financial terms are TBD. After the first-year benefit, **monthly or annual prepaid pack offers** are available only through a versioned owner-accepted renewal and independently verified external payment. An active website plan alone does not renew a pack. Previous Root-bound work is retained but remains subject to actual entitlements, suspension, privacy and law.

## 5. Common quota specification — quantities NOT DECIDED

Proposed fields to quantify and cost-check, with explicit units and measured enforcement:

| Limit dimension | Draft unit | Value | Enforcement context |
|---|---|---|---|
| Private stored objects / bytes | count + GiB per Root | TBD | Private R2, controlled upload/export, owner/account scope |
| Single imported Office document | MB / file; allowlist by feature | **10 MB DOCX/XLSX/PPTX; 2 MB CSV/ICS** (R20-06 initial ceilings) | Quarantine, type/content verification, parser/resource bounds; byte-unit and runtime feasibility TBD |
| Aggregate import batch | MB / batch | **25 MB maximum** (R20-06 initial ceiling) | Server-side before parse; decompressed/record limits still TBD |
| Imported spreadsheet/calendar rows/events | records/file and files/month | TBD | CSV/XLSX/ICS size, formula and date/injection controls |
| Generated document exports | jobs/month + maximum output bytes | TBD | Per-user/Root resource controls, timeout/rate/cost budgets |
| Live share grants | simultaneous links/Root; expiry policy | TBD | Revocable scoped sharing, no default public access |
| Project support/marketing requests | submissions/month/Root | TBD | Staff capacity and abuse limits, not a fake instantaneous service |
| Site-owned content allowances | pages, languages, supported capabilities | TBD | Determine whether tier differentiator vs uniform technical quota |
| Mailboxes, domain allowances, care | count/period and support definition | TBD BY TIER | Only after providers/terms/real operations are approved |
| Concurrent collaborators | named memberships/account or Root | TBD | Must not be interpreted as shared login or auto-granted staff rights |

`COMMON-BASE` applies uniformly to **technical resource limits** across every audience website tier (R12-03 + R13-05). Website pages, localization deliverables, design complexity, revision counts, domain/mailbox and care allowances may vary by tier. A paid quota extension is a **proposal** until separately approved. Remaining numerical values are TBD; R20-06 sets initial upload/batch ceilings, subject to runtime feasibility and exact byte definition.

## 6. Price-construction workflow — owner sets prices one by one

**R14-05 DECIDED:** the owner will determine amounts **later, one plan or pack at a time**. Do not automatically populate a complete 12-plan schedule or convert illustrative competitor prices into approved iDigitalRoot prices. R13-06 still requires a **research-backed price proposal when the owner asks to price a specific item**.

Each pricing worksheet will distinguish (a) **initial annual paid website package** with included site creation, registered-domain/hosted-mailbox/care allowances, and its matching complimentary first-year pack; (b) **subsequent annual website renewal** without repeating initial creation labor, subject to agreed service scope; (c) **normal paid monthly and annual tool-pack prices** after year one or in other explicitly approved scenarios; (d) separately agreed extras and upgrades. No stand-alone first-build fee and no monthly website-creation quote in the current design.

Per item, record benchmark date/source/like-for-like caveats, development labor, bilingual UI/content/QA, R2/D1/Workers and document workloads, mail/domain/provider costs, support and security obligations, country-local payment/tax impact, expected margin and effective/expiry/version information. The quote must make the first-year pack benefit clear without declaring the website free. Exact prices, quotas, support commitments, quote terms and exchange rates remain TBD until explicit approval.

Country-specific quotes must bind approved market, seller/customer identities, Root, immutable catalogue versions, payment and term periods, item-level amounts/currency/tax basis, explicit customer-owner acceptance and independent staff reconciliation. Browser-submitted monetary values must never be authoritative.

## 6A. Preliminary external price evidence — RESEARCH, NOT iDigitalRoot PRICES

**Research date:** 20 October 2026. Published seller prices are marketing offers/starting points; they are neither independent representative market samples nor like-for-like bids for iDigitalRoot’s managed bilingual Cloudflare-based product. Do not use these numbers as approved iDigitalRoot prices, costs or legal claims.

| Market | Directly published example | Caveat | Source |
|---|---|---|---|
| Lebanon | LB Clouds landing-page first-year starting package **USD 639** (build+hosting+domain); from **USD 140/year** year two, optional maintenance extra | One landing page; a first-year bundle is not equivalent to a full managed multi-page site | https://lbclouds.com/services/web-development-lebanon/ |
| Iraq | Phoenix IT lists a website **Basic plan at IQD 225,000/year** and a **Premium plan at IQD 315,000/year**, with different language, domain and space allowances | These are the provider’s advertised package prices, not iDigitalRoot cost estimates | https://phoenixitiq.com/packages/ |
| Saudi Arabia | Oxira published first-year website packages at **SAR 1,499 / 2,499 / 4,999**, with differing domain, page and support inclusions | Platform/agency model differs; published prices exclude VAT | https://oxira.sa/en/website-builder/ |
| UAE | Apex Digital advertises managed website/SEO plans **from AED 2,500/month** with 12-month minimum and VAT extra | Higher-touch SEO service bundle; not comparable with bare hosting | https://www.apexdigital.ae/price |

**Official infrastructure-cost inputs (not per-site retail prices):**

- Cloudflare Workers Paid account starts at **USD 5/month**; requests/CPU overages may apply: https://developers.cloudflare.com/workers/platform/pricing/ (checked 20 Oct 2026).
- Cloudflare D1 Workers Paid includes **25 billion rows read/month**, **50 million rows written/month** and **5 GB** storage; overages billed by usage: https://developers.cloudflare.com/d1/platform/pricing/ (checked 20 Oct 2026).
- Cloudflare R2 Standard lists **USD 0.015 per GB-month** storage, **USD 4.50/million Class A** and **USD 0.36/million Class B** operations, with account-level included usage: https://developers.cloudflare.com/r2/pricing/ (checked 20 Oct 2026).
- **Important:** Cloudflare email routing/forwarding is not a paid, managed inbox/mailbox entitlement. Actual mailbox storage, SMTP, verification email delivery and support costs require a separately vetted provider: https://developers.cloudflare.com/email-service/get-started/route-emails/ .

**Do not simply divide the base Cloudflare bill by one website.** Estimate first-year build labor, multilingual content/QA, support, security review, provider mail/domain, office document conversion safety, ongoing operations and insurance/contingency first. D1/R2 shared account allowances are not guaranteed per-customer quotas. Model monthly/annual workload (P50/P95), retention costs and peak document-generation abuse limits before setting numerical quotas.

**Pending price derivation:** the owner will price items one by one. For each requested item, prepare evidence-backed **initial annual website price**, its **subsequent annual renewal** if relevant, or the selected pack’s **post-benefit monthly/annual prices**. Show the **family-matched** first-year tool-pack benefit (clock starts at purchase) and actual domain/hosted-mailbox allowances separately. All values remain **PROPOSAL — NOT APPROVED** until the owner explicitly accepts that item and the complete required tier/limits matrix is settled before implementation.

## 6B. Round 16 reconciliation — identity, residency, recovery, support (DOCUMENTATION ONLY)

**R16-01 — DECIDED: no construction delay extension.** Purchase establishes the paid annual website term and 12-month matching introductory pack grant. Tools remain unavailable until the Root is live and the website plan is active. The complimentary grant expires on its original purchase-based date regardless of construction duration, with no automatic adjustment. The commercial UI and versioned quote must disclose this clearly before owner acceptance. Confirm exact purchased-at event and calendar/month arithmetic in later contract design; these are implementation details, not a reopening of the policy.

**R16-02 — DECIDED direction: backup authenticator plus supervised recovery.** Password + email OTP remain normal login; high-impact actions use independently registered passkeys/security keys. Require backup registration, secure device-loss recovery with identity verification, privileged approval/dual control where risk warrants, cooldowns, reauthentication, audit/security notices, revocation of lost devices and existing sessions as appropriate. **R17-05 now selects pre-registered independent recovery methods plus supervised reset. Still TBD:** the operational verifier, evidence methods for individuals/guardians/business owners, exact wait periods and enrollment requirements. No email-OTP-only path may silently bypass high-impact step-up. Do not store raw passkeys or recovery credentials in logs.

**R16-03 — DECIDED direction: verified regional processing with country-specific restrictions.** No promise of in-country or uniformly GCC/MENA-local storage. Validate each intended market's law, contracts, identity/email/domain vendors, Worker processing, D1 storage/replicas, R2 objects, backups, logs, subprocessors and cross-border transfers **before** enabling that market. Cloudflare documentation checked 20 Oct 2026: D1 jurisdictional restrictions are EU/FedRAMP and Middle-East D1 locations are not supported; R2 jurisdiction restrictions are EU/US/FedRAMP; location hints do not guarantee residency. See https://developers.cloudflare.com/d1/configuration/data-location/ and https://developers.cloudflare.com/r2/reference/data-location/ . Regulatory compatibility remains **BLOCKED** by market until verified; no infrastructure mutation permitted in discovery.

**R16-04 — DECIDED engineering targets, NOT operational guarantees:** recoverable data loss **RPO <= 24 hours** and restoration **RTO <= 48 hours**. Account for platform D1, workspace/private R2 objects, metadata and SSO identity/security state, invoices/audit history and mailbox/domain provider dependencies. R17-03/04 now select full platform-owned backup coverage, **90-day recovery-copy retention** and **monthly restoration tests** as design policies. Detailed backup schedules, independent recovery authority, encryption controls, evidence, application consistency and legal holds remain **TBD**. D1 Time Travel offers supported point-in-time restore but does not alone back up R2 objects or restore a complete platform (https://developers.cloudflare.com/d1/reference/time-travel/). No PASS or service guarantee until target-aligned end-to-end restore is measured using permitted non-production data.

**R16-05 — DECIDED direction: defined business-hours support.** No implied 24/7 general response. R17-01/02 select **separate market schedules and tier-differentiated response commitments**. **TBD:** actual weekdays, local-time hours, holiday calendars, first-response targets for Entry/Growth/Premium, escalation, exception coverage and proven staffing. These are versioned service terms requiring owner approval before sale; never fabricate uptime or response guarantees.

**Compatibility with earlier decisions:** owner-only customer approvals, restricted Support visibility under customer-authorized sessions, staff least privilege, supervised identity recovery, manual financial verification, minor guardian-category consent and no unapproved provider integrations still apply. Indefinite retention/no voluntary deletion remains a requested policy, not an override of country-specific statutory rights. First-year promotion, pack switching and independent renewal behavior stay as written above; R16-01 supersedes only the previously open construction-extension question.

## 6C. Round 17 reconciliation — support, recovery, notifications (DOCUMENTATION ONLY)

The six answers below are **DECIDED policy directions** rather than production evidence, approved numerical SLAs or provider authorization. They refine the original `authority/master/04_SECURITY/INCIDENT_LOGGING_MONITORING_BACKUP_DR.md`, `SECURITY/CLIENT_PANEL_SECURITY_REQUIREMENTS.md` and `QA_AND_RELEASE_GATES.md` without replacing them.

| ID | Owner choice | Resulting policy | Still TBD / blocked |
|---|---|---|---|
| R17-01 | B: Separate support hours for regional markets | Maintain explicit support calendars for the intended launch markets (Lebanon, Iraq, Bahrain, Kuwait, Oman, Qatar, Saudi Arabia, UAE), expressed in local time with regional weekend/holiday handling | Exact open hours, holiday lists, timezone reference rules, staffing and exception coverage |
| R17-02 | B: Different response commitments by tier | Entry, Growth and Premium have versioned, tier-specific business-hours first-response policies. Scheduling is evaluated against the customer's authorized market calendar. | Priority classes, per-tier first-response times, escalation rules, any service credits; do not invent 24/7 service or resolution promises |
| R17-03 | A: Full platform-owned data and configuration | Recover platform-owned D1 relational stores, private R2 objects, workspace content, identity/authorization and commercial state, critical configuration, required audit evidence, and release/schema metadata as one consistent recovery plan | Actual inventory, encryption/secrets recovery, key rotation, point-in-time consistency, provider dependencies and accepted restore order. External registrar/hosted mailbox **service contents** are not covered by merely saving platform metadata |
| R17-04 | B: 90-day recovery copies; monthly restore tests | Design protected rolling recovery-copy retention for 90 days and run **monthly** scope-appropriate restoration exercises; preserve logs/evidence and test measured recovery objectives | Backup frequency, integrity validation, geo/residency restrictions, cost, deletion/legal holds, independent recovery permissions; no test is currently PASS |
| R17-05 | A: Pre-registered recovery options + supervised reset | Register independent backup passkey/security-key methods; recovery from total loss uses separately verified identity/guardian authority, supervised reset, additional authorization as warranted, notifications, session/token revocation and audit | Proofing methods, number of authenticators, cooldowns, exact reviewer permissions and recovery evidence rules. Email OTP alone never authorizes high-impact recovery |
| R17-06 | A: Portal inbox + transactional email | Both in-app notifications and actual verified transactional email are first-release requirements, including activation, MFA codes, recovery/security alerts and important support/project notices | Provider, validated deliverability by country, sender domain and consent/required-message policy, throttling, retries/deduplication, costs and incident fallback. No SMS is required by this answer |

### 6C.1 Regional support and versioned service obligations

- A customer is shown the contracted **support calendar for the applicable country** and its website tier. Entries are timezone-aware and holiday-sensitive. A mere locale/language change does not alter the signed service contract.
- Staff case assignment, first-response timers, escalation and notification workflows must use the authoritative schedule and ticket timestamps. Pauses/out-of-hours measurement, critical security routing and staffing fallback are **TBD**.
- Do **not** label a response target as a resolution guarantee, an actual staffed service, or 24/7 coverage without separate evidence and owner approval.

### 6C.2 Recovery architecture contract and honest verification status

- **Target only — NOT TESTED:** recovery point objective **RPO <= 24 hours** and recovery time objective **RTO <= 48 hours** (R16-04). Backup-copy policy: **90 days**; restore-exercise frequency: **monthly** (R17-04). The backup-copy duration must not be confused with workspace-record retention, which is a separate requested indefinite-retention policy subject to law.
- Scope includes authoritative platform-owned relational data, account/workspace/Root state, billing/consent/entitlement history, private R2 files and their D1 references, audit evidence, required configuration/versions and recoverability of credentials through an approved secret-lifecycle procedure. Do not back up plaintext secrets into unsafe archives or the repository.
- External hosted email/mailbox content, domains, DNS, identities and other provider-owned state require **separate verified provider arrangements**, even though their platform-owned metadata is in scope. A D1 time-travel capability or ZIP of source code is not full recovery.
- Restoration must verify a coherent app/schema/data version, per-Root access boundaries, live/expired/revoked entitlements, guardian visibility rules, non-resurrection of revoked SSO/shares, and a tested rollback/forward-recovery plan. Backups and evidence must be protected by least privilege, encryption, integrity and appropriate geography.
- **Open compliance gate:** 90-day recovery copies and the requested indefinite/no-voluntary-deletion default must obey applicable rights, erasure duties, child-data safeguards and country-specific residency constraints. The recovery policy must specify how lawful deletions propagate to recovery copies, restoration procedures and future versions.
- Monthly exercise reports must record source snapshot/version, actual measured data-loss window and restoration duration, recovered vs failed asset classes, dependent provider state, failures, remediation and authorized reviewer. Planned or simulated exercises are **NOT_RUN/BLOCKED**, not PASS.

### 6C.3 Supervised identity recovery and notification failure handling

- An owner, collaborator, staff member or guardian losing all strong authenticators follows a verified, separately authorized recovery procedure. Do not allow one Support agent to grant themselves unrestricted recovery powers, bypass customer verification via email alone, or restore a disabled member's access by using a stale recovery request.
- Normal login still requires password + email code; sensitive actions use approved strong passkeys/security keys. Pre-registered backup methods reduce dependence on staff recovery. Recovery events trigger secure portal/inbox notices and transactional email notices wherever possible, without exposing secrets in messages or logs.
- Notification jobs need delivery receipts when supported, deduplication, bounded retries, cost/rate controls, observability and user-visible pending/failure states. Critical recovery or other sensitive flows **fail closed** if essential verification/delivery dependencies are unavailable; ordinary core browsing should degrade safely when optional notifications fail.

### 6C.4 What remains unapproved (not assumptions)

1. Each country's exact business hours, public holidays and workforce coverage; tier × priority response thresholds and escalation paths.
2. Technical backup cadence and full D1/R2/config snapshot consistency, retention mechanism and tested recovery exercises; external mailbox/registrar recovery agreements, encryption, residency, operations cost and lawful deletion handling.
3. Transactional email delivery vendor, sending domains, market coverage, validated codes and recovery messages, deliverability checks and sending-cost budget.
4. Guardian/business identity-proofing for supervised recovery, independent reviewers, notification fallback, abuse limits and cooldowns.
5. Exact prices, per-tier support and domain/email allowances, common storage/file quotas and final local source/migration scope, all subject to their own approval gates.

## 6D. Round 18 reconciliation — Student tools, private imports and approvals (DOCUMENTATION ONLY)

**Scope authority:** Owner Round 18 answers, reconciled with `CLIENT_PANEL_BLUEPRINT.md` §§6–7,10,14–15; `FEATURE_INVENTORY.csv` Student positions STU-01 through STU-15 plus Student Toolbox; `SECURITY/CLIENT_PANEL_SECURITY_REQUIREMENTS.md`; `SECURITY/CLIENT_PANEL_THREAT_MODEL.md`; `QA_AND_RELEASE_GATES.md`; original `authority/master/04_SECURITY/` and `authority/current/STUDENT_LAUNCH_SCOPE.md`. These are specifications, not implemented features, approved D1 schemas or passing security tests.

| ID | Explicit owner answer | DECIDED behavior | Remaining design/assurance items |
|---|---|---|---|
| R18-01 | A — One coordinated Student calendar | My Semester, Study Planner, Exam Countdown and Campus Calendar feed a unified, accessible calendar view while keeping individually editable authoritative records. Preserve native EN/AR, timezones and approved ICS support; no external calendar sync required. | Event provenance, collision/edit rules, local versus UTC semantics, recurring events, import deduplication and conflict resolution, calendar privacy under guardian/owner grants. |
| R18-02 | A — Persist and recover active study timer sessions | Study Timer saves authoritative start/pause/resume/stop state durably and reconstructs session state on reload/close/return; prevent overlapping or double-counted sessions across tabs/devices and handle clock changes. | Whether timer continues while closed, allowed manual correction, idle timeout, pause/break semantics, server-time authority and device/offline behavior. Do not infer final policy from selection alone. |
| R18-03 | A — Currency-specific Student Budget | Expenses and budgets use an explicitly selected currency and accounting period, calculate accurate same-currency sums and provide protected, validated spreadsheet operations. No automatic FX/banking integration. | Currency changes/rounding, budget periods, CSV/XLSX column rules, data ownership/access and export privacy, money-precision test vectors. |
| R18-04 | B — Retain original attachment with imported record | Preserve the uploaded original source document privately, bound to its originating account/Root/record and authorized users, in addition to normalized data. No arbitrary file vault. | Per-tool allowed file types, sizes, scan provider, quarantine/release policy, object lifecycle, legal retention/deletion, safe download and disaster recovery; do not assume an unscanned file is acceptable. |
| R18-05 | A — Specific categories and revocable guardian grants | Verified guardian authorizes named organization, specific data categories, Root, purpose, expiry/review and revocation; no unapproved minor-data read by ordinary organizational owners or collaborators. Log grant/consumption/revocation. | Country-specific legal grounds and verification, exact category list, rights after withdrawal, guardian changes, age transition, audits and previously downloaded copies. No retroactive retrieval guarantee for copies already disclosed. |
| R18-06 | A — Separate design/content and final-project approvals | Account owner makes distinct authenticated approvals for immutable, hash/version-bound design/content artifacts and final project readiness. Staff coordinate and perform checks but cannot impersonate client approval. | Artifact composition, approval stages, rejection/revision routing, expiry/stale tabs, preview origin/TTL, two concurrent decisions and independent release authorization. |

### 6D.1 Coordinated Student calendar and timer — functional guarantees

- Maintain *one calendar view*, not a single undifferentiated database object. Source-specific ownership and change history remain intact for courses, plans, exams and campus events; calendar display is a projection of these authorized sources.
- Parse imported ICS as untrusted input: bound event count, recurrence expansion, date ranges, Unicode/encoding, timezones, attachment/URL fields, and duplicate identity. Never auto-fetch remote ICS URLs or embedded resources; never assume external calendar-provider connections.
- Timer start/resume/pause/stop must be idempotent and concurrency-controlled (e.g. record version compare-and-set), with unambiguous restore state after Worker/browser restart. User-editable local wall clocks and duplicated tabs must not create extra completed time. Background/offline continuation policy remains TBD and must be specified before Student Timer acceptance.
- Budget keeps separate currency and period semantics, uses exact decimal/integer-minor-unit arithmetic where applicable, rejects unsupported mixing and spreadsheet formula injection, and never presents a guessed exchange rate as a confirmed figure.

### 6D.2 Retained Office originals — security and privacy contract

- **DECIDED:** uploaded original DOCX/XLSX/PPTX/CSV/ICS files are retained with the imported record, rather than thrown away after extraction. Preserve record linkage and immutable provenance (upload identity, content hash, source type, scan outcome, Root/user scope and timestamps). Do not treat the uploaded file's client-provided filename, MIME type or extension as trustworthy.
- **MANDATORY architecture constraint:** initial upload goes to a private quarantine location using server-only R2 bindings and a non-user-selected object key. Enforce signature/content/extension allowlists, bounded uncompressed size/count, archive recursion/decompression limits, safe parsers, malware/suspicious content policy, macro/external-resource blocking and output sanitization. A missing or failed required check **fails closed**; never turn a fixture scan into a production pass.
- Originals and normalized outputs must be accessed only through separately authorized account/Root/member/entitlement/state and applicable guardian category checks, with narrowly permissioned downloads, safe `Content-Disposition`/origin, no-store controls, and audit. Never expose R2 credentials or serve untrusted uploaded HTML/SVG/executable content inline on the application origin.
- Retaining originals increases backup, legal rights, child-data, residency and breach impact. **UNRESOLVED:** duration after record removal/account closure, legal deletion/hold precedence, scan failure handling (reject vs quarantine until approved recheck), source-document replacement/versioning, max quotas, scanning/provider funding and safe export policy. Previous owner preference for no voluntary deletion does **not** waive legal obligations.

### 6D.3 Guardian and approval authorization

- Guardian grants are specific capabilities over approved categories and named organizational membership, with proof of guardian authority and customer-visible records. Account-owner visibility over minor records is **not** general blanket access. Revocation denies future reads, exports and shares and invalidates outstanding authorizations wherever technically possible; previously downloaded copies require contractual/process controls, not impossible revocation claims.
- Design/content and final project approvals each capture authenticated account owner, account/Root/project, the exact artifact hash and version, timestamps, decision/comments and resulting state. For replacement files, changed owner, revoked session, expiry, wrong Root, stale preview or simultaneous decisions, reject or supersede rather than transfer an approval. A version approval never authorizes provider mutations or deployment.

### 6D.4 No acceptance transferred from older projects

All Round 18 items are **DECIDED specification choices / IMPLEMENTATION NOT BUILT / QA NOT RUN / SECURITY NOT ASSESSED**. The security baseline, 151 risk titles and 345 ASVS requirements remain applicable for architecture-specific mapping and evidence; a new feature is not secure merely because a checklist or unit test exists.

## 6E. Round 19 reconciliation — focused Student tools, source-file access and approvals (DOCUMENTATION ONLY)

**Authority checked:** `CLIENT_PANEL_BLUEPRINT.md` §§ 7, 10.1–10.2, 14–15; `FEATURE_INVENTORY.csv` entries `STU-05` (Study Timer), `STU-13` (Research Shelf), `TOOL-02` (Portfolio Builder), `TOOL-07` (Career Kit), `TOOL-09` (Project Share), `TOOL-12` (Root Export); `SECURITY/CLIENT_PANEL_SECURITY_REQUIREMENTS.md`; `SECURITY/CLIENT_PANEL_THREAT_MODEL.md`; `QA_AND_RELEASE_GATES.md`. These are product/architectural requirements, **not working software or completed tests**.

| Owner decision | Explicit answer | Bound scope and reconciliation | Remaining detail |
|---|---|---|---|
| R19-01 | **B — Automatically pause Study Timer after inactivity** | Supersedes any assumption in R18-02 that active study time accrues indefinitely while a browser is shut/reloaded. Durable session recovery still applies: authoritative persisted state and last observed activity are reconstructed, but unobserved time may not count as study. | Idle threshold, trusted activity definition, multi-tab/foreground/background behavior, offline grace, how server infers pause timestamp, user correction/audit policy. |
| R19-02 | **A — Opportunity-specific Career Kit snapshot** | One shared Career Kit engine (Toolbox + Workspace navigation). Owner-authorized user selects eligible CV/project/achievement/contact items into an independently versioned, private application snapshot. Actual PDF/DOCX output remains required under approved broad Office compatibility. | Snapshot field rules, personal-data redaction, immutable-export behavior, contact consent and formatting limits. |
| R19-03 | **A — Private Portfolio Builder, explicit CMS handoff later** | Store curated private portfolio projects safely within the Client's Root. Permit approved private export/controlled sharing, but do **not** auto-publish/synchronize to site CMS. `Open Website Admin` SSO simulation or a CMS-ready preview is not proof of real CMS publishing. | Export/share semantics, permitted portfolio media and the versioned real-CMS interface once an actual independent client CMS is authorized and available. |
| R19-04 | **A — Research Shelf structured references and notes** | Save manual, validated reference URLs, citations, tags, search/organization and notes. No arbitrary server fetching of reference URLs, imported executable HTML or generalized attachment vault. | Citation-style requirements, URL allowlist/normalization, duplicate detection and optional project associations. |
| R19-05 | **A — Owner and narrowly authorized members download imported originals** | Account owner and record creator can download eligible originals while their membership/entitlements and applicable privacy grants are valid. Other collaborators require specific, server-enforced rights. For minors, guardian-approved category grants and applicable safeguarding restrictions override a commercial owner's broad access claim. Supervised Support access remains a separate time-limited customer-authorized permission. | Departing creator's access revoked; ability to download during suspended-plan legal/data-access exceptions, audit visibility, signed response/download expiry, object-size and rate ceilings. |
| R19-06 | **A — Exactly two formal project approvals** | Owner-only approval #1: identified, immutable design/content version and evidence. Owner-only approval #2: distinct identified immutable final-project version and evidence. Superseding either artifact invalidates/refreshes its dependent approval as appropriate. **Neither** is permission to deploy, which has a separate release-authority gate. | Artifact composition, partial review comments, revision/reopen policy, notification/escalation, exact staff transitions. |

### 6E.1 Study Timer: persistence without fabricating study time

- **DECIDED:** R18-02 keeps authoritative timer session state across reload/disconnect; R19-01 additionally requires pause after inactivity. An inactive browser, blocked network or closed tab cannot be assumed to continue studying solely because a start timestamp exists.
- **Design requirement (not owner-approved values):** server-stored session ID, scoped user/Root, monotonic state transitions, last credible activity/heartbeat, bounded overlap and concurrency-safe pause/resume. Reconstruct after reload and explicitly disclose any inferred inactivity boundary.
- **TBD:** threshold, detection method, policy when the last browser signal never arrives, background tab handling, whether the user can propose a correction and which actor approves it. Avoid false precision about unobserved time.

### 6E.2 Career Kit: private exact-version packages

- `TOOL-07` and `NAV-CAREER-KIT` are **two menu entries for one capability**, not duplicated data stores. Selected source versions are captured into a saved opportunity-specific snapshot rather than silently changing when a CV/portfolio entry is later edited.
- PDF/DOCX (as previously selected) should be generated only from authorized, validated, bounded source fields; versions and exports require account/Root/user/entitlement checks, privacy-aware optional redactions, predictable output names and formula/template/HTML injection controls as applicable.
- Employment outcomes, credential verification and CMS publication must not be implied by an exported package.

### 6E.3 Portfolio Builder, Research Shelf and controlled sharing

- **Portfolio Builder:** retain explicit private/public item selection but no working CMS write until the future per-site CMS contract and actual consumer are delivered. Share links require their own scoped grants, expiry/revocation controls, download security and audit. No auto-sharing merely because the user stores a project.
- **Research Shelf:** one normal structured references-and-notes model is approved; imported Office originals for *other authorized tools* do not expand Research Shelf into a generic file-vault. No unsolicited remote content ingestion/fetching or executable HTML.
- **Original Office documents:** R18-04 permits authorized retention of source DOCX/XLSX/PPTX/CSV/ICS where import is approved, subject to quarantine/actual scan and safe private delivery. R19-05 limits original-file downloads independently of whether a member can view normalized extracted fields; do not leak originals via previews, exports, cache or direct R2 access.

### 6E.4 Two owner approvals and staff boundary

- Draft/review → owner design/content approval (exact artifact/version/hash) → staff work and independent QA → owner final-project approval (exact final artifact/version/hash) → launch-ready review; **actual deployment still separately restricted**.
- Project/Production Staff prepare releases and respond to change requests. Operations may coordinate the workflow. No staff role or generic collaborator can accept either milestone on the owner's behalf under R3-05/R19-06.
- Reject replay, crossed account/Root/project IDs, disabled owner, stale review tabs, changed hash, simultaneous approve/reject, cancellation, expired previews and role/entitlement changes. Only authorized re-issued versions can be re-reviewed.

### 6E.5 Truthful status

All six decisions are **DECIDED in discovery**. Every related module remains **NOT BUILT / NOT TESTED / SECURITY NOT ASSESSED**. Neither the current public/CMS 32-step evidence nor the original security coverage transfers to these new features.

## 6F. Round 20 reconciliation — timer, Career Kit, sharing, Root Export, import limits (DOCUMENTATION ONLY)

**Authority checked:** `CLIENT_PANEL_BLUEPRINT.md` §§ 7, 10.1–10.2, 15–17; `FEATURE_INVENTORY.csv` (`STU-05`, `TOOL-07`, `TOOL-09`, `TOOL-12`, and `NAV-CAREER-KIT`); `SECURITY/CLIENT_PANEL_SECURITY_REQUIREMENTS.md`; `SECURITY/CLIENT_PANEL_SECURITY_TEST_PLAN.csv`; `QA_AND_RELEASE_GATES.md`. **Only these explicit owner answers are newly decided; proposals and missing details remain unapproved.**

| ID | Explicit Round 20 answer | Contract now DECIDED | Unresolved implementation details |
|---|---|---|---|
| R20-01 | **A — Study Timer pauses after 10 minutes of inactivity** | R18-02 durable persistence/recovery and R19-01 automatic idle pause remain. Persist trustworthy activity/session checkpoints; compute a bounded automatic pause using the **10-minute inactivity threshold**. Do not silently count unlimited closed-tab/offline time as study. | What qualifies as a credible activity signal during passive reading, offline/reload behavior, exact authoritative cutoff and clock-skew/disconnect handling. |
| R20-02 | **A — Corrections with recorded history** | An authorized student may correct a recorded study session, supplying a reason. Preserve original value, corrected value, actor, timestamp, Root/session and immutable or append-only correction history; no unlogged overwrite. | Maximum adjustments/frequency, suspicious-correction handling and guardian/owner visibility within applicable scope. |
| R20-03 | **A — Complete tailored Career Kit application package** | One shared Career Kit (`TOOL-07`, also `NAV-CAREER-KIT`) produces a Root-scoped immutable opportunity snapshot with selected CV, achievements, portfolio evidence, contact details and optional cover-letter content, plus usable **PDF/DOCX** exports. Changing upstream records does not silently change the snapshot. | Exact output layouts, fields, attachment rules, redaction controls, export byte/processing quotas and accessibility tests. |
| R20-04 | **B — Share links: 30 days by default, up to 90 days** | Private Portfolio and Project Share links require explicit grants; default **30 days**; enforce maximum **90 days**; may be revoked sooner. Root/account/entitlement suspension, owner/member revocation and guardian limits can invalidate access earlier. No public access by default. | Recipient identity/access policy per output, link-download permission and stricter minor/sensitive-data exceptions. |
| R20-05 | **A — Structured Root Export + separately selected eligible originals** | Authorized Root Export contains structured user-eligible records in approved JSON/CSV plus a scoped manifest; optionally produces a protected package of **specifically selected, independently authorized retained Office originals**. Do not automatically export every collaborator's documents. Recheck authorization at request, job execution and download; audit without sensitive payloads. | Exact export packaging/encryption, maximum bytes/files, async job expiry/retry policy, shared membership and subject-access exceptions. |
| R20-06 | **A — Conservative file-size limits** | Initial common per-file ceilings: **10 MB each DOCX/XLSX/PPTX**, **2 MB each CSV/ICS**, **25 MB aggregate per import batch**. Enforce before parsing/expansion, along with type/content checks, quarantine, verified scanning and private R2 retention of approved originals (R18-04). | Confirm MB versus MiB byte definition, row/event/slide/zip-part/decompressed-size ceilings, scanner/parser runtime feasibility, aggregate storage and cost quotas. |

### 6F.1 Boundaries and negative security cases — required, NOT YET TESTED

- **Timer:** unauthorized Root or session corrections denied; verify 10-minute idle behavior, passive study, backdated/future client timestamps, network loss, stale heartbeats, multiple tabs/devices, duplicate corrections and append-only history. Never present inferred duration as measured human activity.
- **Career Kit:** snapshot hashes/versions survive later source edits; unauthorized CVs, projects, minors' private evidence and cross-Root items excluded; test PDF/DOCX injection and template output safety, redactions, size bounds and deterministic exports.
- **Sharing:** defaults/90-day maximum, exact expiry boundary, guessed tokens, replay, wrong Root/account/recipient, suspension, guardian revocation and stale caches must fail closed. Audit share creation, access and revocation without logging access tokens.
- **Root Export:** optional source originals require their own permissions even when structured fields are readable; block overbroad owner/member exports of protected minor records; test delayed jobs after membership/pack changes, token expiry, output encryption/private download and cleanup on failure.
- **Import:** enforce 10/2/25 MB before expensive processing, plus decompression and record-count ceilings independent of compressed length; reject polyglots/macros, external references, unsafe embedded media and malicious CSV formulas as applicable. No scan provider configured means **BLOCKED/QUARANTINED**, not approved or live.

**Status for all six:** DECIDED product/design choices; implementation NOT BUILT, runtime/security tests NOT RUN, independent review NOT PERFORMED. No source, schema, cloud or provider authorization follows from this documentation.

> **Supersession note (Round 22):** Section 6G preserves the *earlier Round 21 proposal* for traceability. Any 6G reference to undecided Root/project authority, identity authority, cross-database delivery approach, support-thread authority, transfer category, or preview mode has now been **resolved at the product-direction level by Section 6H**. A diagram or `TBD` table in 6G is historical and is not a second active architecture choice. Section 6H controls. Schema/API specifics remain proposed until final scope approval.

## 6G. Round 21 — separate Admin/Client D1, real operational flows and transfers (DOCUMENTATION ONLY)

**Decision authority:** explicit owner Round 21 answers, reconciled with `CLIENT_PANEL_BLUEPRINT.md` §§2, 5–7, 11–14 and 17; `authority/master/03_SYSTEM_DEFINITIONS/SYSTEM_BOUNDARIES_AND_DATA_OWNERSHIP.md`; `authority/master/03_SYSTEM_DEFINITIONS/CROSS_SYSTEM_IDENTITY_SSO_AND_AUTHORIZATION.md`; `authority/master/02_FOUNDATIONAL_BLUEPRINTS/iDigitalRoot_Admin_Operations_Dashboard_Final_Technical_Blueprint_v1.0.md`; `DISCOVERY_QUESTIONS.csv`; `SECURITY/CLIENT_PANEL_THREAT_MODEL.md`; `QA_AND_RELEASE_GATES.md`. These are **owner-decided product directions, not approved schemas, migrations, provider calls or implemented APIs**.

| ID | Owner's explicit answer | DECIDED direction | Still pending |
|---|---|---|---|
| R21-01 | B — Separate Admin and Client databases | Maintain separate Admin D1 and Client D1 boundaries, not the earlier recommended single shared Platform D1. | Authoritative table/domain allocation, separate schema lineages, identity ownership, secure cross-service contracts, consistency and recovery rules. |
| R21-02 | A — Secure lead handoff into Admin qualification queue | Qualified public inquiry submitted through reviewed authenticated/versioned boundary; staff reviews, deduplicates and quotes. Never silently creates an activated customer identity. | Inspect exact existing public wizard implementation and retain its intended visitors@ notification/lead-delivery contract; define failure/retry/reconciliation and public schema impact. |
| R21-03 | A — Authorized staff creates Root after verified purchase | Owner accepts immutable quote; Billing independently verifies payment; staff makes idempotent authorized new-Root association and starts versioned onboarding. | Authority for Root ID and lifecycle, site creation event protocol, disputes/cancellation, cross-DB failure handling. |
| R21-04 | A — Complete threaded support workflow | Persistent case/reference, client+staff messages, attachment rules, staff assignment, state history, inbox/email notifications, regional calendars and tier response commitments. | Single authoritative thread location, staff-private notes boundary, visibility, counters/status consistency, attachment quarantine. |
| R21-05 | B — Controlled ownership transfers | Allow tightly scoped verified Root transfer between accounts with contracts/entitlements/data reconciliation and auditable state machine. | Transfer what data, whose signatures, guardian/minor grant impacts, pause/locking, financial carryover, replay/race and rollback/forward recovery. |
| R21-06 | A — Versioned protected preview releases | Authorized staff issues time-bounded, account/Root-bound versioned protected previews; owner makes separate exact-version design/content and final approvals. | Real preview artifact origin/host, safe transport, TTL, hash/provenance, revocation and stale-tab/concurrency behavior. |

### 6G.1 Data and identity boundaries — decision vs proposed allocation

The owner has **decided physical database separation** but **has not selected a per-domain source-of-truth map**. This proposal is for the next discovery round, **NOT an owner-approved database layout**:

| Domain | Proposed authority, NOT APPROVED | Other side's usage |
|---|---|---|
| Staff identities, permissions, staff-only notes and operational audit | Admin D1 | Customer interface never receives staff secrets/notes |
| Quote versions, invoice/payment verification, commercial catalogue and financial approval | Admin D1 | Client sees server-authorized views and submits owner decisions through a validated API; never decides Paid client-side |
| Customer identities, MFA credentials/sessions, account membership and personal/private tool records | Client D1 | Admin operates through narrowly authorized APIs, not unrestricted copying or dual passwords |
| Root master record, lifecycle/projects/preview approvals, tool entitlement grant source | **TBD: must appoint one authority per record** | Other D1 contains only a carefully bounded projection/reference or invokes authority for sensitive decisions |
| Support case/thread, staff-only notes and client messages | **TBD: one authoritative thread** | The other UI accesses a filtered authorized projection/proxy, not a second independently editable thread |
| Lead/inquiry original intake | Existing Public Backend / Lead service | Admin receives verified lead identity and deduplicated qualification metadata |
| Website pages/media/website CMS identities/detailed analytics | Independent client CMS | Client/Admin only scoped operational references; no duplicated central CMS data |

System/feature owners must define fields, stable IDs, referential checks where cross-DB foreign keys cannot exist, update/version checks, and stale-projection handling before any migration. Browser-supplied account/site/role/price is never trustworthy. No application is allowed unbounded reads or writes into the other application's database merely because both run on Workers.

### 6G.2 Cross-database consistency and failure model — proposal pending decision

```mermaid
flowchart LR
  PUB[Public inquiry] --> LEAD[Public lead authority]
  LEAD -->|authenticated bounded handoff| ADMIN[Admin API and staff roles]
  ADMIN --> AD1[(Admin D1)]
  CLIENT[Client session / scoped API] --> CD1[(Client D1)]
  CLIENT <-->|service-authorized, versioned contract| ADMIN
  ADMIN -.->|proposed outbox + idempotent delivery| CLIENT
  CLIENT -.->|proposed acknowledgments / reconciliation| ADMIN
  CLIENT --> R2[(Private R2 via Worker only)]
  CMS[Independent website CMS] -.->|separate scoped SSO later| CLIENT
```

- Distinct D1 bindings do **not** confer a shared ACID transaction. Cloudflare's `D1Database.batch()` guarantees a transaction only for the statements in a batch on one database binding; do not extend that guarantee across two separate D1 databases. Official reference: `https://developers.cloudflare.com/d1/worker-api/d1-database/` (consulted during Round 21 reconciliation).
- **DRAFT PROPOSAL:** per-authority local transactions append versioned outbox events, uniquely identified and idempotently consumed on the other side. Consumers validate workload identity, schema/version, event ordering, account/Root/state scope and current authority. Add bounded retries, reconciliation, observable failures, dead-letter/manual repair and compare-and-set checks. No external Queue service or paid resources are approved simply by selecting the pattern.
- **Mandatory failure invariant:** a quote approval, pending payment, Root creation, ownership transfer or paid tool unlock must not show success or grant authorization in the wrong system before required authoritative commits/evidence. Show truthful Pending/Failed states while dependent synchronization is incomplete. Authorization-sensitive reads must fail closed or validate against the actual authority, rather than blindly trust a stale replicated flag.
- Exact account/Root/entitlement transfer uses staged transitions and compensation/forward reconciliation, **not** claimed distributed rollback. Replay, out-of-order, duplicate, dropped messages, staff permission changes, suspended accounts, partial provider failure and restore divergence require negative tests.

### 6G.3 Approved customer and staff workflows — state contracts not endpoints

**Public inquiry → Admin → purchase → Client:** Existing public inquiry remains anonymous/lead identity; authenticated handoff into Admin qualification (not auto-provisioned client), staff qualification/deduplication, immutable quote, account-owner acceptance, Operations may record **Pending Verification** evidence, independent Billing verification, then staff-authorized idempotent Root creation/association and invitation. Existing commercial rule still applies: website service and matching first-year pack **begin at eligible paid purchase**, but tool use starts only when the Root becomes **Live**. **Do not silently start a second 12-month clock at later staff Root creation**. Late or failed synchronization cannot create double grants, double Roots or fabricated payment states.

**Support:** A complete case is visible to eligible clients with its message thread, history, status, request ownership, attachments and notifications; Admin supports assignment, authorized private operator notes and security audit. Staff-only notes/other customers' cases never appear in the Client API, exports, emails or search. Regional support calendars and tier responses exist as contract fields with **numeric hours/targets still TBD**, not an invented SLA.

**Transfer:** An eligible transfer is a new audited business process, not a direct update to `account_id` scattered across independent databases. Start with a Root/contract/entitlement/privacy/guardian inventory and versioned transfer evidence. Define who consents, what travels, what is legally nontransferable, any temporary access freeze, billing obligations, issuer/SSO revocation, shares/exports, and recovery on partial transfer before approving the transfer API/schema. No automatic transfer of personal/minor data is authorized by R21-05 alone.

**Protected preview:** Bounded staff publication, private preview object/version hash and exact owner review authority; noindex/no-store and approved origin/embedding strategy; revocable access and anti-replay/stale-version checks. Approvals remain separate design/content and final-project events, and **neither authorizes production deployment**. Existing R10-04 limits real Open Website Admin to SSO broker with two isolated *local test* consumers until a real website CMS exists.

### 6G.4 Separate schema and security preparation — BLOCKED UNTIL SCOPE APPROVAL

- **Proposed isolated lineage:** e.g. `admin/0001_...` and `client/0001_...`, each pinned to its respective brand-new D1 database and separately checked during migration review. These are illustrative names only; **no migration file created or approved**. Existing Public Core `0001–0016` and Analytics `0001–0002` stay byte-frozen; no accidental Core `0017`.
- Before implementation: retrieve/verify original full master companion, follow its original read order, inspect exact MOTION01 source/archive and existing local `AGENTS.md`, create approved domain ownership/DFD/threat model, explicit migrations/recovery, and gain one final bounded owner scope approval.
- Every major boundary gets threat/risk/ASVS mapping (fresh `NOT_ASSESSED`), server-side object/property/function authorization, scope/entitlement checks, service authentication, key lifecycle, rate/resource bounds, anti-injection/SSRF/upload defenses, audit and adverse failure tests. Public/CMS evidence is not Client/Admin PASS. Do not use historical launcher scripts or mutate remote providers during discovery.
- Requested dual-DB architecture may cost more in complexity and recovery. It does not authorize a third database, Queues, remote bindings, new spending, provider mutations or deployment. Separate approval remains required for these.

**Round 21 status:** six owner decisions recorded; specific cross-database contracts and transfer/privacy/operational details remain **TBD**. Architecture/security/QA work is **NOT BUILT / NOT ASSESSED / NOT RUN**, and final construction authorization remains **BLOCKED**.

## 6H. Round 22 reconciliation — authoritative domains and cross-service delivery (DOCUMENTATION ONLY)

**Owner answers (21 October 2026):** all six are explicit discovery decisions and **not** construction, migration, deployment or provider authorization. The detailed engineering contract below separates OWNER DECIDED invariants from IMPLEMENTATION PROPOSALS and still-unanswered choices. Earlier 6G alternatives are retained as historical proposals but **superseded** wherever Round 22 resolves them.

| ID | Decision in owner's words | OWNER DECIDED invariant | Still TBD / evidence required |
|---|---|---|---|
| R22-01 | A — Admin controls Roots and project lifecycle | Admin is the authority for stable Root identity, legal/current account association, project stages and operational state, staff-managed versioned previews and transfer lifecycle; Client may request and display but does not independently issue authoritative state. | Exact record schema and state transition permission matrix, authoritative owner-approval storage, derived Client projections, official measurement behind any Live/Health status. |
| R22-02 | A — Client owns customer identities; Admin owns staff identities | Customer password/MFA/sessions/memberships/guardian permissions stay Client-authoritative; staff identity/role/MFA stay Admin-authoritative. No passwords or stronger authenticators are copied across domains. | Bounded actor-to-workload delegation, account context proofs, role-revocation propagation, separate customer/staff session lifetimes and staff account-link model. |
| R22-03 | A — Durable event delivery with visible Pending states | Persist authoritative changes and durable delivery intent locally; use idempotent authenticated, versioned delivery with retries/reconciliation. A dependent operation stays Pending, Failed or Blocked rather than claiming success or granting access on missing confirmation. | Transport/bindings, exact local outbox schema, event signing/auth, ordered versions, retries/backoff, dead-letter operations and repair permissions. No paid Queue provision has been approved. |
| R22-04 | A — Admin owns complete support cases | Admin is authoritative for case ID, complete message thread, status, staff assignment, staff-private notes and support audit. Client sends and reads only through authorized service contracts. | Attachment policy and R2 namespace, delivery semantics, customer-visible message projections, reconciliation and notification fan-out. |
| R22-05 | A — Root services and eligible Root-owned records transfer | A controlled transfer can change account ownership of the Root's eligible services/contracts and legally transferable Root-owned records; it cannot automatically relocate a person's unrelated/private records, another Root, or restricted minor data. | Required approvals from both account owners and affected people/guardians, transfer freeze, invoice/subscription rules, historic shares/revocation/SSO, nontransferable exceptions, reconciliation/forward recovery. |
| R22-06 | A — Protected local preview infrastructure | Before approved remote staging, construct and test time-limited, site/user/account-scoped, immutable versioned previews in the **local authorized environment only**. | Actual local preview runtime/origin, ticket/access TTL, iframe/embed policy, revocation, asset handling, how an external owner reviews after separate staging authority. Do not call localhost review a deployed preview. |

### 6H.1 Active domain ownership map — decided vs proposed

| Domain / asset | Authoritative application/data boundary | What the other application can do | Decision status |
|---|---|---|---|
| Public inquiry/anonymous lead | Existing Public Backend/Lead service | Authenticated, idempotent lead handoff into Admin qualification, without activating customer | Fixed original boundary + R21-02 |
| Staff identities, roles and permission bundles | **Admin D1 / Admin IAM** | Client cannot read staff credentials or grant staff privileges | R22-02 DECIDED |
| Customer identities, membership, guardians, sessions/MFA | **Client D1 / Client IAM** | Admin requests bounded customer/account membership validation, never copies credentials | R22-02 DECIDED |
| Roots and ownership/project status | **Admin D1 / Admin lifecycle authority** | Client reads scoped projections/status, submits authorized requests and shows Pending until verified | R22-01 DECIDED |
| Support case/thread, assignment, staff-only notes | **Admin D1 / Admin support authority** | Client obtains filtered authenticated thread and posts authorized replies; staff-only fields always excluded | R22-04 DECIDED |
| Quote/invoice/payment verification/catalogue | Admin commercial authority per prior R10/R21 contracts | Client owner accepts immutable terms with verified identity; Paid only after independent Billing validation | Already DECIDED in earlier rounds |
| Private Student/Professional/Entrepreneur/Business workspace records | Client account/Root-scoped private workspace authority | Admin does **not** gain direct arbitrary content access. Only customer-authorized, time-limited support access; owner/minor permissions apply | Original boundary + earlier owner decisions |
| Website content/media/users/analytics | Each independent website CMS | Neither Admin nor Client centralizes ordinary website CMS content | Original fixed boundary |
| Purchased tool entitlement/grant authority | **Admin D1 / Admin commercial authority** | Client must verify current Admin-authoritative website-plan/pack/Root eligibility before protected work; a Client projection is not a grant | **R23-01 DECIDED**; exact proof, outage and revocation mechanics TBD |
| Exact-version project approval ledger | **Admin D1 / Admin project ledger** | Client validates customer identity/owner status, forwards an exact-version decision; Admin rechecks current authority/version and atomically records immutable outcome | **R23-02 DECIDED**; exact protocol, anti-replay and rejection/repair mechanics TBD |
| Private R2 source attachments, preview assets and export packages | Worker-controlled private object boundary, with explicit owner/Root/classification metadata | No browser D1/R2 credentials; enforce conditional read/write, scan/quarantine and revocation | Fixed design/security constraints; actual bindings pending |

**Historical Round 22 proposal, partly resolved by Round 23:** The owner selected Admin as the authoritative source for paid tool entitlements (R23-01) and the immutable exact-version project approval ledger (R23-02). Client still owns customer sessions/membership/private workspaces and must authenticate the customer, while Admin verifies authoritative Root/entitlement/approval state and records the final approval. **The exact cross-service proof, freshness, outage and revocation mechanics remain proposed/TBD.** A Client cached `paid=true` or cached owner flag is never sufficient authorization.

### 6H.2 Revised conceptual data-flow diagram — proposed implementation mapping

```mermaid
flowchart LR
  V[Public visitor / quote wizard] --> P[Public lead service]
  P -->|Authenticated bounded handoff| A[Admin Worker APIs]
  S[Privileged staff] -->|Staff session / MFA| A
  A --> AD[(Admin D1: staff, Roots, projects, support, billing)]
  C[Customer Client App] -->|Customer session / MFA| W[Client Worker APIs]
  W --> CD[(Client D1: identity, membership, workspaces)]
  A <-->|Versioned authenticated requests and events| W
  AD -->|Local transactional outbox intent| OB[Durable relay / reconciliation PROPOSED]
  OB -->|Idempotent event with confirmation| W
  W -->|Scoped ack / identity checks| A
  A -->|Worker-only protected preview files| R[(Private R2)]
  W -->|Worker-only private tool files/exports| R
  A -.->|Future scoped broker; not deployed CMS| CMS[Independent client CMS consumer]
```

This is a **conceptual DFD**, not the final per-feature threat model, an installed service topology, a production connection, or evidence of a working SSO consumer. Admin D1 and Client D1 have **no distributed ACID commit**. If the Admin authority has committed but Client synchronization is delayed, the authoritative state is not silently reversed: the dependent Client feature shows `Pending/Unavailable` and cannot unlock access. Reconciliation must ensure exactly-once *business effects* through idempotency, not claim exactly-once message transport.

### 6H.3 Durable message and authorization contract — proposed for scope freeze

- Events carry stable event ID, originating domain/authority, schema version, aggregate account/Root/case reference, monotonically checked aggregate version, occurred-at timestamp, correlation/causation IDs, safe minimal payload and auditable processing outcome. Sensitive data/credentials do not enter event payloads by convenience.
- Producer writes its state transition and pending outbound intent atomically **within its own D1** if supported by the actual runtime. Workload-to-workload identity is authenticated; consumers verify authorization for operation/action/account/Root, schema and idempotency. Two DBs are never assumed to commit together.
- Consumer keeps a deduplication receipt and compare-and-set/version check; out-of-order/duplicate/replay, schema mismatch, revoked membership, stale Root owner, expired contract or missing dependency cannot create a paid grant, transfer, share or project approval.
- Retry/backoff, bounded delivery attempts, observable queue/outbox backlog, administrator-visible reconciliation and safe manual repair are required. New Cloudflare Queue or provider provisioning is **not approved**; transport choice stays pending.
- On uncertainty: show status `Pending/Failed/Blocked`; return explicit recoverable errors as appropriate; deny or confirm via the authoritative service for permission-sensitive operations. Avoid generating notifications that claim a failed action succeeded.
- Protect against cross-domain actor confusion: staff identities from Admin and customer identities from Client must not be mistaken for each other when an event crosses the trust boundary. No browser-supplied account ID, role, payment flag or audience label determines authorization.

### 6H.4 Owned business workflows — required after scope approval, NOT YET IMPLEMENTED

1. **Public lead:** authenticated handoff to Admin with deduplication and safe retries. Preserve existing public website/quote wizard and intended lead/email contract. Anonymous lead never becomes a live customer automatically.
2. **Purchase/Root creation:** staff-qualified, owner-accepted immutable quote → pending evidence entered by Operations → independent Billing verification → Admin idempotently creates authoritative Root → Client account/membership association confirms. The previously approved paid website and first-year matching-pack clock both begin at **eligible verified purchase**, not delayed Root creation or later website go-live. Tools remain unavailable until the Root is Live and required active entitlements pass checks.
3. **Support:** Client posts authorized scoped message → Admin-authoritative append/state → restricted Client response; enforce staff-private note projection exclusion; durable notifications only after committed status. A disconnected Client does not create a conflicting second thread.
4. **Preview and approval:** Admin produces local private immutable preview artifacts with version/hash and scoped time-limited access → Client presents owner-only approval action → Admin validates current identity/account/Root/project/version and records design/content then final-project approvals separately. Replaced or stale artifacts require new review; neither approval authorizes remote deployment.
5. **Transfer:** two-account verified request and inventory → required consent and contractual/privacy checks → staged `Pending/Locked` operations → Admin changes authoritative Root ownership exactly once → Client memberships/private Root records and revocations reconcile → transfer becomes `Completed` only after confirmation. Never blindly copy guardian-restricted/private data or treat one partial DB update as finished. Decide whether active support cases, invoices, expired share tokens and prior previews follow the transfer.

### 6H.5 Dedicated schemas, original security and release gates

- **Requested isolated D1 design, not created:** new Admin migration lineage and separate Client migration lineage, each with its own history/checksum, forward recovery, local synthetic data and cross-service reconciliation strategy. No migration DDL exists or is approved here. Frozen Public Core `0001–0016` and Analytics `0001–0002` remain unchanged; no accidental `0017`.
- All original `authority/master/04_SECURITY/` authorities remain minimum requirements. Existing 151-title risk and 345-requirement ASVS registers are freshly **NOT_ASSESSED** for the new Admin/Client threat surfaces. Explicit controls/negative tests must cover staff vs customer IAM, client support private-note stripping, entitlements under delayed/reordered events, transfer consent/races, preview version replay, R2 object isolation, private export/share revocation and consistent 90-day backup/restore with monthly exercises.
- Local acceptance must use actual Workers-compatible execution, isolated D1s and R2, real browser EN/AR/mobile/a11y, adversarial/cross-account testing and sealed fresh-extraction reproduction. An inaccessible independent/provider/legal gate remains `BLOCKED`; no self-test upgrades it to independent PASS.
- **Status:** DISCOVERY DECISIONS RECORDED; application `NOT_BUILT`; schemas/migrations `NOT_CREATED`; new security assessment `NOT_ASSESSED`; tests `NOT_RUN`; hosting/provider spending/deployment `NOT_AUTHORIZED`. The complete original master handoff plus exact source/AGENTS.md inspection still must be verified before application source changes. The small handoff is not the entire master.

### 6H.6 Unresolved decision queue narrowed by Round 22

1. **R23-01/02 DECIDED:** Admin owns authoritative entitlement/grant records and exact-version approval ledger. **Still TBD:** protected-operation authorization proof/freshness/revocation/outage behavior and immutable approval exchange/idempotency/recovery.
2. **Transfer authorization and privacy:** origin/destination owner signoffs, pending dues, member/guardian consent, eligible dataset, freeze/revoke/safe-restore and owner-visible status.
3. **Event operation policy:** transport within existing approved bindings, retries/escalation, reconciliation authority, cryptographic service identity and poisoned-event handling (without silently approving new Cloudflare resources).
4. **Preview audience and lifetime:** owner versus collaborator read-only access, ticket TTL/revocation, exact snapshot/host and how remote customer review works only *after* separate staging authority.
5. **Support attachment scope:** allowed file classes/size and quarantine/scanning, R2 access/retention, client/staff visibility, SLA and alert integration.
6. **Other prior open decisions:** precise per-market support calendars/tier response targets, actual legal/provider/data-residency/child-deletion permissions, commercial amounts and quotas, approved email/domain provider contracts, real client CMS availability/SSO integration, source/master verification and final scope freeze. Do not re-ask settled platform boundaries, hosting, four audience inclusion or Student 12+16 requirement.

## 6I. Round 23 reconciliation — entitlements, approval ledger, transfer consent and reconciliation (DOCUMENTATION ONLY)

**Owner answers (21 October 2026):** All five choices are explicit discovery decisions, not local implementation scope approval, database migration authority, provider mutation, independent testing acceptance or deployment permission. Sections 6G and 6H remain for history; this section is the **current owner-decision authority** for the five topics below.

| ID | Confirmed owner answer | Owner-decided contract | Unapproved specifics / required evidence |
|---|---|---|---|
| **R23-01** | **A — Admin is authoritative for purchased tool entitlements** | Admin controls versioned plan/pack grants, paid status and Root eligibility. Client checks authoritative Account + Root + plan + pack + user/action/state before protected tool activity, rather than trusting a stale entitlement projection. | Exact online check or revocation-aware proof, permitted caching, revocation latency, service-outage behavior, auth workload credentials, negative tests. |
| **R23-02** | **A — Admin's authoritative project ledger** | Admin persists immutable exact-version design/content and final-project decisions. Client authenticates the owner and submits an intent; Admin verifies live owner identity/membership/Root/version, records decision atomically in its own D1 and returns confirmed outcome. | Signature/proof or delegated request envelope, ticket expiration, duplicate/replay handling, same-time version changes, return/notification idempotency. |
| **R23-03** | **A — Both account owners plus staff verification** | Current owner and destination owner must each give verified, traceable approval for a Root ownership transfer. Authorized staff review contractual/financial/privacy prerequisites, and relevant member or guardian consent is also required where law and classification demand it. | Identity step-up and approval expiry, freeze window, precise eligible data classes, suspended plans/dues, old invoices, support cases, revocation and recovery protocol. |
| **R23-04** | **A — Owner and explicitly authorized collaborators may inspect protected previews** | Preview access may be granted to the Root owner and named authorized collaborators; **only the account owner** may execute the two formal approval actions. Staff-only artifacts and other Root/account previews remain segregated. | Local preview origin, short TTL, direct/link access model, revocation and immutable artifact delivery, share-leak prevention, external review only with separate remote authority. |
| **R23-05** | **A — Operations-led reconciliation with restricted escalation** | Bounded automatic idempotent retries first; Operations may view status and initiate authorized reconciliation. Billing alone independently confirms financial corrections; critical identity/security/entitlement/transfer overrides require privileged approval with recorded reason and audit. | Specific Operations repair permissions, maker/checker separation, poisoned-message inspection, incident escalation, tamper-evident evidence and reconciliation SLA. |

### 6I.1 Updated authoritative allocation and trust boundaries

1. **Public Lead:** Original Public Backend remains source for anonymous inquiry; authenticated, deduplicated handoff to Admin qualification remains required. A lead is not a customer identity or accepted purchase.
2. **Admin D1 (authoritative):** staff IAM/role assignments; qualified leads, immutable quotes and independent payment verification; plan catalogue and active/retired entitlement grants; Root IDs/account association and lifecycle/project stages; exact-version project approval ledger; complete support cases/thread, staff-private notes and operational reconciliation/audit.
3. **Client D1 (authoritative):** customer IAM/MFA/sessions, guardians, membership and access grants, current client account context, Root-scoped private workspaces/record versions and customer-generated tool material. Root/entitlement/project/support displays may have derived views but those **do not become independent sources of authorization**.
4. **Worker-controlled private R2:** quarantined/scanned eligible imported Office originals, authorized generated exports and bounded preview assets, with enforceable metadata/revocation and no direct browser credentials. Root transfers and permissions must be rechecked before serving any object or export.
5. **Independent site CMSs:** remain separate and not delivered by this scope; locally tested two-consumer SSO broker cannot be represented as a deployed CMS action. Public Core D1 `0001–0016` and Analytics D1 `0001–0002` are byte-frozen.
6. **Cross-service events:** authenticated, versioned, minimal payload, idempotency receipt and authoritative actor validation. No distributed/atomic D1 transaction spanning Admin and Client; reconcile partial commits and show Pending/Blocked rather than inventing success.

### 6I.2 Transactional authorization: required invariants (mechanism not yet approved)

- **Tool operation:** A valid Client customer session and current Root membership are necessary but not sufficient. Admin's authoritative Root `Live`, paid website plan, one eligible active pack, precise operation/entitlement, term and account/Root association must be checked at protected operations. Owner-only approvals and guardian restrictions apply independently. Upon uncertainty, do not authorize writes, import, export, share, or irreversible actions from a stale copy; customer-visible outcomes must be truthful. The selected availability strategy still needs owner review.
- **Project approval:** The owner identity is established by Client IAM and attested to Admin through a bounded authenticated workload contract. Admin checks owner status and the current immutable artifact hash/version, keeps approval1 (design/content) and approval2 (final) separate, and commits one definitive immutable receipt per valid action. An already superseded version, replay or concurrent conflicting decision is rejected. Staff and collaborators may review/comment, never approve for the customer.
- **Transfer:** Prepare inventory and both verified owner approvals, including guardian/member requirements. Restrict/freeze affected operations, prevent overlapping transfers, reconcile contracts and Root-scoped eligible records, move Root authority exactly once at Admin, revoke obsolete shares/preview/SSO sessions as applicable, then confirm Client re-scoping. A partial transfer remains Pending/Blocked for supervised repair. Historic invoices, legally nontransferable records, personal data from unrelated Roots and private records lacking valid transfer authority are never silently re-parented.
- **Reconciliation:** Automatic retries and compensations are bounded and idempotent. Operations may initiate a permitted recovery path but cannot self-verify a payment or forge a customer approval. Billing controls payment verification; privileged security changes require appropriate step-up/separation of duties. Keep sanitized append-only decision and event logs without sensitive payloads or auth tokens.
- **Preview:** An owner/collaborator can view the same immutable protected local artifact according to their grant. The collaborator cannot inherit an approval capability because the preview is visible; only the owner creates the two exact-version approval records. Local preview availability is not evidence of authorized staging or a live website CMS.

### 6I.3 Conceptual cross-service DFD — proposed mechanics, not deployed

```mermaid
flowchart LR
  V[Public visitor / quote wizard] --> PL[Original public lead service]
  PL -->|authenticated handoff| A[Admin Worker API]
  Staff[Individual staff + MFA] --> A
  A --> AD[(Admin D1 - authoritative grants, Roots, projects, approvals, support)]
  Owner[Customer owner + MFA] --> C[Client Worker API]
  Collaborator[Authorized collaborator] -->|preview and comment only| C
  C --> CD[(Client D1 - customer IAM, membership, private workspace)]
  C -->|authenticated owner decision / entitlement check| A
  A -->|versioned event and confirmation| C
  AD --> O[Proposed durable outbox and bounded reconciliation]
  O -->|idempotent signed/workload-authorized event| C
  A -->|Worker-only| R[(Private R2 - preview, imports, exports)]
  C -->|Worker-only| R
  A -.-> CMS[Two isolated local CMS SSO test consumers, not deployed]
```

**All arrows are conceptual contracts.** The exact transport, permission token/proof design, outbox, separate D1 migration DDL, queue resources and runtime configuration are NOT APPROVED. Do not confuse design descriptions with running Workers or working provider integrations.

### 6I.4 Minimum negative/security/reliability tests — NOT RUN

| Test area | Required negative and race cases | Status |
|---|---|---|
| Entitlements | forged/stale `paid` claim, wrong Root/Account, same-person other account, out-of-order suspend/renew, stale projection following cancellation/transfer, Admin outage and revocation racing export/share | **NOT_RUN** |
| Owner approval | collaborator attempts approve, staff impersonates owner, wrong project/version/hash, two simultaneous conflicting decisions, approval replay, owner disabled between initiation and Admin commit | **NOT_RUN** |
| Transfer | forged receiving owner, missing one owner consent, guardian restriction, cross-Root originals, plan mismatch/unpaid dues, simultaneous destinations, revoked shares and half-complete two-D1 commit | **NOT_RUN** |
| Preview | unauthorized collaborator, wrong account/site, expired/revoked grant, superseded artifact, link forwarding, private object enumeration, client content interpreted as executable HTML | **NOT_RUN** |
| Repair/reconciliation | Operations edits `Paid` directly, Billing bypass, poisoned event, duplicate/out-of-order/old schema, missing ack, outbox restart, log leakage, repair reactivating a revoked user or entitlement | **NOT_RUN** |
| Recovery | diverged Admin and Client D1 restore points plus R2 object inventory; 90-day protected recovery copies and monthly exercises against RPO 24h/RTO 48h goals | **NOT_RUN** |

### 6I.5 Historical unresolved contract queue before Round 24

1. **Current entitlement proof and outage behavior:** online authority check versus tightly bound revocation-aware proof, permitted read-only modes and fail-closed response when Admin is unavailable.
2. **Transfer obligations:** which past contracts/invoices, domain/mailbox links, staff support cases, shares/previews and client-owned records survive or require new explicit approval by the destination owner.
3. **Customer-facing support attachments:** permitted file classes, common sizing rules versus separate caps, scanning/quarantine, Admin ownership and Client-authorized access, guardian handling.
4. **Approval and preview transport:** approval exchange/nonce/TTL and local preview lifetime. These are mostly engineering design choices under final scope review, not a request to reopen owner-only approvals.
5. **Cross-service repair authority:** write-specific Operations vs Billing vs privileged override matrix, without inventing unrestricted repair rights.
6. **Other existing gates:** numeric commercial prices/quotas, exact domain/email/transactional-email providers, support calendars and tier response targets, countries' child-data/legal residency/deletion, original full-master/source verification, two separately approved Admin/Client migration/recovery plans and final local-scope consent. These remain genuinely OPEN/BLOCKED; no prior QA PASS transfers.

**Round 23 checkpoint (superseded by Round 24 additions below):** OWNER DECISIONS RECORDED; implementation `NOT_BUILT`; migration DDL `NOT_CREATED`; Client/Admin ASVS and risk mappings `NOT_ASSESSED`; tests `NOT_RUN`; provider/spend/deployment `NOT_AUTHORIZED`.

## 6J. Round 24 reconciliation — entitlement outage, transfer history, support images and controlled repair (DOCUMENTATION ONLY)

**Owner answers (21 October 2026).** This is an explicit discovery decision ledger, not local implementation scope approval or authority to create schemas, application source, providers, invoices, external messages or remote resources. The earlier 6I.5 unresolved list is a *historical pre-Round-24 checkpoint*; this section is controlling for the five topics below.

| ID | Explicit owner answer | Current authoritative policy | Open detail / verification |
|---|---|---|---|
| **R24-01** | **A — Lock tool access temporarily** | If Client cannot verify the current Admin-authoritative account/Root/Live website/active website plan/one active tool-pack/term/operation eligibility, protected tools **fail closed**. Display an accurate temporary-unavailable state rather than infer permission from an old Client projection. | Endpoint timeout and revocation strategy, retries, error UX and recovery; test reads, writes, private imports, downloads/exports and shares against outage, stale grants, reactivation and races. Do not mistake general account login for paid entitlement. |
| **R24-02** | **A — Transfer eligible remaining services; retain historical invoices** | On a verified transfer approved by **both account owners** and staff (R23-03), eligible remaining Root-bound services can continue with the receiving account if contract/provider/privacy rules permit. **Historical invoices and their contracting/legal debtor relationship remain with the original account.** Future renewals require destination-owner acceptance and appropriate verified payment. | Transferability of domain, hosted mailbox, provider contracts, tax, outstanding balances, prepaid terms and jurisdiction-specific restrictions. Neither provider mutation nor new paid contract is automatic. |
| **R24-03** | **A — Preserve history; revoke old access; new owner approves unfinished work** | Preserve immutable previous project decisions and versioned preview history as restricted audit evidence; promptly revoke previous owner's account/Root-bound preview, share and approval access. The destination owner exclusively approves **unfinished project milestones** and new versions; do not forge, edit or duplicate historical approvals. | Exact transfer freeze, pending approval invalidation, preview issuer/revocation, member/guardian grants, cross-D1 ack/recovery; whether historical audit records are visible to destination owner requires classification-based response filtering. |
| **R24-04** | **A, clarified as “images” — Images only** | Although option A was worded “Images and PDFs only,” the owner's added free-text **“images”** is treated as the narrower controlling choice: **only image attachments in customer support cases; PDFs and Office files are not authorized as support attachments.** This does **not** change permitted original Office imports in approved Student/other tools. | Exact raster formats, animated/SVG restrictions, image dimension/byte/count caps, metadata stripping, scanning/CDR, private R2 retention, authorized staff and customer download. Resolve as design limits; do not infer image formats merely from “images.” |
| **R24-05** | **B — Permit controlled operational record corrections** | After bounded automatic retries, Operations may propose/perform **designated non-financial operational corrections** only through an authorized, versioned correction workflow with a **different independent authorized reviewer** and complete before/after/reason/evidence audit. Corrections must preserve authoritative ownership and not manufacture cross-D1 success. | Eligible field allowlist, reviewer-role matrix, approval expiration, conflict/version handling, key/event compromise response and error budgets. **No Operations authority** to change `Paid`, verify settlement, edit prices, mint entitlement grants, impersonate customer approval, reset MFA, bypass child access, or force Root transfer; protected exceptions require their existing Billing/privileged and owner controls. |

### 6J.1 Reconciliation with original Client authority and prior owner decisions

1. **Entitlement, identity and consistency:** R24-01 extends R22-03 and R23-01. Admin D1 remains authoritative for paid plans, Roots and grants; Client D1 remains authoritative for customer session/membership, guardians and private records. An Admin outage or stale cross-service projection cannot become an implicit Client-side grant. Distinguish temporary commercial-tool denial from other correctly authorized account/support access. The source-of-truth split and durable Pending states are unchanged; no cross-D1 ACID claim is made.
2. **Transfer and finance:** R24-02 refines the “eligible Root-owned services” scope in R22-05 and the both-owners-and-staff verification in R23-03. It does **not** move historic invoices or absolve prior financial obligations. Plans expire independently; only contractually transferable unused service remains eligible. No implicit paid extension and no unapproved domain/registrar/mailbox provider operation.
3. **Transfer and project approvals:** R24-03 refines the Admin immutable ledger (R23-02) and owner-only two-stage approvals (R18-06/R19-06). Historical approval evidence is preserved but old grants are revoked, and unfinished milestones await destination-owner approval. Client authorization, Admin Root authority and R2 preview access must agree before completing the transfer; partial state is `Pending/Blocked` until reconciled.
4. **Support images:** R24-04 narrows R21-04's authorized support-attachment workflow. Admin remains authoritative for full support threads and staff-private notes (R22-04). Only permitted inspected *images* may be exposed through scoped Worker endpoints; direct R2 credentials and cross-account ticket attachment reads are forbidden. The original Office source-file import policy (R18-04) is unrelated and unchanged.
5. **Operations maker/checker:** R24-05 extends R23-05. Independent secondary review is required for authorized non-financial correction operations; Admin business invariants still need version checks and durable audit, Client cannot be updated by independent ad hoc DB writes, and correction replay/out-of-order delivery must be idempotent and safe. A Super Admin's elevated privileges do not make fabricated client consent acceptable.
6. **Original security authority remains unchanged:** Complete `authority/master/04_SECURITY/`, `SECURITY/CLIENT_PANEL_SECURITY_REQUIREMENTS.md`, threat model, 151-title risk baseline and 345 ASVS entries. File safety, least privilege, CSRF/session hardening, property/object/function authorization, immutable business approvals, logging/privacy and fail-closed behavior apply without inherited PASS. No applicable security check is N/A merely because the decision table is complete.

### 6J.2 Updated proposed cross-service state model — NOT IMPLEMENTED

```mermaid
flowchart LR
  Client[Client Worker: member / guardian / Root context] -->|fresh scoped tool authorization| Admin[Admin Worker: authoritative grants and live Root]
  Admin --> AD[(Separate Admin D1)]
  Client --> CD[(Separate Client D1)]
  Admin -->|confirmed scoped response| Client
  Admin -->|unavailable / unverifiable| Block[Tool operations temporarily BLOCKED]
  Client -->|active support case with inspected image| Support[Admin-authoritative threaded support]
  Ops[Operations: non-financial proposed correction] --> Review[Independent authorized reviewer]
  Review -->|approved, version-bound| Admin
  Admin -->|durable outbox / reconciliation proposal| Client
  Admin -->|private Worker-mediated object access| R2[(Private R2)]
  Client -->|private Worker-mediated object access| R2
```

Diagram is conceptual only. Service transport, freshness, request signing, image processing, storage boundaries, correction reviewer identity and two independent migration lineages still need engineered contracts and tests; drawing a flow does not prove implementation.

### 6J.3 Required negative, race and failure tests — **NOT_RUN**

| Area | Examples of tests required in later authorized local implementation | Status |
|---|---|---|
| Tool outage | Admin offline, timeout, stale paid flag, revoked Root, membership changed, suspended plan, stale share/export download, retry storm, error leak, wrong-account optimistic cache | NOT_RUN |
| Transfer finance | Forged/duplicated both-owner signatures, current-owner change mid-transfer, old invoice re-parent, moved debt, expired pack, provider non-transfer, outstanding renewal, split Admin/Client commit | NOT_RUN |
| Transfer preview | Old owner URL/session/SSO/share survives transfer, unfinished approval incorrectly accepted, stale hash/version, historic ledger altered, wrong recipient sees restricted prior comments | NOT_RUN |
| Images-only support | Valid JPEG/PNG/etc according to *future approved allowlist*; PDF/Office/HTML/SVG/polyglot/oversize malformed image denial; metadata leaks; scanner outage; direct R2 bypass; wrong-ticket/Root; race after case closure | NOT_RUN |
| Operations corrections | Self-review, wrong reviewer, changed reviewer's role, forged/stale reason, nonallowlisted financial/identity/entitlement field, duplicate/out-of-order repair, poisoned outbox, restored stale grant, inconsistent dual-DB response | NOT_RUN |

### 6J.4 Historical open matters after Round 24 (superseded where resolved by Round 25)

- **Support image contract:** permitted types, byte/dimension/count limits, metadata/animation policy, scanner failure and authorized case attachment retention; support attachments are **images only**, not PDFs.
- **Operational correction matrix:** precise correctable fields, two-person independence, reviewer roles and immutable audit; financial and high-impact security/ownership actions remain outside Operations correction authority.
- **Transfer and contract adapters:** provider/domain/mailbox eligibility, outstanding debt, historic invoice classification, cancel/rollback/forward completion, destination customer views, guardian/minor restrictions and obsolete-preview access removal.
- **Engineering design/specification:** authenticate and authorize cross-service requests, short-lived proof/online checks and revocation, durable outbox implementation using approved existing local tooling only, poisoned-event handling, local preview/SSO contract, two separate isolated Admin/Client D1 migration lineages and recovery tests, without modifying public frozen lineages.
- **Owner/legal/provider/release gates:** twelve website-package prices, renewal amounts, four tool-pack prices, numerically defined common quotas (beyond already approved import caps), domain/mail/transactional-email/scanner provider contracts, exact per-market service calendars and tier response commitments, residency and minor-record law, requested indefinite retention/no-voluntary-deletion legal exceptions, original full-master check and final explicit local scope approval. Separate remote/spend/staging/production authority is still required.

**Historical Round 24 checkpoint: DECISIONS RECORDED.** Client/Admin application **NOT_BUILT**; Admin and Client D1 **NOT_CREATED**; risk/ASVS **NOT_ASSESSED**; tests **NOT_RUN**; provider integrations/recovery objectives **NOT_VERIFIED**; remote mutation/deployment **NOT_AUTHORIZED**.

## 6K. Round 25 decisions — support images, correction review, transfer history, provider reviews and regional service matrix (DOCUMENTATION ONLY)

**Owner answers (Round 25; explicit decisions, NOT permission to implement):**

| ID | Owner-selected answer | Binding design rule | Still requires engineering/evidence |
|---|---|---|---|
| **R25-01** | **A — JPEG, PNG and WebP only** | Support attachments allow only JPEG, PNG and WebP; the option selected in Round 25 additionally proposes **5 MB per image, at most 3 images per message**. SVG, GIF/animation, PDF, Office and other formats are excluded from support-case attachments. Workspace Office imports remain separately approved. | File-signature and decoded-type validation, dimensions/pixel limits, decompression and malicious-content checks, scanner/quarantine availability, metadata stripping and storage/deletion lifecycle; verify proposed 5 MB/3 count against cost/runtime. |
| **R25-02** | **A — Operations proposes; Super Admin reviews** | Maker/checker: authorized Operations staff prepare corrections for strictly allowlisted, non-financial operational fields; a *different* Super Admin approves the exact version and reason before it can be applied. Self-review, staff impersonation and review after value/version change fail closed. | Approved list of fields, required evidence, concurrency protocol, privilege checks, rollback/reversal and tamper-evident audit. No overrides to identity, MFA, owner approval, Paid, grants or transfers. |
| **R25-03** | **A — Preserve original case history** | Historical support cases remain with their original contracting account when a Root transfers. The destination account does **not** inherit the old case thread, staff-only notes or image objects. A new destination case may reference explicitly approved, redacted context. | Process for ongoing ticket closure/cross-reference, retention/legal requests, staff redaction, notification and restricted evidence integrity. |
| **R25-04** | **A — Manual provider-specific transfer review** | Domain and hosted mailbox transfers require provider-by-provider staff review, verified owner authority, costs, mailbox/privacy and contract checks. No automatic registrar/email mutation is authorized. | Actual registrar/mail vendor, supported market, porting conditions, technical steps, expected downtime, fees and a separately authorized provider action. |
| **R25-05** | **A — Prepare complete proposed regional service matrix** | A versioned eight-market support-schedule/response-target proposal must be prepared for owner approval, including staffing/cost and holiday calendars. | Exact approved service hours, published tier SLAs, staffing, holiday exceptions, incident escalation and measured service evidence. The **proposal below is not an owner-approved schedule or contractual SLA**. |

### 6K.1 Required image-handling and support-case guarantees

1. Support images are not a generic file vault. Authorize case/account/Root/user at upload, processing, metadata read, download, export, deletion and staff review; no arbitrary R2 URLs or direct client R2 credentials.
2. Proposed initial limit: **5 MB each, maximum three images per support message** (based on the selected option's stated terms). Verify byte conventions, aggregate per-case size, pixel dimensions, decoded image memory, image metadata policy and platform costs. Do not claim these limits are runtime-validated.
3. Enforce allowlisted decoded formats **JPEG/PNG/WebP**; reject spoofed extensions/MIME, SVG, active content, GIF/animation, malformed/polyglot files, decompression bombs and oversize dimensions. Randomize storage keys; quarantine and scan/inspect before availability; transform to safe rendering form where justified; prevent unsafe inline serving and leaks via previews, logs or notifications.
4. Until scanning, format checks and authorized private storage succeed, attachment state remains **Pending/Rejected**, not downloadable or delivered as a support image. Scanner failure must fail closed with a visible state. Capture scanner/version evidence and retention classification.
5. Historical case retention during Root transfer is **original-account-only**. Destination-case references disclose no private notes, original messages or attachments without a separately authorized, minimised disclosure.

### 6K.2 Operations correction control — decided policy, proposed enforcement mechanism

```mermaid
flowchart LR
  OA[Operations Manager: propose allowlisted correction] --> VC{Field + version + evidence valid?}
  VC -->|No| DENY[Deny + audit]
  VC -->|Yes| REVIEW[Different Super Admin reviews exact request]
  REVIEW -->|Rejected or stale| DENY
  REVIEW -->|Approved| COMMIT[Authoritative Admin write + append audit + durable outbox]
  COMMIT --> SYNC[Client projection reconciliation: Pending to confirmed]
  SYNC -->|Cannot confirm| LOCK[Fail closed for dependent operations]
```

A reviewer may not approve their own correction through role switching; proposed and committed value, source version, actor identities, rationale and timestamps must be preserved. No generic "fix database" endpoint. Financial updates require independent Billing verification; account-owner approvals and Root-transfer consents require their existing actors. The append-only/tamper-evident audit mechanism remains an engineering task, not an achieved guarantee.

### 6K.3 Eight-country regional support schedule — COMPLETE PROPOSAL, NOT OWNER-APPROVED

The table proposes **customer-facing business hours**, not national statutory work hours or proof of iDigitalRoot staffing. All times below are *customer-market local times*, 09:00–17:00, exclusive of an approved country-specific holiday calendar. One named schedule/version per country is required, and the ticket must bind to the agreed market/tier and its effective contract version. The chosen weekdays reflect a **proposed service pattern** and must be checked against actual staff availability, costs, religious holidays and local regulatory obligations before commercial publication.

| Market | IANA zone | Proposed support days | Proposed local hours | Holiday calendar and market verification |
|---|---|---|---|---|
| Lebanon | `Asia/Beirut` | Monday–Friday | 09:00–17:00 | Lebanon official holiday and operating calendars: verify and approve |
| Iraq | `Asia/Baghdad` | Sunday–Thursday | 09:00–17:00 | Iraq official holiday and operating calendars: verify and approve |
| Bahrain | `Asia/Bahrain` | Sunday–Thursday | 09:00–17:00 | Bahrain official holiday and operating calendars: verify and approve |
| Kuwait | `Asia/Kuwait` | Sunday–Thursday | 09:00–17:00 | Kuwait official holiday and operating calendars: verify and approve |
| Oman | `Asia/Muscat` | Sunday–Thursday | 09:00–17:00 | Oman official holiday and operating calendars: verify and approve |
| Qatar | `Asia/Qatar` | Sunday–Thursday | 09:00–17:00 | Qatar official holiday and operating calendars: verify and approve |
| Saudi Arabia | `Asia/Riyadh` | Sunday–Thursday | 09:00–17:00 | Saudi official holiday and operating calendars: verify and approve |
| United Arab Emirates | `Asia/Dubai` | Monday–Friday | 09:00–17:00 | UAE official holiday and operating calendars: verify and approve |

**External context, not iDigitalRoot commitments:** Official Saudi Press Agency describes Sunday–Thursday governmental working days and Friday–Saturday weekend (https://www.spa.gov.sa/7e453de27d); the UAE government describes a Monday–Friday federal government pattern with Friday half-day, Saturday–Sunday weekend (https://u.ae/en/information-and-services/jobs/working-in-uae-government-sector/working-hours-in-the-public-sector). These support distinct market calendars but **do not establish iDigitalRoot staffing or customer support availability**. Verify every country's current holidays and the actual staffing model before publication. Lebanon timezone has seasonal offsets; store IANA zone, not a fixed UTC offset. Provider/weather/bank holiday dates are not inferred from customer country.

**Proposed differentiated first-human-response targets; all durations are eligible business-hours only (NOT an approved SLA):**

| Severity | Entry | Growth | Premium | Scope/interpretation |
|---|---:|---:|---:|---|
| Critical | 4 business hours | 2 business hours | 1 business hour | High-impact service/security issue triaged under documented procedures; no 24/7 guarantee |
| High | 1 business day (8 h) | 4 business hours | 2 business hours | Major functional blockage affecting business operations |
| Normal | 2 business days (16 h) | 1 business day (8 h) | 4 business hours | Ordinary defects/service inquiries |
| Low | 4 business days (32 h) | 2 business days (16 h) | 1 business day (8 h) | Guidance/low-urgency requests |

Business-hour countdown pauses outside the purchased market calendar. Ticket submission remains available through the portal around the clock **only when the platform is operating**; first-response clocks do not imply round-the-clock staffing. No resolution-time, financial credit, on-call rota or uptime promise is included. A security incident may require a separate confidential escalation procedure, not a fabricated advertised 24/7 human response. Every service-level calculation needs holiday-version, timezone/DST, priority-change, case-reopen and notification-delivery tests. **Business ownership:** Operations drafts the matrix and costs; Billing validates plan pricing; Support validates staffing, capacity and holiday coverage; owner approves exact terms before any customer promise.

### 6K.4 R25 negative/security acceptance tests — NOT_RUN

- Image-only allowlist: extension/MIME spoof, SVG/HTML/PDF/Office upload, GIF/animation, polyglot and malformed JPEG/PNG/WebP, exif leak, dimension bomb, image parser/scanner failure, virus signature, oversized file and fourth image in one message; no direct R2 access; revoked/cross-account case download; attachment transfer to destination case denied by default.
- Correction maker/checker: same actor self-review (including account switch), unallowlisted field, forged staff scope, stale version, parallel reviews, independent reviewer disabled, approval-reason tamper, retry/duplicate outbox events; no Paid/entitlement/session/transfer bypass, full pre/post evidence and audit.
- Root transfer with open support case: old thread remains confidential with originating account, destination case contains only approved redacted references, historical invoices and immutable approvals unchanged, old user grants/shares revoked, cross-Root/minor restrictions still enforced.
- Registrar/mailbox transfer: no provider API side effect from local testing; missing receiving-owner authorization, stale provider ownership, unsigned quotation, undisclosed cost and mailbox privacy concern all block provider action.
- Regional SLA calculator: each of eight market calendars, IANA zone/DST, Friday/weekend edge, holiday closure, tier change, severity change, reopened ticket, midnight cutoff, first-human-response timestamp, backlog, concurrent support capacity, missing calendar version; outputs **NOT_RUN** until implementation.

## 6L. Consolidated implementation-scope outline v0.1 — WORKING DRAFT, NOT SCOPE APPROVAL

This section is a **reconciliation scaffold**, not the final frozen implementation contract. It groups current owner-decided scope and identifies missing release-critical facts. Do not treat an unspecified exact API route, new D1 table, outside provider, numeric cost or source code as approved by this section.

| Workstream | Existing owner-decided scope | Must be pinned in final scope / remaining blockers |
|---|---|---|
| Audience & experience | EN native/LTR and AR native/RTL; accessible responsive calm Client; eleven specialized areas (Home, Roots, Projects, Tools, Domains, Email, Services, Billing, Renewals, Support, Account) | Actual route/site map, complete component state matrix, a11y/keyboard/reduced-motion, staff Admin screens and acceptance |
| Company/platform separation | One public company site with 4 audience stories, public CMS separate from Admin, Client and independently scoped site CMSs | Current MOTION01 source/AGENTS.md verification, compatible read-only public lead handoff; do not change frozen public migrations |
| Admin staff | Five specialized roles; Operations Manager broad coordination, Pending payment evidence; Billing independently verifies payments; Super Admin reviews Ops allowlisted corrections | Full field-level RBAC/maker-checker matrix, privileged MFA/session, restricted support access, operational controls/audit |
| Customer identity & teams | Client-authoritative identity/MFA/memberships; verified invitation after accepted quote, password + emailed code normal login, passkey/security key sensitive step-up; separate pre-registered recovery + supervised reset; owner + limited collaborators with account switching | Precise recovery/guardian proof, member onboarding/revocation, per-account Root visibility, limited support-session access and risk-based action re-auth |
| Products & billing | Admin-authoritative 12 annual creation+service website packages, 4 separate tool packs, one active pack per Root; matching year-one tool pack, paid switching, monthly/annual paid packs, owner-only acceptance, manual invoices/reconciliation, no auto renewal | **Approved monetary prices & pack switch amounts** (one by one), actual resource quotas, taxes/currencies/country terms, bundled domain/mail allowances/providers |
| Project/Root lifecycle | Admin-authoritative verified purchase → Root creation, typed versioned 4-family intake, stage updates, protected local previews, two exact-version owner approvals, controlled both-owner+staff transfer | State/action matrix, exact artifacts/preview TTL/site binding/consent, project and staff/private note boundary, third-party services and transfer rollback |
| Support & notifications | Admin-authoritative threaded support; Client scoped reply/visibility; image-only JPEG/PNG/WebP support attachments; regional business-hours/tier model; portal inbox + real transactional email required | Support schedules and response proposals **not approved**, email provider, staffed coverage, image scanner and privacy/retention |
| Four audience packs | Student 12 Toolbox +16 Workspace positions/27 distinct capabilities, Professional reuse, Entrepreneur 4 additions, Business 2 additions; all first commercial release | Per-tool acceptance/role/field/schema/format/share matrix, guardian grants, quality and adversarial tests; no AI or paid social analytics dependency |
| Office/workspaces | DOCX/XLSX/PPTX/CSV/ICS controlled imports, retained inspected originals in private R2, no generic vault; 10MB document, 2MB CSV/ICS, 25MB batch design ceilings; currency-specific Student Budget, coordinated calendar, timer 10min idle/correction history, opportunity Career Kit snapshots, private Portfolio and structured Research Shelf | Parser/scanner feasibility, file-count/decoded-size quotas, encryption/classification, safe PDF/DOCX output and accurate export/share permissions, 30-day default/90-day max shares |
| Data authority & synchronization | **Separate Admin D1 and Client D1**; Admin owns commercial/Roots/projects/approvals/support; Client owns customer IAM/membership/guardian/workspaces; Admin entitlement checks fail closed when unreachable; durable outbox/Pending/reconciliation | Two **new independent** reviewed migrations/recovery lineages; cross-service protocol, idempotency/order/replay/version, least-privilege bindings, transfer and dual-DB restore failure semantics |
| SSO & website CMS | Signed single-use, short-lived, site/user/audience/scoped SSO; two isolated **local test consumers** | Actual client CMS remains unbuilt; broker is contract test only, never show Open Website Admin as live; real consumer/release needs separately approved scope |
| Security, privacy & delivery | Original seven security authority files; preserve 151-title risk inventory and 345 ASVS requirements; strong ASVS L2/applicable L3; Workers+D1+private R2; local workerd/browser EN/AR tests; sealed source/manifest/SBOM/reproduction | **ALL Client ASVS/risk work starts NOT_ASSESSED, tests NOT_RUN**; child-data guardian/legal checks for 8 countries, deletion/retention conflict, reviewed providers/independent QA, 90-day recovery copies/monthly exercises, RPO24h/RTO48h objectives not tested |

**Engineering implementation order after (and only after) explicit final bounded scope approval:** (1) verify exact original master SHA/CRC/manifests/read order, current sealed MOTION01 and local repo tooling; (2) approve separate Admin/Client isolated D1 migration/recovery tasks, preserving public Core0001–0016 and Analytics0001–0002 byte-for-byte; (3) implement staff/customer identity + cross-service authorization and audit; (4) build one real purchase→Root→onboarding→protected preview→two owner approvals→support vertical slice; (5) finish commercial/renewal/domain-email *metadata*, outbox/repair/transfer/notifications; (6) implement full four-audience approved workspaces with real persistence/import/export/share; (7) threat/ASVS/negative/race/local Workers-D1-R2/browser EN/AR-a11y tests and exact-version fixes; (8) immutable sealed review ZIP, checksum manifest, pinned locks, test/security matrices, SBOM/provenance, fresh extraction, owner guide and unresolved risk list. This is an **internal draft work sequence**, not new approval to construct, deploy, operate or spend.

**Explicit blocked/late-gated items:** full original master companion (`IDIGITALROOT_CODEX_MASTER_HANDOFF_2026-10-14_v1.1.zip`, required SHA256 `f1ea6c341baf3c81afa5b797ed09beb9b1a400325338e8a42ed671c2a5f23b20`) not fully verified here; exact current MOTION01 source evidence/AGENTS.md not yet re-inspected for implementation; final scope and isolated migration owner approval not granted; commercial prices and provider selection remain TBD; multi-market minors/privacy/residency/deletion law unresolved; tests/provider contracts/independent security/QA not executed; no cloud account resource authority, spend or deployment. **No client application currently built.**

---

## 6M. Round 26 owner decisions — engineering baseline, quota-evidence process, email boundary, mandatory legal rights (21 October 2026)

**Status: DECIDED AS POLICY; NO IMPLEMENTATION OR DEPLOYMENT APPROVAL.** This section supersedes only the conflicting or unresolved proposals explicitly identified below. Historical draft sections remain for traceability, not authority.

| ID | Explicit owner choice | Binding implication | Still open / proof gate |
|---|---|---|---|
| R26-01 | **A — Adopt eight-market support schedule and three-tier response targets as a provisional engineering baseline** | Model per-market calendars/holidays and Entry/Growth/Premium priority response targets from §6K.3, but do not publish as contractual SLA | Actual staffing, holidays, capacity, cost, owner final SLA approval and provider incident response arrangements |
| R26-02 | **A — Prepare measured and costed numerical quota proposals** | Produce a quota proposal with workload measurement, unit economics, safety margins, and abuse-resistance validation; do not invent production capacity | R2/D1/Workers workload measurements, scanner/parser throughput, email/domain costs, exact owner-approved quota numbers, price matrix |
| R26-03 | **A — Provider-independent transactional email interface first** | Define versioned, bounded interface for activation, password reset, email-code MFA, high-impact notifications, support and commercial notices. Local test adapter must be deterministic and clearly simulated | Provider selection, delivery-verification, reputation/rate limits, market coverage, secure secrets and actual provider integration require separate authority |
| R26-04 | **A — Support mandatory legal rights, without elective deletion offering** | Indefinite ordinary retention/no discretionary deletion remains owner's preferred product policy **where lawful**; implement legal-request case intake/assessment, authorized export, rectification, erasure when legally required, guardian request and legal-hold exceptions in design. Do not suppress lawful requests | Country-by-country legal assessment for Lebanon, Iraq, Bahrain, Kuwait, Oman, Qatar, Saudi Arabia and UAE; child-data rules; processor/subprocessor contracts, R2/backup deletion propagation |

### 6M.1 Quota and cost-evidence protocol — proposed engineering measurement plan, NOT measured capacity

Already-decided preliminary upload ceilings: Office DOCX/XLSX/PPTX **10 MB each**, CSV/ICS **2 MB each**, combined import batch **25 MB**, support JPEG/PNG/WebP **5 MB each and 3 per message**. Limits remain subject to actual workerd/parser/scanner tests; stop/fail closed on unsafe or unmeasured paths. New numerical limits for per-Root storage, object count, workspace rows, exports/imports per period, active shares, emails, and processing concurrency remain **TBD**, to be separately owner-approved. Common technical quotas apply across website tiers, while commercial content/care inclusions differ.

Pre-approval costing method:
1. Fix synthetic representative workloads for smallest and largest permitted files, ordinary customer load, burst/abuse cases, and month-end renewal/notification periods. Never use owner production data.
2. When authorized to run local measurement, observe Worker request/CPU, D1 rows read/written and storage, R2 GB-month and Class A/B operations, object copies and 90-day backup amplification, scanning and office-file parser time/memory/failure rates. Label unrun metrics **NOT_MEASURED**.
3. Construct per-Root, shared overhead and 95th-percentile usage cases. Compute costs using the **published provider rate at the dated quotation**, accounting for account-level included allowances and rounding; these are not a client price nor guaranteed bill.
4. Include hosting/domain registration, real hosted mailbox, outbound transactional email, labor for eight-country tiered support, human delivery and independent billing verification, security review, logging, restoration and incident contingency. No "free" domain/mail cost assumption.
5. Propose bounded numbers and rationale with headroom, rate/cost-limit paths and explicit acceptance tests. Owner approves numerical catalogue/quotas/prices one by one before dependent implementation, preserving R10-05 and R13-06.

Published provider inputs confirmed for **21 October 2026** (subject to change):
- D1: https://developers.cloudflare.com/d1/platform/pricing/ — rows read/written, storage metrics and account-level paid allowances; no estimate of iDigitalRoot actual use exists.
- R2: https://developers.cloudflare.com/r2/pricing/ — Standard storage, Class A/B operations and account-level allowances; original Office files + protected backups increase consumption.
- Workers: https://developers.cloudflare.com/workers/platform/pricing/ — request/CPU and plan dependence. **No live billing or provider account usage was accessed or modified.**

### 6M.2 Transactional-email boundary — proposed contract, not provider verification

`NotificationIntent` contains event type, template/version, message locale, recipient verification state, account/Root context when applicable, correlation/idempotency identifiers, priority and privacy-safe metadata; it never stores password, email OTP, passkey credential, token-bearing URL or workspace payload in persistent general logs. Worker-controlled delivery adapter exposes `requestDelivery`, `getDeliveryStatus` and bounded `retry` with time-limited single-use challenges validated on server, rate/abuse protection, idempotent sends and redacted audit. Provider outage yields clear pending/unavailable state; login/recovery code delivery MUST NOT show success unless an actual approved provider confirms accepted delivery in the relevant environment. Local test adapter is explicitly `SIMULATED`; no email is sent by the planning package.

### 6M.3 Data rights / retention and child-privacy boundary

Mandatory legal data-access, correction, portability/export, deletion and guardian-authority handling must be implemented wherever applicable, regardless of a product preference against discretionary deletion. All decisions need proof of identity/authority, least-privilege reviewer, scope, statutory grounds/deadlines, affected Admin/Client D1 + private R2 + 90-day recovery copies, disclosure exception, outcome evidence and customer notice without secret leakage. Requests involving minors require verified guardian scope and valid jurisdiction-specific basis. Unknown law is a **BLOCKED commercial release gate**, not a waiver. Retention, legal hold and immutable financial/security evidence must be separately classified.

### 6M.4 Decision inheritance and no-work gate

Carry forward R1–R25 unchanged unless explicitly superseded above. No full master ZIP inspection, no executable tests, no Cloudflare mutation, no local source scaffolding or schema work is authorized by R26; project state remains **DISCOVERY / NOT BUILT**. Next deliverable is the consolidated implementation-scope draft (separate document), which is not the owner's approval of implementation.

## 7. State and transaction contract — design requirements, NOT schema approval

- **Quote:** staff draft → authorized issuance (immutable version) → owner acceptance/rejection/expiry. Revision creates a new quote version.
- **Manual payment:** submitted evidence (Pending Verification) → separate authorized Billing review → verified Paid or rejected/needs information. Uploaded evidence alone never marks Paid.
- **Entitlement:** an owner-accepted paid annual website-creation package and independently verified payment create a 12-month matching-family included-pack grant and initiate the paid website service period at purchase (R15-01/02/06), not launch; actual tool operations require that the website is live and its plan active. Normal paid tool terms require their own accepted month/year plan and verified payment. Enforce site/account/user/state and period on every operation, export and share. No client-supplied price/role/pack authority.
- **Renewal:** annual website service and tool packs renew independently; tools can renew monthly or annually after promotional eligibility. No auto-charge or automatic paid conversion from the first-year included pack. Generate versioned terms, obtain owner approval and independently verify payment before entitlement changes.
- **Expiry/suspension:** immediately lock tool operations and data access under the approved policy; preserve recorded data, avoid resurrecting expired shares, handle legally mandatory subject access/deletion through separate authorized compliance processes.
- **Pack change:** one active audience pack per Root; within the complimentary first year an owner-authorized switch is allowed only on agreed **paid** terms, otherwise the included pack remains until year one ends. Preserve old data and immutable history, test concurrent switch/renewal and paid-grant replacement races. Exact switch charge/term remains TBD.
- **Financial controls:** idempotent transitions, compare-and-set/version constraints, staff separation of duties, event audit and cross-account/site negative tests.

The above describes an intended business contract, not implemented functionality or a frozen D1 schema. New Client/Admin migrations need separate explicit approval and must not modify the frozen public Core0001–0016 or Analytics0001–0002 lineage.

## 8. Open material decisions and pre-implementation blockers

**Updated through Round 25:** See §§6K–6L for decided support-image allowlist/limits, Operations→Super Admin correction review, original-account support-case history, manual domain/mail transfer checks and the complete **proposed** regional service matrix. Historical open-question text below may include matters resolved by R25; where conflicting, R25 controls. Quantitative support SLAs, domain/email provider contracts, staff coverage and cross-service API details are still unapproved.

1. **Construction-time entitlement (DECIDED R16-01):** complimentary pack and paid website service both start at purchase, but tools are unavailable until go-live; no delay extension. **Outstanding acceptance detail:** customer-visible disclosure/acknowledgment, precise authoritative purchase timestamp, date/time-zone handling and truthful project status. Do not describe this as an unresolved extension decision.
2. **Paid mid-year pack switching:** define amount/method/term, whether previous complimentary grant is cancelled, any credit, and when new pack expires. No free midyear switch is authorized; no second active pack.
3. **Site domain/hosted mail service:** actual registered domain and functional mailbox are included in every tier; define provider, ownership, extensions, mailbox counts/storage, registration timing, failure handling, market suitability, and annual renewal scope. No fake forwarding-only fulfillment.
4. **Prices one by one:** 12 initial annual website package amounts, 12 annual managed-service renewal amounts, four pack monthly/annual amounts, any paid-switch charge, add-ons, and approved contract terms. All remain **TBD** and are blocked for implementation under R10-05 until explicitly approved.
5. **Common numerical ceilings:** R20-06 decides initial per-file ceilings (**10 MB DOCX/XLSX/PPTX; 2 MB CSV/ICS**) and **25 MB/batch**. Exact byte definition, decompressed/row/asset limits and engineering feasibility remain TBD. Storage, file counts, exports, shares, collaborators, and bounded processing costs remain TBD; quota exceptions require approved plan terms.
6. **Country-specific offer terms:** USD base and versioned local quotations, tax/exchange-rate sources, payment evidence, local contract and allowed domain/email service for Lebanon, Iraq and all six GCC markets.
7. **Data/security:** minor guardian-category authorization, member/owner access, lawful retention/deletion and data residency; original privacy constraints are not waived by the owner's indefinite-retention preference.
8. **Operational discovery (R17 reconciled):** per-market business-hours calendars and tier-specific first-response commitments **DECIDED as a model**, exact schedules/targets TBD; full platform-owned backup scope, **90-day recovery copies**, **monthly restore tests** DECIDED as design policy; **RPO 24 hours / RTO 48 hours** remain untested objectives. Pre-registered backup authenticators plus supervised recovery and portal inbox + transactional email are selected; actual procedures, provider, deliverability, evidence, cost and incident plans remain TBD/BLOCKED. R16-03 still requires verified residency/legal processing per country, no unverified MENA-local data guarantee.
9. **Round 18 and Round 19 feature/permission details:** coordinated Student event provenance/ICS merge semantics; Student Timer offline/background rules and correction policy; Student Budget precision/import schema; original Office attachment quarantine/scanning, allowable file classes/quantities/lifecycles; guardian verification/data-category matrix and withdrawal effects; separate design/content and final artifact approval evidence, preview transport and rejected/stale transitions. These are **not** resolved merely by selecting the headline behavior.
10. **Round 19 unresolved implementation details:** Student Timer idle/heartbeat/clock policy; Career Kit snapshot fields and generation constraints; Portfolio safe shares without CMS synchronization; Research Shelf citation/URL validation; original-file download grant matrix; two owner approval artifact transitions and anti-race tests.
11. **Pre-implementation authority:** full original master ZIP verification and original read order, source/AGENTS.md/toolchain inspection, explicit isolated Client/Admin migration lineage, final bounded implementation scope approval. Separate provider/spend/staging/production authorization remains required.

12. **Round 20 narrowed details:** 10-minute idle activity evidence/cutoff and correction rules; Career Kit output composition details; 30-day/default and 90-day/max share recipient/authentication policy; Root Export original-file eligibility/export protection/job limits; 10/2/25 MB file/batch byte convention and measured scanner/parser feasibility. Core choices are decided; these precise mechanics are not.

13. **Round 21/22 two-database contracts (PARTIALLY RESOLVED):** R22-01..R22-06 decide Admin as Root/project authority, Client customer IAM and Admin staff IAM, durable events/Pending failure, Admin support-thread authority, eligible Root-owned transfer scope, and protected LOCAL previews. Section 6G documents the superseded Round 21 alternatives; Section 6H is current. Still pending are authority for grants/approval receipts, exact transfer consents/private-data handling, event/reconciliation implementation, preview TTL/audience/hosting, support attachment rules and **separate reviewed Admin/Client migration lineages**. No schema or remote service approved.

## 9. Required tests when implementation is later authorized

**Additional Round 25 tests: ALL NOT_RUN.** See §6K.4 for image allowlist/scanning, maker-checker concurrency, non-transferred historical cases, provider-specific transfer review, calendar/tier response calculation. Do not infer PASS from a specified test.

**Additional Round 21 and Round 22 tests (NOT RUN):** public inquiry replay/tampered lead IDs, duplicate lead imports and safe outage reconciliation; versioned quote acceptance then forged/duplicated payment evidence; Operations records Pending Verification but only Billing can set verified Paid; Root creation exactly once even on outbox redelivery/recovery, failure between independent D1 commits, stale client entitlement and delayed/reordered/poisoned events; cross-account/Root API and staff-role attacks; support private-note leaks in client APIs, notifications, search, exports, cached projections and logs; transfer ownership races involving two customers, guardian-restricted data, retired shares/SSO, active renewal and partial write; preview access wrong-account/site/user/version and expired/revoked links; two owner approval artifacts stale/concurrent/replayed; dual-DB consistent restore (90-day copies/monthly exercises) and drift repair without resurrecting access. Validate actual separate bindings and authorized service-to-service boundary in local workerd/D1 tests only after scope approval. **No test is PASS yet.**


**Additional Round 20 test requirements (NOT RUN):** credible activity cutoff at ten minutes and corrected session history; single shared Career Kit versioned CV/achievements/portfolio/contact/optional cover letter PDF/DOCX; private-share default thirty days/max ninety days with early revocation and guardian checks; Root Export only expressly selected accessible originals; import rejection above 10 MB/2 MB per type or 25 MB per batch, oversized-expanded inputs, malware/scan provider outage and retry abuse. Test policy/entitlement recheck at queue execution and download.

**Additional Round 19 test requirements (NOT RUN):** verify timer idle pause under closed tab, reload, offline loss, forged client time, two tabs, simultaneous start, stale heartbeat, multiple Roots, and permitted corrections; opportunity snapshot remains fixed after source CV edit and prevents unauthorized contact disclosure; Portfolio private by default and CMS publishing unavailable in absence of real consumer; Research Shelf rejects unsafe references and cannot server-fetch arbitrary URLs; original-file downloads deny unauthorized collaborators, revoked creators, another Root, unapproved guardians, suspended entitlements and expired/granted shares; two immutable owner approvals reject stale hashes, cross-Root/role, replay and concurrent conflicting decisions; both fail to grant deployment authority. Tests must exercise real workerd/D1/private R2 under approved local implementation, not fixtures presented as provider validation.

**Additional Round 18 test requirements (NOT RUN):** mixed semester/course/exam/study/campus events in one EN/AR timezone-aware calendar, ICS import dedupe/recurrence/timezone and malicious references; timer reload/disconnect/restart, modified local clock, tab/device race, pause/resume/stop replay and offline ambiguity; budget correct per-currency/period totals and malicious spreadsheet formulas; import of benign/malformed/polyglot/macro-bearing DOCX/XLSX/PPTX/CSV/ICS, archive bombs, scanner outage, quarantined object not downloadable, cross-Root original-file requests, linked source replacement and private R2 backup/restore; guardian grant denial before consent, narrow category enforcement, revocation, cross-org/Root and guardian-identity misuse; design/content and final-owner approval separately, stale artifact/version, missing staff QA evidence, owner-disabled session, concurrent decisions, and denial of implied deployment authority. **All tests pending; no PASS claimed.**

Test (not yet run): first-year **matching-family** included pack cannot be billed twice, incorrectly renewed, issued to a different Root, extended silently or activated before independent payment verification; benefit and website term use approved purchase date (not launch); no access before the site is live; construction delays never extend the included period (R16-01), and disclosure/expiry is accurate; a paid midyear switch never leaves two active packs and does not silently renew the complimentary grant; no monthly website-creation order; year-two annual website renewal cannot repeat creation by accident; multi-Root pack isolation; one-pack uniqueness under concurrent changes; expiring website vs active pack and vice versa; replayed/changed quote versions; same-person multi-account access; Operations payment evidence without Billing verification; forged price/currency/tax/role changes; renewal date and timezone edge cases; controlled shares after suspension and entitlement change; revocation; stale contract versions; invoices/exports with malicious CSV/office content; minors/guardian access; RPO/RTO breach scenarios and recovery exercises, supervised MFA recovery and session revocation, country-specific data residency constraints, authenticated business-hours support cases, restoration/retention and negative object/function/property authorization. Also test market-specific support calendar/weekend/holiday and tier-response calculations; exercise all platform-owned D1/R2/config/audit restore classes under the 90-day copy policy, **monthly** restore exercise reporting, RPO/RTO measurement and recovery corruption/missing-provider cases; prove lawful deletion and isolation across recovery copies, guardian and disabled-user revocation after restore; validate pre-registered recovery methods and supervised reset, staff separation of duties, OTP-only bypass denial, account enumeration/rate protections; verify portal-inbox and transactional-email security notices, deliverability failure paths, deduplication and safe degradation. **These are future NOT_RUN/BLOCKED tests.** Actual provider and country claims require separate approved integrated testing, not local fixtures.

**Historical Round 21/22 draft checkpoint:** DISCOVERY DRAFT v0.10, NOT ACCEPTED, NOT IMPLEMENTED, NOT DEPLOYED. No application source, database schema, remote resources or GitHub repository contents were changed at that checkpoint.


**Additional Round 22 contract tests (NOT RUN):** staff token used as customer membership, customer MFA/session replay as staff; forged Root lifecycle or owner switch sent directly to Client, stale Root/project/entitlement projection under revoked plan; concurrent Admin Root transfers targeting the same Root and different destinations; transfer involving a guardian-restricted attachment; customer retrieval of staff-only support notes through search/export/attachment metadata; producer committed/outbox event delayed, duplicate, out-of-order, lost, poisoned or replayed; two D1 recovery points diverging, repair without resurrecting revoked grants; preview after expiry/revocation or after artifact supersession; no direct browser R2 access and cross-Root original-file download attempts. Every new test starts NOT_RUN; owner review or provider proof cannot be inferred.

---

**Current document status: DISCOVERY DRAFT v0.15 (through Round 26), NOT SCOPE-APPROVED, NOT IMPLEMENTED, NOT DEPLOYED.** No application source, D1 migrations, GitHub repository contents, Cloudflare resources, providers or production environments were changed by this documentation revision.


**Companion owner-review draft:** `IDIGITALROOT_ADMIN_CLIENT_IMPLEMENTATION_SCOPE_DISCOVERY_v0.1_2026-10-21.md` — a synthesized scope proposal, NOT an approved implementation specification.
