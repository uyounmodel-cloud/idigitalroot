# IDR-P00B — Source archive anomaly triage

Date: 2026-10-21 UTC. No repair, rebuild, checksum regeneration, extraction or historical launcher execution. `PERMISSION_TO_MODIFY_SOURCE = NO`.

## Finding and scope-review classification

**Seven missing generated test-fixture outputs and one original FE test-fixture compiler-config mismatch are freshly reproduced.** Parent archive identity and parent checksum success remain valid statements about delivered bytes; nested fixture self-consistency is FAIL. A component collector exit 0 means collection completed, not nested PASS. Nothing was silently fixed.

All eight anomalies are **NOT BLOCKS_SCOPE_REVIEW**: their exact bytes, provenance and paths are available; they do not prevent reading or reconciling scope documents, and they lie under the preserved legacy public frontend test fixture rather than a new Admin/Client implementation or migration. They remain gates for any acceptance that relies on this fixture. Classification `BLOCKS_SECURITY_ACCEPTANCE` below refers to the affected package/fixture integrity/provenance claim, not a claim that an exploit was demonstrated. This is not a harmlessness finding and not permission to repair.

Local build execution remains **NOT_RUN**. Static scripts show the integration launcher builds the fixture before loading its generated worker, so absence alone is not proof that the supported clean-build path fails. Conversely, the embedded fixture standalone `verify` command first checks its stale/missing files and cannot pass on the delivered tree. Do not collapse these different entrypoints into a single build PASS or FAIL.

## Exact origin and metadata

- Original FE: master member `01_CURRENT_IMPLEMENTATIONS/01_PUBLIC_WEBSITE/IDIGITALROOT_P1-FE-02_PUBLIC_FRONTEND_SOURCE_v1.1.1_CANDIDATE.zip`; SHA256 `3709a3aa234e7f1a5dbb840037b9a9c04e53ac49172b8b216bb309697f24ef95`. Fixture prefix `tests/authority/be01/`.
- Original standalone backend: `01_CURRENT_IMPLEMENTATIONS/03_SHARED_BACKEND/IDIGITALROOT_P1-BE-01_PUBLIC_BACKEND_SOURCE_v1.1.2.zip`; SHA256 `c32aefa179bca74cd6d4f11c42fe02cb5421db6117a9f5f4d711ef674829d1a0`. All seven original dist entries are actually present there.
- Current preserved public candidate: `downloads/IDIGITALROOT_MOTION01_SOURCE_2026-10-16_rc2.zip`; SHA256 `a3a11293559b72dac65973184412b38fbbf76b61cf89e4acec845db812dfbd2b`. Fixture prefix `website/tests/authority/be01/`.
- Original fixture `tests/authority/be01/SHA256SUMS.txt` SHA256 `68ca8ac180248468a2a4a9721e118af1d137771cb5b336ad1b257bde071220e7`; identical to the standalone original backend checksum file. Missing outputs are declared at lines 2–8; tsconfig at line 40. No fixture-level RELEASE_MANIFEST.json is present in original FE.
- Current fixture `website/tests/authority/be01/SHA256SUMS.txt` SHA256 `0049feeb63920562bf3665afeb3266212796d2ee32d54d0a3e0e4a0ec2f49400`; missing outputs lines 3–9. `website/tests/authority/be01/RELEASE_MANIFEST.json` SHA256 `0a1f73b0383b190f877e0b9ec77f9a4c270db97fe271880c61a4f8ec3da32f8b`, version `1.1.3r3`, candidate; parent pin is the original BE v1.1.2 ZIP. That parent declaration does not claim unchanged descendant contents.

Current parent root checksum lines 291/292 cover the embedded manifest/checksum bytes themselves; line 324 correctly records the current tsconfig hash. Root/component success therefore coexists with nested stale entries.

## Seven exact missing entries

Each full current member = `website/tests/authority/be01/` + relative path below; each original FE member = `tests/authority/be01/` + relative path. Current observations are ABSENT for every row, both in the ZIP member set and the previously inspected fixture. Original FE observations are also ABSENT. Expected hashes are declared by the fixture checksum files, not inferred from filenames.

| ID / relative path | Current expected SHA256; manifest entry / bytes | Original FE expected SHA256 | Observed original standalone BE SHA256 | Classification / blast radius |
|---|---|---|---|---|
| A1: `dist/core/crypto.js` | `261daed5a78cb8ca4ab45a14740f33ec668070085dfceb77d7ea4c8af7d5ba3c`; `files[1]` / 703 bytes | `261daed5a78cb8ca4ab45a14740f33ec668070085dfceb77d7ea4c8af7d5ba3c` | `261daed5a78cb8ca4ab45a14740f33ec668070085dfceb77d7ea4c8af7d5ba3c`; PRESENT | BLOCKS_SECURITY_ACCEPTANCE of nested fixture integrity; not scope review; generated local-build prerequisite, supported rebuild NOT_RUN |
| A2: `dist/core/http.js` | `db36fea3279dbbb58564af3e2aecc8e41d10fcb411016be6692e040eb2f32c39`; `files[2]` / 3139 bytes | `db36fea3279dbbb58564af3e2aecc8e41d10fcb411016be6692e040eb2f32c39` | `db36fea3279dbbb58564af3e2aecc8e41d10fcb411016be6692e040eb2f32c39`; PRESENT | BLOCKS_SECURITY_ACCEPTANCE of nested fixture integrity; not scope review; generated local-build prerequisite, supported rebuild NOT_RUN |
| A3: `dist/core/types.js` | `8e609bb71c20b858c77f0e9f90bb1319db8477b13f9f965f1a1e18524bf50881`; `files[3]` / 11 bytes | `8e609bb71c20b858c77f0e9f90bb1319db8477b13f9f965f1a1e18524bf50881` | `8e609bb71c20b858c77f0e9f90bb1319db8477b13f9f965f1a1e18524bf50881`; PRESENT | BLOCKS_SECURITY_ACCEPTANCE of nested fixture integrity; not scope review; generated local-build prerequisite, supported rebuild NOT_RUN |
| A4: `dist/services/inquiry.js` | `ac8e26f575cba2d4287761bb531559563621570b649e91441117b8851f976fed`; `files[4]` / 12606 bytes | `ac8e26f575cba2d4287761bb531559563621570b649e91441117b8851f976fed` | `ac8e26f575cba2d4287761bb531559563621570b649e91441117b8851f976fed`; PRESENT | BLOCKS_SECURITY_ACCEPTANCE of nested fixture integrity; not scope review; generated local-build prerequisite, supported rebuild NOT_RUN |
| A5: `dist/services/public-content.js` | `3abecbf62009545719c3c843052218b360ec7a04c06e3fd2929fe913d0059f40`; `files[5]` / 14682 bytes | `ead33c2c4781cfe9b0f4d4e156bc9a3f4aaa0b908a5d968bfb1577c328175c76` | `ead33c2c4781cfe9b0f4d4e156bc9a3f4aaa0b908a5d968bfb1577c328175c76`; PRESENT | BLOCKS_SECURITY_ACCEPTANCE of nested fixture integrity; not scope review; generated local-build prerequisite, supported rebuild NOT_RUN |
| A6: `dist/site-profile/config.js` | `be38bda84f2f568d26de317ce68f4068b0c3d10f79a6bf4320370d544347a9de`; `files[6]` / 343 bytes | `be38bda84f2f568d26de317ce68f4068b0c3d10f79a6bf4320370d544347a9de` | `be38bda84f2f568d26de317ce68f4068b0c3d10f79a6bf4320370d544347a9de`; PRESENT | BLOCKS_SECURITY_ACCEPTANCE of nested fixture integrity; not scope review; generated local-build prerequisite, supported rebuild NOT_RUN |
| A7: `dist/worker.js` | `e803ca85e69ef6ce1703e3825de686003f84fafb000758b25e0c397c87d83859`; `files[7]` / 7016 bytes | `74766dcea0cc9554758549f84b6dff2b793cafc3c7f3ff1e5724aa90219134a6` | `74766dcea0cc9554758549f84b6dff2b793cafc3c7f3ff1e5724aa90219134a6`; PRESENT | BLOCKS_SECURITY_ACCEPTANCE of nested fixture integrity; not scope review; generated local-build prerequisite, supported rebuild NOT_RUN |

For each A1–A7: (a) **YES**, current embedded metadata expects the path in the current sealed delivery; actual membership is **NO**. (b) It is a generated build output: both tsconfigs declare `rootDir: src`, `outDir: dist`; package `build` runs `tsc -p tsconfig.json`; the matching TypeScript sources remain delivered. The exact closure operator includes an explicit nested-path dist-exclusion policy, described below. (c) **YES**, the original versions are present in the original standalone BE archive and absent from the delivered frontend fixture. For five entries the current expected hashes also equal the original standalone BE hashes; current `services/public-content.js` and `worker.js` expect different later bytes. Exact later generated bytes for those two are **NOT LOCATED in the inspected ancestor deliveries**, not silently substituted from the original BE.

### Packaging mechanism and strength of causal evidence

The exact original master closure operator `01_CURRENT_IMPLEMENTATIONS/01_PUBLIC_WEBSITE/IDIGITALROOT_P1-FE-02R1_LOCAL_CLOSURE_v1.7.zip!02_OPERATOR/seal_source.py`, SHA256 `ccdb5ed6e9f4018243c567f14c6d739ea565c6eac13abe61ce50d7ed44bbe44f`, explicitly defines `exclude={node_modules,dist,.astro,.fe02-build}` and excludes a file if **any** relative path part matches. It rebuilds the outer SHA file, but serializes existing nested SHA files without reconciling their declarations. Static reading proves this policy can omit nested dist outputs while retaining their old nested checksum file. It was not executed. An invocation log proving this exact script created original FE v1.1.1 was not located, so precise original invocation/intent attribution remains UNKNOWN; the observed stale-metadata mechanism is strongly supported, not a fabricated historical execution result.

The preserved historical TRACE `P1-CMS-TRACE-01_LINEAGE_AND_INTEGRITY.md` additionally explains that older BE/AN sealed sources omitted dist and required TypeScript build before tests. That is supporting history for generated-output treatment, not proof that every later archive intentionally allowed inconsistent nested checksums.

The local unsealed MOTION sealer `/workspace/idigitalroot-motion-2026-10-16/seal-source.py`, SHA256 `575e59cab953921544ba41f3a72cb45e5913ec7b383e31001b335f3c478d925d`, takes inherited root manifest paths and regenerates root/component metadata; it does not reconcile the embedded fixture manifest. This supports propagation of the inconsistency, but is an unsealed working helper and is not elevated to immutable project authority.

Targeted ancestor checks (raw ZIP SHA freshly computed; no exhaustive inventory/CRC rerun):

| Archive in downloads/ | Observed SHA256 | Fixture observation |
|---|---|---|
| `IDIGITALROOT_CLARITY_SOURCE_2026-10-15_rc3.zip` | `3d6f8d50510dbe0502c677995f87cf074412a3524528bba07cc81036d3aeb463` | All seven absent; fixture checksum file `0049feeb63920562bf3665afeb3266212796d2ee32d54d0a3e0e4a0ec2f49400` unchanged from MOTION |
| `IDIGITALROOT_HORIZON_SOURCE_2026-10-15_rc3.zip` | `b380a611a1f7af5d2784c213503d01c23806f658960e174b675d7f826e6b40bd` | All seven absent; fixture checksum file `0049feeb63920562bf3665afeb3266212796d2ee32d54d0a3e0e4a0ec2f49400` unchanged from MOTION |
| `IDIGITALROOT_ROOT02_SOURCE_2026-10-15_rc4.zip` | `7bdedafbaae67633d0b8281cc4fb0cb1da429143d372f5cc09e289f2b3dadefa` | All seven absent; fixture checksum file `0049feeb63920562bf3665afeb3266212796d2ee32d54d0a3e0e4a0ec2f49400` unchanged from MOTION |
| `IDIGITALROOT_WEBSITE_STUDIO_SOURCE_2026-10-15_rc4.zip` | `f3d374b3e2922ffa355d21b0bbb3432302221d0481415be82cf4a2d0a4b46bdf` | All seven absent; fixture checksum file `0049feeb63920562bf3665afeb3266212796d2ee32d54d0a3e0e4a0ec2f49400` unchanged from MOTION |

MOTION names ROOT02 rc4 SHA `7bdedafbaae67633d0b8281cc4fb0cb1da429143d372f5cc09e289f2b3dadefa` as predecessor; the inconsistency already exists in that exact predecessor and in inspected CLARITY/HORIZON/STUDIO deliveries. No inferred generation of absent later worker/public-content bytes was performed.

### Static build-path evidence

- Original FE `tests/integration-server.mjs` SHA256 `84577b12dd1bd14723b1ef02ce84274bb5a78476e99680b83683bec54f8f7ff4`, lines 3–5: selects fixture, compiles its tsconfig, checks compile status, then imports `dist/worker.js`.
- Current `website/tests/integration-server.mjs` SHA256 `389b4cf93b808b7facd8c1f468e23f76c62a85ccf175ef5e678fdcc296224f86`, lines 3–5 has the same prerequisite pattern.
- Current `website/scripts/run_closure.py` SHA256 `36b8f6ce3f1b060d46beead4d638b1c35072c1621c4071ff2afaf271418f89e3`, lines 70–75 explicitly installs/checks/builds the backend before its tests. This is static evidence only, not an install/build performed in P00B.
- Embedded fixture `scripts/verify_source.py` SHA256 `cdcd5cc246e34994c4a0258fd8d6e5332dba76b6f2306c56fa8734af7502079e` directly reads every declared path and will encounter missing dist before building when called through the fixture package `verify` script. This failure path is established by code inspection; no historical verifier was run.
- Targeted scan of current website/CMS/backend/analytics `src` members found no `tests/authority/be01` or `../tests/` literal imports. This supports test-fixture separation; it is not a complete dynamic import/security audit.

## A8 — Original FE fixture tsconfig discrepancy

Exact member: `01_CURRENT_IMPLEMENTATIONS/01_PUBLIC_WEBSITE/IDIGITALROOT_P1-FE-02_PUBLIC_FRONTEND_SOURCE_v1.1.1_CANDIDATE.zip!tests/authority/be01/tsconfig.json`.

- **Expected:** `7995588e062f86e4f97a76337368696ae3fbd7e74f8fe37bd4ae5bfcac989d4b`, from original fixture SHA256SUMS line 40. The standalone original BE file actually matches this hash.
- **Observed:** `e5df715440bae055d03ae8944d1aa22bb0527c129ef76d60ec069a17dcb7ecd6`, freshly hashed original FE fixture bytes.
- Original FE **outer** SHA256SUMS line 60 correctly declares the observed `e5df...` hash. Thus the overall sealed FE candidate covers the changed fixture config; its nested backend checksum file retains the standalone expectation.
- Actual semantic delta: adds `compilerOptions.types: []` and reformats `lib` and `include` arrays. Both already contain `ES2022` and `DOM`; DOM was **not** newly added. `types: []` affects ambient type-package inclusion, so this is a source compiler-configuration difference, not merely whitespace or generated dist.
- No change rationale/invocation log for that original fixture edit was located. Its runtime/build effect is NOT_TESTED. Do not claim accepted backend source was modified: the separate canonical BE v1.1.2 bytes remain exact; the original FE is a candidate, not an accepted successor to that backend.
- Current MOTION fixture tsconfig is `7995588e062f86e4f97a76337368696ae3fbd7e74f8fe37bd4ae5bfcac989d4b`, and current nested checksum + embedded manifest both match it. A8 is **HISTORICAL_ONLY with respect to current MOTION**, but still **BLOCKS_SECURITY_ACCEPTANCE of blanket original FE fixture self-consistency**. It is not a scope-reading blocker.

## Blast radius and safe closure gates

| Gate | A1–A7 | A8 | Evidence needed to close |
|---|---|---|---|
| Read-only P01 scope review | Does not block; exact fixture/provenance defects are bounded and do not obscure scope authority | Does not block; exact config diff/provenance known | Carry these warnings into scope review; no acceptance substitution |
| Local build | Generated prerequisites; clean supported compile not run. Direct nested integrity-first verify is blocked on delivered files | Compile semantics potentially affected; original standalone verify also mismatches config | Separately authorized clean extraction/build and explicit entrypoint selection; compare outputs/toolchain and verify behavior. No permission now |
| Package/security acceptance | BLOCKS_SECURITY_ACCEPTANCE for any claim all nested manifests/checksums pass | Same for original FE; current MOTION match does not rewrite history | Owner-reviewed bounded successor packaging policy, exact source provenance, fresh reproduction and targeted/adversarial validation; preserve original ZIPs |
| Frozen authorities/migrations | No affected migration or approved HTML path; outputs confined to test fixture | No affected canonical migration/approved UI; compiler config in candidate fixture differs | P00 frozen comparison 66 copied migrations match; public Core 0001–0016 and Analytics 0001–0002 remain untouched |

Safe follow-up is to **propose**, under a later approved repair scope, whether distribution excludes generated fixture outputs and represents only source honestly, or includes regenerated outputs with reconciled metadata. Never backfill old hashes with guessed bytes, overwrite accepted artifacts, remove historical declarations silently, or treat a rebuild as proof of identical previously accepted source. No such repair is authorized by P00B.

Original exact-byte master preflight remains PASS for binary/hash/CRC/inventory; nested source self-consistency is a separate, qualified FAIL as above. No zero-vulnerability, production-ready or accepted-build claim is made.
