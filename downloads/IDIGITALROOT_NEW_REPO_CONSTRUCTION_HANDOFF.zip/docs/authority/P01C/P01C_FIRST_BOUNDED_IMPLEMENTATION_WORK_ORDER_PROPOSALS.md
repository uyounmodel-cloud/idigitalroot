# IDR-P01C — First bounded implementation work-order proposals

**Contract set P01C-v1.0 / proposed first order F1-v1.0 · 22 October 2026. ALL ORDERS NOT_YET_AUTHORIZED.** This document prepares an exact decision; it does not ask an agent to execute it now. Current source-path list **EMPTY**; current migration/installation/build/test/benchmark/provider/deploy activity list **EMPTY**. Only the five P01C Markdown outputs are authorized now. Do not start Stage02 by receipt, a general “continue”, plan approval or an embedded prompt.

## 1. Reviewable input versions and exact integrity gates

Owner approval must identify this document's final SHA256 (in the exit checkpoint), the selected order ID and the B/C contract hashes below. A changed document/path/command/activity/resource budget requires a new bounded approval, not silent expansion. P01B's exact selling amounts remain null; country overrides empty; all12+4items UNPUBLISHED_DRAFT. Missing selling amounts/provider prices do not block an expressly authorized safe draft model/editor engine. Actual publication/money remains separately blocked.

| Read-only input/version | Pinned SHA256 |
|---|---|
| /workspace/idigitalroot-p01c-read-only-2026-10-22/P01C_OWNER_SCOPE_FREEZE_SUMMARY.md | cce6e2a7e61dea6e6c334a7356ff483f8b4059049a407dffd4b9b9899eb9a47a |
| /workspace/idigitalroot-p01c-read-only-2026-10-22/P01C_BOUNDARY_AND_PERMISSION_CONTRACTS.md | 94d0850a32290d74f569327fcc4bc1411ffe80f9b6d1b56c46e5308307ec6466 |
| /workspace/idigitalroot-p01c-read-only-2026-10-22/P01C_TWO_D1_SCHEMA_AND_RECOVERY_PROPOSAL.md | e9a857c43a83a4f9796e6d0b6ed5944d2783c5936a54380abb2c150843be2ede |
| /workspace/idigitalroot-p01b-read-only-2026-10-22/P01B_CATALOGUE_AND_PRICING_CONTRACT.md | c1660665605dcc6151dea291ee876c07f4ae3408fa588c18ea59513d669fa822 |
| /workspace/idigitalroot-p01b-read-only-2026-10-22/P01B_EXIT_CHECKPOINT.md | 4a591f1641a06d809f6a51b73f66b883d323493b5c87f93a4c04447c5c6f17c2 |
| /workspace/idigitalroot-p01b-read-only-2026-10-22/P01B_IMPLEMENTATION_APPROVAL_BOUNDARIES.md | 77d9e9cf354dd8998d1ae59b1daea1cc2d32c3f3b691c23bdb783f1901755724 |
| /workspace/idigitalroot-p01b-read-only-2026-10-22/P01B_QUOTA_AND_COST_EVIDENCE_PLAN.md | 90d0f7f7907d10b8b5da30f1ef7fedb4272967b1cdb3a09ed6e4aa4b10b4b2fa |
| /workspace/idigitalroot-read-only-preflight-2026-10-21/REPOSITORY_BASELINE.json | db2d6684aaa2e566a935184ce5edbea78ab1b26454752188e9575122fc0c1252 |
| /workspace/idigitalroot/downloads/IDIGITALROOT_CODEX_MASTER_HANDOFF_2026-10-14_v1.1.zip | f1ea6c341baf3c81afa5b797ed09beb9b1a400325338e8a42ed671c2a5f23b20 |
| /workspace/idigitalroot-p01a-read-only-2026-10-22/P01A_AUTH_SCOPE_RECONCILIATION.md | 84a3044ea2b0f53c11902999c743189e4b9dc0b1f5473437a81983c762ed858c |
| P01B proposal ZIP member01_PROPOSED_CATALOGUE_MACHINE_READABLE.json | d96ef2314ff41b253d0c692183a3bd9cd81d42fec20dc0415e254b301053711e |

Required original checkout entry and exit: branch`work`,HEAD`08f614b1698dec2db657248f95ceea723ab537e7`,tree`dce28a4004a1d060d936e9656b5c4d589e787839`,243exact raw baseline hashes and clean status. Preserve P00/P00B/P01/P01A/P01B/P01C reports, archived master/handoff/Public CMS/MOTION and all source. Existing historical checkout remains read-only; no Git init/clone/worktree/switch/reset/commit/push/PR, no lockfile/manifest/fixture repair. Future new root below is not an existing approved checkout and must not conceal overwrite of user files.

## 2. Recommended first task: F1-v1.0 — bounded policy-model foundation

Purpose: create a tiny dependency-free, nonintegrated contract-validation/authorization POLICY MODEL for separate Admin and Client trust namespaces, with pure deterministic model tests. This is the first slice of foundation IAM/authorization/contracts, NOT a login service or secure integrated editor. It cannot authenticate anyone, verify WebAuthn/signatures, issue sessions/keys, persist commercial data or provide a Worker/API. All positive results must be labeled MODEL_ONLY / NOT_AUTHENTICATED; no reusable production authorization adapter. Do not infer a verified caller from fields merely passing schema validation.

Inputs are the exact table above, unchanged original security registers and B's deny-by-default scopes. No numerical selling values or real provider required. F1 may model an explicit TEST_ONLY staff draft capability and Client grant/epoch/barrier state to demonstrate logic; it may not assign real publication/recovery grants or mark IAM implemented. An isolated model is allowed ONLY if this exact scope and tests are separately affirmed by the owner. If owner wants a secure integrated UI first, stop and explain actual IAM/persistence dependencies; no fake login shortcut.

### F1 proposed source allowlist — exact10files, NOT allowed now

| Future absolute file path | Permitted content if F1 later approved |
|---|---|
| /workspace/idigitalroot-next-candidate/docs/foundation-scope.md | Pinned scope/input hashes and explicit MODEL_ONLY/exclusions; no new owner policy. |
| /workspace/idigitalroot-next-candidate/contracts/v1/envelope.mjs | Pure structural validator for contract version/context/required fields/digest references/expected versions; no network/crypto or trusted-actor creation. |
| /workspace/idigitalroot-next-candidate/contracts/v1/outcomes.mjs | Pure typed outcome definitions (Deny/Pending/Conflict/Unquotable/model result); no success/Paid inference. |
| /workspace/idigitalroot-next-candidate/contracts/v1/authority-context.mjs | Separate Admin/Client/workload model-context shapes; default deny missing/unknown/unverified context; explicit MODEL_ONLY tag not accepted as authenticated proof. |
| /workspace/idigitalroot-next-candidate/admin/src/authorization/policy-model.mjs | Pure staff policy model for fixed five bundles plus explicitly supplied TEST_ONLY capabilities/assignments; no granted publish or account-owner impersonation. |
| /workspace/idigitalroot-next-candidate/client/src/authorization/policy-model.mjs | Pure Client object/property/function/account/Root/member/guardian/grant/epoch/barrier model; no stale projection default. |
| /workspace/idigitalroot-next-candidate/tests/contracts/envelope-model.test.mjs | Named model cases for envelope/version/field/context/digest/epoch/error validation; no historical script import. |
| /workspace/idigitalroot-next-candidate/tests/authorization/admin-model.test.mjs | Five-bundle model positive/negative and privilege/field separation cases; all proof inputs synthetic and labeled. |
| /workspace/idigitalroot-next-candidate/tests/authorization/client-model.test.mjs | Owner/collaborator/guardian/minor/multi-account/Root and revoke/expiry/fail-closed model cases; no credentials or app access. |
| /workspace/idigitalroot-next-candidate/docs/foundation-exit.md | Exact created-file hashes/test outcomes/limitations/unfinished review; no integrated feature or security PASS. |

Only parents needed for those files may be created; no package.json/lock/dependency/config/SQL/migration,server or other source file. New root must be absent or established empty/nonconflicting at entry; existing different files/unknown contents are a STOP, never overwrite/clean. Exact file list cannot expand because a test fails. Tool/test runner's transient internal reads/processes do not permit source-side filesystem/network/subprocess utilities.

### F1 verification commands proposed for later explicit approval

These are literal command proposals, NOT executed by P01C. First inspect every newly authored model/test file, reject imports or code using network,child_process,Worker threads,credential generation,DB,provider/client libraries,unbounded allocation or persistent writes. Only standard non-I/O language/assert/node:test facilities and the enumerated new pure modules may be imported. No historical runner or attached script. New model files may be written by an editor within the exact allowlist after approval, not through an unreviewed downloaded script.

Approved-IF-affirmed read-only preflight: `GIT_OPTIONAL_LOCKS=0 git -C /workspace/idigitalroot rev-parse HEAD HEAD^{tree}`, `branch --show-current`, `status --porcelain=v1 --untracked-files=all`, `ls-files -z`, and inline raw SHA256 comparison to the pinned baseline and all selected input documents. Inspect/hash pinned tool files without executing project commands. Standard filesystem operations may create only the enumerated new parents/evidence files and read/write/hash those files. No arbitrary shell/script entry point or network command is authorized by this proposal.

Pinned existing Node binary: `/workspace/idigitalroot-connected-runtime/toolchains/node-v22.19.0-linux-x64/bin/node`, raw SHA256`596b5144ff242737f1c1be6a5f0ccb3907dbba2482344143cb1a6898633402a9`. It was read/hashed in P01C, not executed or freshly version-tested. Future preflight may run this exact binary with `--version` only if F1 is explicitly approved; require22.19.0. Wrong/missing hash/version means STOP, no install/fetch/alternate runtime. No package install/build is included.

Proposed single model-test invocation (owner must affirm TEST_EXECUTION=YES; otherwise source-only task returns NOT_RUN):

```text
bash --noprofile --norc -c 'ulimit -t 30; exec /usr/bin/timeout --signal=TERM --kill-after=5s 60s /workspace/idigitalroot-connected-runtime/toolchains/node-v22.19.0-linux-x64/bin/node --max-old-space-size=128 --test --test-concurrency=1 /workspace/idigitalroot-next-candidate/tests/contracts/envelope-model.test.mjs /workspace/idigitalroot-next-candidate/tests/authorization/admin-model.test.mjs /workspace/idigitalroot-next-candidate/tests/authorization/client-model.test.mjs' > /workspace/idigitalroot-p01c-f1-evidence/model-tests.log 2>&1
```

Execute only from the new root; exact3test files, no glob/discovery expansion. Node's own sequential test-runner processes are allowed; tested source may not launch subprocesses. Proposed ceiling:60seconds wall for this invocation plus5seconds termination grace;30CPU seconds per process via ulimit;128MiB V8 heap per Node process (not a claim of total RSS cap),test fixtures≤10MiB total,no load/stress loop,≤1,000deterministic cases,no network/database/provider/customer data. Observe actual resource/exit outcome; if resource containment cannot be maintained,STOP rather than expand limits. A runner error/timeout,unsupported flag,zero tests or skipped required negative is NOT a PASS. Capture the underlying command exit; no `|| true`/pipe masking. No benchmark/performance conclusion from timings. Repeat only after a diagnosed allowed-file correction; require fresh authorization for more scope/resources.

Exact future F1 evidence file allowlist: `/workspace/idigitalroot-p01c-f1-evidence/ENTRY.json`, `model-tests.log`, `EXIT.json`, `INDEPENDENT_REVIEW.md`, `SHA256SUMS.txt`. Only that directory's parents may be created; no arbitrary log/database/data directory. ENTRY records original243baseline+input/tool hashes and empty-root state; EXIT records exact10source hashes,actual case counts/pass/fail/skip/unrun and preservation. Independent review records reviewer/function,scope,findings and unresolved issues; if unavailable,write UNASSIGNED/PENDING,never fabricate a reviewer/PASS. Model work may exit “prepared for independent review” but cannot claim security acceptance or integrated IAM. Source hashes follow completed creation; no output hash is invented beforehand.

Minimum meaningful model cases: valid/model-only context and malformed/unknown version/fields; wrong Admin-vs-Client/workload namespace; each five-bundle function/field restriction; unknown commercial.publish DENY; staff cannot accept as customer/Billing maker-checker violation; two accounts/multiple Roots/foreign object/property injection; collaborator cannot owner-approve; guardian/minor category/expiry/revoke; missing/stale/unavailable Admin grant,barrier or mismatched epochs denies; account-switch stale response; correct typed Pending/Conflict/Unquotable with no Paid or numeric0 fallback. Replay/digest cases validate model identity distinctions only,not durable DB nonce/idempotency proof. Positive MODEL_ONLY results are not authenticated application actions. Independent reviewer must examine deny/default and original policy preservation,not merely accept a green test count.

F1 exit: list the10files and5evidence paths only; prove legacy243hashes and all prior reports unchanged; report actual test execution vs unrun,resources/failures and independent-review state. No working IAM/editor/Worker/D1/R2/paid/provider/full58feature claim. Stop; F2 is not implied. This order is small enough to decide without collecting selling prices or full production suppliers.

## 3. Strict subsequent sequence — dependency roadmap, NOT execution orders

Only F1 and the two schema sections below are immediately selectable bounded proposals. F2–F6/PUBLIC-NEW are dependency milestones rather than approvable wildcard execution orders; their listed path families are scope boundaries, not allowed edits. Each row inherits exact source pins above plus completed predecessor artifact hashes and independent findings. Paths are proposed relative to the new root; each later owner order must replace directory families below with an exact enumerated file allowlist before execution. No directories here become a present source authorization.

| Future slice / strict dependency | Proposed boundary and acceptable operations only if separately approved | Minimum evidence / explicit exclusions |
|---|---|---|
| F2 Independent actual IAM+authorization/contracts | After reviewed F1 and independently approved initial Admin/Client persistence: admin/src/identity/,admin/src/authorization/,client/src/identity/,client/src/membership/,client/src/guardians/,contracts/identity/. Exact files/trusted maintained WebAuthn/password verifier/tool pins/test credentials and run resources must be approved first. | Prove actual password+WebAuthn enrollment/session/revocation/step-up/backups/recovery,wrong RP/origin,namespace/role/account/guardian negatives and independent review. Accessible device/L3 applicability review. No email factor,provider identity assumption or copied legacy CMS authentication. Browser/Worker test/build/installation not authorized by F1; require their own explicit commands/resources. |
| F3 NULL-safe unpublished catalogue draft/editor | Requires secure reviewed Staff IAM/role/action controls plus approved Admin catalogue persistence expansion: admin/src/catalogue/,admin/src/pricing/drafts/,admin/src/admin-ui/commerce/. | Positive save/reload/version conflict/null display,12/4complete proposed identities,unknown-field/price/Paid overposting/role/CSRF/wrong-account negatives and EN/AR/a11y. All real prices null/unpublished; no live quote/publish/paid/provider. Missing selling amounts is NOT a blocker to this engineered editor. |
| F4 Safe local review/publication rules | After F3 and exact publication capability/high-value multi-user policy: admin/src/pricing/review/,admin/src/pricing/publication/,admin/src/audit/commerce/. | Explicit LOCAL_SYNTHETIC noncustomer approval data only if named in later task. Exact immutable version/overlap/replay/CAS/maker-checker/step-up/rollback and internal-data redaction. No real PUBLISHED offer,final prices,customer contract or provider. Need approved actual terms/data before real publication. |
| F5 Supported local commercial state flows | After reviewed F4,Admin/Client commerce persistence expansions and G-RACE: admin/src/quotes/,admin/src/payments/,admin/src/renewals/,admin/src/pack-switch/,contracts/admin-client/commerce/,client/src/commercial-read-model/. | Synthetic quote-owner/Billing separation,purchase clocks,one Root/pack,expiry/switch/transfer/outbox/Pending/recovery,race/outage tests under new explicit run scope. Tests cannot turn LOCAL payment evidence into real settlement; no real invoice/Paid/registration/mailbox/sending. |
| F6 Full four-pack tools/projects/support/files/SSO candidate | Separate bounded feature orders,after actual IAM/grants/schemas,approved safe formats/global budgets and explicit measurement authorization. client/src/tools/<exact feature>,admin/src/projects/,admin/src/support/,sso/broker/,sso/consumers/site-a/,sso/consumers/site-b/. | All58features tracked,56required;Student27unique and4packs,real durable outputs,EN/AR/accessibility,151risk/345ASVS/54case row evidence,protected previews/two approvals/guardian/privacy/deletion/restore and independent QA. Two fake local consumers≠real client CMS. No partial slice mislabeled complete,quota/performance/provider proof from mocks. |
| PUBLIC-NEW separate no-CMS work order | New-public content/motion/intake paths must be separately enumerated; depends on reviewed Admin intake/notice contract,not historical CMS reuse. | EN/AR,accessible reduced motion,noCMS,only secured wizard→authenticated Admin lead+durable visitors@idigitalroot.com notice. Deterministic local adapter clearly simulated; real provider/email/domain/supplier/release later. No existing Public CMS/MOTION edits,public migration or deploy. |

No later row has approved commands/resources/path list. For each require exact predecessor source/locks/runtime/hash and targetfile list,positive+negative+fault+security oracles,independent reviewer and sanitized exit/source/hash/risk/gap artifacts before approval. Actual build/browser/workerd/D1/scanner/load/benchmark/keys need expressly named bounded activities; an example test family is not permission. Selling prices not required for draft/synthetic engines; actual real publication/quotes/payment remain blocked by unapproved terms/non-null data. Provider/legal/live acceptance never inferred from local success.

## 4. Separate ADMIN_SCHEMA-v1.0 and CLIENT_SCHEMA-v1.0 requests

These are independent optional future requests,NOT part of F1 and NOT actual D1 bindings. C's complete logical table inventory is a future design,not an all-tables migration instruction. Below is a narrowly proposed foundation subset; commerce/tool expansions need separate reviewed successors. Approve one schema task without implicitly approving the other. Actual remote/Cloudflare D1 create/apply is EXCLUDED. Pure local synthetic SQLite verification,if explicitly selected,is not actual Workers/D1 acceptance. No SQL is written by P01C.

### ADMIN_SCHEMA-v1.0 — UNAPPROVED independent lineage `idr_admin_foundation_v1`

Proposed scope: Staff subjects/five-role capability policy+assignments,staff password/WebAuthn public metadata,invites/challenges/sessions/step-up,recovery case/reviewer/limited grant,authz epochs,local audit/dedupe/outbox/inbox metadata. NO catalogue/real price/payment/Root/provider tables in this first migration. New0001belongs only to this new lineage; not legacy/public0017. Owner must approve exact entities/fields/keys/CAS/unique/index/retention and recovery design against C before creation; no actual DBID/binding or legal retention duration is invented.

| Exact future file allowlist (NOT currently allowed) |
|---|
| /workspace/idigitalroot-next-candidate/admin/schema/idr_admin_foundation_v1/0001_identity_authority.sql |
| /workspace/idigitalroot-next-candidate/admin/schema/idr_admin_foundation_v1/SCHEMA_MANIFEST.json |
| /workspace/idigitalroot-next-candidate/admin/schema/idr_admin_foundation_v1/RECOVERY_PLAN.md |
| /workspace/idigitalroot-next-candidate/admin/tests/schema/admin-foundation-schema.test.py |
| /workspace/idigitalroot-next-candidate/admin/docs/schema/admin-foundation-boundary.md |

If CREATE_SCHEMA_FILES=YES is affirmatively authorized,write only those5files and parents. SCHEMA_MANIFEST pins source/lineage/order/hash,not private credentials. No other app files or migrations. If APPLY_SYNTHETIC_SQLITE_AND_RECOVERY=NO/blank,stop after files and state NOT_RUN; migration-file approval alone does not authorize application.

If isolated verification IS separately affirmed,only this literal future command is proposed,after reading the newly authored exact harness to reject network,subprocess,other filesystem or existing database access:

```text
/usr/bin/timeout --signal=TERM --kill-after=5s 60s /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -I /workspace/idigitalroot-next-candidate/admin/tests/schema/admin-foundation-schema.test.py --database /workspace/idigitalroot-p01c-admin-schema-evidence/synthetic-admin.sqlite > /workspace/idigitalroot-p01c-admin-schema-evidence/schema-test.log 2>&1
```

Future execution uses pinned Python binary`/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3` raw SHA256`fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7` (P01C metadata/hash only,not a DB test). Missing/changed tool means STOP,no install. Proposed≤60seconds wall+5seconds termination grace,one process,≤10MiB synthetic DB+fixtures,≤100synthetic subjects and bounded rows,no stress/load/benchmark,no real credentials or cryptographic key generation. If harness cannot maintain this cap,stop; do not expand resources. Allow only new isolated stdlib SQLite file above plus its own SQLite journal/WAL/SHM siblings; never open an existing source/review/owner DB. External targets and actual D1/Wrangler are forbidden. Test flags,DB path and harness files cannot change without approval.

Exact future evidence allowlist under `/workspace/idigitalroot-p01c-admin-schema-evidence/`: ENTRY.json,schema-test.log,EXIT.json,INDEPENDENT_REVIEW.md,SHA256SUMS.txt,synthetic-admin.sqlite and test-created SQLite journal/WAL/SHM siblings,plus manifest-listed sanitized synthetic snapshot copy for restore. Snapshot filename must be fixed as `synthetic-admin-restore.sqlite`; no other archive/customer data. Harness may initialize/apply its own newly approved0001and simulate rollback/failed apply/restore only to these new synthetic files. No automatic deletion/cleanup of any preexisting file; cleanup of its own outputs requires that activity to be selected.

Minimum schema evidence: unique principal/credential/invite/session/command keys and FK/field invariants; role/namespace separation;purpose/expiry/revoke/CAS and wrong-account/guardian negatives as applicable;atomic local audit/dedupe/outbox/inbox behavior;partial-apply failure must not mark success;reapply/replay safe refusal;restore current revocation/delete/version metadata and old-nonce denial;lineage/hash mismatch/missing snapshot fails closed. Tests must prove underlying SQL effects,not merely match source text. Plain SQLite does not prove D1 dialect/config/Worker/API/R2/auth or deployment. Actual restore/copy/object/key proof for the full system remains NOT_RUN. Independent reviewer records UNASSIGNED/PENDING if absent; no self-approved security PASS.

Exit artifacts pin all5source files and exact migration manifest/evidence/actual commands/outcomes; prove original243hashes and prior reports unchanged. Stop before another lineage/schema expansion/apply target. This request cannot create bindings/resources,apply public SQL,construct actual credentials or connect a provider.

### CLIENT_SCHEMA-v1.0 — UNAPPROVED independent lineage `idr_client_foundation_v1`

Proposed scope: Customer subjects/password/WebAuthn public metadata,accounts/memberships,guardian relationship/category grants,invites/challenges/sessions/step-up,recovery case/reviewer/limited grant,authz/privacy epochs,local audit/dedupe/outbox/inbox metadata. NO tools/real money/Root ownership/provider tables in this first migration. New0001belongs only to this new lineage; not legacy/public0017. Owner must approve exact entities/fields/keys/CAS/unique/index/retention and recovery design against C before creation; no actual DBID/binding or legal retention duration is invented.

| Exact future file allowlist (NOT currently allowed) |
|---|
| /workspace/idigitalroot-next-candidate/client/schema/idr_client_foundation_v1/0001_identity_authority.sql |
| /workspace/idigitalroot-next-candidate/client/schema/idr_client_foundation_v1/SCHEMA_MANIFEST.json |
| /workspace/idigitalroot-next-candidate/client/schema/idr_client_foundation_v1/RECOVERY_PLAN.md |
| /workspace/idigitalroot-next-candidate/client/tests/schema/client-foundation-schema.test.py |
| /workspace/idigitalroot-next-candidate/client/docs/schema/client-foundation-boundary.md |

If CREATE_SCHEMA_FILES=YES is affirmatively authorized,write only those5files and parents. SCHEMA_MANIFEST pins source/lineage/order/hash,not private credentials. No other app files or migrations. If APPLY_SYNTHETIC_SQLITE_AND_RECOVERY=NO/blank,stop after files and state NOT_RUN; migration-file approval alone does not authorize application.

If isolated verification IS separately affirmed,only this literal future command is proposed,after reading the newly authored exact harness to reject network,subprocess,other filesystem or existing database access:

```text
/usr/bin/timeout --signal=TERM --kill-after=5s 60s /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -I /workspace/idigitalroot-next-candidate/client/tests/schema/client-foundation-schema.test.py --database /workspace/idigitalroot-p01c-client-schema-evidence/synthetic-client.sqlite > /workspace/idigitalroot-p01c-client-schema-evidence/schema-test.log 2>&1
```

Future execution uses pinned Python binary`/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3` raw SHA256`fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7` (P01C metadata/hash only,not a DB test). Missing/changed tool means STOP,no install. Proposed≤60seconds wall+5seconds termination grace,one process,≤10MiB synthetic DB+fixtures,≤100synthetic subjects and bounded rows,no stress/load/benchmark,no real credentials or cryptographic key generation. If harness cannot maintain this cap,stop; do not expand resources. Allow only new isolated stdlib SQLite file above plus its own SQLite journal/WAL/SHM siblings; never open an existing source/review/owner DB. External targets and actual D1/Wrangler are forbidden. Test flags,DB path and harness files cannot change without approval.

Exact future evidence allowlist under `/workspace/idigitalroot-p01c-client-schema-evidence/`: ENTRY.json,schema-test.log,EXIT.json,INDEPENDENT_REVIEW.md,SHA256SUMS.txt,synthetic-client.sqlite and test-created SQLite journal/WAL/SHM siblings,plus manifest-listed sanitized synthetic snapshot copy for restore. Snapshot filename must be fixed as `synthetic-client-restore.sqlite`; no other archive/customer data. Harness may initialize/apply its own newly approved0001and simulate rollback/failed apply/restore only to these new synthetic files. No automatic deletion/cleanup of any preexisting file; cleanup of its own outputs requires that activity to be selected.

Minimum schema evidence: unique principal/credential/invite/session/command keys and FK/field invariants; role/namespace separation;purpose/expiry/revoke/CAS and wrong-account/guardian negatives as applicable;atomic local audit/dedupe/outbox/inbox behavior;partial-apply failure must not mark success;reapply/replay safe refusal;restore current revocation/delete/version metadata and old-nonce denial;lineage/hash mismatch/missing snapshot fails closed. Tests must prove underlying SQL effects,not merely match source text. Plain SQLite does not prove D1 dialect/config/Worker/API/R2/auth or deployment. Actual restore/copy/object/key proof for the full system remains NOT_RUN. Independent reviewer records UNASSIGNED/PENDING if absent; no self-approved security PASS.

Exit artifacts pin all5source files and exact migration manifest/evidence/actual commands/outcomes; prove original243hashes and prior reports unchanged. Stop before another lineage/schema expansion/apply target. This request cannot create bindings/resources,apply public SQL,construct actual credentials or connect a provider.

## 5. Exact approval statement — COPYABLE, BLANK, NOT GIVEN

The following is a template for a NEW explicit owner message. No identity/date/hash/choice is filled on the owner's behalf. Select ONE work-order ID; approve additional independent schema tasks only by a separate complete statement. An unfilled activity is NO. Current P01C completes with every activity NO; do not execute this template.

> I have reviewed contract set P01C-v1.0 and approve ONLY work-order ID [F1-v1.0 OR ADMIN_SCHEMA-v1.0 OR CLIENT_SCHEMA-v1.0], as defined in P01C_FIRST_BOUNDED_IMPLEMENTATION_WORK_ORDER_PROPOSALS.md SHA256 [paste exact final hash from P01C_EXIT_CHECKPOINT.md]. Governing B hash [exact hash] and C hash [exact hash] are accepted for this bounded task only, with all stated unresolved/requires-review gates retained. I authorize creation/modification ONLY of the exact file allowlist in that selected section and only its specified external evidence files. SOURCE_CREATION=[YES/NO]; TEST_EXECUTION=[YES/NO for F1 exact model command only]; CREATE_SCHEMA_FILES=[YES/NO for selected schema only]; APPLY_SYNTHETIC_SQLITE_AND_RECOVERY=[YES/NO for selected schema's exact command/targets only]; OWN_SYNTHETIC_CLEANUP=[YES/NO,never preexisting files]. I approve only the selected section's command/resource limits. All unselected activities/orders,dependency installation,other builds/tests/benchmarks,keys/credentials,actual D1/Wrangler/bindings/provider/email/domain/procurement/spend/deployment/Git mutation remain NO. I understand model/SQLite evidence is not working IAM,real payment/provider or full local product/security acceptance. Owner name/date/reference:[blank].

Owner must actually affirm an exact hash and coherent selected activities. Example: selecting F1 with SOURCE_CREATION=YES and TEST_EXECUTION=YES gives no migration privilege; selecting a schema with APPLY=NO gives file creation only. Any contradicted/ambiguous selection must be clarified before dependent work,while preserving unaffected evidence. This is one approval form,not a request to fill prices or repeat26discovery rounds. No blanket approve-all option.

## 6. Current stopping state

Exactly five P01C Markdown outputs only; no new candidate source root,models,tests,SQL,schema manifests,DBs,evidence runtime directories,keys or processes exist from this task. All proposed minimum tests are NOT_RUN; all151risk/345ASVS/54case statuses remain unchanged. Real .com/Zoho/Google rates remain unverified,all prices null and quotas unmeasured. PKG-01 preserved; no legacy fixture reuse/repair. **F1 recommended for the next owner decision; not yet authorized. STOP at P01C,OWNER REVIEW/APPROVAL PENDING.**

PERMISSION_TO_MODIFY_SOURCE=NO
PERMISSION_TO_CREATE_MIGRATIONS=NO
PERMISSION_TO_DEPLOY=NO
IMPLEMENTATION_SCOPE_APPROVAL=NOT_GIVEN
NEXT_STAGE=OWNER_REVIEW_APPROVAL_PENDING
