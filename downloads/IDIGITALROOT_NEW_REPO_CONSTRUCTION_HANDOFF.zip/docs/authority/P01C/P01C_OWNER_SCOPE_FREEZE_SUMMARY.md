# IDR-P01C — Owner scope-freeze summary

**Contract set P01C-v1.0 · 22 October 2026 · NOT_IMPLEMENTED · NOT_APPROVED FOR CONSTRUCTION.** This short summary and the three technical companions form one review set. The exit checkpoint pins their exact hashes. Nothing in it runs a previous prompt or authorizes source, migration, benchmark, procurement or deployment.

## Fixed decisions

One eventual complete LOCAL Admin+Client candidate serves Students, Professionals, Entrepreneurs and Businesses. All58features remain:56required, UX-01 proposed, EXT-TEAMS limited/partial. Student12Toolbox+16Workspace positions share Career Kit=27unique tools; Professional reuses capabilities; Entrepreneur has4bounded additions, Business2. All current new implementation/tests remain NOT_BUILT/NOT_RUN. The five staff bundles are Super Admin, Operations Manager, Project/Production Staff, Billing Staff and Support Staff. The11Client areas are Home, Roots, Projects, Tools, Domains, Email, Services, Billing, Renewals, Support and Account; Inbox is separate. A first engineering slice is not that complete product.

New corporate Public Site is separate: EN/AR motion design, NO CMS, only secured request wizard→authenticated Admin lead qualification and durable transactional notice addressed to visitors@idigitalroot.com. Preserve old Public CMS/MOTION; client website CMS/factory comes later. Broker+exactly2isolated fake local consumers is not a delivered CMS.

Workers, physically separate NEW Admin D1 and NEW Client D1, private Worker-controlled R2; no cross-D1 ACID. Admin controls staff/commercial/Root/project/approval/support truth; Client controls customer/member/guardian/private-workspace truth. Protected actions need current Admin entitlement and current Client rights; outage fails closed. Legacy Public Core0001–0016/Analytics0001–0002 stay unchanged, no public0017.

Twelve annual website packages and4packs; creation once, real eligible domain/hosted mailbox, matching pack included12months from independent Billing-verified purchase; no extension for construction delay. One active pack/Root, no tools-only account, no automatic customer charging; tools require Live+active website+valid pack+rights. Owner accepts exact quote; Operations Pending evidence is not Paid; independent Billing verifies payment; staff creates Root afterward. Two immutable owner-only exact-version project approvals do not authorize deployment. Both-owner+staff transfer, origin invoices/support history, Operations-maker/distinct-SuperAdmin-checker, guardian13–17/privacy and temporary supervised support remain fixed.

AUTH-2026-10-22-01: PASSWORD AND WebAuthn for staff/owners/collaborators/guardians/allowed minors; independent backup authenticators and supervised recovery. Email contact/notices only, never login, factor fallback or recovery proof. No automatic ASVS/L3 PASS. Fixed file ceilings:Office10MB each,CSV/ICS2MB,batch25MB; support JPEG/PNG/WebP≤5MB and≤3/message; shares default30d/max90d; timer inactivity10min. Byte convention, expanded/parser/scan/CPU/global budgets stay TBD—not secretly chosen here.

## Proposed package inclusions — owner offer/technical signoff still needed

| Tier | Pages | Languages | Hosted mailboxes | Standard domain | Revision cycles | Care h/month |
|---|---|---|---|---|---|---|
| Entry | up to5 | 1 | 1 | 1 | 1 | 0.5 |
| Growth | up to10 | up to2 | 2 | 1 | 2 | 1 |
| Premium | up to20 | up to2 | 3 | 1 | 3 | 2 |

Every numeric inclusion above is PROPOSED, not a published customer promise or measured capacity. Future authorized Admin flows can version prices AND material inclusions with review/guardrails; accepted sale/quote/invoice terms remain immutable. Corporate/Admin/Client EN/AR requirements are independent of client-site language allowance. Provider eligibility, real mailbox service and domain renewal need real contracts; forwarding is not a mailbox. Care/response/build-hour figures are planning candidates, not an SLA.

## Seven unmeasured quota hypotheses

All tiers share these test candidates only:2GiB Root storage;2,000structured records;5named collaborators;50new shares/rolling30d;20active shares;100exports/rolling30d;2concurrent heavy jobs/Root. All NOT_MEASURED/NOT_APPROVED, not seeded entitlements. Security, essential authentication/recovery/rights and global capacity cannot be bought around. Separate permission and measured evidence precede quota promises.

## Price editing versus publication

PRICE-ENGINEERING can be designed and later built under a bounded source order with all selling amounts null, country overrides empty and all12+4items UNPUBLISHED_DRAFT. No demand to fill32prices before building the draft engine. PRICE-COMMERCIAL-PUBLISH still requires approved non-null prices, inclusions, terms, country/tax/FX and applicable supplier eligibility. Frequent edits create prospective versions with fresh WebAuthn, CAS, audit/review; no null→zero/free plan, retroactive money edit or synthetic Paid claim. P01B's old-gate interpretation is preserved, not expanded back into a blanket construction ban.

## Genuinely material owner decisions

Choose the exact first work order and its path/activity/resource limits; approve Admin and Client schema/recovery tasks separately when selected. For integrated IAM/commercial publication, review recovery/privileged reviewer governance and exact publish grants/high-value dual control. Review proposed package inclusions, term/switch/credit/refund/renewal policy and, after measurement, meaningful quotas. Actual numbers remain later editable Admin data. Real suppliers, eight-market legal/guardian/residency/retention/support and release/spend are later gates; .com/Zoho/Google reference rates remain unverified. No repeated Rounds1–26 or new authentication-method choice.

## What can be built first; blocking conditions

Recommended F1 is SMALL: contract validation and separate staff/client authorization POLICY MODELS with bounded pure local model tests, explicitly NOT working IAM, editor, Worker, DB or provider. It needs only a separately affirmed exact hash/path/test authorization, not selling amounts or procurement. A secure integrated price editor must wait for verified IAM+authorization and approved persistence; a fake login is not enough. G-RACE/real WebAuthn/recovery, schema/migration, heavy workload and live release have their own review gates. PKG-01 remains a separate legacy-fixture acceptance failure, not a general F1 blocker; no fixture reuse/repair here.

## Recommended next exact owner approval

Review companion D, F1-v1.0:10enumerated files, no installation/DB/network, only its named bounded Node model-test commands and evidence paths if expressly approved. Its copyable statement has unfilled owner version/hash/activity choices. Approve that one order or request one material amendment; do not automatically approve F2–F6 or either migration task. Current allowed source paths EMPTY. No more general documentation stage is required to decide F1. **Owner decision pending; STOP at P01C.**

PERMISSION_TO_MODIFY_SOURCE=NO
PERMISSION_TO_CREATE_MIGRATIONS=NO
IMPLEMENTATION_SCOPE_APPROVAL=NOT_GIVEN
NEXT_STAGE=OWNER_REVIEW_APPROVAL_PENDING
