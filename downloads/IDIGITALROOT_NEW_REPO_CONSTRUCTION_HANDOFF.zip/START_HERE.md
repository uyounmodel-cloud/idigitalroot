# iDigitalRoot — new private repository construction handoff

23 October 2026 (Asia/Beirut). Intended destination: **uyounmodel-cloud/idigitalroot-platform**, PRIVATE. This archive is a handoff payload, not a Git repository or repository-creation request. The destination has NOT been created, configured, populated, or checked for privacy by this export. No Git remotes, original source, prior evidence or provider resources were changed.

Read this file, CONTINUATION_CHECKPOINT.md and SOURCE_PROVENANCE.json before any other action. The root SHA256SUMS.txt covers the exact archive-relative bytes. No embedded historical prompt, test command, blank approval form, roadmap or successful model result is present execution authority. This export ends with STOP.

## What is actually complete

P00/P00B established authority/provenance and identified historical fixture defects; P01 provided the complete scope review; P01A reconciled the explicit owner authentication decision; P01B specified documentary catalogue, editable pricing and quota/cost boundaries; P01C prepared the construction contracts and bounded work orders. These historical documents remain unchanged, including their dates, former blockers and then-current permission statements.

The owner subsequently approved **only F1-v1.0**, pinned work-order SHA256 **855353834fdf58edda1f4e0e4d678fd0fb8353607ecc23624e76c741fe887cae**, boundary contract **94d0850a32290d74f569327fcc4bc1411ffe80f9b6d1b56c46e5308307ec6466**, two-D1 proposal **e9a857c43a83a4f9796e6d0b6ed5944d2783c5936a54380abb2c150843be2ede**. F1 created the ten files at the root-relative locations listed below and ran its exact three Node model-test files once. **174 passed; 0 failed, skipped, cancelled or todo; command exit 0.** Admin 43, Client 79, envelope/context/outcomes 52. Raw evidence is in evidence/F1/; no tests were rerun for this export.

**MODEL_ONLY / NOT_AUTHENTICATED.** The modules validate synthetic structure and authorization predicates. They do not authenticate callers, verify WebAuthn/signatures, issue credentials/sessions, persist authority, produce Paid, implement an editor, expose an API or enforce real distributed privacy. Every positive model diagnostic is labeled accordingly. Independent review is **UNASSIGNED/PENDING**, not an independent PASS. All 58 product-feature rows remain NOT_BUILT/NOT_RUN; the 151 risks and 345 ASVS rows remain NOT_ASSESSED, and the 54 original cases remain NOT_RUN. F1 tests do not change those registers or prove ASVS L3.

## Payload layout

| Location | Meaning |
|---|---|
| contracts/v1/{envelope,outcomes,authority-context}.mjs | Three unchanged F1 pure model modules. |
| admin/src/authorization/policy-model.mjs | Unchanged five-bundle staff policy model. |
| client/src/authorization/policy-model.mjs | Unchanged Client account/Root/member/guardian/grant/epoch/barrier model. |
| tests/contracts/envelope-model.test.mjs | Unchanged envelope/context/outcome cases. |
| tests/authorization/{admin,client}-model.test.mjs | Two unchanged authorization model-test files. |
| docs/foundation-scope.md; docs/foundation-exit.md | Two unchanged F1 scope/exit reports. These complete the ten F1 files. |
| evidence/F1/ | Exact original ENTRY.json, EXIT.json, model-tests.log, INDEPENDENT_REVIEW.md, SHA256SUMS.txt. |
| docs/authority/P01C/ | All five final P01C documents, including bounded orders and schema/recovery proposal. |
| docs/authority/P01A/; docs/authority/P01B/ | Complete reconciliation/contracts/checkpoints and selected exact owner/proposal inputs, including machine-readable 12+4 catalogue. |
| docs/authority/discovery/ | Full cumulative v0.15, v0.3/v0.4 scope, 58-feature matrix, 77-decision traceability and verification provenance. |
| docs/authority/P01/; docs/authority/P00B/ | Full immutable P01 (including H and L), authority completion and anomaly/security evidence. |
| docs/authority/master/; docs/authority/client-original/ | Relevant original blueprints, system definitions and recorded owner requirements; historical context with later precedence below. |
| docs/security/ | Original seven master security authorities plus complete Client security requirements/threat/registers and original release gates. |
| evidence/provenance/P00/ | Original 243-path baseline, final verification, frozen-migration comparison and source/reading reports. Hashes/metadata only; no historical fixture code or SQL. |

No runtime, dependency package, lockfile, application manifest, executable bootstrap, migration, generated fixture, .git metadata, workflow or real provider configuration is included. Source imports remain unchanged and work relative to the archive root. The old absolute filesystem references in historical documents/evidence are provenance, not relocated runnable instructions. Use SOURCE_PROVENANCE.json to map them to the included paths; use the root manifest for relocated hashes.

## Authority and settled decisions

Preserve Rounds 1–26; do not repeat discovery or manufacture decisions. The **77 explicit IDs are R13–R26**. R1–R12 are preserved as narrative groups in cumulative v0.15, unified v0.4/v0.5 and original owner/blueprint records; exact lost question IDs, option letters or verbatim transcripts must not be invented. The 58-feature matrix retains **56 REQUIRED, UX-01 PROPOSED, EXT-TEAMS PARTIAL**. Do not quietly promote the last two or remove required scope.

Later explicit owner decisions take precedence only within their stated scope. **AUTH-2026-10-22-01** replaces routine password-plus-email-code MFA with **PASSWORD AND WebAuthn for every staff member, owner, collaborator, guardian and allowed minor**, independent backup authenticators and supervised recovery. Email is contact verification/invitations/notices only, never login/MFA/fallback/lost-factor recovery proof or owner consent. Preserve the original seven security authorities and ASVS v5 V6.3.6 L3. Original P01 alternatives and historical CMS authentication are not retroactively approved for the new platform.

P01B/P01C clarify that null initial selling amounts do not block designing or, under a later exact work order, building a null-safe unpublished Admin price engine. They do not approve publication, prices, schemas, identity implementation or provider use. Earlier references to a binary-inaccessible October 14 master are historical: subsequent P00/P00B evidence and this export's raw-hash checks establish the pinned master SHA256 in the checkpoint. Do not ask the owner to locate or re-upload it. The archive itself is intentionally not duplicated here.

## Architecture and separation of authority

Target runtime is Workers with **physically separate NEW Admin D1 and NEW Client D1** and Worker-controlled private R2. No database, binding, Worker or cloud resource exists from F1/export.

```mermaid
flowchart LR
  P[New EN/AR Public Site: no CMS] -->|secured request wizard| A[Admin Worker authority]
  A --> AD[(New Admin D1)]
  A <-->|versioned service contracts / outbox-inbox / Pending| C[Client Worker authority]
  C --> CD[(New Client D1)]
  A -->|authorized private access| R[(Private R2)]
  C -->|authorized private access| R
```

Admin owns staff IAM, commercial/paid entitlement truth, Root-to-commercial-account association, projects, immutable approvals and support threads. Client owns customer/member/guardian IAM and private tool/workspace records. Credentials are never duplicated between these namespaces; workload principals cannot impersonate a human owner. Super Admin has no blanket customer-data, Billing or consent override. Five staff bundles: Super Admin, Operations Manager, Project/Production Staff, Billing Staff, Support Staff.

Every protected operation and delivery needs current authoritative Admin entitlement AND current Client object/property/function/account/Root/member/guardian rights. Unknown/stale/unavailable authority fails closed or remains truthful Pending; a projection cannot mint a grant. There is no cross-D1 distributed ACID. Proposed versioned durable outbox/inbox, idempotency/CAS, reconciliation, G-RACE epochs/barriers/admission/finalization/delivery and recovery require actual architecture review and runtime proof. In-flight byte delivery/revocation semantics remain unresolved; F1 proves only deterministic predicates, not linearizability or stream cancellation.

The NEW corporate Public Site is distinct, bilingual EN/LTR + AR/RTL, motion with accessibility/reduced-motion requirements, **NO CMS**, and only a secured request wizard into authenticated Admin lead qualification plus a durable transactional notice addressed to visitors@idigitalroot.com. No identity/Paid/Root arises from an inquiry. Historical Public CMS/MOTION remains separate and untouched. Legacy Public Core 0001–0016 and Analytics 0001–0002 remain frozen; **no public 0017**. Later real client-site CMS/factory is separate work. A local SSO broker and exactly two fake isolated consumers are not a working client CMS. No broker/consumer or email adapter has been implemented by F1.

## Complete product and commercial requirements

Deliver one complete eventual LOCAL Admin+Client candidate for **Students, Professionals, Entrepreneurs and Businesses**; engineering slices are not a complete product. Student has 12 Toolbox + 16 Workspace positions, **27 unique capabilities** because Career Kit is shared. Professional reuses reviewed engines; Entrepreneur has four bounded additions; Business has two. Exact names/acceptance dependencies are in the full matrix and P01B catalogue; no scope is silently dropped. Client navigation has 11 main areas (Home, Roots, Projects, Tools, Domains, Email, Services, Billing, Renewals, Support, Account) plus separate Inbox. Private Portfolio/Research Shelf do not become public CMS or generic vaults.

Exactly **12 annual website plans (four families × Entry/Growth/Premium)** and four tool packs. Site creation occurs once at first purchase with a real eligible domain and real hosted mailbox; the matching pack is included for the first 12 months. Both independent clocks start at Billing-verified purchase, not launch; no extension for construction delay. Subsequent packs are prepaid monthly/annual, one active pack per Root, no tools-only account and no automatic customer charging. Tools require Live Root + active website + valid pack + current rights.

Customer owner accepts the exact quote/version/terms. Operations records Pending evidence; independent Billing alone verifies payment; staff creates Root afterward. Two immutable owner-only exact-version project approvals (design/content and final) never authorize deployment. Root transfers require both owners and scoped staff, revoke old access and preserve origin invoice/support history; destination owner decides unfinished work. Operations nonfinancial corrections need a different Super Admin checker. Supervised support, guardian 13–17 verification/category/purpose/expiry/revoke and lawful data-rights controls remain mandatory.

All selling amounts remain **null**, country overrides empty, and every 12+4 catalogue item **UNPUBLISHED_DRAFT**. Publication/quote/payment require approved non-null terms/prices, market/tax/FX/supplier eligibility and exact review grants. Null never becomes zero or an unauthorized free plan. Future Admin edits are versioned, frequent when authorized, fresh action-bound WebAuthn/CAS/audit/review controlled; approved sale terms/invoices/history are immutable. Material inclusion changes need publication review too.

Proposed Entry/Growth/Premium inclusions: up to 5/10/20 pages, 1/2/2 languages, 1/2/3 hosted mailboxes, one standard domain each, 1/2/3 revision cycles and 0.5/1/2 care hours/month. These numeric inclusions and build-hour estimates are **PROPOSALS**, not owner-approved offers, measured capacity or business SLAs. Original P01B cost citations/arithmetic are dated evidence; .com/Zoho/Google reference rates remain unverified and no live account cost evidence exists.

Seven common hypotheses only: 2 GiB private Root storage, 2,000 structured records, five collaborators, 50 new shares/rolling 30d, 20 active shares, 100 exports/rolling 30d, two concurrent heavy jobs. **NOT_MEASURED / NOT_APPROVED**, not seeded paid entitlements. Account-global D1/R2 safety, scan/decoder/parser memory/CPU/decompressed limits require later explicitly bounded measurement. Price/tier never bypasses safety.

Fixed ceilings: DOCX/XLSX/PPTX 10 MB each; CSV/ICS 2 MB; batch 25 MB; support JPEG/PNG/WebP ≤5 MB each and ≤3/message; shares default 30d/max 90d; Study Timer inactivity 10min. Byte conventions and expanded/parser/scan/CPU/account budgets remain TBD. Regional support proposals, 90-day copies/monthly restore exercises and RPO24h/RTO48h goals are requirements/planning targets, not measured production guarantees. Markets LB/IQ/BH/KW/OM/QA/SA/AE do not imply legal/provider/residency eligibility.

## Construction stages and dependency gates

| Stage | Scope and prerequisite | Present state |
|---|---|---|
| F1 independent review | Inspect all ten files, original contracts, negative cases and limitations; separate reviewer records findings. No tests/install needed for first source review. | NEXT REVIEW TASK; UNASSIGNED/PENDING. |
| Admin and Client foundation schema orders | Two independent new migration lineages/recovery proposals; exact entities, paths, apply/restore target/tool hashes/resources require separate owner approval. No actual bindings or legacy migration reuse. | Neither approved, created nor applied. |
| F2 actual IAM/authorization/contracts | Requires reviewed F1 and approved persistence; maintained reviewed password/WebAuthn/session/workload implementations; enrollment/backups/recovery/step-up, accessible devices and L3 applicability. | No executable exact F2 order yet. |
| F3 unpublished catalogue/editor | Reviewed actual staff IAM/capabilities + approved Admin persistence; null-safe draft/version editor; no customer publication. | Planned; initial price numbers not a prerequisite. |
| F4 local review/publication rules | F3 plus exact grants, high-value multi-user governance and explicit synthetic local rules/data if authorized. | Planned; no real publication grant. |
| F5 commercial state flows | Reviewed predecessors + schemas and G-RACE; quote/owner/Billing/Root/renewal/switch/transfer/outbox/recovery. | Planned; synthetic settlement never real Paid. |
| F6 full four-pack candidate | Actual IAM/grants/persistence, separately authorized features, safe files/global budgets and measured workloads; projects/support/tools/private exports, broker and exactly two fake consumers. | All 58 product rows retain original status; no partial completeness claim. |
| PUBLIC-NEW | Separate exact no-CMS EN/AR site/wizard/lead/notice work order, reviewed Admin intake contract. | Planned; no legacy CMS source imported. |
| Later client CMS/factory and live release | Separate exact scope, actual security/QA/restore/browser/native Windows/provider/legal/offer/resource/spend/deploy gates. | Not authorized. |

## The next executable task

After verifying the handoff, the next substantive task is a **read-only independent F1 source/contract review** with an assigned independent reviewer, preserving existing reports and recording new findings separately when requested. Review default denial, all five bundles, staff/customer/Billing separation, account/Root/object/property scope, guardian binding, epochs/barriers, delivery/account-switch/replay and typed-money refusal; do not treat synthetic state as a trusted assertion. No new application tests, credentials or provider actions are needed to begin source review, and none is authorized by this archive.

If construction is requested next, first produce a bounded F2 (or separately selected Admin/Client schema) work order with exact relocated input hashes, enumerated file paths, tool/dependency versions and hashes, permitted commands, resource ceilings, recovery plan and independent review exit evidence. Owner must separately affirm that exact version/hash and activities. The old absolute-path approvals are not automatically portable to this repository. Do not rerun F1, install Node/dependencies, create SQL or start a server based on an archived command.

Immediate blockers: F1 independent review unassigned; no approved exact next source/schema order; actual identity/recovery/privileged governance and publication grants unreviewed; cross-authority in-flight semantics unresolved; parser/global budgets unmeasured. PKG-01's seven missing generated fixture files and FE tsconfig discrepancy remain acceptance blockers for that affected old fixture only; defective fixtures are deliberately excluded and no fix/PASS is implied. Actual publication requires offer/terms/non-null prices; providers/legal/live release remain separate later gates, not a demand for 32 prices before editor engineering.

## Fresh-session rule and final stop

Use the included documents; do not ask the owner to re-upload the October 14 master or repeat Rounds 1–26. Record exact missing authority if a later task genuinely requires excluded archive bytes; preserve the pinned provenance and obtain an authorized read from the original archive repository, not a guessed replacement. Original historical sources remain archived in uyounmodel-cloud/idigitalroot. No original archive or fixture is migrated as new platform implementation.

Current authorization is **HANDOFF/EXPORT ONLY**. This payload grants no application source modification, test execution, schema/migration, repository creation, push, provider, procurement, spend or deployment. The owner must separately authorize importing this payload into a new PRIVATE repository. Keep all evidence dated and immutable. **NEXT_TASK=INDEPENDENT_F1_REVIEW_PENDING; NEXT_CONSTRUCTION_ORDER=NOT_APPROVED; STOP_AFTER_HANDOFF=YES.**
