import { exact, integer, strings, text, validateContext } from '../../../contracts/v1/authority-context.mjs';
import { modelOnly, outcome } from '../../../contracts/v1/outcomes.mjs';

const epochs = ['ownership', 'grant', 'membership', 'guardian', 'privacy'];
const rules = Object.freeze({
  'tool.read': ['title', 'content'], 'tool.mutate': ['title', 'content'],
  'share.create': ['itemVersion', 'recipient'], 'export.create': ['itemVersion', 'format'],
  'project.comment': ['comment'], 'project.approve': ['artifactHash', 'artifactVersion'],
  'quote.accept': ['quoteHash', 'termsVersion'], 'support.message': ['message'],
  'renewal.read': ['period', 'status'],
});
const protectedTools = ['tool.read', 'tool.mutate', 'share.create', 'export.create'];
export function evaluateClient(context, request, state, now) {
  const identity = validateContext(context, 'CLIENT_HUMAN', 'client-model', now);
  if (identity.kind !== 'ModelOnly') return identity;
  if (!exact(request, ['operation', 'accountId', 'rootId', 'objectId', 'fields', 'expectedVersion',
    'expectedEpochs', 'category', 'purpose', 'phase']) ||
      !['operation', 'accountId', 'rootId', 'objectId', 'category', 'purpose'].every(k => text(request[k])) ||
      !strings(request.fields) || !integer(request.expectedVersion) || !['EXECUTION', 'DELIVERY'].includes(request.phase) ||
      !exact(request.expectedEpochs, epochs) || !epochs.every(k => integer(request.expectedEpochs[k])) ||
      !exact(state, ['testOnly', 'accountId', 'rootId', 'objectId', 'recordSubjectId', 'version', 'category',
        'readers', 'writers', 'member', 'admin', 'epochs', 'barrier', 'stepUp', 'guardian', 'minor']) ||
      state.testOnly !== true || !['accountId', 'rootId', 'objectId', 'recordSubjectId', 'category'].every(k => text(state[k])) ||
      !integer(state.version) || !strings(state.readers) || !strings(state.writers) ||
      !exact(state.epochs, epochs) || !epochs.every(k => integer(state.epochs[k])) ||
      !['ACTIVE', 'REVOKING', 'TRANSFER_PENDING', 'RECONCILE_REQUIRED'].includes(state.barrier) ||
      !exact(state.member, ['subjectId', 'role', 'current', 'expiresAt']) ||
      !text(state.member.subjectId) || !text(state.member.role) || typeof state.member.current !== 'boolean' ||
      !integer(state.member.expiresAt) || typeof state.minor !== 'boolean' ||
      !exact(state.admin, ['availability', 'current', 'accountId', 'rootId', 'checkedAt', 'expiresAt',
        'live', 'websiteActive', 'packCount', 'barrier']) ||
      !['CURRENT', 'UNAVAILABLE', 'MISSING'].includes(state.admin.availability) ||
      !['current', 'live', 'websiteActive'].every(k => typeof state.admin[k] === 'boolean') ||
      !['accountId', 'rootId'].every(k => text(state.admin[k])) ||
      !['checkedAt', 'expiresAt', 'packCount'].every(k => integer(state.admin[k])) ||
      !['ACTIVE', 'REVOKING', 'TRANSFER_PENDING', 'RECONCILE_REQUIRED'].includes(state.admin.barrier)) {
    return outcome('Deny', 'VALIDATION_ERROR');
  }
  if (![context, request, state.admin].every(x => x.accountId === state.accountId && x.rootId === state.rootId) ||
      request.objectId !== state.objectId || request.category !== state.category ||
      state.member.subjectId !== context.subjectId || state.member.role !== context.role ||
      !state.member.current || state.member.expiresAt <= now) return outcome('Deny', 'NOT_FOUND_SCOPED');
  if (state.barrier !== 'ACTIVE' || state.admin.barrier !== 'ACTIVE') return outcome('Deny', 'BARRIER_ACTIVE');
  if (!epochs.every(k => request.expectedEpochs[k] === state.epochs[k])) return outcome('Deny', 'EPOCH_MISMATCH');
  if (request.expectedVersion !== state.version) return outcome('Conflict', 'VERSION_CONFLICT');
  const fields = Object.hasOwn(rules, request.operation) ? rules[request.operation] : null;
  if (!fields || !request.fields.every(k => fields.includes(k))) return outcome('Deny', 'FORBIDDEN');
  if (context.role === 'Guardian' || state.minor || context.role === 'Minor') {
    const g = state.guardian;
    if (!exact(g, ['testOnly', 'verified', 'revoked', 'subjectId', 'minorId', 'organizationId',
      'rootId', 'categories', 'purpose', 'expiresAt', 'age']) || g.testOnly !== true || g.verified !== true ||
      g.revoked !== false || !text(g.subjectId) || !text(g.minorId) || g.subjectId === g.minorId ||
      g.minorId !== state.recordSubjectId || g.organizationId !== state.accountId ||
      g.rootId !== state.rootId || !strings(g.categories) || !g.categories.includes(request.category) ||
      g.purpose !== request.purpose || !integer(g.age) || g.age < 13 || g.age > 17 ||
      !integer(g.expiresAt) || g.expiresAt <= now ||
      (context.role === 'Guardian' ? g.subjectId !== context.subjectId : g.minorId !== context.subjectId)) {
      return outcome('Deny', 'FORBIDDEN');
    }
  } else if (state.guardian !== null) return outcome('Deny', 'VALIDATION_ERROR');
  if (['project.approve', 'quote.accept'].includes(request.operation)) {
    if (context.role !== 'Owner' || state.minor) return outcome('Deny', 'FORBIDDEN');
    const s = state.stepUp;
    if (!exact(s, ['subjectId', 'operation', 'objectId', 'version', 'expiresAt']) ||
        s.subjectId !== context.subjectId || s.operation !== request.operation || s.objectId !== state.objectId ||
        s.version !== state.version || !integer(s.expiresAt) || s.expiresAt <= now) return outcome('Deny', 'REAUTH_REQUIRED');
  } else if (state.stepUp !== null) return outcome('Deny', 'VALIDATION_ERROR');
  const read = ['tool.read', 'renewal.read'].includes(request.operation);
  if (!(read ? state.readers : state.writers).includes(context.subjectId)) return outcome('Deny', 'FORBIDDEN');
  // The same fresh grant rule applies at execution AND delivery. No cached epoch is authority.
  if (state.admin.availability === 'UNAVAILABLE') return outcome('Pending', 'AUTHORITY_UNAVAILABLE');
  if (state.admin.availability !== 'CURRENT' || !state.admin.current || state.admin.checkedAt !== now ||
      state.admin.expiresAt <= now) return outcome('Deny', 'ENTITLEMENT_UNVERIFIABLE');
  if (protectedTools.includes(request.operation) &&
      (!state.admin.live || !state.admin.websiteActive || state.admin.packCount !== 1)) return outcome('Deny', 'ENTITLEMENT_UNVERIFIABLE');
  return modelOnly(); // No actual protected execution, delivery, consent or entitlement.
}
