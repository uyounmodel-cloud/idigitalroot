import { modelOnly, outcome } from './outcomes.mjs';

export const plain = x => x !== null && typeof x === 'object' &&
  !Array.isArray(x) && Object.getPrototypeOf(x) === Object.prototype;
export const exact = (x, keys) => plain(x) && Reflect.ownKeys(x).length === keys.length &&
  keys.every(k => Object.hasOwn(x, k));
export const text = x => typeof x === 'string' && /^[A-Za-z0-9_.:/-]{1,128}$/.test(x);
export const integer = x => Number.isSafeInteger(x) && x >= 0;
export const strings = x => Array.isArray(x) && x.length <= 32 && Array.from(x).every(text) && new Set(x).size === x.length;
const keys = ['testOnly', 'evidence', 'namespace', 'subjectId', 'sessionId', 'accountId',
  'rootId', 'credentialEpoch', 'authzEpoch', 'assurance', 'audience', 'expiresAt', 'role'];
const roles = Object.freeze({
  ADMIN_STAFF: ['SuperAdmin', 'OperationsManager', 'ProjectProductionStaff', 'BillingStaff', 'SupportStaff'],
  CLIENT_HUMAN: ['Owner', 'Collaborator', 'Guardian', 'Minor'],
  WORKLOAD: ['ADMIN_SERVICE', 'CLIENT_SERVICE', 'PUBLIC_INTAKE', 'LOCAL_SSO_A', 'LOCAL_SSO_B'],
});
export function validateContext(context, namespace, audience, now) {
  if (!exact(context, keys) || !integer(now) || context.testOnly !== true ||
      context.evidence !== 'MODEL_ONLY' || !Object.hasOwn(roles, context.namespace) ||
      !roles[context.namespace].includes(context.role) ||
      !['subjectId', 'sessionId', 'accountId', 'rootId', 'audience'].every(k => text(context[k])) ||
      !integer(context.credentialEpoch) || !integer(context.authzEpoch) || !integer(context.expiresAt)) {
    return outcome('Deny', 'CONTEXT_INVALID');
  }
  if (context.namespace !== namespace || context.audience !== audience) return outcome('Deny', 'NAMESPACE_MISMATCH');
  if (context.expiresAt <= now) return outcome('Deny', 'EXPIRED');
  const expected = namespace === 'WORKLOAD' ? 'SYNTHETIC_WORKLOAD' : 'SYNTHETIC_PASSWORD_AND_WEBAUTHN';
  if (context.assurance !== expected) return outcome('Deny', 'REAUTH_REQUIRED');
  return modelOnly(); // Schema-conforming synthetic assertions remain NOT_AUTHENTICATED.
}

export function currentReply(selection, reply) {
  const keys = ['accountId', 'selectionVersion'];
  if (!exact(selection, keys) || !exact(reply, keys) || !text(selection.accountId) ||
      !text(reply.accountId) || !integer(selection.selectionVersion) || !integer(reply.selectionVersion)) {
    return outcome('Deny', 'VALIDATION_ERROR');
  }
  return selection.accountId === reply.accountId && selection.selectionVersion === reply.selectionVersion
    ? modelOnly() : outcome('Deny', 'STALE_ACCOUNT_REPLY');
}
