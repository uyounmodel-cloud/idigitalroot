// F1 only: these are diagnostic model values, never authentication or grants.
const reasons = Object.freeze({
  Deny: ['VALIDATION_ERROR', 'CONTRACT_UNSUPPORTED', 'CONTEXT_INVALID', 'NAMESPACE_MISMATCH',
    'FORBIDDEN', 'NOT_FOUND_SCOPED', 'REAUTH_REQUIRED', 'ENTITLEMENT_UNVERIFIABLE',
    'BARRIER_ACTIVE', 'EPOCH_MISMATCH', 'EXPIRED', 'STALE_ACCOUNT_REPLY'],
  Pending: ['AUTHORITY_UNAVAILABLE', 'PENDING_CONFIRMATION'],
  Conflict: ['VERSION_CONFLICT', 'IDEMPOTENCY_CONFLICT'],
  Unquotable: ['PRICE_UNPUBLISHED', 'AMOUNT_MISSING', 'TERMS_UNAPPROVED'],
});
export function outcome(kind, reason) {
  if (!Object.hasOwn(reasons, kind) || !reasons[kind].includes(reason)) throw new TypeError('Unknown diagnostic outcome');
  return Object.freeze({ kind, reason, model: 'MODEL_ONLY', authentication: 'NOT_AUTHENTICATED' });
}
export function modelOnly() {
  return Object.freeze({ kind: 'ModelOnly', model: 'MODEL_ONLY', authentication: 'NOT_AUTHENTICATED' });
}
export function quoteBlocker(draft) {
  if (!draft || draft.status !== 'PUBLISHED') return outcome('Unquotable', 'PRICE_UNPUBLISHED');
  if (!Number.isSafeInteger(draft.amount) || draft.amount <= 0) return outcome('Unquotable', 'AMOUNT_MISSING');
  // F1 has no publication/terms authority, even if a caller supplies non-null numbers.
  return outcome('Unquotable', 'TERMS_UNAPPROVED');
}
