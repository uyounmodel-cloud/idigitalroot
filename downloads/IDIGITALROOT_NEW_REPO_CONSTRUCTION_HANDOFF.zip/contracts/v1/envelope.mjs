import { exact, integer, text, strings, validateContext } from './authority-context.mjs';
import { modelOnly, outcome } from './outcomes.mjs';

const keys = ['commandId', 'operation', 'contractVersion', 'schemaId', 'producerId', 'audience',
  'purpose', 'issuedAt', 'expiresAt', 'nonce', 'correlationId', 'causationId', 'actor',
  'accountId', 'rootId', 'objectId', 'expectedVersions', 'payloadDigest', 'payload'];
const versions = ['object', 'ownership', 'membership', 'guardian', 'entitlement', 'price', 'terms'];
const digest = x => typeof x === 'string' && /^[a-f0-9]{64}$/.test(x);
export function validateEnvelope(e, profile, now) {
  if (!exact(profile, ['operation', 'schemaId', 'producerId', 'audience', 'purpose', 'namespace', 'payloadFields']) ||
      !strings(profile.payloadFields) || !integer(now) || !exact(e, keys)) return outcome('Deny', 'VALIDATION_ERROR');
  if (e.contractVersion !== 'idr.contract.v1') return outcome('Deny', 'CONTRACT_UNSUPPORTED');
  if (!['commandId', 'operation', 'schemaId', 'producerId', 'audience', 'purpose', 'nonce',
    'correlationId', 'causationId', 'accountId', 'rootId', 'objectId'].every(k => text(e[k])) ||
      !integer(e.issuedAt) || !integer(e.expiresAt) || e.issuedAt > now || e.expiresAt <= now ||
      e.expiresAt <= e.issuedAt || !digest(e.payloadDigest) || !exact(e.expectedVersions, versions) ||
      !versions.every(k => integer(e.expectedVersions[k])) || !exact(e.payload, profile.payloadFields) ||
      !profile.payloadFields.every(k => typeof e.payload[k] === 'string' && e.payload[k].length <= 256)) {
    return outcome('Deny', 'VALIDATION_ERROR');
  }
  if (!['operation', 'schemaId', 'producerId', 'audience', 'purpose'].every(k => e[k] === profile[k])) {
    return outcome('Deny', 'NAMESPACE_MISMATCH');
  }
  const context = validateContext(e.actor, profile.namespace, profile.audience, now);
  if (context.kind !== 'ModelOnly') return context;
  if (e.actor.accountId !== e.accountId || e.actor.rootId !== e.rootId) return outcome('Deny', 'NOT_FOUND_SCOPED');
  return modelOnly(); // No digest calculation, signature, nonce storage or trusted identity.
}

const replayKeys = ['authority', 'operation', 'namespace', 'subjectId', 'key', 'accountId', 'rootId', 'objectId', 'payloadDigest'];
export function compareReplay(previous, next, currentReadRights) {
  if (![previous, next].every(x => exact(x, replayKeys) && replayKeys.every(k => text(x[k])) && digest(x.payloadDigest))) {
    return outcome('Deny', 'VALIDATION_ERROR');
  }
  if (currentReadRights !== true) return outcome('Deny', 'FORBIDDEN');
  if (!replayKeys.every(k => previous[k] === next[k])) return outcome('Conflict', 'IDEMPOTENCY_CONFLICT');
  return modelOnly(); // Identity equality only; no receipt is persisted or returned.
}
