@echo off
echo Preparing the iDigitalRoot website preview. The first run may take several minutes.
echo Your browser will open automatically when the website is ready.
echo Keep this window open. When you finish browsing, return here and press Enter to stop.
wsl.exe --cd "%~dp0." -- python3 OPEN_WEBSITE_PREVIEW.py > "%~dp0WINDOWS_PREVIEW_LAUNCH.log" 2>&1
type "%~dp0WINDOWS_PREVIEW_LAUNCH.log"
echo If the preview failed, send PREVIEW_LOGS.zip. If it was not created, send WINDOWS_PREVIEW_LAUNCH.log.
pause
