#!/usr/bin/env python3
"""Owner local browser review of a sealed candidate; never deploys."""
from pathlib import Path, PurePosixPath
import argparse,hashlib,json,os,platform,posixpath,shutil,signal,socket,subprocess,sys,tarfile,tempfile,threading,time,urllib.request,urllib.error,zipfile
p=argparse.ArgumentParser();p.add_argument('--frontend-node');p.add_argument('--backend-node');p.add_argument('--no-open',action='store_true');p.add_argument('--test-seconds',type=int);a=p.parse_args()
root=Path(__file__).resolve().parent
results=root/'PREVIEW_LOGS';results.mkdir(exist_ok=True)
run=results/time.strftime('%Y%m%d-%H%M%S');run.mkdir()
meta=json.loads((root/'OPERATOR_MANIFEST.json').read_text());archive=root/meta['source_file']
stage=None;children=[];handles=[];status='FAIL';stop=threading.Event()
def requested_stop(*_):stop.set()
signal.signal(signal.SIGTERM,requested_stop);signal.signal(signal.SIGINT,requested_stop)
if hasattr(signal,'SIGHUP'):signal.signal(signal.SIGHUP,requested_stop)
def execute(name,cmd,cwd,env):
    print(name+'...',flush=True)
    with (run/(name+'.log')).open('w') as f:rc=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
    if rc:raise RuntimeError(name+' failed. The saved logs will let me diagnose it.')
def get_node(version,override=None):
    existing=override or shutil.which('node')
    if existing and subprocess.check_output([existing,'-p','process.versions.node'],text=True).strip()==version:return Path(existing).resolve()
    if override:raise RuntimeError('Specified Node runtime has the wrong version')
    arch={'x86_64':'x64','aarch64':'arm64'}.get(platform.machine())
    if not arch:raise RuntimeError('Unsupported Linux CPU architecture')
    name=f'node-v{version}-linux-{arch}.tar.xz';base=f'https://nodejs.org/dist/v{version}/'
    with urllib.request.urlopen(base+'SHASUMS256.txt',timeout=45) as r:sums=r.read().decode()
    expected=next(x.split()[0] for x in sums.splitlines() if x.endswith('  '+name))
    downloaded=stage/name
    with urllib.request.urlopen(base+name,timeout=45) as r,downloaded.open('wb') as f:shutil.copyfileobj(r,f)
    if hashlib.sha256(downloaded.read_bytes()).hexdigest()!=expected:raise RuntimeError('Official Node download integrity mismatch')
    with tarfile.open(downloaded) as t:
        if hasattr(tarfile,'data_filter'):t.extractall(stage,filter='data')
        else:
            # Preserve safe extraction on the owner's older Ubuntu Python as well.
            for m in t.getmembers():
                n=PurePosixPath(m.name)
                if n.is_absolute() or '..' in n.parts or not (m.isfile() or m.isdir() or m.issym() or m.islnk()):raise RuntimeError('Unsafe Node archive entry')
                if m.issym() or m.islnk():
                    link=posixpath.normpath(posixpath.join(posixpath.dirname(m.name) if m.issym() else '',m.linkname))
                    if link.startswith('/') or link=='..' or link.startswith('../'):raise RuntimeError('Unsafe Node archive link')
            t.extractall(stage)
    return stage/name[:-len('.tar.xz')]/'bin/node'
try:
    if hashlib.sha256(archive.read_bytes()).hexdigest()!=meta['source_sha256']:raise RuntimeError('Sealed source archive checksum mismatch')
    for port in [4388,4399,4400]:
        with socket.socket() as s:
            s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
            try:s.bind(('127.0.0.1',port))
            except OSError:raise RuntimeError(f'Preview port {port} is occupied. No existing application was stopped.')
    stage=Path(tempfile.mkdtemp(prefix='idigitalroot-preview-',dir='/tmp'));source=stage/'source'
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:raise RuntimeError('Source ZIP CRC failure')
        for n in z.namelist():
            path=PurePosixPath(n)
            if path.is_absolute() or '..' in path.parts:raise RuntimeError('Unsafe source archive path')
        z.extractall(source)
    node=get_node('22.19.0',a.frontend_node);backend=get_node('22.16.0',a.backend_node);npm=str(backend.parent/'npm')
    original=os.environ.copy()
    env={**original,'PATH':str(node.parent)+os.pathsep+str(source/'node_modules/.bin')+os.pathsep+original['PATH'],'ASTRO_TELEMETRY_DISABLED':'1','WRANGLER_SEND_METRICS':'false','npm_config_cache':str(stage/'npm-cache')}
    execute('Verifying source files',['sha256sum','--check','SHA256SUMS.txt'],source,env)
    execute('Installing pinned dependencies',[npm,'ci','--engine-strict','--no-audit','--no-fund'],source,env)
    # Reuse the existing owner authentication read-only before building/testing.
    connection='UNVERIFIED'
    try:
        identity=subprocess.run([str(node),str(source/'node_modules/wrangler/bin/wrangler.js'),'whoami'],cwd=source,env={**original,'PATH':str(node.parent)+os.pathsep+original['PATH'],'WRANGLER_SEND_METRICS':'false'},capture_output=True,text=True,timeout=45)
        text=identity.stdout+identity.stderr
        connection='UNAUTHENTICATED' if 'not authenticated' in text else 'AUTHENTICATED' if ('logged in' in text.lower() or 'account name' in text.lower()) else 'UNVERIFIED'
    except (OSError,subprocess.TimeoutExpired):pass
    (run/'cloudflare-read-only-status.json').write_text(json.dumps({'status':connection,'operation':'wrangler whoami only','login_performed':False,'provider_mutation_performed':False},indent=2)+'\n')
    env.update(XDG_CONFIG_HOME=str(stage/'config'),XDG_CACHE_HOME=str(stage/'cache'))
    (source/'.dev.vars').write_text('IDR_PUBLIC_API_BASE_URL="http://127.0.0.1:4388"\nIDR_PUBLIC_SITE_ORIGIN="http://127.0.0.1:4400"\n')
    execute('Checking the website',[npm,'run','check'],source,env)
    execute('Building the local website',[npm,'run','build'],source,env)
    execute('Checking frontend boundaries',[sys.executable,'scripts/check_worker_bindings.py'],source,env)
    be=source/'tests/authority/be01';beenv={**env,'PATH':str(backend.parent)+os.pathsep+str(source/'node_modules/.bin')+os.pathsep+original['PATH']}
    execute('Preparing local content service',[npm,'ci','--ignore-scripts','--no-audit','--no-fund'],be,beenv)
    execute('Verifying backend toolchain',[npm,'run','install:verify'],be,beenv)
    execute('Building local content service',[npm,'run','build'],be,beenv)
    execute('Preparing preview',[str(node),str(source/'node_modules/typescript/bin/tsc'),'-p','tsconfig.fe02.json'],source,env)
    # Only the synthetic preview fixture is extended. Sealed application source is unchanged.
    fixture=(source/'tests/integration-server.mjs').read_text();seed=(root/'preview_seed.mjs').read_text()
    marker='let failApi=false;';assert marker in fixture
    (source/'preview-fixture.mjs').write_text(fixture.replace(marker,seed+'\n'+marker))
    execute('Rechecking sealed source',['sha256sum','--check','SHA256SUMS.txt'],source,env)
    for name,cmd,process_env in [('content',[str(backend),'preview-fixture.mjs'],beenv),('website',[str(node),'node_modules/.bin/astro','preview','--ignore-lock','--host','127.0.0.1','--port','4400'],env)]:
        log=(run/(name+'.log')).open('w');handles.append(log);children.append(subprocess.Popen(cmd,cwd=source,env=process_env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True))
    deadline=time.monotonic()+45
    while time.monotonic()<deadline and not stop.is_set():
        if any(c.poll() is not None for c in children):raise RuntimeError('A local preview service stopped')
        try:
            with urllib.request.urlopen('http://127.0.0.1:4400/',timeout=2) as r:body=r.read().decode();assert r.status==200 and 'Your ambition deserves' in body
            with urllib.request.urlopen('http://127.0.0.1:4400/ar',timeout=2) as r:body=r.read().decode();assert r.status==200 and 'dir="rtl"' in body
            break
        except Exception:time.sleep(.2)
    else:raise RuntimeError('Website preview did not become ready')
    status='PASS'
    (run/'READY.json').write_text(json.dumps({'status':'PASS','source_sha256':meta['source_sha256'],'fixture_profile':'Synthetic publications using approved code-owned presentation copy; not production content','deployment_performed':False,'provider_mutation_performed':False,'launcher_pid':os.getpid()},indent=2)+'\n')
    print('PREVIEW READY. The website is opening in your browser. Keep this window open.',flush=True)
    print('Sample content is used. Live inquiry submission and analytics are still unfinished.',flush=True)
    if not a.no_open:
        cmd=shutil.which('cmd.exe') or ('/mnt/c/Windows/System32/cmd.exe' if Path('/mnt/c/Windows/System32/cmd.exe').exists() else None)
        if cmd:
            opened=subprocess.run([cmd,'/c','start','','http://127.0.0.1:4400'],capture_output=True,timeout=15)
            if opened.returncode:print('Automatic browser opening failed; see the installation guide for the local address.',flush=True)
        else:print('See the installation guide for the local browser address.',flush=True)
    print(f'Preview launcher PID: {os.getpid()}. Press Enter here to stop the preview.',flush=True)
    if a.test_seconds is not None:stop.wait(a.test_seconds)
    else:
        def enter_to_stop():
            try:input();stop.set()
            except EOFError:pass
        threading.Thread(target=enter_to_stop,daemon=True).start()
        while not stop.wait(1):
            if any(c.poll() is not None for c in children):raise RuntimeError('A preview service stopped')
except Exception as e:
    status='FAIL';(run/'error.txt').write_text(str(e)+'\n');print('Preview could not start. Send PREVIEW_LOGS.zip so I can diagnose it; no debugging is needed from you.',flush=True)
finally:
    for c in reversed(children):
        if c.poll() is None:
            try:os.killpg(c.pid,signal.SIGTERM)
            except ProcessLookupError:pass
        try:c.wait(timeout=5)
        except subprocess.TimeoutExpired:os.killpg(c.pid,signal.SIGKILL);c.wait()
    for f in handles:f.close()
    (run/'RESULT.json').write_text(json.dumps({'status':status,'source_sha256':meta['source_sha256'],'deployment_performed':False,'provider_mutation_performed':False},indent=2)+'\n')
    with zipfile.ZipFile(root/'PREVIEW_LOGS.zip','w',zipfile.ZIP_DEFLATED) as z:
        for f in run.rglob('*'):
            if f.is_file():z.write(f,f.relative_to(run))
    if stage:shutil.rmtree(stage)
    print('Preview stopped. Logs saved in PREVIEW_LOGS.zip.',flush=True)
sys.exit(0 if status=='PASS' else 1)
