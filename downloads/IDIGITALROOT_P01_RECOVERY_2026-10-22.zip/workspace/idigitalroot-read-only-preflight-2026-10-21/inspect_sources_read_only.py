"""Read local ZIP/source bytes; write evidence only beside this script. No project execution."""
import pathlib,json,zipfile,io,hashlib,re
P=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/workspace/idigitalroot')
digest=lambda b:hashlib.sha256(b).hexdigest()
master=zipfile.ZipFile(REPO/'downloads/IDIGITALROOT_CODEX_MASTER_HANDOFF_2026-10-14_v1.1.zip')
z=zipfile.ZipFile(REPO/'downloads/IDIGITALROOT_MOTION01_SOURCE_2026-10-16_rc2.zip')
def inspect(archive,label):
    results=[]; names=set(archive.namelist())
    for name in archive.namelist():
        parent=str(pathlib.PurePosixPath(name).parent);prefix='' if parent=='.' else parent+'/'
        if name.endswith('SHA256SUMS.txt'):
            rows=[]
            for line in archive.read(name).decode('utf-8-sig').splitlines():
                if not line.strip():continue
                match=re.match(r'^([0-9a-f]{64})\s+\*?(.*)$',line)
                if not match:rows.append({'unparsed_line':line,'ok':False});continue
                expected,f=match.groups();full=prefix+f.removeprefix('./')
                got=digest(archive.read(full)) if full in names else 'MISSING'
                rows.append({'path':full,'expected':expected,'observed':got,'ok':got==expected})
            results.append({'checksum_file':name,'count':len(rows),'pass':all(r['ok'] for r in rows),'rows':rows})
        if name.endswith('RELEASE_MANIFEST.json'):
            metadata=json.loads(archive.read(name));rows=[]
            for row in metadata.get('files',[]):
                if not isinstance(row,dict) or not ('path'in row or 'name'in row) or 'sha256'not in row:continue
                full=prefix+row.get('path',row.get('name'));exists=full in names
                data=archive.read(full) if exists else b''
                expectedsize=row.get('size_bytes',row.get('bytes',row.get('size')))
                rows.append({'path':full,'exists':exists,'sha_ok':exists and digest(data)==row['sha256'],'size_ok':exists and(expectedsize is None or len(data)==expectedsize)})
            results.append({'manifest_file':name,'count':len(rows),'pass':all(r['sha_ok']and r['size_ok']for r in rows),'rows':rows})
    return {'archive':label,'crc_first_bad':archive.testzip(),'checks':results}
findings={'current':inspect(z,'MOTION01')}
handoff=zipfile.ZipFile(P/'preparation/01_REFERENCE_VERIFIED/IDIGITALROOT_CLIENT_PANEL_BLUEPRINT_AND_AI_HANDOFF_2026-10-16_v1.2.zip')
findings['oct16']=inspect(handoff,'OCT16')
findings['original_components']=[inspect(zipfile.ZipFile(io.BytesIO(master.read(n))),n) for n in master.namelist() if n.startswith('01_CURRENT_IMPLEMENTATIONS/')and n.endswith('.zip')]
(P/'SOURCE_ARCHIVE_CHECKS.json').write_text(json.dumps(findings,indent=2))
for label in ['current','oct16']:
    print(label,[(r.get('checksum_file',r.get('manifest_file')),r['count'],r['pass'])for r in findings[label]['checks']])
    for r in findings[label]['checks']:
        bad=[v['path']for v in r['rows']if not v.get('ok',v.get('sha_ok',False))]
        if bad:print('FAILED_REFERENCES',r.get('checksum_file',r.get('manifest_file')),bad)
print('original',[(pathlib.Path(r['archive']).name,len(r['checks']),all(c['pass']for c in r['checks']))for r in findings['original_components']])
cmsname=next(n for n in master.namelist()if n.endswith('IDIGITALROOT_P1-CMS_FINAL_CONNECTED_SOURCE_v1.5.3.zip'))
cms=zipfile.ZipFile(io.BytesIO(master.read(cmsname)));rows=[]
for n in z.namelist():
    if '/migrations/'not in n or not n.endswith('.sql'):continue
    suffix=n[n.index('schema/'):];original=cms.read(suffix)
    rows.append({'current_path':n,'canonical_archive':cmsname,'canonical_path':suffix,'expected':digest(original),'observed':digest(z.read(n)),'match':original==z.read(n)})
(P/'FROZEN_MIGRATION_COMPARISON.json').write_text(json.dumps(rows,indent=2))
print('migrations',len(rows),'equal',all(r['match']for r in rows),'0017+',any(int(pathlib.Path(r['current_path']).name[:4])>=17 for r in rows))
inventory=[{'path':n,'bytes':len(z.read(n)),'sha256':digest(z.read(n))}for n in z.namelist()if not n.endswith('/')]
(P/'CURRENT_SOURCE_INVENTORY.json').write_text(json.dumps(inventory,indent=2))
copies=[]
for root in [pathlib.Path('/workspace/idigitalroot-motion-2026-10-16/source'),pathlib.Path('/workspace/idigitalroot-motion-2026-10-16/fresh-rc2'),pathlib.Path('/workspace/idigitalroot-connected-runtime/a3a11293559b72dac659/source')]:
    row={'path':str(root),'exists':root.is_dir(),'files_checked':0,'mismatches':[],'missing':[]}
    if root.is_dir():
        for r in inventory:
            f=root/r['path'];row['files_checked']+=1
            if not f.is_file():row['missing'].append(r['path'])
            elif digest(f.read_bytes())!=r['sha256']:row['mismatches'].append(r['path'])
    copies.append(row)
(P/'LOCAL_SOURCE_COPY_COMPARISON.json').write_text(json.dumps(copies,indent=2));print('local_copies',json.dumps(copies))
out=P/'current-source-inspection';out.mkdir(exist_ok=True)
for n in z.namelist():
    if n.endswith(('.ts','.astro','.mjs','.json','.jsonc','.md','.sql','.txt'))and not n.startswith(('docs/','website/src/content/frozen-fixtures','website/src/scripts/client'))and not '/tests/'in n and '..'not in pathlib.PurePosixPath(n).parts:
        f=out/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(z.read(n))
mm=json.loads(master.read('RELEASE_MANIFEST.json'));mp=set(r['path']for r in mm['files'])
cs=set(re.match(r'^([0-9a-f]{64})\s+\*?(.*)$',l).group(2)for l in master.read('SHA256SUMS.txt').decode().splitlines()if l.strip())
diff={'checksums_only':sorted(cs-mp),'manifest_only':sorted(mp-cs)}
(P/'MASTER_MANIFEST_COVERAGE.json').write_text(json.dumps(diff,indent=2));print('master_manifest_coverage',diff)
