# iDigitalRoot P1-BE-01 Public Backend Source v1.1.2

P1-CMS-03 bounded extension of the accepted public backend. It preserves published-content and inquiry behavior while adding published-only redirect resolution and public search. P1-CMS-03R1 adds defense-in-depth external redirect host revalidation; the current code-owned external host allowlist is explicitly empty.

Search is locale-aware, bounded and deterministic; only published eligible pages, Knowledge and AVAILABLE services are returned. Draft/private/internal fields are excluded. Raw visitor search text is neither stored nor written to Analytics; the response exposes only privacy-safe result-count/query-length classes suitable for the accepted `internal_search` event contract.

The backend carries the accepted Core migration lineage `0001`–`0016` without an independent schema fork. It contains no production IDs, credentials, deployment commands or paid-resource actions.

Run `python scripts/verify_all.py` from a fresh extraction. A passing run ends with `P1_BE11_LOCAL_VALIDATION_PASS`.


## v1.1.2 bounded public-media delivery seam

Adds `GET /api/public/v1/media/:mediaId` as the only public byte-delivery seam for approved local-upload media. The endpoint revalidates current D1 approval/object state, resolves the opaque R2 key only on the backend, streams bytes through the `PUBLIC_MEDIA_BUCKET` binding, emits a public validator when available, and fails closed when the media record, object, or binding is unavailable. The public frontend never constructs or receives an R2 URL. No migration or schema change is introduced.
