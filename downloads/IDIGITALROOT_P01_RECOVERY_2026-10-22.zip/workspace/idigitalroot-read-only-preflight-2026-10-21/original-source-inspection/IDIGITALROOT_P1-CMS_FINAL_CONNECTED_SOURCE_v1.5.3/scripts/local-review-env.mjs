import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {createProductionEnv} from '../dist/worker.js';
import {LocalAccessVerifier} from '../dist/core/security.js';
import {AdvancedCmsService,FixtureGoogleDriveClient,R2BindingAdapter} from '../dist/core/advanced.js';
import {D1AdvancedRepository} from '../dist/core/repository.js';
import {ProductionAnalyticsAdapter} from '../dist/analytics/adapter.js';
import {NodeSqliteD1,applySchema,freshSqlitePath} from '../tests/helpers/local-d1.mjs';
import {CoreAuthorizationVerifier} from '../local-review/an-dist/analytics/auth.js';
import {queryAnalytics,exportAnalytics,requireAnalyticsConfig,REPORT_REGISTRY} from '../local-review/an-dist/analytics/reports.js';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(__dirname,'..');

class LocalBucket{
  constructor(){this.m=new Map()}
  async put(k,v){const b=v instanceof Uint8Array?v:new Uint8Array(v);this.m.set(k,b.slice())}
  async get(k){const v=this.m.get(k);return v?{arrayBuffer:async()=>v.slice().buffer}:null}
  async delete(k){this.m.delete(k)}
}

function applyAnalyticsSchema(db){
  const dir=path.join(root,'schema','analytics','migrations');
  for(const f of fs.readdirSync(dir).filter(x=>/^\d{4}.*\.sql$/.test(x)).sort())db.db.exec(fs.readFileSync(path.join(dir,f),'utf8'));
}
function execIfPossible(db,sql){try{db.db.exec(sql)}catch(e){throw new Error(`LOCAL_REVIEW_FIXTURE_SQL_FAILED: ${e.message}`)}}
function seedRootActor(db){
  const at=new Date().toISOString();
  const role=db.db.prepare(`SELECT role_id FROM roles WHERE role_key='CMS_ROOT_ADMIN'`).get();
  if(!role?.role_id)throw new Error('CMS_ROOT_ADMIN role missing');
  db.db.prepare(`INSERT OR IGNORE INTO actors(actor_id,actor_type,status,display_name,primary_email_normalized,created_at) VALUES('actor_local_root','HUMAN','ACTIVE','Root Admin','root@example.invalid',?)`).run(at);
  db.db.prepare(`INSERT OR REPLACE INTO actor_security_state(actor_id,activation_state,row_version,updated_at) VALUES('actor_local_root','active',1,?)`).run(at);
  db.db.prepare(`INSERT OR REPLACE INTO cms_external_identities(identity_id,actor_id,provider_key,issuer,subject,observed_email_normalized,identity_state,bound_at,row_version) VALUES('identity_local_root','actor_local_root','cloudflare_access','https://local.cloudflareaccess.invalid','root-local','root@example.invalid','ACTIVE',?,1)`).run(at);
  db.db.prepare(`INSERT OR IGNORE INTO actor_roles(actor_id,role_id,granted_at) VALUES('actor_local_root',?,?)`).run(role.role_id,at);
  db.db.prepare(`INSERT OR IGNORE INTO actor_role_scopes(actor_id,role_id,granted_at,scope_kind) VALUES('actor_local_root',?,?,'global')`).run(role.role_id,at);
}
function hashJson(v){return crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex')}
function ensureLocaleState(db,eid,locale,actor='actor_local_root'){
  const at=new Date().toISOString();
  db.db.prepare(`INSERT OR IGNORE INTO content_locale_state(entity_id,locale_code,translation_state,row_version,updated_by_actor_id,updated_at) VALUES(?,?,'MISSING',1,?,?)`).run(eid,locale,actor,at);
}
function ensurePage(db,{id,key,path:routePath,parent=null,ordinal=1,titleEn,titleAr}){
  const at=new Date().toISOString();const rid=`route_${id}`;
  db.db.prepare(`INSERT OR IGNORE INTO routes(route_id,route_key,route_kind,code_owned,created_at) VALUES(?,?,'PRIMARY',1,?)`).run(rid,key,at);
  for(const lc of ['en','ar'])db.db.prepare(`INSERT OR IGNORE INTO route_paths(route_path_id,route_id,locale_code,path,is_canonical,is_active,updated_by_actor_id,updated_at) VALUES(?,?,?,?,1,1,'actor_local_root',?)`).run(`rpath_${id}_${lc}`,rid,lc,routePath,at);
  db.db.prepare(`INSERT OR IGNORE INTO content_entities(entity_id,entity_type,stable_key,route_id,created_at) VALUES(?,'PAGE',?,?,?)`).run(id,key,rid,at);
  db.db.prepare(`INSERT OR IGNORE INTO page_hierarchy(page_entity_id,parent_page_entity_id,sibling_ordinal,row_version,updated_by_actor_id,updated_at) VALUES(?,?,?,1,'actor_local_root',?)`).run(id,parent,ordinal,at);
  for(const [lc,title] of [['en',titleEn],['ar',titleAr]]){
    ensureLocaleState(db,id,lc);
    const exists=db.db.prepare(`SELECT count(*) c FROM content_revisions WHERE entity_id=? AND locale_code=?`).get(id,lc).c;
    if(!exists){const content={title,lead:lc==='en'?'Owner-review connected CMS fixture.':'بيانات محلية متصلة لمراجعة نظام الإدارة.'};const rev=`rev_${id}_${lc}_1`;db.db.prepare(`INSERT INTO content_revisions(revision_id,entity_id,locale_code,revision_number,workflow_state,validation_state,schema_version,content_json,content_hash_sha256,created_by_actor_id,created_at) VALUES(?,?,?,1,'DRAFT','VALID',1,?,?, 'actor_local_root',?)`).run(rev,id,lc,JSON.stringify(content),hashJson(content),at);db.db.prepare(`UPDATE content_locale_state SET translation_state='DRAFT',latest_revision_id=?,row_version=1,updated_by_actor_id='actor_local_root',updated_at=? WHERE entity_id=? AND locale_code=?`).run(rev,at,id,lc)}
  }
}
function ensureGlobalCopy(db,key,content){
  const at=new Date().toISOString();let row=db.db.prepare(`SELECT entity_id FROM content_entities WHERE stable_key=? AND entity_type='GLOBAL_PUBLIC_COPY'`).get(key);let eid=row?.entity_id;
  if(!eid){eid=`global_${key.replace(/[^a-z0-9]+/gi,'_')}`;db.db.prepare(`INSERT INTO content_entities(entity_id,entity_type,stable_key,created_at) VALUES(?,'GLOBAL_PUBLIC_COPY',?,?)`).run(eid,key,at)}
  ensureLocaleState(db,eid,'en');ensureLocaleState(db,eid,'ar');
  const exists=db.db.prepare(`SELECT count(*) c FROM content_revisions WHERE entity_id=? AND locale_code='en'`).get(eid).c;
  if(!exists){const rev=`rev_${eid}_en_1`;db.db.prepare(`INSERT INTO content_revisions(revision_id,entity_id,locale_code,revision_number,workflow_state,validation_state,schema_version,content_json,content_hash_sha256,created_by_actor_id,created_at) VALUES(?,?, 'en',1,'DRAFT','VALID',1,?,?, 'actor_local_root',?)`).run(rev,eid,JSON.stringify(content),hashJson(content),at);db.db.prepare(`UPDATE content_locale_state SET translation_state='DRAFT',latest_revision_id=?,row_version=1,updated_by_actor_id='actor_local_root',updated_at=? WHERE entity_id=? AND locale_code='en'`).run(rev,at,eid)}
}
function ensureNavFooterRevisions(db){
  const at=new Date().toISOString();
  for(const [eid,lc,content] of [
    ['ent_fixture_nav','en',{items:[{label:'Personal',href:'/personal'},{label:'Students',href:'/students'},{label:'Knowledge',href:'/knowledge'},{label:'Contact',href:'/contact'}]}],
    ['ent_fixture_nav','ar',{items:[{label:'الشخصي',href:'/personal'},{label:'الطلاب',href:'/students'},{label:'المعرفة',href:'/knowledge'},{label:'تواصل معنا',href:'/contact'}]}],
    ['ent_fixture_footer','en',{groups:[{label:'Personal',links:[{label:'Students',href:'/students'},{label:'Contact',href:'/contact'}]},{label:'Legal',links:[{label:'Privacy',href:'/legal/privacy'}]}]}],
    ['ent_fixture_footer','ar',{groups:[{label:'الشخصي',links:[{label:'الطلاب',href:'/students'},{label:'تواصل معنا',href:'/contact'}]},{label:'القانوني',links:[{label:'الخصوصية',href:'/legal/privacy'}]}]}]
  ]){
    ensureLocaleState(db,eid,lc);
    const exists=db.db.prepare(`SELECT count(*) c FROM content_revisions WHERE entity_id=? AND locale_code=?`).get(eid,lc).c;
    if(!exists){const rev=`rev_${eid}_${lc}_1`;db.db.prepare(`INSERT INTO content_revisions(revision_id,entity_id,locale_code,revision_number,workflow_state,validation_state,schema_version,content_json,content_hash_sha256,created_by_actor_id,created_at) VALUES(?,?,?,1,'DRAFT','VALID',1,?,?, 'actor_local_root',?)`).run(rev,eid,lc,JSON.stringify(content),hashJson(content),at);db.db.prepare(`UPDATE content_locale_state SET translation_state='DRAFT',latest_revision_id=?,row_version=1,updated_by_actor_id='actor_local_root',updated_at=? WHERE entity_id=? AND locale_code=?`).run(rev,at,eid,lc)}
  }
}
function seedOwnerReviewContent(db){
  const fixture=fs.readFileSync(path.join(root,'schema','fixtures','representative-upgrade.sql'),'utf8');execIfPossible(db,fixture);
  // The accepted representative upgrade fixture uses a deliberately different provider-row ID.
  // Normalize only this local review fixture to the production service's registered adapter ID;
  // ON UPDATE CASCADE preserves the fixture provenance/import references without changing schema.
  db.db.prepare(`UPDATE media_import_providers SET import_provider_id='imp_google_drive' WHERE provider_key='google_drive' AND import_provider_id<>'imp_google_drive'`).run();
  seedRootActor(db);
  const pages=[
    ['page_personal','page.personal','/personal',null,2,'Personal','الشخصي'],
    ['page_students','page.students','/students','page_personal',1,'Students','الطلاب'],
    ['page_toolbox','page.student.toolbox','/student/toolbox','page_students',1,'Root Toolbox','صندوق أدوات الجذر'],
    ['page_workspace','page.student.workspace','/student/workspace','page_students',2,'Student Workspace','مساحة الطالب'],
    ['page_majors','page.student.majors','/student/majors','page_students',3,'Majors','التخصصات'],
    ['page_knowledge','page.knowledge','/knowledge',null,3,'Knowledge','المعرفة'],
    ['page_services','page.services','/services',null,4,'Services','الخدمات'],
    ['page_about','page.about','/company/about',null,5,'About','من نحن'],
    ['page_contact','page.contact','/contact',null,6,'Contact','تواصل معنا'],
    ['page_faq','page.faq','/faq',null,7,'FAQ','الأسئلة الشائعة'],
    ['page_rootcheck','page.root-check','/root-check',null,8,'Root Check','فحص الجذر']
  ];
  for(const p of pages)ensurePage(db,{id:p[0],key:p[1],path:p[2],parent:p[3],ordinal:p[4],titleEn:p[5],titleAr:p[6]});
  // Ensure home hierarchy exists without replacing accepted fixture content/publication truth.
  db.db.prepare(`INSERT OR IGNORE INTO page_hierarchy(page_entity_id,parent_page_entity_id,sibling_ordinal,row_version,updated_by_actor_id,updated_at) VALUES('ent_fixture_home',NULL,1,1,'actor_local_root',?)`).run(new Date().toISOString());
  ensureNavFooterRevisions(db);
  ensureGlobalCopy(db,'site-design-profile',{latinUi:'idr-latin-ui',latinAccent:'idr-latin-serif',arabicUi:'idr-arabic-ui',arabicDisplay:'idr-arabic-kufi',arabicEditorial:'idr-arabic-naskh',fontFamilies:['idr-latin-ui','idr-latin-serif','idr-arabic-ui','idr-arabic-kufi','idr-arabic-naskh'],weights:[400,500,600,700,800,900],fallbacks:['system-ui-tahoma-arial'],body:16,lineHeight:1.6,headings:'signature-large',typeScale:'signature-large',nav:15});
  ensureGlobalCopy(db,'site-brand-contact-social',{brandName:'iDigitalRoot',tagline:'Your personal digital root',contactEmail:'hello@idigitalroot.com',defaultTitle:'iDigitalRoot',defaultDescription:'Managed personal digital presence, built with people and managed with care.',socialLinks:[]});
}
function seedAnalytics(db){
  applyAnalyticsSchema(db);
  execIfPossible(db,fs.readFileSync(path.join(root,'schema','fixtures','analytics-synthetic.sql'),'utf8'));
  const start='2026-10-05T00:00:00Z',end='2026-10-06T00:00:00Z',at='2026-10-06T00:05:00Z';let i=0;
  for(const key of Object.keys(REPORT_REGISTRY)){
    const dims=JSON.stringify({locale_code:'en'}),hash=crypto.createHash('sha256').update(key+'|'+dims).digest('hex');
    db.db.prepare(`INSERT OR IGNORE INTO analytics_rollups(rollup_id,report_key,window_granularity,window_start,window_end,dimension_hash,dimensions_json,metric_count,metric_sum,metric_min,metric_max,metrics_json,source_through_received_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(`rollup_local_${++i}`,key,'DAY',start,end,hash,dims,i*7,Number(i*3),1,i*4,'{}',at,at);
  }
}
export function buildLocalReviewEnvironment(origin='http://127.0.0.1:4177'){
  const corePath=freshSqlitePath('idr-cms04-owner-core-');const coreDb=new NodeSqliteD1(corePath);applySchema(coreDb);seedOwnerReviewContent(coreDb);
  const analyticsPath=path.join(fs.mkdtempSync(path.join(os.tmpdir(),'idr-cms04-owner-analytics-')),'analytics.sqlite');const analyticsDb=new NodeSqliteD1(analyticsPath);seedAnalytics(analyticsDb);
  const bucket=new LocalBucket();
  const principal=()=>({providerKey:'cloudflare_access',issuer:'https://local.cloudflareaccess.invalid',subject:'root-local',email:'root@example.invalid',issuedAt:new Date().toISOString(),expiresAt:new Date(Date.now()+8*3600_000).toISOString(),type:'app'});
  const verifier=new LocalAccessVerifier({root:principal()});
  const authz=new CoreAuthorizationVerifier(coreDb);
  const bridge={
    async query(c,q){return queryAnalytics(analyticsDb,coreDb,authz,{authenticated:true,actorId:c.actorId,sessionId:c.sessionId,requestId:c.requestId,environmentKey:'LOCAL_REVIEW'},q)},
    async export(c,q){return exportAnalytics(analyticsDb,coreDb,authz,{authenticated:true,actorId:c.actorId,sessionId:c.sessionId,requestId:c.requestId,environmentKey:'LOCAL_REVIEW'},q)},
    async config(c){const ctx={authenticated:true,actorId:c.actorId,sessionId:c.sessionId,requestId:c.requestId,environmentKey:'LOCAL_REVIEW'};await requireAnalyticsConfig(authz,ctx);return {source:'P1-AN-01',environment:'LOCAL_REVIEW',collectionMode:'CONSENTED_SYNTHETIC_FIXTURE',policyGate:'LOCAL_REVIEW_ONLY'}}
  };
  const analytics=new ProductionAnalyticsAdapter(bridge);
  const env=createProductionEnv({CORE_DB:coreDb,MEDIA_BUCKET:bucket,PREVIEW_SECRET:'LOCAL_REVIEW_PREVIEW_SECRET_NOT_PRODUCTION_2026',CMS_ORIGIN:origin,accessVerifier:verifier,analytics});
  // Local review keeps production-shaped D1/R2 services but swaps only the provider HTTP client for a deterministic local fixture.
  const png=Uint8Array.from(Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9Zl1sAAAAASUVORK5CYII=','base64'));
  const fixtures=new Map([['drive_fixture_12345',{name:'drive-fixture.png',mime:'image/png',bytes:png}]]);
  env.advanced=new AdvancedCmsService(undefined,new D1AdvancedRepository(coreDb,false),new R2BindingAdapter(bucket),'LOCAL_REVIEW','LOCAL_REVIEW_PREVIEW_SECRET_NOT_PRODUCTION_2026',new FixtureGoogleDriveClient(fixtures));
  return {env,coreDb,analyticsDb,bucket,verifier,principal,paths:{corePath,analyticsPath}};
}
