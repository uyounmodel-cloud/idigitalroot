export declare function stableJson(value: unknown): string;
export declare function utf8Bytes(value: string): number;
export declare function utcSeconds(date: Date): string;
export declare function parseUtc(value: string): Date | null;
