export interface AcquisitionInput {
    referrerUrl?: unknown;
    utmSource?: unknown;
    utmMedium?: unknown;
    utmCampaign?: unknown;
    utmContent?: unknown;
    utmTerm?: unknown;
}
export interface SanitizedAcquisition {
    referrerClass: string;
    referrerHost: string | null;
    utmSource: string | null;
    utmMedium: string | null;
    utmCampaign: string | null;
    utmContent: string | null;
    utmTerm: string | null;
}
export declare function sanitizeAcquisition(input: AcquisitionInput | undefined, publicOrigins: readonly string[]): SanitizedAcquisition;
