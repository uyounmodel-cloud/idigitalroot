import type { AnalyticsEnv, Clock, D1Database } from '../core/types.js';
export interface IngestOutcome {
    accepted: number;
    duplicate: number;
    ignoredOff: number;
    receiptStored: boolean;
    requestId: string;
}
export declare function ingestAnalytics(request: Request, env: AnalyticsEnv, clock?: Clock): Promise<IngestOutcome>;
export declare function recordSecurityRejection(db: D1Database, code: string, request: Request, clock?: Clock): Promise<void>;
export declare function deriveInternalSearchGroup(rawNormalizedQuery: string, secret: string): Promise<string>;
