import type { D1Database } from '../core/types.js';
import { type EventDefinition, type SeededEventKey } from '../site-profile/idigitalroot.js';
export interface RegistryRecord {
    definition: EventDefinition;
    enabled: boolean;
    allowedModes: readonly string[];
    dbRawExportAllowed: boolean;
}
export declare function loadRegistryRecord(db: D1Database, eventKey: string, schemaVersion: number): Promise<RegistryRecord>;
export declare function validateProperties(definition: EventDefinition, value: unknown): Record<string, unknown>;
export declare function seededEventKeys(): SeededEventKey[];
