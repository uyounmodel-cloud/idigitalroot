import type { AuthorizationVerifier, D1Database, TrustedCmsContext } from '../core/types.js';
type Row = Record<string, unknown>;
export declare const REPORT_KEYS: readonly ["overview", "content_routes", "acquisition", "audience_technology", "coarse_geography", "engagement_custom", "internal_search", "inquiry_funnel", "performance_web_vitals", "public_runtime_health", "bot_abuse"];
export type ReportKey = typeof REPORT_KEYS[number];
export interface ReportDefinition {
    reportKey: ReportKey;
    eventKeys: readonly string[];
    allowedDimensions: readonly string[];
    allowedFilters: readonly string[];
    allowedSorts: readonly string[];
    rawAllowed: boolean;
}
export declare const REPORT_REGISTRY: Readonly<Record<ReportKey, ReportDefinition>>;
export interface QueryInput {
    reportKey: string;
    mode?: 'aggregate' | 'raw';
    start: string;
    end: string;
    dimensions?: string[];
    filters?: Record<string, string>;
    sort?: string;
    pageSize?: number;
}
export interface QueryResult {
    reportKey: ReportKey;
    mode: 'aggregate' | 'raw';
    rows: Row[];
}
export declare function queryAnalytics(analyticsDb: D1Database, coreDb: D1Database, verifier: AuthorizationVerifier, ctx: TrustedCmsContext, input: QueryInput): Promise<QueryResult>;
export declare function exportAnalytics(analyticsDb: D1Database, coreDb: D1Database, verifier: AuthorizationVerifier, ctx: TrustedCmsContext, input: QueryInput): Promise<QueryResult>;
export declare function requireAnalyticsConfig(verifier: AuthorizationVerifier, ctx: TrustedCmsContext): Promise<void>;
export declare function reportRegistryDigestInput(): string;
export declare const GENERIC_REPORT_DIMENSIONS: readonly ["locale_code", "route_id", "entity_id", "country_code", "continent_code", "browser_class", "os_class", "device_class", "language_class", "viewport_class", "bot_class"];
export {};
