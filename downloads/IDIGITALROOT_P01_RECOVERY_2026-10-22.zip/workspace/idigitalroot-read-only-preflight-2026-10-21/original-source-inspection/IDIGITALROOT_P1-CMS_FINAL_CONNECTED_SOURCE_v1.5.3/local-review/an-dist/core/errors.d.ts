export declare class AnalyticsError extends Error {
    readonly status: number;
    readonly code: string;
    readonly publicMessage: string;
    constructor(status: number, code: string, publicMessage: string);
}
