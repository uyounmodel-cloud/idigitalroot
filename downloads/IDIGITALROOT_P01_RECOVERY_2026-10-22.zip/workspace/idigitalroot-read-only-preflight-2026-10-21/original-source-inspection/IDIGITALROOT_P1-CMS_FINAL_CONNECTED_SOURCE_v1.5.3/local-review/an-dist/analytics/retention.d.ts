import type { D1Database } from '../core/types.js';
export interface SyntheticRetentionFixture {
    testOnlySyntheticDataset: true;
    status: 'APPROVED';
    categoryKey: string;
    policyVersionKey: string;
    durationSeconds: number;
}
export interface RetentionResult {
    blocked: boolean;
    categoryKey: string;
    deleted: number;
    reason: string;
}
export declare function runRetentionGate(analyticsDb: D1Database, coreDb: D1Database, categoryKey: string, nowDate?: Date, synthetic?: SyntheticRetentionFixture): Promise<RetentionResult>;
