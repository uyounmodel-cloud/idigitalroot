import type { AnalyticsPermission, AuthorizationVerifier, D1Database, TrustedCmsContext } from '../core/types.js';
export declare class CoreAuthorizationVerifier implements AuthorizationVerifier {
    private readonly coreDb;
    private readonly now;
    constructor(coreDb: D1Database, now?: () => Date);
    permissions(context: TrustedCmsContext): Promise<ReadonlySet<AnalyticsPermission>>;
}
export declare function requirePermission(verifier: AuthorizationVerifier, context: TrustedCmsContext, permission: AnalyticsPermission): Promise<void>;
