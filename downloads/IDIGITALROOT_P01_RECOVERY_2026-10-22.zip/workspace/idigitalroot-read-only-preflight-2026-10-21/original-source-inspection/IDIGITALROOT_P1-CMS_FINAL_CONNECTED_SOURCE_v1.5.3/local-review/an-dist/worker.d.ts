import type { AnalyticsEnv } from './core/types.js';
export declare function handleAnalyticsRequest(request: Request, env: AnalyticsEnv): Promise<Response>;
declare const _default: {
    fetch: typeof handleAnalyticsRequest;
};
export default _default;
