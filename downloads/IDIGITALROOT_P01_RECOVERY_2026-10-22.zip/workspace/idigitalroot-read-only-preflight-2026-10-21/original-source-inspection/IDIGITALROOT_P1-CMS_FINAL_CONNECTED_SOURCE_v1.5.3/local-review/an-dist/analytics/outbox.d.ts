import type { D1Database } from '../core/types.js';
export interface ReplayResult {
    selected: number;
    delivered: number;
    retryable: number;
}
export declare function replayConversionOutbox(coreDb: D1Database, analyticsDb: D1Database, limit?: number, nowDate?: Date): Promise<ReplayResult>;
