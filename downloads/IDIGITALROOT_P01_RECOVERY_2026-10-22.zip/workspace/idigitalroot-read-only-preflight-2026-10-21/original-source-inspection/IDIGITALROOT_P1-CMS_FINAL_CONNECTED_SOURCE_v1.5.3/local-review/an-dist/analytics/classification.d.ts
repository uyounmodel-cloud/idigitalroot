import type { ProviderRequestMetadata } from '../core/types.js';
export interface CoarseDimensions {
    browserClass: string;
    osClass: string;
    deviceClass: string;
    languageClass: string;
    viewportClass: string;
    countryCode: string | null;
    continentCode: string | null;
    botClass: 'HUMAN_LIKELY' | 'AUTOMATION_LIKELY' | 'VERIFIED_BOT' | 'UNKNOWN';
}
export declare function classifyBrowser(userAgent: string | null): string;
export declare function classifyOs(userAgent: string | null): string;
export declare function classifyDevice(userAgent: string | null): string;
export declare function classifyLanguage(value: string | null): string;
export declare function classifyViewport(width: unknown): string;
export declare function classifyBot(userAgent: string | null, cf?: ProviderRequestMetadata): CoarseDimensions['botClass'];
export declare function coarseDimensions(input: {
    userAgent: string | null;
    acceptLanguage: string | null;
    viewportWidth?: unknown;
    cf?: ProviderRequestMetadata;
}): CoarseDimensions;
