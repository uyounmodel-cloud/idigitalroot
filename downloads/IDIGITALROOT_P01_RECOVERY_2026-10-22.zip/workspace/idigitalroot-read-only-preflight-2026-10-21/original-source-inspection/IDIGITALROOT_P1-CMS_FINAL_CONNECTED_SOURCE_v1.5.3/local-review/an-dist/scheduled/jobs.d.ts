import type { D1Database } from '../core/types.js';
import { type Granularity } from '../analytics/rollup.js';
export declare function runClosedWindowRollups(analyticsDb: D1Database, granularity: Granularity, start: string, end: string): Promise<import("../analytics/rollup.js").RollupResult[]>;
export declare function runScheduledAnalytics(analyticsDb: D1Database, coreDb: D1Database, start: string, end: string, granularity?: Granularity): Promise<{
    rollups: import("../analytics/rollup.js").RollupResult[];
    outbox: import("../analytics/outbox.js").ReplayResult;
    health: Record<string, string | number | null>;
}>;
