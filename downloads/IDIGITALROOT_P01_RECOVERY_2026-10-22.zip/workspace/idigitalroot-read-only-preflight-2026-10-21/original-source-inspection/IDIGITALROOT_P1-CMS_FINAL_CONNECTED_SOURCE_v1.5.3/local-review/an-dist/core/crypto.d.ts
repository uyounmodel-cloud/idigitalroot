export declare function sha256Hex(input: string | Uint8Array): Promise<string>;
export declare function hmacSha256Hex(secret: string, input: string): Promise<string>;
export declare function randomId(): string;
