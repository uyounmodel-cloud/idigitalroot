export type PrivacyMode = 'OFF' | 'COOKIELESS' | 'CONSENTED';
export type PropertyRule = {
    type: 'string';
    maxLength: number;
    pattern?: RegExp;
    enum?: readonly string[];
} | {
    type: 'number';
    min?: number;
    max?: number;
} | {
    type: 'boolean';
};
export interface EventDefinition {
    eventKey: string;
    schemaVersion: 1;
    eventClass: string;
    publicAllowed: boolean;
    allowedModes: readonly Exclude<PrivacyMode, 'OFF'>[];
    propertyRules: Readonly<Record<string, PropertyRule>>;
    rawExportAllowed: boolean;
}
export declare const IDIGITALROOT_ANALYTICS_PROFILE: {
    readonly profileKey: "idigitalroot-public";
    readonly profileVersion: "p1-an-01-v1";
    readonly endpointPath: "/api/analytics/v1/events";
    readonly maxBodyBytes: 65536;
    readonly maxBatchEvents: 25;
    readonly maxEventIdLength: 128;
    readonly maxClockSkewSeconds: 900;
    readonly maxDateRangeDays: 366;
    readonly maxQueryPageSize: 100;
    readonly maxExportRows: 1000;
    readonly maxRollupEventsPerWindow: 5000;
    readonly eventRegistryVersion: "v1";
    readonly eventDefinitions: {
        page_view: {
            eventKey: string;
            schemaVersion: 1;
            eventClass: string;
            publicAllowed: true;
            allowedModes: ("COOKIELESS" | "CONSENTED")[];
            propertyRules: {};
            rawExportAllowed: true;
        };
        component_interaction: {
            eventKey: string;
            schemaVersion: 1;
            eventClass: string;
            publicAllowed: true;
            allowedModes: ("COOKIELESS" | "CONSENTED")[];
            propertyRules: {
                interaction_key: {
                    type: "string";
                    maxLength: number;
                    pattern: RegExp;
                };
            };
            rawExportAllowed: true;
        };
        internal_search: {
            eventKey: string;
            schemaVersion: 1;
            eventClass: string;
            publicAllowed: true;
            allowedModes: ("COOKIELESS" | "CONSENTED")[];
            propertyRules: {
                result_count_class: {
                    type: "string";
                    maxLength: number;
                    enum: string[];
                };
                query_length_class: {
                    type: "string";
                    maxLength: number;
                    enum: string[];
                };
                query_group_hash: {
                    type: "string";
                    maxLength: number;
                    pattern: RegExp;
                };
            };
            rawExportAllowed: false;
        };
        inquiry_funnel_step: {
            eventKey: string;
            schemaVersion: 1;
            eventClass: string;
            publicAllowed: true;
            allowedModes: ("COOKIELESS" | "CONSENTED")[];
            propertyRules: {
                step_key: {
                    type: "string";
                    maxLength: number;
                    pattern: RegExp;
                };
                outcome: {
                    type: "string";
                    maxLength: number;
                    enum: string[];
                };
            };
            rawExportAllowed: true;
        };
        inquiry_accepted: {
            eventKey: string;
            schemaVersion: 1;
            eventClass: string;
            publicAllowed: false;
            allowedModes: ("COOKIELESS" | "CONSENTED")[];
            propertyRules: {
                conversion_kind: {
                    type: "string";
                    maxLength: number;
                    enum: string[];
                };
            };
            rawExportAllowed: true;
        };
        web_vital: {
            eventKey: string;
            schemaVersion: 1;
            eventClass: string;
            publicAllowed: true;
            allowedModes: ("COOKIELESS" | "CONSENTED")[];
            propertyRules: {
                metric_key: {
                    type: "string";
                    maxLength: number;
                    enum: string[];
                };
                value_bucket: {
                    type: "string";
                    maxLength: number;
                    pattern: RegExp;
                };
            };
            rawExportAllowed: true;
        };
        runtime_error: {
            eventKey: string;
            schemaVersion: 1;
            eventClass: string;
            publicAllowed: true;
            allowedModes: ("COOKIELESS" | "CONSENTED")[];
            propertyRules: {
                error_code: {
                    type: "string";
                    maxLength: number;
                    pattern: RegExp;
                };
                build_id: {
                    type: "string";
                    maxLength: number;
                    pattern: RegExp;
                };
                stack_signature: {
                    type: "string";
                    maxLength: number;
                    pattern: RegExp;
                };
            };
            rawExportAllowed: false;
        };
        ingest_security: {
            eventKey: string;
            schemaVersion: 1;
            eventClass: string;
            publicAllowed: false;
            allowedModes: ("COOKIELESS" | "CONSENTED")[];
            propertyRules: {};
            rawExportAllowed: false;
        };
    };
};
export type SeededEventKey = keyof typeof IDIGITALROOT_ANALYTICS_PROFILE.eventDefinitions;
