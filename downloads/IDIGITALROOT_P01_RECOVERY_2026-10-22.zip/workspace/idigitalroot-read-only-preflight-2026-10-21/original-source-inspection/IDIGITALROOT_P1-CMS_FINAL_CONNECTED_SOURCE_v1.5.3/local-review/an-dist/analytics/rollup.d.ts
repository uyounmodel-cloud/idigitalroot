import type { D1Database } from '../core/types.js';
import { type ReportKey } from './reports.js';
export type Granularity = 'HOUR' | 'DAY';
export interface RollupResult {
    reportKey: ReportKey;
    granularity: Granularity;
    groups: number;
    events: number;
    skipped: boolean;
}
export declare function rollupWindow(db: D1Database, reportKey: ReportKey, granularity: Granularity, start: string, end: string, nowDate?: Date): Promise<RollupResult>;
export declare function analyticsHealth(db: D1Database, nowDate?: Date): Promise<Record<string, number | string | null>>;
