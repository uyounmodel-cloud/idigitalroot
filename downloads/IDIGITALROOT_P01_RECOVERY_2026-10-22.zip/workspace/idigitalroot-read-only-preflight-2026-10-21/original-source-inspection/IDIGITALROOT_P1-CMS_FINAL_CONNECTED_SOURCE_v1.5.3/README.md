# iDigitalRoot Public Website CMS — Connected Source v1.5.3

This is the bounded **P1-CMS-04R2 full professional editor-UI repair** of the connected CMS. It responds to the owner's connected review requirement that the Public Website CMS must feel like a simple professional content-management product, not a developer console.

## Owner-facing product rule

For ordinary Public Website CMS users:

- show human page/section/service names, not stable keys or database identifiers;
- show forms, buttons, selectors, media controls and rich-text editors, not JSON editors;
- show charts, metrics and tables for analytics, not raw report payloads;
- show readable activity/version comparisons, not object arrays or internal IDs;
- keep technical keys, IDs, row versions and structured service payloads internal to the connected service layer;
- expose a technical value only when it is genuinely required for an authorized operation, and present it in plain human language.

This rule applies across the entire CMS and is part of the reusable generic CMS core for future public websites.

## Frozen authority preserved

- Accepted CMS backend/service foundation remains v1.4.1.
- Accepted public BE authority remains v1.1.1 and is pinned in `local-review/BE_DIST_PIN.json`.
- Core D1 migrations remain exactly `0001`–`0016`; no `0017+` migration exists.
- Analytics D1 migrations remain exactly `0001`–`0002`.
- P1-CMS-04R2 changes editor-facing UI/test/local-review-package material only. Backend/service/schema authority is not redesigned.
- Owner-approved CMS UI/UX v4.1 remains the design/product authority.

## Professional editor presentation

The connected CMS now presents the ordinary editor experience with human-facing UI across the full workspace set, including:

- Pages, website map and homepage sections using human names and public URLs;
- Visual Website Editor with human page/section names, normal fields, design selectors, media controls and a sanitized WYSIWYG/safe-source rich-text editor;
- Navigation and Footer as structured rows/groups with add, edit, remove and reorder controls;
- English/Arabic translation as side-by-side fields;
- Media and connected-provider screens as cards, facts, previews and ordinary actions;
- Analytics as report tabs, metrics, charts and tables;
- Publishing and schedules with human content names, languages, statuses and dates;
- Activity history with human users/actions/content names;
- Users/roles and signed-in sessions without exposing internal IDs;
- SEO, inquiry, legal, services, knowledge and settings as normal forms and controls.

The connected backend still uses structured payloads internally because the accepted contracts require them. Those structures are not the normal content-editor interface.

## Stale-runtime protection for owner review

The CMS displays an unmistakable visible marker:

`OWNER REVIEW BUILD v1.5.3`

The corresponding bounded owner-review launcher uses its own isolated local port so an older local CMS server cannot be mistaken for this build.

## Security boundary

Rich content is not arbitrary executable HTML. The visual editor keeps a bounded formatting allowlist and sanitizes unsafe source. Scripts, event handlers, arbitrary styles, iframes and unsafe URLs are not accepted. Server-side validation remains authoritative.

## EN / AR

English remains full LTR. Arabic remains a full RTL mirror with the CMS sidebar on the right; in the visual editor, page tree right, canvas center, inspector left. CMS UI language and public-preview language remain independent.

## Local verification

From a fresh extraction run:

```text
python scripts/verify_all.py
```

A complete pass ends with:

```text
P1_CMS04_BROWSER_PASS
P1_CMS04_LOCAL_VALIDATION_PASS
P1_CMS04R1_OWNER_EDITOR_UX_READY_FOR_OWNER_REVIEW
P1_CMS04R2_FULL_PROFESSIONAL_UI_READY_FOR_OWNER_REVIEW
```

This package does not grant deployment or production authority.
