# iDigitalRoot P1-CMS-02 Full CMS Source v1.4.1 — P1-CMS-03R1 Bounded Defect Repair

This source is the bounded P1-CMS-03 continuation of the exact accepted CMS v1.3 lineage. It preserves the final owner-approved v4.1 frontend for later wiring and closes only the authorized backend/data traceability gaps.

## P1-CMS-03R1 bounded repair in v1.4.1
- Repaired F1 strict design-profile token/value allowlists; no arbitrary CSS-like design input.
- Repaired F2 exact semantic Personal Root / Toolbox / Student Workspace / Major registry keys.
- Repaired F3 external redirect policy with an explicit empty code-owned host allowlist plus BE defense in depth.
- Repaired F4 exact active component code/D1 parity with `rich_text` and `cards` compatibility rows and a retired `retired_legacy` marker.
- Per-target bulk operations; translator-authorized locale editing; controlled locale registry.
- Typed footer, taxonomy-create, locale-aware SEO, redirect, inquiry-definition, publication queue/health, audit-filter, global settings/design, product and service management services.
- Production P1-AN adapter seam with separated aggregate/raw/export/config permissions.
- Core migration `0016_http_redirect_and_final_registry_closure.sql` only; Core `0001`–`0015` and Analytics `0001`–`0002` remain byte-identical to their accepted authorities.

G-10, G-14, G-21, G-22 and G-23 remain explicit future/policy gates. The final v4.1 CMS frontend is not redesigned or implemented here.

## Verification
Run from a fresh extraction:

```text
python scripts/verify_all.py
```

A passing run ends with `CMS_APPROVED_SCOPE_BACKEND_REPAIR_READY_FOR_UI_WIRING`. No deployment, provider-resource mutation, credential entry, paid entitlement change or spend is performed.
