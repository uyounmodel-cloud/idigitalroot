export const SITE_PROFILE={key:'idigitalroot',locales:['en','ar'] as const,defaultLocale:'en',shellDirection:{en:'ltr',ar:'rtl'} as const};
export type ComponentDef={key:string;retired?:boolean;allowedOn:string[];maxChildren:number;maxInstances?:number;validate:(v:Record<string,unknown>)=>boolean};
const text=(v:unknown,max=5000)=>typeof v==='string'&&v.length<=max&&!/<\s*script|javascript\s*:|on[a-z]+\s*=|<\s*iframe|<\s*style|style\s*=/i.test(v);
const href=(v:unknown)=>typeof v==='string'&&(v.startsWith('/')||/^https:\/\/[A-Za-z0-9.-]+(?:\/[^\s]*)?$/.test(v)||/^mailto:[^\s@]+@[^\s@]+$/.test(v));
const scalar=(v:unknown)=>v===null||typeof v==='boolean'||typeof v==='number'||text(v,12000);
function bounded(v:unknown,depth=0):boolean{if(depth>3)return false;if(scalar(v))return true;if(Array.isArray(v))return v.length<=32&&v.every(x=>bounded(x,depth+1));if(v&&typeof v==='object'){const e=Object.entries(v as Record<string,unknown>);return e.length<=48&&e.every(([k,x])=>k.length<=80&&!/css|script|html|iframe|sql|token|secret/i.test(k)&&(!/href|url|link/i.test(k)||x==null||href(x))&&bounded(x,depth+1))}return false}
const obj=(v:Record<string,unknown>)=>bounded(v);
const items=(v:Record<string,unknown>,max=12)=>Array.isArray(v.items)&&v.items.length<=max&&v.items.every(x=>bounded(x));
const PAGE=['PAGE']; const PAGE_KNOWLEDGE=['PAGE','KNOWLEDGE_ARTICLE'];
const defs:ComponentDef[]=[
 {key:'hero',allowedOn:PAGE,maxChildren:0,maxInstances:1,validate:v=>text(v.heading,180)&&(!('body'in v)||text(v.body))},
 {key:'rich_text',allowedOn:PAGE_KNOWLEDGE,maxChildren:0,maxInstances:12,validate:v=>text(v.text,12000)},
 {key:'rich-content',allowedOn:PAGE_KNOWLEDGE,maxChildren:0,maxInstances:12,validate:obj},
 {key:'image',allowedOn:PAGE_KNOWLEDGE,maxChildren:0,maxInstances:24,validate:obj},
 {key:'gallery',allowedOn:PAGE_KNOWLEDGE,maxChildren:0,maxInstances:4,validate:v=>items(v,24)},
 {key:'video-embed',allowedOn:PAGE_KNOWLEDGE,maxChildren:0,maxInstances:8,validate:obj},
 {key:'cards',allowedOn:PAGE,maxChildren:8,maxInstances:8,validate:v=>items(v,12)},
 {key:'cta',allowedOn:PAGE,maxChildren:0,maxInstances:8,validate:v=>text(v.label,120)&&href(v.href)},
 {key:'feature-cards',allowedOn:PAGE,maxChildren:8,maxInstances:4,validate:v=>items(v,12)},
 {key:'audience-cards',allowedOn:PAGE,maxChildren:8,maxInstances:4,validate:v=>items(v,12)},
 {key:'service-cards',allowedOn:PAGE,maxChildren:8,maxInstances:4,validate:v=>items(v,16)},
 {key:'pricing-comparison',allowedOn:PAGE,maxChildren:0,maxInstances:2,validate:obj},
 {key:'faq',allowedOn:PAGE_KNOWLEDGE,maxChildren:20,maxInstances:4,validate:v=>items(v,30)},
 {key:'case-study',allowedOn:PAGE_KNOWLEDGE,maxChildren:0,maxInstances:8,validate:obj},
 {key:'evidence-metric',allowedOn:PAGE_KNOWLEDGE,maxChildren:0,maxInstances:16,validate:obj},
 {key:'process-timeline',allowedOn:PAGE,maxChildren:12,maxInstances:4,validate:v=>items(v,20)},
 {key:'downloadable-resource',allowedOn:PAGE_KNOWLEDGE,maxChildren:0,maxInstances:12,validate:obj},
 {key:'article-research-feed',allowedOn:PAGE,maxChildren:0,maxInstances:4,validate:obj},
 {key:'contact',allowedOn:PAGE,maxChildren:0,maxInstances:2,validate:obj},
 {key:'personal-root-atlas',allowedOn:PAGE,maxChildren:12,maxInstances:2,validate:obj},
 {key:'root-toolbox',allowedOn:PAGE,maxChildren:12,maxInstances:2,validate:obj},
 {key:'student-workspace',allowedOn:PAGE,maxChildren:8,maxInstances:2,validate:obj},
 {key:'major-explorer',allowedOn:PAGE,maxChildren:8,maxInstances:2,validate:obj},
 {key:'root-convergence',allowedOn:PAGE,maxChildren:8,maxInstances:2,validate:obj},
 {key:'illustrative-people-stories',allowedOn:PAGE,maxChildren:8,maxInstances:8,validate:obj},
 {key:'brand-manifesto',allowedOn:PAGE,maxChildren:0,maxInstances:2,validate:obj},
 {key:'managed-services',allowedOn:PAGE,maxChildren:8,maxInstances:2,validate:obj},
 {key:'knowledge-preview',allowedOn:PAGE,maxChildren:0,maxInstances:4,validate:obj},
 {key:'final-cta',allowedOn:PAGE,maxChildren:0,maxInstances:1,validate:obj},
 {key:'footer',allowedOn:['FOOTER','PAGE'],maxChildren:12,maxInstances:1,validate:obj},
 // Existing iDigitalRoot v4.3 families retained and validated through bounded non-executable payloads.
 ...['student-problem','student-foundation','story','human-stories','three-experiences','roots','toolbox','student-benefits','my-dream','major-personalization','project-to-career','human-built','knowledge','not-student','proof','signature-ticker'].map(key=>({key,allowedOn:PAGE,maxChildren:12,maxInstances:4,validate:obj} as ComponentDef)),
 {key:'retired_legacy',retired:true,allowedOn:[],maxChildren:0,maxInstances:0,validate:()=>false}
];
export const COMPONENTS:Record<string,ComponentDef>=Object.fromEntries(defs.map(d=>[d.key,d]));
export const ANALYTICS_REPORTS={
 overview:{rawAllowed:true,dimensions:['locale_code','route_id']},content_routes:{rawAllowed:true,dimensions:['route_id','entity_id','section_instance_id','component_key','locale_code']},acquisition:{rawAllowed:false,dimensions:['referrer_class','referrer_host','utm_source','utm_medium','utm_campaign','locale_code']},audience_technology:{rawAllowed:true,dimensions:['browser_class','os_class','device_class','language_class','viewport_class']},coarse_geography:{rawAllowed:true,dimensions:['country_code','continent_code']},engagement_custom:{rawAllowed:true,dimensions:['component_key','section_instance_id','route_id']},internal_search:{rawAllowed:false,dimensions:['route_id','locale_code']},inquiry_funnel:{rawAllowed:true,dimensions:['route_id','locale_code']},performance_web_vitals:{rawAllowed:true,dimensions:['route_id','device_class']},public_runtime_health:{rawAllowed:false,dimensions:['route_id']},bot_abuse:{rawAllowed:false,dimensions:['bot_class','country_code']}
} as const;

export const SITE_PROFILE_RECORDS={
 personalRoots:['personal-root-website','personal-root-portfolio','personal-root-cv','personal-root-digital-card','personal-root-qr-codes','personal-root-links','personal-root-achievements','personal-root-contact','personal-root-health'],
 rootToolbox:['root-toolbox-cv-studio','root-toolbox-portfolio-builder','root-toolbox-digital-card','root-toolbox-qr-studio','root-toolbox-link-hub','root-toolbox-achievement-kit','root-toolbox-career-kit','root-toolbox-email-signature','root-toolbox-project-share','root-toolbox-personal-brand-kit','root-toolbox-contact-card','root-toolbox-root-export'],
 studentWorkspace:['student-workspace-university-life','student-workspace-my-future','student-workspace-personal-growth'],
 majors:['major-architecture-design','major-computer-science-engineering','major-medicine-health-sciences','major-business-law-humanities','major-other']
} as const;
export const GLOBAL_PUBLIC_COPY_KEYS=['site-brand-contact-social','site-design-profile'] as const;
export const NON_SECRET_RUNTIME_KEYS=new Set(['public.inquiry.enabled','public.knowledge.enabled','public.search.enabled']);
export const FONT_FAMILY_IDS=new Set(['idr-latin-ui','idr-latin-serif','idr-arabic-ui','idr-arabic-kufi','idr-arabic-naskh']);
export const DESIGN_FONT_ROLE_IDS={
 latinUi:new Set(['idr-latin-ui']),
 latinAccent:new Set(['idr-latin-serif']),
 arabicUi:new Set(['idr-arabic-ui']),
 arabicDisplay:new Set(['idr-arabic-kufi']),
 arabicEditorial:new Set(['idr-arabic-naskh'])
} as const;
export const DESIGN_FALLBACK_STACK_IDS=new Set(['system-ui-tahoma-arial']);
export const DESIGN_FONT_WEIGHTS=new Set([400,500,600,700,800,900]);
export const DESIGN_BODY_SIZE_PRESETS=new Set<unknown>([16,17,18,'16px','17px','18px','comfortable','large','extra-readable']);
export const DESIGN_LINE_HEIGHT_PRESETS=new Set<unknown>([1.6,1.7,'1.6','1.7']);
export const DESIGN_HEADING_SCALE_PRESETS=new Set(['signature-large','balanced','Signature large','Balanced']);
export const DESIGN_NAV_SIZE_PRESETS=new Set<unknown>([15,16,'15px','16px']);
export const EXTERNAL_REDIRECT_HOSTS=new Set<string>();
