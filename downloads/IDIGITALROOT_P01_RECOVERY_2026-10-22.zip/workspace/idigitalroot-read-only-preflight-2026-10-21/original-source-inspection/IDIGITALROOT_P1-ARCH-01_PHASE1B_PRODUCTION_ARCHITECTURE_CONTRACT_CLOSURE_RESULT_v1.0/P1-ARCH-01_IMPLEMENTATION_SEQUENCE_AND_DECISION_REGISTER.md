# P1-ARCH-01 — Implementation Sequence and Decision Register

**Purpose:** define the remaining Phase 1B dependency order after architecture closure.  
**Important:** this task does not execute these implementation tasks.

## 1. Dependency rules

The sequence is designed around four rules:

1. **The approved v4.3 UI and this architecture contract are the shared upstream contract.** The CMS does not wait for frontend code to invent its content model, and frontend does not wait for CMS screens to define its components.
2. **Physical data and authentication are independent foundations.** They may proceed in parallel after this closure.
3. **Frontend visual conversion can proceed against frozen typed fixtures.** It must not require live D1/CMS availability to prove parity.
4. **Integration follows stable contracts, then security/QA, then authorized staging/production release.** No production deployment is implied by task completion.

## 2. Exact remaining Phase 1B dependency sequence

### Gate 0 — P1-ARCH-01 (this task)
Deliverables freeze:
- logical topology and boundaries;
- content/component ownership;
- localization/media/publishing semantics;
- inquiry/security/auth semantics;
- environment/release model;
- downstream dependency rules.

No downstream task may reinterpret the approved v4.3 UI as permission to redesign it.

### Wave 1 — may run in parallel after HQ accepts this closure

#### P1-DATA-01 — Physical D1 data model and migration contract
Depends on: **P1-ARCH-01 only**.

Must freeze physical representations for:
- content/section/localized records;
- version/publication pointers/history;
- media metadata/state references;
- inquiry/Lead + idempotency/security metadata;
- CMS control/audit data required by P1-AUTH-01;
- non-secret runtime configuration where D1-backed;
- indexes/constraints/retention support/migrations.

Must not depend on frontend implementation details beyond the content contract already frozen here.

#### P1-AUTH-01 — Dedicated Public CMS identity/session/authorization contract
Depends on: **P1-ARCH-01 only**.

Must freeze:
- identity provider/mechanism;
- stable actor mapping;
- MFA policy/mechanism for privileged roles;
- session lifecycle/revocation/CSRF;
- permission model and role bundles;
- protected auth/audit events;
- CMS origin/cross-origin security decisions.

It may reference logical identity/audit requirements from this closure; P1-DATA-01 and P1-AUTH-01 reconcile their physical persistence through a bounded interface, not by waiting cyclically on each other. If one needs a storage adjustment, the change is resolved at the data-contract boundary before either is accepted.

#### P1-FE-01 — Astro/TypeScript v4.3 presentation conversion
Depends on: **P1-ARCH-01 only**.

Must:
- convert approved v4.3 presentation into Astro/TypeScript;
- preserve route intent, component families, visual direction and interaction/a11y behavior;
- use typed fixture content matching this contract;
- keep React islands optional and justified;
- preserve EN/AR LTR/RTL and reduced-motion behavior;
- contain no production CMS/API dependency yet.

This task proves frontend parity independently of backend availability.

### Wave 2 — foundation implementations

#### P1-BE-01 — Public content + inquiry Worker service implementation (proposed Phase 1B task)
Depends on: **P1-DATA-01** and this architecture; inquiry public path does not depend on CMS auth.

Implements:
- published-content read semantics;
- public inquiry validation/idempotency/Lead persistence;
- safe errors/rate/abuse boundaries;
- no active route claims beyond actually implemented service endpoints.

#### P1-CMS-01 — Dedicated Public Website CMS foundation
Depends on: **P1-DATA-01 + P1-AUTH-01 + P1-ARCH-01**.

Implements:
- dedicated authenticated CMS application shell;
- content tree/registered section editing;
- localization state/editor;
- navigation/footer/SEO editing;
- history visibility and permission-aware workflows;
- no executable arbitrary source editing.

It consumes the component contract frozen by P1-ARCH-01, so it does not need P1-FE-01 to define content families.

#### P1-FE-02 — Published content/localization/media binding
Depends on: **P1-FE-01 + P1-DATA-01 + P1-BE-01**.

Implements:
- replace fixtures with published-read contract;
- published route/locale resolution;
- SEO/canonical/hreflang binding;
- approved media delivery;
- safe missing/fallback states;
- cache/revision behavior.

P1-FE-02 does not need CMS UI completion; it integrates against the published service contract.

### Wave 3 — editorial publication/media + live inquiry integration

#### P1-CMS-02 — Media, preview, publish/version/schedule/rollback workflows (proposed)
Depends on: **P1-CMS-01 + P1-DATA-01 + P1-AUTH-01**.

Implements:
- R2 quarantine/validation/finalization;
- provider/embed registry and sanitizer policy;
- preview capabilities;
- permission-aware publish/unpublish/schedule/rollback;
- audit-visible publication history.

#### P1-FE-03 — Production interaction and Phase 1B integration closure
Depends on: **P1-FE-02 + P1-BE-01 + P1-CMS-02**.

Implements/integrates:
- live eight-step inquiry submission and truthful receipt;
- production validation/error/a11y behavior;
- public content refresh/version behavior;
- preview compatibility needed for editorial QA;
- final route/link/inquiry/client-login truth boundaries.

Client Login remains non-functional unless a genuine separately authorized Phase 3 portal exists; P1-FE-03 must not fabricate one.

### Wave 4 — independent verification and release preparation

#### P1-SEC-01 — Phase 1B security/negative authorization verification (proposed)
Depends on: **P1-AUTH-01 + P1-BE-01 + P1-CMS-02 + P1-FE-03**.

Tests authz denial, CSRF/session protections, sanitizer/CSP, media quarantine, preview isolation, inquiry abuse/idempotency, safe errors, audit and secret/log hygiene.

#### P1-QA-01 — Full Phase 1B integrated QA (proposed)
Depends on: all implemented Phase 1B surfaces above.

Tests EN/AR, RTL/LTR, responsive behavior, accessibility, route parity, CMS editorial flows, publication/version/rollback, media, inquiry, performance and negative cases against the immutable candidate.

#### P1-REL-01 — Immutable staging release candidate (proposed)
Depends on: **P1-SEC-01 + P1-QA-01 PASS** and closed production-launch policy gates.

Produces no-Git ZIP/SHA evidence, manifests, deployment/rollback instructions, configuration declaration and staging candidate. Staging mutation/deploy requires the appropriate separate authorization.

#### Production release
Depends on: verified staging + explicit production release approval. It is not part of P1-ARCH-01.

## 3. Dependency graph — no circularity

```text
P1-ARCH-01
 ├─ P1-DATA-01 ─┬─ P1-BE-01 ──────────────┐
 │              ├─ P1-CMS-01 ─ P1-CMS-02 ─┼─ P1-FE-03 ─┬─ P1-SEC-01 ─┐
 │              │                           │            └─ P1-QA-01 ──┼─ P1-REL-01
 │              └───────────────────────────┘                            │
 ├─ P1-AUTH-01 ────────┴─ P1-CMS-01/P1-CMS-02 ─────────────────────────┘
 └─ P1-FE-01 ─ P1-FE-02 ───────────────────┘
```

Clarification: P1-DATA-01 and P1-AUTH-01 may be developed in parallel from the same logical contract. Acceptance of either cannot rely on an undefined circular handoff; their shared persistence interface is reconciled before final acceptance of both.

## 4. Phase exclusions carried through sequence

- Phase 2 Staff Admin is not a prerequisite for the Public CMS.
- Phase 3 Client Portal is not a prerequisite for `/client-login` truthful public content.
- Phase 4 per-client Website CMS is not a prerequisite for Public Website or Public CMS.
- Business product implementation is not mixed into Personal/Student Phase 1B.
- No mandatory paid AI API is introduced.

## 5. Decision register

Statuses are restricted to the output-contract vocabulary.

| ID | Decision | Status | Basis / reconciliation | Downstream consequence |
|---|---|---|---|---|
| D-ARCH-001 | Personal iDigitalRoot is current product; Student Edition is first commercial audience. | CLOSED_FROM_AUTHORITY | Owner/current-state and product model; v4.3 | All FE/CMS content scoped accordingly. |
| D-ARCH-002 | Business is separate and must not be merged into current Personal/Student content tree. | CLOSED_FROM_AUTHORITY | Current state/conflict resolution | Legacy solution routes cannot activate Business product. |
| D-ARCH-003 | Exact v4.3 SHA is presentation/content authority; architecture may not redesign it. | CLOSED_FROM_AUTHORITY | P1-GATE-01 owner approval | FE-01 parity target pinned. |
| D-ARCH-004 | Public Website CMS is a dedicated Phase 1 application. | CLOSED_FROM_AUTHORITY | Phase 1 brief/HQ state | P1-CMS-01 is separate from Phase 2 Admin. |
| D-ARCH-005 | Future Admin integration is access/control integration, never a duplicate Public CMS. | CLOSED_FROM_AUTHORITY | Phase 1 brief | Phase 2 consumes CMS seam. |
| D-ARCH-006 | Astro + TypeScript; React islands only when justified. | CLOSED_FROM_AUTHORITY | HQ state/Phase 1 brief/master handoff | FE tasks use Astro baseline. |
| D-ARCH-007 | Cloudflare Workers/D1/R2 is the Phase 1B runtime/data baseline. | CLOSED_FROM_AUTHORITY | HQ state/Phase 1 brief/master handoff | Data/API/media tasks stay on baseline. |
| D-ARCH-008 | Owner release workflow is no-Git immutable ZIP/SHA-256 evidence with retained rollback artifacts. | CLOSED_FROM_AUTHORITY | HQ state/master handoff | P1-REL-01 cannot depend on Git history. |
| D-ARCH-009 | Historical Stage 9C/schema/API work is evidence, not live production proof. | CLOSED_FROM_AUTHORITY | HQ evidence limits/current state | DATA/API tasks must freeze/implement exact current contracts. |
| D-ARCH-010 | Dedicated CMS edits registered content/config only; ordinary editorial work needs no source edits. | RECONCILED | Phase 1 CMS brief + prior full-solution requirements + v4.3 markers | Typed section registry. |
| D-ARCH-011 | Public, CMS, public-content Worker, inquiry Worker and privileged CMS Worker have explicit trust boundaries. | RECONCILED | Current stack + security authority | Separate service responsibilities; no direct browser D1. |
| D-ARCH-012 | D1 owns relational records; R2 owns object bytes; public browser has neither privileged binding. | RECONCILED | Stack + technical authorities | P1-DATA-01/R2 design. |
| D-ARCH-013 | Current v4.3 route intent supersedes the older 58-screen broad-product assumption. | RECONCILED | v4.3 `renderRoute` + conflict handling | Compatibility routes cannot resurrect out-of-scope product lines. |
| D-ARCH-014 | v4.3 CMS section families are stable registered content families; component/layout behavior remains code-owned. | RECONCILED | v4.3 `data-cms-section`/`data-cms-block` evidence | CMS schema maps fields, not arbitrary components. |
| D-ARCH-015 | EN/AR use a locale registry with independent translation/publication state and native LTR/RTL behavior. | CLOSED_FROM_AUTHORITY | localization extension + v4.3 | DATA/CMS/FE locale model. |
| D-ARCH-016 | Translation states are MISSING, DRAFT, NEEDS_REVIEW, READY, PUBLISHED, OUTDATED, ARCHIVED. | CLOSED_FROM_AUTHORITY | localization extension §5 | CMS workflow/state constraints. |
| D-ARCH-017 | Production fonts are self-hosted appropriately licensed WOFF2 assets; no mandatory external Google Fonts dependency. | RECONCILED | acceptance requirement + v4.3 production font note | FE/release must include license/version evidence. |
| D-ARCH-018 | Rich content is sanitized; arbitrary scripts/event handlers/dangerous URLs are forbidden. | CLOSED_FROM_AUTHORITY | Phase 1 brief + localization/rich media extension | Sanitizer/CSP security tests. |
| D-ARCH-019 | Embeds use approved provider registry aligned with CSP; provider changes are privileged/audited. | CLOSED_FROM_AUTHORITY | rich media extension §§7–8 | CMS/media implementation. |
| D-ARCH-020 | Media enters private quarantine and is ineligible for publication until validated/approved. | RECONCILED | Phase 1 brief/media requirements | R2 state model and QA negative tests. |
| D-ARCH-021 | Publishing retains drafts, preview, permission checks, history, schedule where enabled, rollback and audit. | CLOSED_FROM_AUTHORITY | Phase 1 brief + localization extension §9 | CMS-02/publish data model. |
| D-ARCH-022 | Rollback republishes a retained valid revision and preserves history; it does not rewrite history. | RECONCILED | versioning authority + immutable release discipline | DATA/CMS transaction design. |
| D-ARCH-023 | CMS identity uses stable IDs, least privilege, protected revocable sessions and MFA for privileged publishing/admin roles. | RECONCILED | developer blueprint/master handoff/security requirements | P1-AUTH-01 provider-specific closure. |
| D-ARCH-024 | Exact CMS identity provider/MFA implementation is downstream, provided it satisfies D-ARCH-023. | PROPOSED_EXTENSION_REQUIRES_LATER_IMPLEMENTATION | Provider not frozen in package | P1-AUTH-01. |
| D-ARCH-025 | Public inquiry remains eight steps, human-reviewed Lead intake, no public signup. | CLOSED_FROM_AUTHORITY | Lead Inquiry v1.1 + Phase 1 brief + v4.3 | P1-BE-01 and FE-03. |
| D-ARCH-026 | Same stable Lead record family is written in Phase 1 and consumed/extended by Phase 2. | CLOSED_FROM_AUTHORITY | Phase 1 brief + Lead extension | No duplicate Lead system. |
| D-ARCH-027 | Current v4.3 Step 7 requires name/email; university/country/phone/contact method are optional in the current UI contract. | RECONCILED | Later approved v4.3 supersedes older policy-open field optionality | DATA/BE validation matches approved current UI. |
| D-ARCH-028 | Inquiry submit, publish/rollback and other duplicate-sensitive operations use idempotency. | CLOSED_FROM_AUTHORITY | Lead extension + backend reliability requirements | DATA/API idempotency records. |
| D-ARCH-029 | No arbitrary public inquiry file upload in Phase 1B. | CLOSED_FROM_AUTHORITY | Lead Inquiry v1.1 | R2 public upload path absent. |
| D-ARCH-030 | Client Login is not a working portal until Phase 3 genuinely exists. | CLOSED_FROM_AUTHORITY | Phase 1 brief + v4.3 | FE route remains truthful/unavailable. |
| D-ARCH-031 | Dev, staging/preview and production use isolated resources/secrets. | RECONCILED | master/full-solution environment requirements | Deployment bindings separated. |
| D-ARCH-032 | Preview uses read-only time-bounded revision/locale/environment scope and is non-indexable. | PROPOSED_EXTENSION_REQUIRES_LATER_IMPLEMENTATION | Required preview isolation; exact mechanism not frozen | CMS-02/FE preview implementation. |
| D-ARCH-033 | Exact HTTP API paths/version prefix are not declared active by architecture. | RECONCILED | Historical candidate APIs not production proof | API task chooses paths preserving semantics. |
| D-ARCH-034 | Exact Cloudflare resource names, hostnames and bucket/database identifiers are deployment configuration, not content contracts. | PROPOSED_EXTENSION_REQUIRES_LATER_IMPLEMENTATION | No live infra state verified | P1-REL/deploy tasks. |
| D-ARCH-035 | Exact numeric Lead/security/media retention durations and legal bases must be approved before production go-live. | OPEN_NEEDS_HQ_DECISION | Lead Inquiry v1.1 §37 explicitly defers final schedule | DATA must support policy; release gate remains open. |
| D-ARCH-036 | Final Terms/Privacy/Cookies copy and legal approval are content/go-live gates, not architecture inventions. | OPEN_NEEDS_HQ_DECISION | Phase 1 brief says legal content once reviewed/approved | CMS can version it; production publish waits approval. |
| D-ARCH-037 | Root terminology is reconciled as managed Digital Root foundation + Personal Root public layer + Toolbox + private Student Workspace. | RECONCILED | current product model + later v4.3 hierarchy | Prevents old terminology ambiguity from becoming schema duplication. |
| D-ARCH-038 | Root Check may be informational only; a live scanner needs separately validated/authorized backend capability. | RECONCILED | v4.3 disclaimers/current no-backend evidence | No unsupported scanner in Phase 1B. |
| D-ARCH-039 | No promises of jobs, scholarships, search ranking/traffic, AI recommendations or guaranteed outcomes. | CLOSED_FROM_AUTHORITY | product rules + v4.3 QA claims inspection | Content validation/QA. |

## 6. Open items — bounded, not inflated

Only these owner/HQ/legal decisions remain open at architecture level:

1. **D-ARCH-035 — retention/legal-basis schedule.** Required before production go-live; physical data design must support category-specific retention now.
2. **D-ARCH-036 — final legal copy/approval.** CMS/versioning can be implemented without inventing final legal text; production publication waits approval.

Provider choice, API path names, resource names and preview-token implementation are **downstream technical implementation choices**, not owner-policy gaps and not reasons to reopen the architecture.

## 7. Completion condition for next HQ gate

HQ may accept this architecture closure when:
- all eight architecture output files + checksum manifest are internally consistent;
- all 29 P1-ARCH-01 acceptance tests are PASS;
- the two bounded open production-policy items above are preserved as later go-live gates rather than invented values;
- no document claims implementation, deployment, or owner approval of this architecture.
