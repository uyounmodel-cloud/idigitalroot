# P1-ARCH-01 — Phase 1B Production Architecture

**Task:** Production architecture / contract closure only  
**Architecture state:** Candidate for HQ review; not implemented, deployed, or owner-approved  
**Presentation authority:** `iDigitalRoot_Personal_Student_Public_Website_UI_v4.3_A11Y_Personal_Menu_Repair.html`  
**Pinned SHA-256:** `d10b1cff47d5912fecb49d88579971f3e21bb19a33b179e29356ea0eac5646fd`

## 1. Authority and scope

Phase 1B implements the current **Personal iDigitalRoot** public product with **Student Edition as the first commercial audience**. Business remains a separate future product. The approved v4.3 artifact is the immutable presentation/content direction for Phase 1B: production implementation may translate its behavior into Astro/TypeScript and CMS-backed data, but may not redesign its information hierarchy, student-first narrative, route intent, component families, bilingual composition, or interaction meaning without a later approved UI change.

Current authorities reconcile the historical record as follows:

- Astro + TypeScript is the public-site baseline; React islands are permitted only for interaction that is materially simpler/safer as an island.
- Cloudflare Workers, D1, and R2 are the runtime/data baseline.
- The Phase 1 Public Website CMS is a **dedicated application**, not a module inside the future Staff Admin.
- The owner workflow is **no Git**: immutable release ZIPs, SHA-256 evidence, release manifests, and retained rollback artifacts are the release authority.
- Historical Stage 9C/API/schema material is design evidence only. It does not prove a live schema, API, or deployment.
- Phase 2 Staff Admin, Phase 3 Client Portal, and Phase 4 per-client Website CMS are not implemented in this phase. Only their integration seams are defined.

Governing sources: `01_OWNER_GATE/HQ_CURRENT_STATE_PHASE1B.md` (Frozen product/technology boundaries), `03_GOVERNING_AUTHORITY/PHASE1_PUBLIC_WEBSITE_AND_CMS_IMPLEMENTATION_BRIEF.md`, `04_TECHNICAL_AUTHORITY/IDIGITALROOT_MASTER_HANDOFF_2026-09-23_v1.0.md`, and the approved v4.3 UI.

## 2. Deployable logical topology

### 2.1 Public request plane

1. **Public Website — Astro/TypeScript**
   - Serves production HTML, CSS, images, SEO metadata, structured public information, and the approved interactive presentation.
   - Defaults to static/server-rendered output at the Cloudflare edge; JavaScript is limited to approved interactive behavior.
   - Reads only **published** content through the Public Content Worker contract or build-time publication snapshot. It never reads draft CMS data directly.
   - Has no D1 or R2 browser credentials. Browsers never receive storage/database bindings.

2. **Public Content Worker**
   - Read-only application boundary for the current published route/locale revision.
   - Resolves stable route/content IDs to the active published revision and approved media references.
   - Applies cache keys containing environment, locale, route/content ID, and publication revision.
   - Never exposes draft, archived, internal audit, CMS identity, session, or Lead fields.

3. **Inquiry Intake Worker**
   - The only unauthenticated write boundary in Phase 1B.
   - Accepts the approved eight-step inquiry as one human-reviewed Lead intake record family.
   - Performs server validation, normalization, abuse/rate controls, idempotency, privacy/consent checks, and safe error handling before persistence.
   - Does not create a user/client account and does not expose Lead status publicly.
   - Does not accept arbitrary files in v1.

### 2.2 Editorial/control plane

4. **Dedicated Public Website CMS — Astro/TypeScript application**
   - Separate application/origin from the public site.
   - No public self-registration and no anonymous editorial surface.
   - Authenticated editors manage supported content, locales, media, preview, publishing, scheduling where enabled, version history, rollback, and audit-visible actions.
   - The CMS consumes the frozen component/content contract; it does not become a free-form site builder.

5. **CMS Worker/API**
   - Sole privileged write boundary for content, translation, media metadata, publication, versioning, and CMS permission-aware operations.
   - Enforces authentication and authorization server-side on every privileged operation.
   - Enforces optimistic concurrency/version preconditions for mutable records.
   - Owns content sanitation and publication validation, not the browser.

6. **Preview boundary**
   - Draft preview is never made globally public merely because a draft exists.
   - CMS-authenticated preview uses an opaque, time-bounded preview capability bound to environment + content revision + locale. A preview capability grants read-only access to exactly the referenced draft revision(s), not general CMS access.
   - Search indexing is disabled for preview surfaces; preview responses use restrictive caching.

### 2.3 Data plane

7. **D1 — relational authoritative records**
   - Logical data domains: public content/configuration; localized variants; content revisions/publication pointers; CMS identity/role/session metadata where selected by P1-AUTH-01; audit events; inquiry/Lead records and intake security metadata.
   - P1-DATA-01 freezes the physical tables, keys, constraints, and migrations. This architecture intentionally does **not** pretend historical candidate schemas are live.
   - Stable IDs are system identifiers. Display labels/slugs are not authorization keys.

8. **R2 — object/media storage**
   - Stores original uploaded media, quarantine objects, validated/approved derivatives, and immutable release/rollback evidence where the release process elects to persist it in R2.
   - Draft or quarantined objects are private. Public delivery is allowed only for approved/published media through a controlled public URL or Worker delivery boundary.
   - Object keys are opaque/stable and not derived solely from editable filenames.

9. **Secrets and non-secret runtime configuration**
   - Secrets are Cloudflare environment secrets/bindings and never CMS content, browser state, D1 editable settings, source ZIPs, or logs.
   - Non-secret runtime configuration may be versioned in D1 or deployment configuration: enabled locales, provider allowlists, feature/capability flags, public base URLs, safe limits, and content-registry versions.

## 3. Logical resource separation

Each environment has independent Cloudflare resources and secrets. Production data is never used as a development datastore.

| Resource family | Development | Staging / preview | Production |
|---|---|---|---|
| Public Website deployment | isolated dev | isolated staging | isolated production |
| Dedicated Public CMS deployment | isolated dev | isolated staging | isolated production |
| Public Content Worker | dev binding | staging binding | prod binding |
| Inquiry Intake Worker | dev intake | staging intake | prod intake |
| CMS Worker/API | dev privileged | staging privileged | prod privileged |
| D1 | non-production DB(s) | staging DB(s) | production DB(s) |
| R2 | non-production namespace/bucket(s) | staging namespace/bucket(s) | production namespace/bucket(s) |
| Secrets | dev only | staging only | prod only |
| Preview capabilities | dev scope | staging scope | production-authorized scope only |

Exact account IDs, hostnames, database names, bucket names, and bindings are deployment configuration to be frozen later; the **separation requirement is closed here**.

## 4. Request and data flows

### 4.1 Published page read

`Browser → Public Website → published content snapshot/Public Content Worker → D1 publication pointer → approved R2 media`

Rules:
- public response sees one immutable published revision per route + locale;
- no draft fallback to the public site;
- locale fallback is explicit and observable, never accidental field mixing;
- cache invalidation is revision-based after successful publish/rollback;
- publication metadata may be public only when explicitly part of the page model.

### 4.2 CMS editorial flow

`Authenticated CMS user → CMS UI → CMS Worker → validate/authz/concurrency → D1 draft revision → audit`

A draft is append/version oriented. Editing ordinary copy, media references, navigation labels, supported section order/visibility, SEO, inquiry help text, and translation state must not require source-code changes.

### 4.3 Media flow

`Authenticated CMS user → CMS Worker preflight → private R2 quarantine → validation/scanning/metadata → approved media state → eligible for content revision → publish → public delivery`

No object becomes publicly addressable merely because upload succeeded. See the dedicated localization/media/publishing contract for validation details.

### 4.4 Publish flow

`CMS publisher → validate content/locale/media/references → permission check → immutable publication revision → atomic active publication pointer switch → audit → cache revision change`

Rollback is a **new publication event that points to a previously retained valid revision**. It never deletes history or rewrites a prior audit event.

### 4.5 Public inquiry flow

`Visitor → eight-step UI → Inquiry Intake Worker → validate/normalize/rate/idempotency → D1 Lead record + intake metadata → success receipt`

A successful response means the Lead was durably accepted. A retry with the same idempotency key returns the same accepted result rather than creating a duplicate. The public response may expose a non-sensitive reference but never internal status, notes, scores, or staff identity.

## 5. Trust boundaries

| Boundary | Trust rule |
|---|---|
| Browser → Public Website | All client input untrusted. Public pages contain no privileged credentials. |
| Browser → Inquiry Worker | Unauthenticated and adversarial by default; strict schema, lengths, URL protocol, rate/body limits, bot controls and idempotency. |
| Browser → CMS UI | UI possession is not authority. Every privileged action is re-authorized by the CMS Worker. |
| CMS Worker → D1/R2 | Least-privilege Cloudflare bindings; server-side validation before writes. |
| Public Website → content data | Published read model only; no draft/editor/session/Lead access. |
| Preview capability | Read-only, short-lived, environment/revision/locale scoped; no privilege escalation. |
| Future Admin → Public CMS | Integration seam only; future Admin may launch/control access through the CMS contract, never duplicate content tables/editor logic. |
| Future Client Portal | No Phase 1 session/auth coupling. The `/client-login` page is informational/unavailable until Phase 3 genuinely exists. |

## 6. Astro/TypeScript and interaction model

- Astro is the default for page shells, routing, content rendering, metadata, and component composition.
- TypeScript defines frozen content/view models and compile-time registry contracts.
- Prefer framework-free/client-light interaction for menu, FAQ, locale/theme, simple filters/tabs, and accessible disclosure behavior.
- React islands are allowed only for bounded stateful interactions where they materially improve maintainability/testability; an island may not own global routing, publication truth, authentication truth, or security validation.
- Production output must preserve v4.3 accessibility behavior: skip link, valid ARIA relationships, keyboard reachability, visible focus, reduced-motion handling, mobile/desktop navigation behavior, and EN/AR directionality.

## 7. Content versioning and public consistency

Every publishable record uses:
- stable record ID;
- locale identity;
- monotonic or unique revision ID;
- workflow state;
- created/updated actor and time;
- concurrency token/version;
- publication event/pointer;
- schema/content-registry version;
- referenced media IDs and dependency validation result.

The public site consumes a coherent revision set. Publication must fail closed when a required reference, translation rule, media approval, route constraint, or component schema is invalid.

## 8. Security architecture floor

The Phase 1B floor is mandatory, even if exact provider/mechanism details are completed by P1-AUTH-01/P1-DATA-01:

- stable CMS identity IDs; no authorization by display name/email label alone;
- least-privilege role/permission checks on the Worker;
- MFA required for privileged publishing/administrative CMS roles;
- Secure + HttpOnly session cookies, appropriate SameSite policy, session rotation, revocation, inactivity/absolute expiry, CSRF protection where cookie-authenticated state changes occur;
- security headers including CSP aligned to the approved embed registry; no arbitrary inline/external scripts from CMS content;
- input validation, output encoding, sanitized rich content, safe URL protocols, bounded payloads;
- rate limiting/abuse controls on public writes and sensitive auth actions;
- audit of authentication/security events and privileged content/publish/media actions;
- logs redact or minimize personal/free-text inquiry data and secrets;
- secrets never stored as content;
- deny-by-default CORS and cross-origin trust;
- media quarantine/validation before publication eligibility.

## 9. Environment and release topology

### Development
Local/isolated Cloudflare development resources; synthetic/fictional data by default. No production secrets or production D1/R2 bindings.

### Staging / preview
Production-like isolated Workers, D1, R2 and CMS/public deployments. Used for integration, accessibility, security, locale, media, publishing, rollback, and negative-case tests. Preview content remains non-indexable and separate from production publication truth.

### Production
Only a separately approved immutable release may be promoted. Infrastructure mutation/deploy remains outside this task.

### No-Git owner release contract
Each releasable unit must preserve:
1. immutable release ZIP;
2. release manifest with release/task identity;
3. SHA-256 manifest covering every shipped file;
4. test/evidence report;
5. environment/config compatibility declaration with no secrets;
6. previous known-good release reference and rollback instructions/evidence;
7. deploy approval record when deployment is later authorized.

Rollback means redeploying a retained known-good immutable artifact and/or switching content publication to a retained valid revision. Neither rollback path requires a Git history.

## 10. Future seams without scope leakage

### Phase 2 Staff Admin seam
- The future Admin may display Lead records from the **same Phase 1 inquiry record family** and may provide a governed entry/SSO/deep-link into the dedicated Public CMS.
- It must not create a second public-content database, second editor, or divergent publishing model.
- Staff operational Lead statuses, qualification, conversion, proposals and client creation belong to Phase 2.

### Phase 3 Client Portal seam
- Phase 1 keeps `/client-login` as a truthful public boundary page.
- No Phase 1 public visitor is converted into a Client Portal account.
- Future Portal identity/session/token contracts are separate from CMS editorial identity unless a later architecture explicitly unifies them.

### Phase 4 per-client Website CMS seam
- The iDigitalRoot public-site CMS is not the template for or runtime of client website CMSs.
- Shared principles (localization, safe media, versioning) may be reused later, but data and operational boundaries remain independent.

## 11. Explicit non-goals

This closure does not:
- write production Astro/Worker code;
- freeze physical D1 tables/migrations;
- declare HTTP route paths as already active APIs;
- choose/deploy a production identity provider;
- deploy or mutate Cloudflare resources;
- implement Staff Admin, Client Portal, or client Website CMS;
- implement public self-signup;
- implement arbitrary public file upload;
- promise jobs, internships, scholarships, search rankings, traffic, AI recommendations, or business outcomes;
- turn Root Check into a live scanner without a separately validated/authorized backend capability.

## 12. Architecture closure statement

The logical production architecture, ownership boundaries, security boundaries, data flows, environment separation, publication model, inquiry intake seam, and no-Git release topology are sufficiently closed to start the remaining Phase 1B implementation tasks in the dependency order defined by `P1-ARCH-01_IMPLEMENTATION_SEQUENCE_AND_DECISION_REGISTER.md`. Physical schema, exact API route names, identity-provider wiring, Cloudflare resource names, and deployment operations remain bounded downstream implementation decisions rather than architecture gaps.
