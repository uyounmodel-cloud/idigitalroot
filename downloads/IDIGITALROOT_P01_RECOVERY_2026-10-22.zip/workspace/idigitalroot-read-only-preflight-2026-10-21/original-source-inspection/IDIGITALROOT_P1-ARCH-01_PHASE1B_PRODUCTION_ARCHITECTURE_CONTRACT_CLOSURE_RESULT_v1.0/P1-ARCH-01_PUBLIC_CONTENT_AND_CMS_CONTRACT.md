# P1-ARCH-01 — Public Content and Dedicated CMS Contract

**Authority:** approved v4.3 UI/content direction is preserved, not redesigned.  
**Purpose:** freeze the content/component ownership model required before physical D1 schema and application implementation.

## 1. Production content model principle

The production Public Website is a **typed composition system**, not a free-form page builder and not a hardcoded collection of English/Arabic source files. The dedicated Public CMS edits validated content records that feed a fixed code-owned route/component registry.

Three ownership classes are mandatory:

1. **CMS-editable** — ordinary editorial/public configuration that authorized users may change without source code.
2. **Code-owned** — application behavior, component schemas, security rules, route handlers, validation, layout structure, design tokens, functional flows, and registered variants.
3. **System-controlled** — IDs, revision/audit data, publication pointers, security state, integrity hashes, timestamps, actor IDs, session/security metadata.

A field is not CMS-editable merely because it is visible in the UI.

## 2. Current Phase 1 public product surface

### 2.1 Primary Personal/Student routes

These are the current v4.3 product-family routes and must retain their approved intent:

| Route | Content family | Production meaning |
|---|---|---|
| `/` | Student-first Personal homepage | Primary approved story and conversion surface |
| `/personal` | Personal overview | Personal Root public identity layer |
| `/students` | Student Edition | First commercial audience presentation |
| `/student/toolbox` | Root Toolbox | Twelve creation/sharing tool concepts |
| `/student/workspace` | Student Workspace | Three private-planning concept views; marketing/demo presentation only on public site |
| `/student/majors` | Explore by Major | Presentation personalization; entitlement/tools remain the same |
| `/not-a-student` | Personal non-student inquiry door | Human-reviewed path for other individual journeys |

Business is **not** merged into this current product family.

### 2.2 Supporting public routes

The current production contract supports the v4.3 supporting families without reviving historical broad-audience assumptions:

- `/why-idigitalroot`
- `/what-you-get`
- `/services` and approved `/services/{slug}` records such as the website service
- `/how-we-build`
- `/knowledge` and approved `/knowledge/{slug}` articles/categories
- `/company/about`
- `/company/trust`
- `/contact`
- `/pricing` as inquiry/scope-oriented content, not invented fixed pricing
- `/legal/terms`, `/legal/privacy`, `/legal/cookies` after content/legal approval
- `/search`
- `/inquiry` plus the eight wizard steps and `/inquiry/received`
- `/client-login` as a truthful future/existing-client boundary page, not a working Phase 3 portal

`/root-check` may preserve an informational/concept surface only. A live scan/backend is capability-gated and is not authorized by this architecture.

### 2.3 Compatibility/legacy route behavior

The v4.3 implementation explicitly prevents historical broad-scope routes from becoming current products. Production must preserve that intent:

- `/solutions` and `/solutions/personal` resolve to current Personal content.
- `/solutions/students` resolves to Student Edition.
- other historical `/solutions/*` paths must not expose an active Business/industry product; they may redirect to the current non-student inquiry path or a controlled not-current response.
- `/blueprints` and historical blueprint paths must not resurrect a broad production blueprint marketplace; current approved presentation may direct to Explore by Major or a controlled informational equivalent.

Compatibility routes are code-owned routing policy, not independently CMS-publishable product trees.

## 3. Approved homepage section contract

The approved v4.3 source exposes these CMS section identifiers. Their visual composition is code-owned; their supported content is editable as defined below.

| CMS section ID | Approved purpose | CMS-editable content | Code/system-owned behavior |
|---|---|---|---|
| `hero` | Student-first Personal promise and CTAs | localized kicker, heading, lead, approved CTA labels/destinations, approved micro-proof labels | hero composition, orbit/node design, CTA slot count/variant |
| `student-problem` | scattered digital-presence problem | localized heading/lead and approved scatter labels | before/after scene behavior, geometry, connector logic |
| `student-foundation` | managed Digital Root foundation | localized copy; approved foundation node labels/descriptions | node interaction, registered node IDs, safety claims policy |
| `story` | Personal story journey | localized heading/lead and five story-step texts | five-step composition/order constraints unless registry allows reorder |
| `human-stories` | illustrative student stories | localized story copy and approved illustration alt text | illustration/component family; no fabricated client claim conversion |
| `three-experiences` | foundation + Personal Root + Toolbox + Workspace hierarchy | localized copy/labels | hierarchy semantics and three-layer component structure |
| `roots` | Personal Root atlas | localized root labels/descriptions | registered root IDs and public/private semantics |
| `toolbox` | 12 Root Toolbox items | localized tool names/descriptions/module labels | exactly registered tool IDs; tool functionality is not created by copy |
| `student-workspace` | three private workspace concept families | localized marketing descriptions and example labels | privacy-by-default meaning, three registered views, demo/non-live distinction |
| `student-benefits` | managed service benefits | localized service marketing copy/status labels from approved service records | service IDs, plan-dependent disclaimers, interaction logic |
| `my-dream` | goal-oriented story | localized headings/goals/CTA copy | goal IDs and no-outcome-guarantee policy |
| `major-personalization` | presentation by major | localized major display copy, approved evidence/examples | major IDs; same Toolbox entitlement principle; interaction behavior |
| `project-to-career` | project-to-career story | localized copy/list items | no job/internship/scholarship guarantee semantics |
| `human-built` | human-led delivery process | localized process copy | process sequence structure and claim controls |
| `knowledge` | Knowledge preview | selected published article references and localized intro | card component, article eligibility/query rules |
| `not-student` | non-student inquiry door | localized copy/CTA | Personal-only scope and human-reviewed inquiry destination |
| `proof` | trust/accountability | localized evidence-safe copy | no invented badges/certifications/performance claims |
| `faq` | public FAQ | localized questions/answers, order/visibility | accordion behavior/accessibility |
| `final-cta` | final conversion | localized copy/approved CTA labels | destination constraints, component variant |
| `footer` | public navigation/legal/brand close | localized groups/labels/approved route refs/legal links | component structure, route-reference validation |

Approved v4.3 also contains CMS-marked visual/story blocks such as `signature-ticker`, `illustrative-people-stories`, and `brand-manifesto`. These are registered blocks: copy/alt text may be editable where specified, but animation/illustration/source behavior is code-owned.

## 4. Stable product/content families

### 4.1 Personal Root records

Stable product IDs represented by v4.3:
- Website
- Portfolio
- CV
- Digital Card
- QR Codes
- Links
- Achievements
- Contact
- Root Health

CMS may edit localized names/descriptions/public marketing text. Code/system controls stable IDs, eligibility, any future functional implementation, and privacy/security behavior.

### 4.2 Managed Digital Root foundation/service records

Approved presentation families include:
- professionally built website;
- own domain when included;
- professional email when included;
- search & AI technical readiness with **no ranking/recommendation guarantee**;
- protection & monitoring by approved scope;
- connected public links/social destinations;
- room to grow through separately approved upgrades.

CMS may edit evidence-safe localized copy and plan-dependent explanatory text. It may not change technical service state or promise unsupported outcomes.

### 4.3 Root Toolbox records

The current v4.3 toolbox registry contains twelve stable presentation IDs:
1. CV Studio
2. Portfolio Builder
3. Digital Card
4. QR Studio
5. Link Hub
6. Achievement Kit
7. Career Kit
8. Email Signature
9. Project Share
10. Personal Brand Kit
11. Contact Card
12. Root Export

Ordinary editorial copy is CMS-controlled. Tool execution/business logic is code/product controlled and is not implied to exist merely because the marketing item is published.

### 4.4 Student Workspace records

Three stable top-level families:
- **University Life:** My Semester, Study Planner, Exam Countdown, Project Desk, Study Timer, Goals.
- **My Future:** Application Tracker, Career Kit, Cover Letter Guide, Skills Passport, Career Roadmap.
- **Personal Growth:** Learning Log, Experience Journal, Research Shelf, Campus Calendar, Student Budget.

The public website presents these as product concepts/examples. It must keep the distinction that private workspace data is private by default and becomes public only through an intentional later product action. The public CMS edits marketing/demo content, not real student private data.

### 4.5 Major-presentation records

Current approved presentation directions:
- Architecture & Design
- Computer Science & Engineering
- Medicine & Health Sciences
- Business, Law & Humanities
- Every Other Major

The record may hold localized title, headline, description, evidence/example list, and approved presentation marker. It may not remove core Toolbox entitlement or create different contractual product rights by major unless a future owner-approved product decision does so.

### 4.6 Knowledge records

CMS-managed Knowledge content includes:
- article stable ID/slug policy;
- category/kind;
- EN/AR title, summary and body;
- media/alt/caption/credit;
- author/byline only when truthful;
- publication/translation state;
- SEO/public structured information;
- related content references.

No case-study outcome, research result, client quote, certification, visitor metric, ranking, or numerical claim may be invented to fill an empty CMS field.

## 5. Page composition contract

A Page is a stable route record plus an ordered list of **registered section instances**. Each section instance contains:
- stable instance ID;
- registered component-family ID;
- schema version;
- locale-aware content reference(s);
- registered visual/content variant where allowed;
- visibility state;
- order position;
- approved media/reference IDs;
- optional safe configuration from an allowlisted field schema.

CMS operations may, for supported page families:
- edit fields;
- choose from registered variants;
- reorder where the page contract marks reorderable;
- show/hide optional sections;
- add another instance only where multiplicity allows;
- select published Knowledge/media records;
- preview before publish.

CMS operations may **not**:
- insert arbitrary component names;
- paste JavaScript/CSS into section configuration;
- create arbitrary route handlers;
- bypass mandatory legal/security/inquiry sections;
- change application data access;
- convert a marketing/demo block into a live account/tool feature.

## 6. Navigation and route-reference contract

Navigation/footer entries are CMS-editable only as validated references to:
- an approved internal route ID;
- an approved external URL with safe protocol/policy;
- an approved CTA action type.

The route itself remains code/registry controlled. A CMS editor cannot activate an out-of-scope Business product merely by creating a label/URL. Broken internal references fail publication validation.

The approved Personal grouped navigation must preserve the current family:
- Personal overview
- Student Edition
- Root Toolbox
- Student Workspace
- Explore by Major
- Not a student?

## 7. Inquiry content ownership

CMS-editable:
- localized step headings/subheadings/help text;
- approved option labels where option IDs are already registered;
- contextual entry CTA labels/source attribution labels;
- confirmation explanatory copy within approved policy;
- privacy/help links.

Code/system controlled:
- eight-step order/IDs for current contract;
- protected field IDs and server validation schema;
- mandatory name/email validation and current UI optionality choices unless a separately approved change occurs;
- idempotency/security fields;
- stable Lead ID/public reference generation;
- no-self-signup rule;
- no-credentials warning/security rules;
- no arbitrary file upload;
- protected/internal Lead fields;
- successful-persistence condition for receipt.

CMS cannot disable mandatory backend validation, expose internal IDs/notes, or publish an inquiry schema that fails contract validation.

## 8. CMS-editable field classes

### Allowed ordinary editorial classes
- plain localized text;
- constrained rich text;
- localized metadata/SEO copy;
- media references and accessibility text;
- approved internal/external links;
- registered section order/visibility/variant;
- Knowledge categories/articles;
- service/product marketing labels/descriptions;
- FAQ and approved legal content;
- navigation/footer;
- translation workflow state;
- schedule/publication metadata where permitted.

### Conditional/privileged classes
- generic trusted embed configuration;
- provider registry changes;
- legal-policy publication;
- route slug/canonical changes;
- redirects;
- high-impact global navigation changes;
- publish/rollback/schedule actions;
- feature/capability flags.

These require stronger permission and audit policy.

## 9. Code-owned/system-controlled field classes

Code-owned:
- component implementation and layout;
- CSS/design tokens and responsive behavior;
- animation/accessibility behavior;
- registered component schemas/variant enums;
- security headers/CSP generation rules;
- allowed embed field schema and sanitizer configuration;
- application routes/handlers;
- auth/authz logic;
- inquiry validation/security rules;
- data-access logic;
- error semantics;
- D1 migrations and R2 binding rules.

System-controlled:
- IDs and foreign/reference keys;
- revision/schema versions;
- content hashes;
- created/updated/published/rolled-back timestamps;
- actor IDs;
- audit events;
- active publication pointers;
- quarantine/scanner/validation states;
- Lead security metadata;
- session/revocation state;
- idempotency records.

## 10. Rich content rule

Rich content is **content**, not application source. The CMS may provide WYSIWYG and source-HTML views only over a sanitizer-controlled content subset. Publication rejects:
- `<script>`;
- inline event handlers;
- `javascript:` URLs;
- unapproved iframe/provider sources;
- unapproved external scripts/styles;
- unsafe SVG/HTML constructs;
- unsupported custom elements that could execute code.

A novel interactive component, new functional block, new route behavior, or new executable integration requires an immutable code release, not a CMS paste.

## 11. SEO/public structured information ownership

CMS may edit validated public SEO fields:
- locale title/description;
- canonical route selection where policy allows;
- social share title/description/image;
- index/noindex within allowed route policy;
- approved structured public information fields.

Code controls generated schema shape, escaping, allowed types, canonical/hreflang consistency and route constraints. Editors cannot paste arbitrary executable JSON/HTML that bypasses validation.

## 12. Publication validity gates

A content revision cannot publish when any mandatory condition fails, including:
- unknown component/variant/schema version;
- invalid internal route reference;
- required locale field missing for that locale publication;
- media not in an approved state;
- unsanitized/unsafe rich content;
- prohibited embed/provider;
- invalid SEO/canonical configuration;
- inquiry configuration inconsistent with protected backend schema;
- missing required legal/privacy link for a flow that requires it;
- stale concurrency token or superseded revision;
- actor lacks publish permission.

## 13. Contract boundary with P1-DATA-01

This document freezes logical entities and ownership, but **not** final table names, columns, indexes, migration files, or database count. P1-DATA-01 must implement a physical relational design that preserves:
- stable IDs;
- locale variants;
- version history;
- atomic publication pointer semantics;
- media references/states;
- inquiry/Lead stability;
- CMS identity/permission/audit requirements;
- optimistic concurrency;
- no cross-phase duplication.
