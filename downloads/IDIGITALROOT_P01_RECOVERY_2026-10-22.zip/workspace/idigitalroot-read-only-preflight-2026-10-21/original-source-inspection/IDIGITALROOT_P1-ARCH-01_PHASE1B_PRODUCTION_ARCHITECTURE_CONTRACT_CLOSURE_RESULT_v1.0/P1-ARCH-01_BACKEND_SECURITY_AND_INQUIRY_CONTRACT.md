# P1-ARCH-01 — Backend, Security and Inquiry Contract

**Purpose:** close Phase 1B service, API, authentication/security and public inquiry semantics before physical schema/API implementation.

## 1. Backend principles

1. Browsers never receive D1/R2 credentials or Cloudflare privileged bindings.
2. Every write crosses a Worker boundary with server-side validation.
3. CMS authorization is enforced by the server on every privileged operation; hiding a UI control is not authorization.
4. Public content reads expose only published, public-safe records.
5. Historical candidate endpoint lists are not active APIs. P1-DATA-01/P1-AUTH-01 and later API implementation tasks may choose exact paths after preserving this semantic contract.
6. All externally supplied data is untrusted, including CMS rich text, URLs, filenames, embed configuration and query parameters.
7. Failure is deny/fail-closed where security, publication integrity, version concurrency or record ownership is uncertain.

## 2. Service contract families

The following are semantic service families, not claims that these HTTP routes already exist.

### 2.1 Public published-content service

Operations:
- get published page/route for a requested locale;
- get public navigation/footer configuration;
- get published Knowledge index/article records;
- resolve approved public media metadata/delivery reference;
- get public locale availability.

Rules:
- no drafts or internal workflow fields;
- only active published revision pointers;
- safe caching by revision;
- safe not-found/unavailable behavior;
- no arbitrary SQL/filter expression supplied by the client.

### 2.2 Inquiry intake service

Operation:
- accept one completed current inquiry payload and create/reuse exactly one stable Lead intake record according to idempotency semantics.

Rules:
- public unauthenticated write surface;
- strict schema and payload/body limits;
- validation/normalization on Worker;
- idempotency required;
- rate/abuse/bot controls;
- no file upload;
- no account creation;
- no public Lead-status API;
- successful receipt only after durable acceptance.

### 2.3 CMS content service

Operations:
- create/update draft content revisions;
- read draft/history according to permission;
- manage locale variants/translation states;
- manage registered page sections and validated configuration;
- manage navigation/footer/SEO/public structured information;
- manage Knowledge/public marketing records;
- perform optimistic-concurrency guarded edits.

### 2.4 CMS media service

Operations:
- upload preflight;
- quarantine object association;
- media metadata edit;
- validation/scanning status;
- approved derivative/finalization;
- safe deletion/archive only when dependency and retention checks permit.

### 2.5 CMS publishing service

Operations:
- preview capability issue/revoke;
- publish locale/revision;
- schedule/cancel schedule where supported;
- unpublish/archive where policy permits;
- rollback by republishing a retained valid revision;
- inspect history/audit according to permission.

## 3. API contract requirements

### Validation
- Request shape validated against an explicit versioned TypeScript/server schema.
- Lengths, enumerations, nested counts, URL protocols, locale codes, IDs and state transitions are bounded.
- Server validation is authoritative even if the frontend already validated.
- Unknown privileged fields are rejected or ignored according to explicit endpoint policy; mass assignment is forbidden.

### Authentication and authorization
- Public published reads require no CMS identity.
- Inquiry submission requires no account but is abuse-controlled.
- CMS operations require a valid CMS session/identity.
- Every privileged operation checks a specific permission/resource/action combination.
- Permission checks use stable IDs and server-side resource context, never visible role labels.

### Locale and version concurrency
- Locale is explicit in mutable localized-content operations.
- Every mutable record carries a concurrency token/version; stale writes return a conflict rather than silently overwriting newer content.
- Publish/rollback specifies the exact revision/locale being acted upon.
- Source-content changes may mark translations `OUTDATED` without overwriting translations.

### Idempotency
Mandatory where duplicate execution would create harmful duplicates or ambiguous state:
- inquiry final submission;
- publish/rollback action;
- schedule creation/cancellation where supported;
- media finalization;
- any later externally retried create operation with business significance.

An idempotency key is scoped to operation + actor/public client context + environment. Reuse with a materially different payload fails safely.

### Safe errors
Public errors reveal:
- stable error category/code;
- localized safe user message where applicable;
- correlation/reference ID.

They do not reveal:
- SQL/internal query details;
- stack traces;
- secrets;
- auth policy internals;
- private Lead existence/status;
- filesystem/bucket/database identifiers.

### Audit expectations
Privileged create/update/publish/rollback/permission/media-provider/config actions record:
- actor stable ID;
- action type;
- target stable ID/type;
- before/after revision identifiers or summarized change reference;
- timestamp;
- environment;
- outcome;
- correlation ID;
- security-relevant context minimized to what is necessary.

Audit history is append-oriented and protected from ordinary editors.

## 4. CMS identity/authentication boundary

### 4.1 Identity

Each CMS actor has a stable identity ID independent of email/display name. The exact identity provider/protocol is frozen in P1-AUTH-01, but it must map authenticated principals to the same stable authorization/audit identity model.

No public CMS registration is permitted.

### 4.2 Minimum role/permission model

Implementation may group permissions into roles, but server authorization is action-based. Required capability families include:
- read content/drafts;
- edit content;
- edit translations;
- manage media;
- preview drafts;
- publish/unpublish;
- schedule/cancel publication;
- rollback;
- edit privileged provider/embed/global configuration;
- view audit/history;
- manage CMS identities/roles where the selected auth design permits.

A person may hold multiple grants. Root/global administrative privileges must be rare, explicit and auditable.

### 4.3 Session floor

Cookie-authenticated CMS sessions must use:
- HTTPS only;
- `Secure` and `HttpOnly` session cookie;
- explicit appropriate `SameSite` policy;
- session ID/token rotation after authentication and privilege-sensitive events;
- inactivity and absolute expiry;
- server-side revocation/disable path;
- CSRF protection for state-changing cookie-authenticated requests;
- no session token in URLs;
- no long-lived browser storage of privileged bearer credentials by default.

Privileged publishing/administrative roles require MFA. Failed auth, lock/revocation, MFA and privileged session events are security-audited with safe redaction.

### 4.4 Authorization invariants

- `is_admin` as a single authorization strategy is prohibited.
- Email domains, display names, CMS route access, or client-side role flags are not sufficient authority.
- A publisher who cannot manage identities cannot grant themselves new permissions.
- A media editor cannot change CSP/provider allowlists unless separately permitted.
- A translator cannot publish unless explicitly granted publish permission.

## 5. Public inquiry — exact Phase 1B journey

The public inquiry is one **human-reviewed Lead intake**, not onboarding and not signup. The approved v4.3 journey is eight steps:

1. **About You** — `about-you`
2. **What You Need** — `what-you-need`
3. **Goals** — `your-goals`
4. **Current Digital Presence** — `current-presence`
5. **Main Website Requirements** — `main-requirements`
6. **Additional Information** — `additional-information`
7. **Contact Details** — `contact-details`
8. **Review & Submit** — `review`

The current approved presentation then reaches `/inquiry/received` only after successful production acceptance. The standalone v4.3 artifact deliberately fakes no submission; production must replace that preview-only behavior with the service contract above.

## 6. Inquiry field contract

### Step 1 — About You
Registered current options include student, recent graduate, preparing for university, personal project outside university, and not sure. CMS may localize display labels; option IDs are protected.

### Step 2 — What You Need
Registered current direction options include first personal website, stronger portfolio, professional presence, centralized projects/CV/links, refresh existing personal website, or guidance first.

### Step 3 — Goals
Multi-select current goal IDs include presenting work, internship preparation, first-job preparation, application/scholarship material preparation, professional identity, centralizing presence, and private personal-growth organization.

These are **preparation goals**, not promises that iDigitalRoot will obtain a job, internship, scholarship, ranking, or recommendation.

### Step 4 — Current Digital Presence
Current fields:
- existing personal website URL (optional);
- existing domain (optional);
- professional-email state (optional/selection);
- public profile/portfolio links (optional).

Security:
- `http`/`https` only where URL fields are expected;
- never request passwords, tokens or private credentials;
- normalize whitespace/Unicode and bound lengths.

### Step 5 — Main Website Requirements
Current fields:
- preferred languages;
- presentation focus;
- desired supported features/share outputs;
- timing/opportunity context.

Free text is plain/sanitized text; it cannot introduce executable fields or alter protected backend requirements.

### Step 6 — Additional Information
Optional bounded plain text. No raw HTML execution. Logs must not copy this text unnecessarily.

### Step 7 — Contact Details
Current owner-approved UI requires:
- name — required;
- email — required;

Current UI presents these as optional/non-required fields:
- university/institution;
- country;
- phone;
- preferred contact method.

This reconciles the earlier v1.1 statement that phone/country optionality depended on final policy: the later approved v4.3 presentation chooses optionality for current Phase 1B. A later sales-policy change is a separately approved content/contract change.

Email and phone are contact data, not account credentials. Submission does not create a client/user identity.

### Step 8 — Review & Submit
- shows the visitor a review of entered data;
- allows back/edit;
- final action is **Submit Inquiry**, never **Create Account**;
- server revalidates the complete payload;
- successful response occurs only after durable Lead acceptance;
- receipt wording describes human review/contact, not automated acceptance as a client.

## 7. Stable Lead record family

Phase 1B creates one stable Lead family designed for Phase 2 consumption. Logical groups:

### Identity/contact
- stable internal Lead ID;
- optional public-safe inquiry reference;
- name/email and optional contact fields;
- preferred locale/contact method where supplied.

### Inquiry context
- wizard schema/version;
- visitor type/request/goals;
- current digital presence;
- requested languages/focus/features/timing;
- additional information;
- source/contextual CTA attribution.

### Intake/security metadata
- received timestamp;
- locale;
- idempotency record/key hash or equivalent;
- rate/abuse decision metadata;
- privacy/consent versions where applicable;
- minimized network/user-agent metadata only when justified by security/privacy policy.

### Future operational fields
Phase 2 may add/own qualification, assignment, notes, proposal/agreement, conversion and operational status history. Phase 1 must not build a duplicate Lead system and must not delete the original inquiry on conversion.

## 8. Inquiry validation and abuse controls

Mandatory controls:
- strict content type and body-size limit;
- per-field max lengths and enum validation;
- server-side email syntax normalization/validation appropriate to inquiry use;
- safe URL protocol validation;
- plain text/sanitization and output encoding;
- parameterized D1 operations;
- rate limits by appropriate privacy-preserving signals;
- bot/automation challenge or heuristic capability where required by observed abuse, without making paid APIs mandatory by default;
- idempotent final submission;
- CSRF protection when browser/session architecture makes it applicable;
- generic response semantics that do not expose internal Lead existence/state;
- redacted/minimized logging.

No arbitrary file upload exists in the current flow.

## 9. Inquiry idempotency contract

Before final submit, the client obtains or generates an opaque submission attempt identifier according to the implementation contract. Server processing:

1. normalize and hash/canonicalize the protected payload for comparison;
2. atomically reserve/check the idempotency key;
3. if the same key + same accepted payload already succeeded, return the original safe receipt/reference;
4. if same key is reused with a materially different payload, return a safe conflict;
5. if the first attempt is still processing, return a retry-safe state rather than creating a second Lead;
6. only one durable Lead ID is linked to a successful key.

Exact storage/TTL is finalized by P1-DATA-01, consistent with privacy/retention policy.

## 10. Client Login truth boundary

Phase 1B may publish `/client-login` because it is part of the approved public UI. It may not:
- authenticate a client unless the Phase 3 portal genuinely exists;
- create a client account;
- present a fake dashboard/session;
- imply that inquiry submission grants access.

Until Phase 3, production copy must clearly state that client access is unavailable/not connected or link only to a separately verified existing implementation if one is later approved.

## 11. Rich content, embeds and CSP security

CMS content must not execute arbitrary code. Required controls:
- sanitizer allowlist for supported rich HTML;
- remove scripts, event-handler attributes, dangerous URL schemes and unsupported active content;
- generic embeds represented as structured provider records, not pasted executable HTML whenever possible;
- provider registry includes allowed hostname/pattern, embed mode, iframe attributes, sandbox policy, referrer policy, privacy/autoplay controls and active state;
- CSP generated/configured to match approved provider registry and application assets;
- changing provider/CSP policy is privileged and audited;
- no arbitrary external JavaScript from editorial content.

## 12. Safe media boundary

All CMS uploads enter private quarantine. Validation before approval includes as appropriate:
- authenticated/authorized uploader;
- maximum size;
- declared and detected MIME/type consistency;
- extension/content mismatch detection;
- dimension/format validation;
- filename normalization/ignore original filename for object key authority;
- metadata stripping where privacy requires;
- malware/security scanning or equivalent validation for applicable formats;
- image/document transformation only in controlled processors;
- explicit approved/rejected state.

Quarantined/rejected objects are not public and cannot satisfy a publish dependency.

## 13. Retention/privacy architecture

The system must support separate retention policies for at least:
- spam/abuse submissions;
- rejected leads;
- no-response leads;
- qualified leads;
- converted leads;
- communication history when later added;
- security/idempotency metadata;
- CMS sessions/security events;
- audit records;
- rejected/quarantined media.

**Open HQ/legal decision:** exact numeric retention durations, legal bases/processors and deletion exceptions are not present in the package. This is a production-launch policy gate, not a reason to invent durations in this architecture. P1-DATA-01 must make retention implementable; go-live requires the policy to be approved.

## 14. Logging/observability constraints

Logs may contain correlation IDs, safe operation types, status codes, timing and minimized security signals. By default they must not contain:
- passwords/secrets/session tokens;
- full inquiry free-text;
- unnecessary full email/phone;
- raw authorization headers;
- full sanitized/unsanitized content bodies;
- signed preview/media capabilities.

Observability does not change the record-of-truth ownership defined in D1/R2.

## 15. Deferred implementation choices that are not architecture gaps

To be completed by downstream tasks:
- exact auth/identity provider and MFA mechanism (`P1-AUTH-01`);
- physical D1 schemas/indexes/migrations and idempotency storage (`P1-DATA-01`);
- exact HTTP route naming/version prefixing;
- exact rate-limit thresholds and challenge mechanism after security testing;
- exact Cloudflare resource names/bindings;
- exact media scanning/transformation implementation.

Each must conform to this contract and may not silently weaken it.
