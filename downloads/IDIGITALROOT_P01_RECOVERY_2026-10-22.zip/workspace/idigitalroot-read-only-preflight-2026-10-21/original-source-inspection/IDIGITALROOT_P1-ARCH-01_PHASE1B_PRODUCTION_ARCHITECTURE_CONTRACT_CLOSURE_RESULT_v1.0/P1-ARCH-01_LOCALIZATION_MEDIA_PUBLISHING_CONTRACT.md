# P1-ARCH-01 — Localization, Media and Publishing Contract

**Launch languages:** English (LTR) and Arabic (RTL).  
**Architecture principle:** locale, media and publication are first-class versioned data; they are not hardcoded source forks.

## 1. Locale registry

The content system must use a locale registry rather than separate English/Arabic applications. Each locale has at least:
- stable locale code;
- display/native name;
- direction (`ltr` or `rtl`);
- enabled/disabled state by supported surface;
- optional fallback locale;
- formatting configuration where required;
- publication eligibility state.

Phase 1B launches with `en` LTR and `ar` RTL. The architecture remains capable of later approved locales without rebuilding the content model.

## 2. Localization ownership

Localized content applies to:
- route/page titles and descriptions;
- navigation/footer labels;
- headings/body/CTA/FAQ;
- Personal/Student product records;
- Toolbox/Workspace/Major presentation records;
- services/commercial explanatory copy;
- Knowledge content;
- inquiry steps/options/help/errors/receipt text;
- media alt/caption/credit where language-specific;
- SEO title/description/social metadata;
- structured public information fields that contain human language;
- legal content when approved.

Stable IDs, permission keys, component IDs and backend state enums are not translated identifiers.

## 3. Translation lifecycle

The architecture adopts the established translation states:

- `MISSING`
- `DRAFT`
- `NEEDS_REVIEW`
- `READY`
- `PUBLISHED`
- `OUTDATED`
- `ARCHIVED`

Rules:
- source-locale changes may mark related translations `OUTDATED` without discarding the existing translation;
- a locale may be published independently only if the page/route contract permits and all required localized dependencies pass validation;
- translation state is visible in the CMS;
- fallback is explicit. It must never silently mix arbitrary English and Arabic fields inside a single Arabic component;
- public responses identify the actually rendered locale;
- archived translation history is retained according to version/retention policy.

## 4. Arabic RTL / English LTR production behavior

The approved v4.3 artifact already demonstrates a native Arabic composition model rather than mirroring glyphs. Production must preserve:
- `lang` and `dir` set correctly at the document/root level;
- RTL-aware component layout and alignment;
- logical CSS properties where possible;
- icons/glyphs not blindly mirrored when semantic direction must remain unchanged;
- Arabic typography/line-height/letter-spacing appropriate to Arabic;
- correct focus order and keyboard navigation independent of visual direction;
- RTL-safe forms, menus, tabs, CTA rows, breadcrumbs, cards, footer and route-cover layouts;
- EN/AR responsive behavior without horizontal overflow;
- language switch preserving the equivalent route/content context when available.

Locale switching is presentation state, not authentication or authorization state.

## 5. Font contract and self-hosting

The approved v4.3 review artifact uses external Google Fonts in the standalone prototype and explicitly states that production should self-host appropriately licensed WOFF2 assets after approval. Therefore Phase 1B production must:

1. preserve the approved typographic intent/family hierarchy;
2. source only fonts with verified production licensing;
3. self-host approved WOFF2 assets within the controlled public asset/CDN boundary;
4. preload only the minimum critical subsets/weights supported by measured performance evidence;
5. include robust system fallbacks for English and Arabic;
6. avoid runtime dependence on Google Fonts or another mandatory third-party font CDN;
7. record font source/license/version in release evidence.

The package does not include production font binaries. Font acquisition/licensing verification is a downstream implementation task, not permission to alter the approved visual direction.

## 6. Locale preview and publication

The CMS provides:
- side-by-side or clearly comparable source/target editing;
- locale-specific preview;
- visible translation state/completeness;
- route/component preview in correct LTR/RTL direction;
- history per localized revision;
- permission-aware publish by locale;
- detection of `OUTDATED` translation state after relevant source changes.

A preview is not publication. Preview URLs/capabilities are time-bounded, non-indexable and scoped to exact revision(s)/locale/environment.

## 7. Media record contract

Each media asset uses a stable media ID separate from filename/object key. Metadata supports, as applicable:
- media kind/type;
- original filename for display only;
- detected MIME/type;
- width/height/duration or relevant technical dimensions;
- checksum/integrity value where useful;
- source/origin class;
- quarantine/validation/approval state;
- R2 object references/derivatives;
- localized title;
- localized alt text;
- localized caption;
- credit/license/source attribution;
- usage/dependency references;
- created/updated actor/time;
- retention/deletion status.

## 8. Media source classes

Supported architecture classes from current authority:

### Local CMS uploads
- authenticated only;
- private quarantine first;
- validation before approval;
- public eligibility only after approval and content publication.

### Approved external media/embed providers
Architecture supports provider-registry-based content such as:
- YouTube;
- Vimeo;
- public/shared Google Drive link/preview patterns where technically safe and policy-compliant;
- other explicitly approved providers;
- generic trusted iframe/oEmbed only under privileged allowlist policy.

A normal provider URL should be transformed into a controlled responsive embed definition rather than storing arbitrary HTML as the primary record.

Private OAuth-connected provider content is a separate future integration and is not implied by public/shared-link support.

## 9. Embed provider registry

Each provider definition includes at least:
- stable provider ID;
- enabled state;
- allowed hostname(s)/URL pattern(s);
- canonicalization/extraction rules;
- allowed iframe attributes/features;
- sandbox policy;
- referrer policy;
- autoplay/privacy parameters;
- responsive aspect-ratio behavior;
- CSP requirements;
- permission needed to create/use provider;
- audit/version metadata.

Provider registry changes are privileged and audited. Editorial users cannot extend CSP by pasting a new hostname into rich text.

## 10. Rich content sanitization

The CMS may expose WYSIWYG and constrained source HTML for content authors. The server sanitizes on write and/or publish using a versioned policy. Forbidden unless specifically structured/approved:
- scripts;
- event-handler attributes;
- dangerous URL schemes;
- arbitrary styles that can break layout/security policy;
- external script/style imports;
- unapproved iframes/objects/embeds;
- unsafe SVG active content;
- forms that bypass the registered inquiry/contact flows.

Sanitizer policy version is associated with content revision or publication validation so older content can be revalidated after policy upgrades.

## 11. Media quarantine and validation

Upload success does not equal approval. State progression is conceptually:

`UPLOADED_PRIVATE → VALIDATING → APPROVED` or `REJECTED/QUARANTINED`

Required checks are format-dependent and include:
- size limits;
- detected type vs declared type;
- extension mismatch;
- dimensions/duration limits;
- corrupt/malformed object checks;
- metadata/privacy review where applicable;
- malware/security scanning or equivalent for applicable formats;
- safe derivative generation;
- checksum/integrity tracking;
- explicit approval state.

Only approved media may satisfy a publish dependency. A rejected/quarantined object cannot be made public by manually constructing its R2 URL.

## 12. Publishing workflow states

Editorial workflow supports the established states/meanings:
- Draft
- Needs Review
- Scheduled (where scheduling is enabled)
- Published
- Unpublished
- Archived

Translation lifecycle states remain separate but coordinated with publication eligibility.

A content record may have multiple retained revisions while only one revision per route/locale is the current published pointer.

## 13. Draft and review

- Every edit produces or updates a controlled draft revision according to the physical model frozen by P1-DATA-01.
- Editors can save without changing the public site.
- Reviewer/publisher can compare relevant revision information before publish.
- Concurrency conflicts fail rather than silently overwrite another editor.
- Permission checks happen server-side.
- Required references/media/locale fields are validated before approval/publish.

## 14. Preview

Preview must render the production Astro component contract against the exact draft revision/locale while preventing public leakage:
- authenticated CMS preview or opaque short-lived read-only preview capability;
- environment bound;
- exact revision/locale bound;
- noindex/no public sitemap;
- restrictive caching;
- revocable/expiring;
- cannot perform CMS writes.

Preview must show the real RTL/LTR composition, responsive component variants and approved media status. Quarantined media may be previewed only to authorized CMS users through a protected path, never through a public URL.

## 15. Publish transaction

A publication request includes the intended revision and locale. Server steps:
1. authenticate and authorize actor;
2. verify concurrency/precondition;
3. validate component schema/version;
4. validate route/navigation/reference integrity;
5. validate localized required fields and translation state;
6. validate rich content/sanitizer policy;
7. validate media/embed eligibility and CSP compatibility;
8. validate protected inquiry configuration where relevant;
9. create immutable publication event/revision reference;
10. atomically switch the active publication pointer;
11. record audit event;
12. trigger revision-based cache refresh/invalidation behavior.

If any required step fails, the previous published revision remains active.

## 16. Scheduled publishing

Scheduling is supported **where enabled by implementation** and must use the same validation/permission model as immediate publish.

A schedule record contains:
- target content/route + locale;
- exact revision;
- scheduled instant in canonical UTC;
- creator/actor;
- status;
- idempotency/concurrency protection;
- execution outcome/audit reference.

At execution time the system revalidates security-critical dependencies. If the revision/media/provider is no longer valid, publication fails closed and the previous published revision remains.

Exact Cloudflare scheduling mechanism is a downstream deployment choice; architecture semantics are closed here.

## 17. Rollback

Rollback is permission-controlled and audited. It:
- selects a retained previously valid revision;
- revalidates current safety/schema/provider/media constraints;
- creates a new publication event pointing to that retained revision/content snapshot;
- atomically changes the active pointer;
- preserves all intervening history.

Rollback is never implemented by deleting newer revisions or rewriting audit history.

## 18. Unpublish and archive

- Unpublish removes a current public pointer according to route policy but retains history.
- Mandatory system routes may use a safe fallback rather than becoming undefined.
- Archive means the content is no longer offered for ordinary editing/public selection, while history/retention obligations remain.
- Legal content removal must obey legal/policy approval and cannot be casually deleted by a normal editor.

## 19. Publication permissions

At minimum, permissions distinguish:
- edit draft;
- translate/review translation;
- manage media;
- preview;
- publish/unpublish;
- schedule/cancel;
- rollback;
- manage provider/embed registry;
- manage high-impact global configuration.

The CMS UI may simplify these into roles, but server authorization remains permission/resource based.

## 20. Audit requirements

Audit records are required for:
- publish/unpublish/rollback/schedule/cancel;
- provider allowlist/CSP-affecting changes;
- media approval/rejection/deletion actions;
- privileged global navigation/route configuration changes;
- translation state/publication transitions;
- permission-sensitive identity/session/config changes.

Audit uses stable actor and target IDs and is protected from ordinary editorial alteration.

## 21. Public cache/version contract

Public cache keys and revalidation must incorporate publication identity so draft writes never evict/replace public truth accidentally. After publish/rollback:
- the active published revision becomes the only public default;
- stale responses may be purged/revalidated by revision-aware mechanism;
- cache failure must not expose draft content;
- the current revision can be included in diagnostic headers only when safe and useful.

## 22. Accessibility and localization publication gate

Before production publication of a material content/config change, validation/testing must cover as relevant:
- EN LTR and AR RTL rendering;
- missing/outdated translation visibility to editors;
- alt text requirements for meaningful images;
- heading/link/form semantics;
- focus/keyboard behavior when content affects interactive labels/order;
- no horizontal overflow at supported responsive ranges;
- reduced-motion-safe behavior;
- valid internal links and locale equivalents.

## 23. Legal/privacy content

The CMS can host versioned Terms, Privacy and Cookie content, but production publication requires the separately approved legal copy. Architecture does not invent legal language or retention periods. Published legal versions must be retained/auditable enough to associate inquiry/privacy consent with the applicable notice version when required.

## 24. Downstream implementation requirements

- `P1-DATA-01` freezes locale/media/revision/publication physical schema and constraints.
- `P1-AUTH-01` freezes actor/session/permission mechanics.
- `P1-CMS-01` implements editor/translation/media/preview/publish workflows without executable-content escape hatches.
- frontend tasks implement published-read rendering and v4.3-equivalent EN/AR behavior.
- later security/QA tasks prove sanitizer, CSP, media quarantine, preview isolation, schedule/rollback and negative authorization behavior before production release.
