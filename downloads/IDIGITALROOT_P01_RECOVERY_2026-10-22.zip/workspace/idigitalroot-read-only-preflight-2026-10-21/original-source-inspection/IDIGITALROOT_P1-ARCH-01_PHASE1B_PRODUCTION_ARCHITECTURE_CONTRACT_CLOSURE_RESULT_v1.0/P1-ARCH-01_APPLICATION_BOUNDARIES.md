# P1-ARCH-01 — Application Boundaries

**Scope:** Phase 1B architecture/contract closure only.  
**Rule:** application ownership must remain explicit; sharing a product story does not authorize data/runtime coupling.

## 1. Frozen application boundaries

| Surface / service | Phase | Current role | Phase 1B status |
|---|---:|---|---|
| Public Website | 1 | Public marketing/product/content experience | IN SCOPE |
| Dedicated Public Website CMS | 1 | Editorial control for the Public Website | IN SCOPE |
| Public/CMS Workers/API | 1 | Security, data access, inquiry, publishing and preview boundaries | IN SCOPE |
| D1 | 1 | Approved relational records | IN SCOPE at logical-contract level |
| R2 | 1 | Media/object storage and quarantine/approved-object lifecycle | IN SCOPE at logical-contract level |
| Future Staff Admin/Operations | 2 | Internal operations, Leads/clients/projects/services; later CMS access seam | OUT OF IMPLEMENTATION SCOPE |
| Future Client Portal | 3 | Invited accepted clients only | OUT OF IMPLEMENTATION SCOPE |
| Future per-client Website CMS | 4 | Independent CMS for each managed client website | OUT OF IMPLEMENTATION SCOPE |

The dedicated Public CMS is **not** a temporary duplicate of a future Admin CMS. It is the authoritative Phase 1 public-content editor. Phase 2 may integrate access to it, but must not fork it.

## 2. Responsibility matrix

Legend: **O** = authoritative owner; **R** = read/consume; **X** = forbidden/direct access absent; **F** = future seam only.

| Responsibility | Public Website | Public CMS UI | Public Content Worker | Inquiry Worker | CMS Worker/API | D1 | R2 | Future Admin | Future Client Portal |
|---|---|---|---|---|---|---|---|---|---|
| Approved v4.3 visual/component rendering | **O** | R/preview | X | X | X | X | R(media) | F | X |
| Public route navigation/SEO rendering | **O** | preview | R | X | X | R(published model) | R(media) | F | X |
| Editorial content entry | X | **O(UI)** | X | X | **O(enforcement)** | **O(data)** | R | F access seam | X |
| Component registry/types | **O(code)** | R | R | X | R/validate | optional version ref | X | X | X |
| Published content read | R | R | **O(service)** | X | R | **O(record)** | R | F | X |
| Draft content read/write | X | R/write UI | X | X | **O(service)** | **O(record)** | R | F controlled | X |
| Translation workflow | render | **O(UI)** | published read | X | **O(validation)** | **O(record)** | media refs | F | X |
| Media upload | X | initiate | X | X | **O(preflight/finalize)** | metadata | **O(objects)** | F | X |
| Media quarantine/approval | X | status UI | X | X | **O(policy)** | metadata/state | **O(objects)** | F | X |
| Publish/rollback/schedule | X | initiate | consume result | X | **O(permission + transaction)** | **O(history/pointers)** | object eligibility | F | X |
| CMS authentication/session | X | client of auth | X | X | **O(server boundary)** | identity/session metadata if selected | X | F SSO/deep-link | X |
| CMS authorization | X | advisory UI | X | X | **O** | roles/permissions/audit | X | F | X |
| Public inquiry form rendering | **O(UI)** | labels/help only | X | X | X | X | X | F consume Lead later | X |
| Inquiry validation/persistence | X | protected configuration only | X | **O** | X | **O(Lead)** | no files v1 | F later workflow | X |
| Public self-signup | **X** | **X** | **X** | **X** | **X** | **X** | **X** | **X** | **X** |
| Client Portal authentication | informational link only | X | X | X | X | X | X | X | F Phase 3 |
| Secrets | X | X | X | server bindings only | server bindings only | X | X | F own secrets | F own secrets |
| Non-secret runtime configuration | render/consume | manage only approved keys | consume | consume | validate/manage | **O(config record where used)** | X | F | X |
| Audit events | X | view as permitted | X | intake security/audit events | **O(privileged actions)** | **O(records)** | X | F later consume | X |

## 3. Public Website boundary

### Owns
- Astro page composition and route rendering.
- The code-owned component registry and presentation tokens required to reproduce v4.3.
- Accessible interaction behavior: desktop/mobile Personal menu, tabs, FAQ, theme/language controls, reduced-motion behavior, focus lifecycle, inquiry step UI.
- SEO/rendering behavior, route metadata composition, canonical/hreflang output from approved content/configuration.
- Public-only display of published content and approved media.

### Does not own
- Draft truth, publication permission, CMS user sessions, Lead persistence, media approval, authorization, D1 schema, R2 upload credentials, staff workflow, client accounts.

### Direct data access rule
The browser may not connect directly to D1. Public R2 objects may be delivered only after media approval and only through the selected controlled public object delivery model.

## 4. Dedicated Public CMS boundary

### Owns UI workflows for
- page/content navigation;
- localized fields and translation state;
- approved section instances/order/visibility/variant parameters;
- navigation/footer content;
- services and Personal/Student marketing content;
- Knowledge content;
- SEO/public structured information fields;
- inquiry labels/help/options where explicitly editable;
- media library and approval state display;
- preview, publish, schedule where supported, history, rollback;
- audit-visible editorial actions.

### Does not own
- arbitrary JavaScript/CSS/source editing;
- Worker security policy;
- validation rules that protect system integrity;
- D1 migrations;
- R2 bucket/binding configuration;
- authentication bypasses;
- future Admin operational workflows;
- future Client Portal data;
- future client-site CMS content.

## 5. Worker/API trust zones

### 5.1 Public Content Worker
Allowed:
- read current published route/content revision;
- read public locale metadata;
- resolve approved media delivery references;
- return safe cache metadata.

Forbidden:
- draft reads;
- CMS identity/session access;
- Lead reads/writes;
- publication writes;
- arbitrary query exposure.

### 5.2 Inquiry Intake Worker
Allowed:
- receive the eight-step submission;
- normalize/validate fields;
- enforce allowed URL protocols and payload limits;
- perform rate/abuse/idempotency controls;
- create exactly one stable Lead intake record per accepted idempotent submission;
- return a safe receipt/reference.

Forbidden:
- account creation;
- public Lead status endpoint;
- arbitrary file uploads;
- staff notes/qualification fields from the browser;
- exposing internal record IDs when a public-safe reference is used.

### 5.3 CMS Worker/API
Allowed:
- authenticated draft/content/configuration operations;
- authorized media upload preflight/finalization;
- translation state transitions;
- preview capability issuance;
- publish/schedule/unpublish/archive/rollback operations;
- version and audit reads as permitted;
- protected system configuration explicitly designated CMS-manageable.

Forbidden:
- trusting UI role labels;
- content-supplied scripts;
- bypassing validation because an actor is privileged;
- destructive history rewriting;
- direct Phase 2/3/4 business workflow implementation.

## 6. D1 logical ownership matrix

The following are **logical record families**, not frozen physical tables.

| Record family | Logical authority | Primary writers | Readers | Notes |
|---|---|---|---|---|
| Public page/route content | D1 content domain | CMS Worker | CMS, Public Content Worker | stable IDs; route constraints |
| Section/component instances | D1 content domain | CMS Worker | CMS, Public Content Worker | registered families only |
| Navigation/footer | D1 content domain | CMS Worker | public/CMS | route reference validation |
| Locale registry | D1 content domain | authorized CMS config | public/CMS | EN/AR launch; extensible registry |
| Localized variants | D1 content domain | CMS Worker | public/CMS | lifecycle state per locale |
| Media metadata | D1 content domain | CMS Worker/media pipeline | public/CMS | object state separate in R2 |
| Content revisions/history | D1 content domain | CMS Worker | CMS; public only active pointer | immutable retained history |
| Publication pointers/events | D1 content domain | CMS Worker | Public Content Worker/CMS | atomic current revision selection |
| Inquiry/Lead | D1 intake domain | Inquiry Worker; Phase 2 later | Phase 1 receipt-minimal; Phase 2 later | same stable record family |
| Intake abuse/security metadata | D1 intake domain | Inquiry Worker | authorized security/operations later | minimized and retention-controlled |
| CMS identity | D1 control domain or selected IdP mapping | auth service | CMS Worker | exact provider in P1-AUTH-01 |
| CMS roles/permissions | D1 control domain | privileged identity admin process | CMS Worker | stable IDs, least privilege |
| CMS sessions/revocations | D1 control domain or selected auth store | auth service | CMS Worker | provider-specific implementation later |
| Audit | authoritative relevant domain | Workers | authorized CMS/ops | append-oriented, protected |
| Non-secret runtime config | D1/config binding | authorized config workflow | Workers/public where safe | never secrets |

## 7. R2 logical ownership matrix

| Object state | Accessibility | Writer | Publication eligibility |
|---|---|---|---|
| Upload/quarantine original | private | CMS media flow only | NO |
| Rejected object | private/retention-limited | system state | NO |
| Validated original | private by default | media pipeline | only through approved reference policy |
| Approved derivative | controlled public or Worker-served | media pipeline | YES when linked by published content |
| Release/rollback evidence | private operational archive | release process | not public content |

No public inquiry file upload is allowed in Phase 1B v1. If a controlled prospect-document flow is later approved, it is a separate architecture extension with its own quarantine/scanning/retention contract.

## 8. Future Admin integration seam — Phase 2

The Phase 2 Admin may:
- consume the same stable Lead family written in Phase 1;
- transition operational Lead status and later convert an accepted Lead to a client under Phase 2 contracts;
- display a governed link/launch into the Public CMS;
- later participate in identity federation/SSO if P1-AUTH-01 freezes a compatible design.

It may **not**:
- own a copy of public page content;
- create a second CMS editor or publication history;
- move the public CMS tables into an Admin-only schema merely to appear integrated;
- require the Phase 1 public site to wait for Phase 2 runtime implementation.

## 9. Future Client Login seam — Phase 3

The current public route is truthful UX only. Until a genuine Phase 3 portal exists:
- no public signup;
- no fake login success;
- no Phase 1 client session cookie;
- no hidden portal APIs represented as active;
- the page states that access is for accepted/existing clients and is unavailable/not connected until implemented.

## 10. Future client Website CMS seam — Phase 4

Every client website CMS remains independent from the iDigitalRoot Public CMS. Shared libraries/contracts may be reused only where later approved; customer content and credentials do not enter the Public CMS data plane.

## 11. Ownership conflict rules

When implementation encounters ambiguity:
1. system/security truth beats editable presentation;
2. the approved v4.3 presentation contract beats older conflicting broad-audience visual assumptions;
3. current Phase 1B boundary documents beat older “CMS inside Admin” assumptions;
4. dedicated CMS writes public content; public frontend renders it; neither duplicates the other’s authority;
5. D1 owns relational record truth; R2 owns object bytes; D1 metadata references R2 objects but does not embed object bytes;
6. visible labels/slugs never act as permission identities;
7. a future application seam is not permission to implement that future application now.
