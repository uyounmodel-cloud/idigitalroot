# iDigitalRoot P1-AN-01 Analytics Core v1.0

Bounded TypeScript/Workers-oriented first-party analytics core for the accepted Phase 1 iDigitalRoot Public Website / dedicated Public Website CMS architecture.

## Included runtime modules

- public POST-only ingest Worker core: `src/worker.ts` + `src/analytics/ingest.ts`;
- privacy/event registry, acquisition sanitization and coarse request classification;
- trusted conversion-outbox consumer;
- authenticated analytics query/report/RBAC/audit core;
- HOUR/DAY rollups, cursors, health and scheduled-job orchestration;
- fail-closed retention gate with a synthetic-test-only approved-policy seam;
- generic analytics machinery under `src/analytics/` and iDigitalRoot-specific profile under `src/site-profile/`;
- local Node `node:sqlite` D1-compatible adapter and synthetic acceptance tests.

No Cloudflare resources, credentials, account identifiers, production collection, deployment or provider mutations are included.

## Exact local toolchain

See `toolchain.json`. The sealed package requires exactly Node 22.16.0, npm 10.9.2 and TypeScript 5.8.3 available on `PATH`. There are no npm dependencies; `npm ci --offline` is deterministic.

## Verification

From a fresh extraction:

```text
python scripts/verify_all.py
```

The script fails closed. It prints `P1_AN_01_SEALED_SOURCE_VERIFY_PASS` only after internal checksums, immutable migration pins, exact toolchain, offline `npm ci`, TypeScript check/build and all executable synthetic acceptance tests pass.

The source package intentionally contains no deployment command or Wrangler/provider mutation configuration.
