from pathlib import Path
import hashlib,json,zipfile,sys
r=Path('/workspace/idigitalroot-work/public-web');label=sys.argv[1];out=Path('/workspace/idigitalroot-artifacts')/('IDIGITALROOT_P1-FE-02_PUBLIC_FRONTEND_SOURCE_'+label+'_CANDIDATE.zip');exclude={'node_modules','.astro','.wrangler','.fe02-build'}
files=sorted(p for p in r.rglob('*') if p.is_file() and not any(x in exclude for x in p.relative_to(r).parts) and p.relative_to(r).parts[0]!='dist' and not p.name.startswith(('.dev.vars','.env')) and p.relative_to(r).as_posix() not in ['SHA256SUMS.txt','RELEASE_MANIFEST.json'])
m={'version':label,'status':'CANDIDATE','parent_zip_sha256':'3709a3aa234e7f1a5dbb840037b9a9c04e53ac49172b8b216bb309697f24ef95','files':[{'path':p.relative_to(r).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]};(r/'RELEASE_MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n');files.append(r/'RELEASE_MANIFEST.json');(r/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(r).as_posix()+'\n' for p in sorted(files)));files.append(r/'SHA256SUMS.txt')
assert not out.exists()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(r).as_posix())
print(out.name,hashlib.sha256(out.read_bytes()).hexdigest(),flush=True)
with zipfile.ZipFile(out) as z:assert z.testzip() is None;z.extractall(sys.argv[2] if len(sys.argv)>2 else '/workspace/idigitalroot-work/fe02-final1')
