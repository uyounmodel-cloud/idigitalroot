# iDigitalRoot recovery through IDR-P01 — 22 October 2026

Save this ZIP on your PC before abandoning the old environment. Start a new Codex cloud conversation connected to uyounmodel-cloud/idigitalroot, main; attach the ZIP and paste RESUME_PROMPT.txt. This transfers documented results; publication of the broken environment is not required.

Included in full: all files in the existing P00 evidence/reading directory; all four P00B reports; both P01 reports; original uploaded execution-preparation ZIP; two inert supporting local helper copies cited by P00B (not executables to run). Root workspace/ entries preserve the old absolute /workspace/... evidence paths. No repository application file or historical artifact was changed.

Repository main was read-only checked on GitHub and matches reviewed commit08f614b1698dec2db657248f95ceea723ab537e7. The exact49MB October14 master ZIP and other tracked source releases already live in that repository and are not duplicated here. Require the exact raw master SHA and baseline tracked hashes in the prompt. All243 tracked files freshly matched the baseline while preparing this recovery bundle.

Verify this bundle's CRC, RELEASE_MANIFEST.json and SHA256SUMS.txt before restoring. The manifest enumerates actual member paths/size/SHA. Its checksum list covers payload plus manifest; the checksum file cannot hash itself. Retained ORIGINAL evidence checksum files have their historical original path context; they are not substitutes for this bundle's root checksums. Restore listed evidence only outside the repository, reject unsafe paths/symlinks, skip identical existing bytes, stop on different existing bytes. Do not run bundled Python scripts or historical launchers.

Not a backup of the whole machine, live D1/R2, drafts outside these evidence folders, private customer data, credentials, live processes or full verbatim chat history. Earlier R1–R12 are documented narrative decisions, not a magically recovered verbatim transcript. Runtime authentication does not migrate. Keep the old chat and environment until the new conversation verifies recovery. Never upload credentials to GitHub or chat.

IDR-P01: owner read-only review READY. NOT implemented, NOT scope-approved. Authentication policy, prices/terms/quotas, schema/contract approvals and later provider/legal/release gates remain open. No source/schema/deployment permission. The next owner action is P01 sectionsA,H,L; not Stage02.
