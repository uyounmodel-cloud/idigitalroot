#!/usr/bin/env python3
"""Reproduce and review the sealed Phase 1 candidate using LOCAL Workers, D1 and R2 only."""
import argparse,hashlib,json,os,pathlib,signal,socket,sqlite3,subprocess,sys,time,urllib.request,urllib.error
p=argparse.ArgumentParser();p.add_argument('--frontend-node',required=True);p.add_argument('--backend-node',required=True);p.add_argument('--data-dir',required=True);p.add_argument('--evidence-dir',required=True);p.add_argument('--install',action='store_true');p.add_argument('--verify',action='store_true');p.add_argument('--full-browser',action='store_true');p.add_argument('--test-seconds',type=int);p.add_argument('--allow-unsealed-development',action='store_true');a=p.parse_args()
root=pathlib.Path(__file__).resolve().parents[1];(root/'evidence').mkdir(exist_ok=True);out=pathlib.Path(a.evidence_dir).resolve();out.mkdir(parents=True,exist_ok=True);data=pathlib.Path(a.data_dir).resolve();data.mkdir(parents=True,exist_ok=True)
front=pathlib.Path(a.frontend_node).resolve();back=pathlib.Path(a.backend_node).resolve();npm=back.parent/'npm';processes=[];logs=[];steps=[]
env=os.environ.copy();env.update(PATH=str(front.parent)+os.pathsep+str(root/'website/node_modules/.bin')+os.pathsep+env['PATH'],ASTRO_TELEMETRY_DISABLED='1',WRANGLER_SEND_METRICS='false',XDG_CONFIG_HOME=str(out/'config'),XDG_CACHE_HOME=str(out/'cache'),npm_config_cache=str(out/'npm-cache'),IDR_NATIVE_DATA_DIR=str(data))
server_env={**env,'PATH':str(back.parent)+os.pathsep+str(root/'website/node_modules/.bin')+os.pathsep+os.environ['PATH']}
def command(name,cmd,cwd=root,run_env=env,timeout=300):
 print('START '+name,flush=True);begin=time.monotonic();notice=begin+15
 with (out/(name+'.log')).open('w') as log:
  child=subprocess.Popen([str(x) for x in cmd],cwd=cwd,env=run_env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   while child.poll() is None:
    if time.monotonic()-begin>timeout:raise RuntimeError(name+' exceeded its time limit')
    if time.monotonic()>=notice:print(name+' still running ('+str(int(time.monotonic()-begin))+' seconds)',flush=True);notice=time.monotonic()+15
    time.sleep(.2)
  except BaseException:
   try:os.killpg(child.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   child.wait(timeout=10);raise
 steps.append({'name':name,'exitCode':child.returncode,'seconds':round(time.monotonic()-begin,2)});(out/'steps.json').write_text(json.dumps(steps,indent=2)+'\n')
 if child.returncode:raise RuntimeError(name+' failed; see its saved log')
 print('PASS '+name,flush=True)
def start(name,cmd,cwd,url,marker):
 log=(out/(name+'.log')).open('w');logs.append(log);proc=subprocess.Popen([str(x) for x in cmd],cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);processes.append(proc)
 for _ in range(180):
  if proc.poll() is not None:raise RuntimeError(name+' exited during startup')
  try:
   with urllib.request.urlopen(url,timeout=1) as response:
    body=response.read().decode()
    if response.status==200 and marker in body:print('READY '+name,flush=True);return
  except Exception:pass
  time.sleep(.2)
 raise RuntimeError(name+' did not become ready')
def interrupted(*_):raise KeyboardInterrupt('Local review stopped')
signal.signal(signal.SIGTERM,interrupted)
def schema_identity():
 identity={}
 for component in ['cms','backend','analytics']:
  for database,n in [('core',16),('analytics',2)]:
   folder=root/component/'schema'/database/'migrations'
   if not folder.exists():continue
   files=sorted(folder.glob('*.sql'))
   if not files:continue
   expected=14 if component=='analytics' and database=='core' else n
   assert [x.name[:4] for x in files]==[f'{i:04}' for i in range(1,expected+1)],'Frozen migration lineage mismatch'
   identity[component+'/'+database]={x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in files}
 for database in ['core','analytics']:
  values=[x for k,x in identity.items() if k.endswith('/'+database) and k!='analytics/core'];assert all(x==values[0] for x in values),'Runtime schema copies differ'
 historical=identity.get('analytics/core',{});assert all(identity['cms/core'].get(k)==v for k,v in historical.items()),'Accepted analytics fixture prefix differs from canonical runtime lineage'
 return identity
try:
 assert subprocess.check_output([str(front),'-p','process.versions.node'],text=True).strip()=='22.19.0'
 assert subprocess.check_output([str(back),'-p','process.versions.node'],text=True).strip()=='22.16.0'
 assert subprocess.check_output([str(npm),'--version'],env=env,text=True).strip()=='10.9.2'
 for port in [4198,4400]:
  with socket.socket() as sock:
   if sock.connect_ex(('127.0.0.1',port))==0:raise RuntimeError(f'Port {port} is occupied. No existing service was stopped.')
 if not a.allow_unsealed_development:command('source-checksums',['sha256sum','--check','SHA256SUMS.txt'])
 identity=schema_identity();(out/'schema-lineages.json').write_text(json.dumps(identity,indent=2)+'\n')
 if a.install:command('pinned-install',[npm,'ci','--engine-strict','--no-audit','--no-fund','--fetch-retries=1','--fetch-timeout=30000'],root/'website',timeout=420)
 if a.install:
  for component in ['backend','cms','analytics']:command(component+'-pinned-install',[npm,'ci','--ignore-scripts','--no-audit','--no-fund'],root/component,server_env)
 if a.install and a.full_browser:command('audit-tools-install',[npm,'ci','--ignore-scripts','--no-audit','--no-fund'],root/'test-tools')
 if not (root/'website/node_modules/typescript/bin/tsc').exists():raise RuntimeError('Pinned dependencies are missing; use --install')
 for component in ['backend','cms','analytics']:command(component+'-build',[back,root/'website/node_modules/typescript/bin/tsc','-p','tsconfig.json','--pretty','false'],root/component,server_env)
 variables='IDR_PUBLIC_API_BASE_URL="http://127.0.0.1:4198"\nIDR_PUBLIC_SITE_ORIGIN="http://127.0.0.1:4400"\nPUBLIC_API_CONTEXT_SECRET="LOCAL_TEST_CONTEXT_ONLY_NOT_PRODUCTION_2026"\n';varfile=root/'website/.dev.vars'
 if varfile.exists() and varfile.read_text()!=variables:raise RuntimeError('Existing local configuration differs. Use a fresh source extraction.')
 varfile.write_text(variables)
 command('astro-check',[npm,'run','check'],root/'website')
 command('official-workers-build',[npm,'run','build'],root/'website')
 command('frontend-boundary',[sys.executable,'scripts/check_worker_bindings.py'],root/'website')
 command('shared-renderer-compile',[front,root/'website/node_modules/typescript/bin/tsc','-p','tsconfig.fe02.json','--pretty','false'],root/'website')
 command('preview-assets',[front,'scripts/prepare-preview-assets.mjs'])
 if a.verify:command('frontend-runtime-contract',[front,'--test','tests/universal-runtime.test.mjs'],root/'website')
 if a.verify:command('integration-security',[front,'--test','tests/integration-security.test.mjs'])
 if a.verify:
  if (data/'BOOTSTRAP.json').exists():raise RuntimeError('Acceptance requires fresh isolated data; existing review edits were preserved')
  for name,component,tests in [('backend-tests','backend',['tests/backend.test.mjs']),('cms-contract-security','cms',['tests/cloudflare-access.test.mjs','tests/service.test.mjs','tests/advanced.test.mjs','tests/core-d1.test.mjs','tests/r3-parity.test.mjs','tests/p1-cms-03.test.mjs']),('analytics-tests','analytics',['tests/acceptance.test.mjs'])]:command(name,[back,'--test',*tests],root/component,server_env)
 if (data/'BOOTSTRAP.json').exists():
  assert json.loads((data/'BOOTSTRAP.json').read_text())['schemas']==identity,'Existing data has a different schema lineage'
 else:
  command('synthetic-bootstrap',[back,'scripts/export-local-fixture.mjs'],run_env=server_env)
  paths=json.loads((out/'synthetic-bootstrap.log').read_text().strip().splitlines()[-1])
  for key,label in [('corePath','core'),('analyticsPath','analytics')]:
   connection=sqlite3.connect(paths[key]);dump=list(connection.iterdump());tables=[x for x in dump if x.startswith('CREATE TABLE')];indexes=[x for x in dump if x.startswith('CREATE ') and not x.startswith(('CREATE TABLE','CREATE TRIGGER'))];triggers=[x for x in dump if x.startswith('CREATE TRIGGER')];inserts={}
   for sql in dump:
    if sql.startswith('INSERT INTO '):inserts.setdefault(sql.split('"')[1],[]).append(sql)
   pending=set(inserts);ordered=[]
   while pending:
    ready=sorted(t for t in pending if not {x[2] for x in connection.execute('PRAGMA foreign_key_list("'+t+'")') if x[2]!=t}&pending)
    if not ready:raise RuntimeError('Synthetic fixture has a foreign-key cycle')
    for table in ready:ordered+=inserts[table];pending.remove(table)
   sqlfile=out/(label+'-bootstrap.sql');sqlfile.write_text('\n'.join(tables+indexes+ordered+triggers)+'\n');connection.close()
   command(label+'-local-d1',[front,root/'website/node_modules/wrangler/bin/wrangler.js','d1','execute','idigitalroot-'+label+'-local-test','--config','workers/wrangler.local-cms.json','--local','--persist-to',data/'state','--file',sqlfile])
  (data/'BOOTSTRAP.json').write_text(json.dumps({'schemas':identity,'profile':'Synthetic student local review; never production data'},indent=2)+'\n')
 start('native-workers',[front,root/'website/node_modules/wrangler/bin/wrangler.js','dev','--local','--persist-to',data/'state','-c','workers/wrangler.local-cms.json','-c','workers/wrangler.local-api.json','-c','workers/wrangler.local-analytics.json','--ip','127.0.0.1'],root,'http://127.0.0.1:4198/','loginRoot')
 start('built-public-website',[front,'node_modules/.bin/astro','preview','--ignore-lock','--host','127.0.0.1','--port','4400'],root/'website','http://127.0.0.1:4400/','idr-published-model')
 with urllib.request.urlopen('http://127.0.0.1:4400/ar',timeout=10) as response:assert response.status==200 and 'dir="rtl"' in response.read().decode()
 print('INTEGRATED_NATIVE_READY launcher PID '+str(os.getpid()),flush=True)
 if a.verify:
  for name,script in [('native-workflows','scripts/native-workflows.mjs'),('native-negative','scripts/native-negative.mjs'),('native-global-ui','scripts/native-global-ui.mjs'),('studio-owner-workflows','scripts/studio-review.mjs'),('universal-site-browser','scripts/universal-review.mjs'),('menu-draft-isolation','scripts/menu-draft-isolation.mjs')]:command(name,[front,script],timeout=900)
  print('START backend-outage-control',flush=True)
  try:
   os.killpg(processes[0].pid,signal.SIGSTOP)
   try:
    urllib.request.urlopen('http://127.0.0.1:4400/',timeout=15)
    raise RuntimeError('Expected a controlled public failure during backend outage')
   except urllib.error.HTTPError as error:
    text=error.read().decode();assert error.code==503;assert 'noindex' in text;assert not any(x in text for x in ['SELECT ','Traceback','PREVIEW_SECRET'])
  finally:os.killpg(processes[0].pid,signal.SIGCONT)
  with urllib.request.urlopen('http://127.0.0.1:4400/',timeout=15) as response:assert response.status==200
  (out/'backend-outage.json').write_text(json.dumps({'status':'PASS','failureStatus':503,'recoveryStatus':200,'scope':'Only this runner own local Worker process group was paused then resumed','providerMutation':False})+'\n')
  print('PASS backend-outage-control',flush=True)
  if a.full_browser:
   command('studio-accessibility',[front,'scripts/studio-accessibility.mjs'],timeout=240)
   command('universal-accessibility',[front,'scripts/universal-accessibility.mjs'],timeout=1200)
   command('full-browser-inventory',[front,'scripts/browser-inventory.mjs'],timeout=1200)
  result={'status':'PASS','scope':'Local technical gates only','releaseStatus':'BLOCKED','providerMutation':False,'deployment':False,'steps':steps};(out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n')
 elif a.test_seconds is not None:
  end=time.monotonic()+a.test_seconds
  while time.monotonic()<end:
   if any(x.poll() is not None for x in processes):raise RuntimeError('A local runtime exited; see saved logs')
   time.sleep(.5)
 else:input('Integrated local review is ready. Press Enter to stop. Review data will be kept.\n')
except BaseException as error:
 (out/'outcome.json').write_text(json.dumps({'status':'FAIL','reason':str(error),'providerMutation':False,'deployment':False,'steps':steps},indent=2)+'\n');raise
finally:
 for proc in reversed(processes):
  try:os.killpg(proc.pid,signal.SIGTERM)
  except ProcessLookupError:pass
 for proc in processes:
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:
   try:os.killpg(proc.pid,signal.SIGKILL)
   except ProcessLookupError:pass
 for log in logs:log.close()
