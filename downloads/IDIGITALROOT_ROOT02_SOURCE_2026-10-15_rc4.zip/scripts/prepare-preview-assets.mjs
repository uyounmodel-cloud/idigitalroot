import fs from 'node:fs/promises';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');const from=path.join(root,'website/dist/client/_astro'),to=path.join(root,'cms/ui/preview-assets');await fs.mkdir(to,{recursive:true});const css=(await fs.readdir(from)).filter(x=>/^[A-Za-z0-9_.-]+\.css$/.test(x));for(const name of css)await fs.copyFile(path.join(from,name),path.join(to,name));const sprite=await fs.readFile(path.join(root,'website/src/components/IconSprite.astro'),'utf8');await fs.writeFile(path.join(root,'workers/preview-assets.generated.mjs'),`export const css=${JSON.stringify(css)};export const iconSprite=${JSON.stringify(sprite)};\n`);

// Protected previews use the same self-hosted licensed fonts as the public build.
await fs.cp(path.join(root,'website/public/fonts'),path.join(root,'cms/ui/fonts'),{recursive:true});
