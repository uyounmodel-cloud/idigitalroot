import {universalHeader,universalFooter,renderUniversalStatic,legacyDestination} from '../universal-site.js';
import type {Locale,PublishedPageModel} from '../runtime-public.js';
export function renderStaticRoute(path:string,lang='en',_model:PublishedPageModel|null=null){return renderUniversalStatic(legacyDestination(path)||path,lang==='ar'?'ar':'en')}
export function renderStaticHeader(path:string,lang='en',options:{privatePreview?:boolean}={}){return universalHeader(path,lang==='ar'?'ar':'en',!!options.privatePreview)}
export function renderStaticFooter(path:string,lang='en'){return universalFooter(path,lang==='ar'?'ar':'en')}
if(typeof document!=='undefined'){
 const stored=(()=>{try{return localStorage.getItem('idr-universal-theme')}catch{return null}})();if(stored&&['light','dark','system'].includes(stored))document.documentElement.dataset.theme=stored;
 document.addEventListener('click',event=>{if((event.target as Element).closest('[data-action="theme"]')){const current=document.documentElement.dataset.theme||'system';const next=current==='system'?'light':current==='light'?'dark':'system';document.documentElement.dataset.theme=next;try{localStorage.setItem('idr-universal-theme',next)}catch{}}});
 document.addEventListener('keydown',event=>{if(event.key==='Escape'){const details=[...document.querySelectorAll<HTMLDetailsElement>('.u-header details[open]')];const active=document.activeElement;details.reverse().forEach(d=>{if(d.contains(active))d.querySelector<HTMLElement>('summary')?.focus();d.open=false})}});
 document.addEventListener('toggle',event=>{const target=event.target;if(target instanceof HTMLDetailsElement&&target.open&&target.closest('.desktop-nav'))for(const other of document.querySelectorAll<HTMLDetailsElement>('.desktop-nav details[open]'))if(other!==target)other.open=false;},true);
 document.addEventListener('click',event=>{if(!(event.target as Element).closest('.u-header'))for(const d of document.querySelectorAll<HTMLDetailsElement>('.u-header details[open]'))d.open=false});
}
