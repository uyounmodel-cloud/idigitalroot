// Owner-authorized universal corporate information architecture, ROOT 02.
import {UNIVERSAL_ROUTES} from '../universal-site.js';
export const PHASE1B_ROUTES:readonly string[]=UNIVERSAL_ROUTES;
export type Phase1BRoute=(typeof PHASE1B_ROUTES)[number];
