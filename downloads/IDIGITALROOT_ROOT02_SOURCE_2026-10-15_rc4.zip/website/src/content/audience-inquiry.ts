// Presentation recommendations only. The server's published definition remains the validation authority.
export const EXTRA_INQUIRY_OPTIONS:Record<string,{key:string;labels:[string,string]}[]>={
 goals:[{key:'career-growth',labels:['Present my expertise and career story','أقدّم خبرتي ومسيرتي المهنية']},{key:'show-services',labels:['Explain our products or services','أوضّح منتجاتنا أو خدماتنا']},{key:'attract-inquiries',labels:['Make customer inquiries easier','أسهّل استفسارات العملاء']},{key:'business-credibility',labels:['Build a credible company presence','أبني حضوراً موثوقاً للشركة']},{key:'launch-venture',labels:['Introduce a new venture','أعرّف بمشروع جديد']}],
 focus:[{key:'services-offer',labels:['Products and services','المنتجات والخدمات']},{key:'company-story',labels:['Company story and team','قصة الشركة والفريق']},{key:'customer-contact',labels:['Customer contact and inquiries','تواصل العملاء واستفساراتهم']}]
};
const studentGoals=['show-work','internship','first-job','scholarship','identity','centralize','personal-growth'];
const commonGoals=['show-work','identity','centralize','career-growth','show-services','attract-inquiries','business-credibility','launch-venture'];
const focusCommon=['projects-portfolio','personal-identity','balanced','not-sure','services-offer','company-story','customer-contact'];
export function recommendedInquiryOption(audience:string,field:string,key:string){
 if(!['student','professional','entrepreneur','business'].includes(audience))return true;
 if(field==='goals')return(audience==='student'?studentGoals:commonGoals).includes(key);
 if(field==='focus')return(audience==='student'?['projects-portfolio','cv-career','personal-identity','university-journey','balanced','not-sure']:audience==='professional'?[...focusCommon,'cv-career']:focusCommon).includes(key);
 return true;
}
export const INQUIRY_OPTION_WORDING:Record<string,Record<string,[string,string]>>={need_direction:{'first-root':['A new website','موقع جديد'],portfolio:['A stronger showcase of work or services','عرض أقوى لأعمالي أو خدماتي'],career:['A stronger professional or company presence','حضور أقوى مهنياً أو للشركة'],organize:['Bring my digital presence together','أجمع حضوري الرقمي في مكان واحد'],refresh:['Improve an existing website','تطوير موقع موجود']}};
