import { parseFragment, serialize, type DefaultTreeAdapterMap } from 'parse5';

type Node = DefaultTreeAdapterMap['node'];
type Element = DefaultTreeAdapterMap['element'];
const attribute = (node: Node, name: string) => 'attrs' in node ? node.attrs.find(a => a.name === name)?.value : undefined;
function elements(node: Node, out: Element[] = []): Element[] {
  if ('tagName' in node) out.push(node);
  if ('childNodes' in node) for (const child of node.childNodes) elements(child, out);
  return out;
}
const textOf=(node:Node):string=>node.nodeName==='#text'?(node as DefaultTreeAdapterMap['textNode']).value:'childNodes' in node?node.childNodes.map(textOf).join(''):'';
function editableText(n:Element){if(!(/^h[1-4]$/.test(n.tagName)||n.tagName==='p'))return false;let parent:any=n;while(parent){const cls=(attribute(parent,'class')||'').split(/\s+/);if(attribute(parent,'data-product-key')||['knowledge-grid','knowledge-discovery','service-list','workspace-stage','service-art','major-showcase','process-detail','article-aside'].some(k=>cls.includes(k))||['root-detail','bp-detail','knowledge-list'].includes(attribute(parent,'id')||''))return false;parent=parent.parentNode}return true}
export function editorialFields(html:string){const tree=parseFragment(html);return elements(tree).filter(editableText).map((n,index)=>({index,label:textOf(n).trim().slice(0,100),text:textOf(n),kind:n.tagName}));}
export function bindEditorialFields(html:string,fields:unknown){if(!Array.isArray(fields))return html;const tree=parseFragment(html);const targets=elements(tree).filter(editableText);for(const field of fields.slice(0,250)){if(!field||!Number.isInteger(field.index)||field.index<0||typeof field.text!=='string'||field.text.length>12000)continue;const node=targets[field.index];if(!node||textOf(node)===field.text)continue;node.childNodes=[{nodeName:'#text',value:field.text,parentNode:node}];}return serialize(tree);}

/** Update declared presentation fields while retaining code-owned layout and interaction keys. */
export function bindPublishedRecords(html:string,records:{key:string;content:Record<string,unknown>}[]):string {
 const tree=parseFragment(html);const all=elements(tree);
 const setText=(node:Element,value:unknown)=>{if(typeof value!=='string'||!value.trim())return;node.childNodes=[{nodeName:'#text',value:value.slice(0,8000),parentNode:node}];};
 for(const record of records){for(const target of all.filter(n=>attribute(n,'data-product-key')===record.key||(record.key.startsWith('service-')&&(attribute(n,'class')||'').split(/\s+/).includes('service-art')&&attribute(n,'data-service')===record.key.slice(8)))){const children=elements(target,[]);const heading=children.find(n=>/^h[234]$/.test(n.tagName));const paragraph=children.find(n=>n.tagName==='p');if(heading)setText(heading,record.content.title);if(paragraph)setText(paragraph,record.content.description);}}
 const brand=records.find(x=>x.key==='site-brand-contact-social')?.content;
 if(brand){
  for(const target of all.filter(n=>['brand','footer-wordmark'].some(cls=>(attribute(n,'class')||'').split(/\s+/).includes(cls)))){const word=target.childNodes.find((n:any)=>n.tagName==='span'&&!(attribute(n,'class')||'').split(/\s+/).some(x=>['brand-dot','u-logo'].includes(x))) as Element|undefined;if(word&&typeof brand.brandName==='string'&&brand.brandName.trim()){const signature=word.childNodes.find((n:any)=>n.tagName==='span'&&(attribute(n,'class')||'').split(/\s+/).includes('brand-signature'));const current=word.childNodes.filter(n=>n!==signature).map(textOf).join('');if(current!==brand.brandName){setText(word,brand.brandName);if(signature)word.childNodes.push(signature)}}}
  for(const target of all.filter(n=>(attribute(n,'class')||'').split(/\s+/).includes('footer-mission')))setText(target,brand.tagline);
  const email=brand.contactEmail;if(typeof email==='string'&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)&&email.length<=320){for(const target of all.filter(n=>n.tagName==='a'&&attribute(n,'href')?.startsWith('mailto:'))){const attr=target.attrs.find(x=>x.name==='href')!;attr.value='mailto:'+email;}}
 }
 return serialize(tree);
}

/** Select code-owned templates in the published order; omitted sections stay invisible. */
export function composePublishedHome(html: string, sections: { id: string; component: string }[], renderExtra?: (section:any)=>string, aliases:Record<string,string>={},sanitizeHref:(value:unknown)=>string=()=>'' ): string {
  const fragment = parseFragment(html);
  const templates = new Map<string, Element>();
  for (const node of elements(fragment)) {
    const key = attribute(node, 'data-cms-section') || attribute(node, 'data-cms-block');
    if (key && !templates.has(key)) templates.set(key, node);
  }
  const bindHeroAction=(node:Element,section:any)=>{if(section.component!=='hero')return;const config=section.config||{};const target=elements(node,[]).find(n=>n.tagName==='a'&&(attribute(n,'class')||'').split(/\s+/).includes('primary'));if(!target)return;if(typeof config.ctaLabel==='string'&&config.ctaLabel.trim()){target.childNodes=[{nodeName:'#text',value:config.ctaLabel.slice(0,180),parentNode:target}];}const href=sanitizeHref(config.href);if(href){const attr=target.attrs.find(x=>x.name==='href');if(attr)attr.value=href;}};
  const used = new Set<string>();
  const selected: Node[] = [];
  for (const section of sections) {
    // The footer belongs to the separately published global footer boundary.
    if (section.component === 'footer') continue;
    const key=aliases[section.component]||section.component;
    const template = templates.get(key);
    const config=(section as any).config||{};const structured=section.component!=='hero'&&(Array.isArray(config.items)&&config.items.length>0||config.text);
    if((!template||structured)&&renderExtra){const extra=parseFragment(renderExtra(section));for(const node of extra.childNodes){node.parentNode=fragment;selected.push(node);}continue;}
    if (!template || used.has(key)) throw Object.assign(new Error('PUBLIC_COMPONENT_MAPPING_INVALID'), { status: 404 });
    used.add(key);
    template.attrs.push({ name: 'data-section-instance', value: section.id });
    const fields=(section as any).config?.fields;
    if(Array.isArray(fields)){const holder=parseFragment(serialize({nodeName:'#document-fragment',childNodes:[template]} as any));const patched=parseFragment(bindEditorialFields(serialize(holder),fields));const replacement=patched.childNodes[0];if(replacement&&'tagName' in replacement){bindHeroAction(replacement,section);replacement.parentNode=fragment;selected.push(replacement);continue;}}
    bindHeroAction(template,section);template.parentNode = fragment;
    selected.push(template);
  }
  fragment.childNodes = selected as DefaultTreeAdapterMap['childNode'][];
  return serialize(fragment);
}

/** Preserve the selected locale on internal navigation without rewriting media URLs. */
export function localizePublishedLinks(html: string, locale: 'en' | 'ar'): string {
  if (locale === 'en') return html;
  const fragment = parseFragment(html);
  for (const node of elements(fragment)) {
    if (node.tagName !== 'a') continue;
    const href = node.attrs.find(a => a.name === 'href');
    if (!href || !href.value.startsWith('/') || href.value.startsWith('//') || /^\/(?:ar(?:\/|$|\?)|media\/|_astro\/)/.test(href.value)) continue;
    href.value = href.value === '/' ? '/ar' : '/ar' + href.value;
  }
  return serialize(fragment);
}

export function replacePublishedRegion(html: string, attributeName: string, value: string, markup: string): string {
  const fragment=parseFragment(html);
  const target=elements(fragment).find(node=>attributeName==='class' ? (attribute(node,'class')||'').split(/\s+/).includes(value) : attribute(node,attributeName)===value);
  if(!target)throw Object.assign(new Error('PUBLIC_COMPONENT_MAPPING_INVALID'),{status:404});
  const replacement=parseFragment(markup);
  target.childNodes=replacement.childNodes;
  for(const child of target.childNodes)child.parentNode=target;
  return serialize(fragment);
}

/** Defense in depth for the CMS's bounded rich-text source; never executable content. */
export function sanitizePublishedProse(input:string):string {
  const fragment=parseFragment(input.slice(0,12000));
  const allowed=new Set(['p','h2','h3','h4','strong','em','b','i','u','s','ul','ol','li','blockquote','code','pre','br','hr','a','table','thead','tbody','tr','th','td']);
  const discard=new Set(['script','style','iframe','object','embed','svg','math','form','input','textarea','select','button','link','meta','base']);
  const clean=(parent:any,depth=0)=>{
    if(depth>32){parent.childNodes=[];return;}
    const children=[];
    for(const child of parent.childNodes||[]){
      if(child.nodeName==='#text'){children.push(child);continue;}
      if(!child.tagName||discard.has(child.tagName))continue;
      clean(child,depth+1);
      if(!allowed.has(child.tagName)){children.push(...child.childNodes);continue;}
      const href=attribute(child,'href');child.attrs=[];
      if(child.tagName==='a'&&href&&href.length<=2048&&!/[\x00-\x20\\]/.test(href)&&!href.startsWith('//')&&(/^(\/|#)/.test(href)||/^https:\/\//i.test(href))){
        try{const url=new URL(href,'https://public.invalid');if(!url.username&&!url.password)child.attrs=[{name:'href',value:href},{name:'rel',value:'noopener noreferrer'}];}catch{}
      }
      children.push(child);
    }
    parent.childNodes=children;for(const child of children)child.parentNode=parent;
  };
  clean(fragment);return serialize(fragment);
}

/** Bind only explicitly selected section images from the server-approved public media set. */
export function bindSectionMedia(html:string,sections:{id:string;config:Record<string,unknown>}[],media:any[]):string {
 const tree=parseFragment(html);const nodes=elements(tree);
 for(const section of sections){const id=section.config?.mediaId;if(typeof id!=='string'||!id)continue;
  const approved=media.find(m=>m.media_id===id&&m.media_kind==='IMAGE'&&m.source_class==='LOCAL_UPLOAD');if(!approved)continue;
  const target=nodes.find(n=>attribute(n,'data-section-instance')===section.id);if(!target||elements(target,[]).some(n=>n.tagName==='img'&&attribute(n,'src')==='/media/'+encodeURIComponent(id)))continue;
  const children=elements(target,[]),visual=children.find(n=>(attribute(n,'class')||'').split(/\s+/).some(c=>['student-hero-visual','hero-graphic','cover-art'].includes(c)));
  const holder=visual||children.find(n=>(attribute(n,'class')||'').split(/\s+/).includes('shell'))||target;
  const cls=holder.attrs.find(x=>x.name==='class');if(visual&&cls)cls.value+=' has-published-media';
  const image:Element={nodeName:'img',tagName:'img',namespaceURI:holder.namespaceURI,attrs:[{name:'class',value:visual?'published-section-image published-hero-image':'published-section-image'},{name:'src',value:'/media/'+encodeURIComponent(id)},{name:'alt',value:String(approved.alt_text||approved.title||'').slice(0,500)},{name:'loading',value:visual?'eager':'lazy'},{name:'decoding',value:'async'}],childNodes:[],parentNode:holder};
  holder.childNodes.push(image);
 }
 return serialize(tree);
}
