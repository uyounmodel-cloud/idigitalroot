@echo off
title iDigitalRoot - HORIZON 01 - Website and CMS
echo HORIZON 01 - New public website and Website Console. Progress will appear below.
echo Keep this window open. Press Enter when finished browsing to stop both applications.
wsl.exe --status > "%~dp0WINDOWS_WSL_STATUS.log" 2>&1
if errorlevel 1 (
  type "%~dp0WINDOWS_WSL_STATUS.log"
  echo Send WINDOWS_WSL_STATUS.log so I can diagnose the launcher.
  pause
  exit /b 1
)
wsl.exe --cd "%~dp0." -- python3 -u OPEN_CONNECTED_PREVIEW.py
if errorlevel 1 echo Send PREVIEW_LOGS.zip or WINDOWS_PREVIEW_LAUNCH.log for diagnosis.
pause
