"""Copy compatible stopped local review data; never overwrite the previous candidate."""
from pathlib import Path
import hashlib,json,os,re,shutil,sqlite3,tempfile

def schemas(source):
 result={}
 for component in ['cms','backend','analytics']:
  for database in ['core','analytics']:
   folder=source/component/'schema'/database/'migrations'
   files=sorted(folder.glob('*.sql'))
   if files:result[component+'/'+database]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
 return result

def adopt_previous(state,source,data,meta,progress=print):
 previous=meta.get('previousReviewSourceSha256')
 if not previous:return {'status':'NO_PREVIOUS_CANDIDATE'}
 if not re.fullmatch('[0-9a-f]{64}',previous):raise RuntimeError('Invalid previous review identity')
 if (data/'BOOTSTRAP.json').exists():return {'status':'EXISTING_CURRENT_DATA_KEPT'}
 if data.exists() and any(data.iterdir()):return {'status':'NONEMPTY_CURRENT_DATA_KEPT'}
 old=state/previous[:20]/'review-data'
 if not (old/'BOOTSTRAP.json').is_file():return {'status':'NO_PREVIOUS_REVIEW_DATA'}
 if old.is_symlink() or any(p.is_symlink() for p in old.rglob('*')):raise RuntimeError('Previous review data contains symbolic links; originals preserved')
 if json.loads((old/'BOOTSTRAP.json').read_text()).get('schemas')!=schemas(source):raise RuntimeError('Previous review schema differs; originals preserved and no reset performed')
 files=[p for p in old.rglob('*') if p.is_file()]
 if sum(p.stat().st_size for p in files)>2*1024*1024*1024:raise RuntimeError('Previous review copy exceeds safe local staging size; originals preserved')
 progress('Copying compatible earlier review edits into this separate review. The original stays unchanged...')
 with tempfile.TemporaryDirectory(prefix='review-copy-',dir=data.parent) as temp:
  stage=Path(temp)/'review-data';shutil.copytree(old,stage)
  # Open only staged SQLite copies: even a read-only WAL connection may
  # update shared-memory sidecars. The previous candidate is never opened.
  for db in list(stage.rglob('*.sqlite')):
   backup=db.with_name(db.name+'.snapshot')
   staged=sqlite3.connect(db.as_uri()+'?mode=ro',uri=True)
   try:
    copy=sqlite3.connect(backup)
    try:staged.backup(copy)
    finally:copy.close()
   finally:staged.close()
   for suffix in ['-wal','-shm']:
    sidecar=Path(str(db)+suffix)
    if sidecar.exists():sidecar.unlink()
   os.replace(backup,db)
  report={'status':'COPIED_COMPATIBLE_REVIEW_DATA','previousSourceSha256':previous,'originalKept':True,'schemaHashesMatched':True,'sqliteBackupReadOnly':True,'sqliteBackupSource':'staged copy only; original SQLite databases never opened'}
  (stage/'REVIEW_DATA_INHERITANCE.json').write_text(json.dumps(report,indent=2)+'\n')
  if data.exists() and any(data.iterdir()):raise RuntimeError('New review data appeared during copy; no files were overwritten')
  os.replace(stage,data)
 return report
