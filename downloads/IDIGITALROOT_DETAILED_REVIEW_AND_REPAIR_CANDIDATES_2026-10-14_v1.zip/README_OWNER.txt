iDigitalRoot detailed review and repair candidates — 2026-10-14

Read REPORTS/DETAILED_REVIEW.md first. The edition architecture and complete student launch scope are in REPORTS. All 12 Toolbox tools and all 16 Workspace features are mandatory for the first commercial student release; they are NOT implemented by these previews.

To inspect the bounded website repairs, open WEBSITE_PREVIEW and double-click OPEN_WEBSITE_PREVIEW.cmd. To inspect the CMS repairs, open CMS_PREVIEW and double-click OPEN_CMS_PREVIEW.cmd. Extract the ZIP first. Use a new folder and stop older previews before opening their replacement, because the same local ports are reused. Keep each window open; press Enter to stop it. Existing Windows + Ubuntu/WSL is reused.

The website and CMS still use separate temporary sample databases. CMS edits do not update the separate website preview. No production login, API token, Cloudflare deployment or paid resource is needed.

These are separately labeled review candidates; the approved v4.3 website direction and approved CMS v1.5.3 are preserved. The full integrated release remains BLOCKED. Read each preview folder's guide for startup/log instructions.

SHA256SUMS.txt and RELEASE_MANIFEST.json seal this review set; each nested source ZIP also has its own checksums. No owner/HQ approval or production readiness is implied.
