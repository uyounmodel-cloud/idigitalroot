import puppeteer from '/workspace/idigitalroot-work/public-web/node_modules/puppeteer-core/lib/puppeteer/puppeteer-core.js';
import fs from 'node:fs';import os from 'node:os';
import {PHASE1B_ROUTES} from '/tmp/idigitalroot-preview-y71rti_i/source/.fe02-build/content/route-registry.js';
const OUT='/workspace/idigitalroot-audience-review/candidate-browser';console.log('Audit runner PID',process.pid);
const axe=fs.readFileSync('/workspace/idigitalroot-audience-review/audit-tools/node_modules/axe-core/axe.min.js','utf8');
const browser=await puppeteer.launch({executablePath:'/usr/bin/chromium',headless:true,userDataDir:fs.mkdtempSync('/tmp/idr-audience-chrome-'),args:['--no-sandbox','--disable-dev-shm-usage']});
const routes=[],workspaces=[],interactions=[],requests=[];
const inventory=()=>({title:document.title,lang:document.documentElement.lang,dir:document.documentElement.dir,overflow:document.documentElement.scrollWidth-innerWidth,heading:document.querySelector('h1')?.textContent,controls:[...document.querySelectorAll('button,a,input,select,textarea,summary,[role=button]')].map((e,i)=>({index:i,tag:e.tagName,label:(e.getAttribute('aria-label')||e.textContent||e.getAttribute('placeholder')||'').trim().slice(0,180),href:e.getAttribute('href'),type:e.getAttribute('type'),disabled:e.disabled===true,visible:!!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)&&!e.closest('[hidden]'),data:{...e.dataset},form:e.closest('form')?.id||null}))});
async function accessibility(p){await p.addScriptTag({content:axe});return p.evaluate(async()=>{const r=await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa']}});return {violations:r.violations.map(v=>({id:v.id,impact:v.impact,description:v.description,nodes:v.nodes.map(n=>({target:n.target,summary:n.failureSummary}))})),incomplete:r.incomplete.map(v=>({id:v.id,nodes:v.nodes.length})),passes:r.passes.length}})}
try{
 const cms=await browser.newPage();await cms.setBypassCSP(true);await cms.setViewport({width:1440,height:1000});const cmsErrors=[];cms.on('pageerror',e=>cmsErrors.push(e.message));
 await cms.goto('http://127.0.0.1:4198/',{waitUntil:'networkidle0'});await cms.click('#loginButton');await cms.waitForSelector('.sidebar');await cms.waitForNetworkIdle();
 const ids=await cms.$$eval('.sidebar [data-go]',es=>es.map(e=>e.dataset.go));
 for(const lang of ['en','ar']){await cms.click(`[data-ui-lang="${lang}"]`);for(const id of ids){await cms.click(`.sidebar [data-go="${id}"]`);await cms.waitForNetworkIdle();const row={workspace:id,locale:lang,...await cms.evaluate(inventory),accessibility:await accessibility(cms)};workspaces.push(row);console.log('CMS',lang,id,row.accessibility.violations.length);fs.writeFileSync(OUT+'/CMS_WORKSPACE_AUDIT.json',JSON.stringify({workspaces,runtime_errors:cmsErrors},null,2))}}
 fs.writeFileSync(OUT+'/CMS_WORKSPACE_AUDIT.json',JSON.stringify({workspaces,runtime_errors:cmsErrors},null,2));
 await cms.click('[data-ui-lang="en"]');
}finally{await browser.close()}
