# Reproduction

Use the exact nested source ZIPs and verify SHA-256/CRC and their SHA256SUMS first. The owner preview folders provide local-only launchers for existing Windows + Ubuntu/WSL. The launchers stage natively in /tmp, reuse exact Node versions when valid, bound setup steps, preserve logs and stop only their own children. Windows repair-launcher execution remains unverified until run there.

Frontend: Node 22.19.0; backend/CMS Node 22.16.0; npm 10.9.2; TypeScript 5.8.3; Chromium 154.0.8037.57 in these runs. Exact dependencies/locks are in source. Run scripts/run_closure.py from a fresh frontend extraction with --evidence-dir, --node, --backend-node and --browser pointing to these runtimes. It performs deterministic install/check/build, actual workerd and browser gates without deployment.

CMS: verify scripts/verify_package.py before creating generated files. The UI fixes do not change backend TypeScript or its compiled modules. With the pinned toolchain, run scripts/verify_all.py; the historical runner prints review markers that do not constitute owner acceptance. The main-focus assertion was updated for the keyboard-focusable main. The first whole run stopped at the old assertion; the corrected UI static and downstream integration/browser checks passed separately. All prior core/source/schema/parity checks passed before that stop.

Native browser audit scripts in REPORTS are cloud reproduction evidence and use explicit tool/source paths in this workspace; adapt those paths to fresh extracted fixtures and the pinned audit-tool lock. They are not owner installation dependencies. Audit coverage is explained in DETAILED_REVIEW.md. Automated accessibility uses test-only CSP bypass for injecting axe; normal workerd checks preserve CSP.

No remote account, raw API token or paid provider is needed for local fixtures. Existing Cloudflare identity checks are read-only. Actual provider/staging/security/QA/release acceptance and full owner workstation reproduction remain open.

An internal packaging cleanup removed a live launcher log directory during one verification attempt. That attempt failed with a missing log directory; it was a staging-orchestration mistake. The failure log is preserved separately. Cleanup was moved after launcher completion and the exact launcher was rerun. This is not a source/browser acceptance failure or a reason for owner debugging.
