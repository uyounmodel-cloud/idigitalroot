@echo off
echo Preparing the iDigitalRoot CMS repair candidate v1.5.4-r1. Progress appears below.
echo Keep this window open while reviewing the CMS. Press Enter afterward to stop.
wsl.exe --status > "%~dp0WINDOWS_WSL_STATUS.log" 2>&1
if errorlevel 1 (
  type "%~dp0WINDOWS_WSL_STATUS.log"
  echo WSL could not start. Send WINDOWS_WSL_STATUS.log so I can diagnose it.
  pause
  exit /b 1
)
wsl.exe --cd "%~dp0." -- python3 -u OPEN_CMS_PREVIEW.py
if errorlevel 1 echo Send CMS_PREVIEW_LOGS.zip, or WINDOWS_CMS_LAUNCH.log if no ZIP was created.
pause
