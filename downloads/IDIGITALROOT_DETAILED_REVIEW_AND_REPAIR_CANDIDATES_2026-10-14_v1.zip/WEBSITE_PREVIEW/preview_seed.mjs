// Synthetic local review data only. Reuse the approved code-owned presentation copy.
const {renderStaticRoute}=await import(pathToFileURL(path.join(ROOT,'.fe02-build/scripts/client.js')).href);
const {PHASE1B_ROUTES}=await import(pathToFileURL(path.join(ROOT,'.fe02-build/content/route-registry.js')).href);
const {parseFragment}=await import('parse5');
function previewCopy(p,l){const tree=parseFragment(renderStaticRoute(p,l));let heading='',lead='';function text(n){return n.nodeName==='#text'?n.value:(n.childNodes||[]).map(text).join('')}function walk(n){const cls=n.attrs?.find(a=>a.name==='class')?.value||'';if(n.tagName==='h1'&&!heading)heading=text(n);if(n.tagName==='p'&&/(?:^|\s)(?:lead|section-lead)(?:\s|$)/.test(cls)&&!lead)lead=text(n);for(const c of n.childNodes||[])walk(c)}walk(tree);return {heading:heading||'iDigitalRoot',lead};}
for(const l of ['en','ar']){
 const c=previewCopy('/',l),rid=`rev_preview_home_${l}`;publishEntity('ent_fixture_home',rid,l,{title:c.heading,lead:c.lead},2);
 db.prepare("INSERT INTO page_revision_sections SELECT section_row_id||'_preview',?,section_instance_id,component_family_id,ordinal,visible,variant_key,config_json,localized_content_json FROM page_revision_sections WHERE content_revision_id=?").run(rid,`rev_fixture_home_${l}_1`);
}
let previewId=0;
for(const p of PHASE1B_ROUTES){
 if(p==='/'||p.startsWith('/knowledge/')||(p.startsWith('/legal/')&&p!=='/legal/terms'))continue;
 let route=db.prepare("SELECT route_id FROM route_paths WHERE path=? AND locale_code='en' AND is_active=1").get(p),eid;
 if(route)eid=db.prepare('SELECT entity_id FROM content_entities WHERE route_id=?').get(route.route_id)?.entity_id;
 if(!eid){previewId++;const routeId=`rt_preview_${previewId}`;eid=`ent_preview_${previewId}`;
  db.prepare("INSERT INTO routes(route_id,route_key,route_kind,code_owned,created_at) VALUES(?,?,'SUPPORTING',1,?)").run(routeId,`preview.${previewId}`,now);
  db.prepare("INSERT INTO content_entities(entity_id,entity_type,stable_key,route_id,created_at) VALUES(?,'PAGE',?,?,?)").run(eid,`page.preview.${previewId}`,routeId,now);
  for(const l of ['en','ar'])db.prepare("INSERT INTO route_paths(route_path_id,route_id,locale_code,path,is_canonical,is_active,updated_by_actor_id,updated_at) VALUES(?,?,?,?,1,1,'actor_fixture_editor',?)").run(`rp_preview_${previewId}_${l}`,routeId,l,p,now);
 }
 for(const l of ['en','ar']){const c=previewCopy(p,l);publishEntity(eid,`rev_preview_${eid}_${l}`,l,{presentation:c,seo:{title:c.heading,description:c.lead}},2);}
}
// Library items and legal policy are explicitly synthetic, not owner-approved production content.
for(const l of ['en','ar'])publishEntity('ent_fixture_knowledge',`rev_preview_article_${l}`,l,{title:l==='ar'?'مقال نموذجي للمعاينة المحلية':'Sample article for local preview',summary:l==='ar'?'محتوى نموذجي لاختبار عرض المقالات.':'Sample content for checking the article layout.',body:l==='ar'?'<p>هذا محتوى نموذجي للمعاينة المحلية فقط.</p>':'<p>This is sample content for local preview only.</p>'},2);
for(const l of ['en','ar'])publishEntity('ent_legal_terms',`rev_preview_terms_${l}`,l,{title:l==='ar'?'الشروط — نموذج معاينة':'Terms — preview sample',body:l==='ar'?'نص نموذجي للمعاينة المحلية فقط، وليس سياسة منشورة.':'Sample text for local layout review only. This is not a published policy.'},2);
