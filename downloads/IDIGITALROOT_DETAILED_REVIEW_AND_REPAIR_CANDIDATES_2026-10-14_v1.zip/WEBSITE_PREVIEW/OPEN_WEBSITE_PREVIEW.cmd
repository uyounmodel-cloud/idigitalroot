@echo off
echo Preparing the iDigitalRoot website preview. Progress will appear below.
echo Keep this window open while browsing. Press Enter after browsing to stop.
wsl.exe --status > "%~dp0WINDOWS_WSL_STATUS.log" 2>&1
if errorlevel 1 (
  type "%~dp0WINDOWS_WSL_STATUS.log"
  echo WSL could not start. Send WINDOWS_WSL_STATUS.log so I can diagnose it.
  pause
  exit /b 1
)
wsl.exe --cd "%~dp0." -- python3 -u OPEN_WEBSITE_PREVIEW.py
if errorlevel 1 (
  echo Send PREVIEW_LOGS.zip, or WINDOWS_PREVIEW_LAUNCH.log if no ZIP was created.
)
pause
