#!/usr/bin/env python3
"""Owner local browser review of a sealed candidate; never deploys."""
from pathlib import Path, PurePosixPath
import argparse,hashlib,json,os,platform,posixpath,shutil,signal,socket,subprocess,sys,tarfile,tempfile,threading,time,urllib.request,urllib.error,zipfile,uuid
p=argparse.ArgumentParser();p.add_argument('--frontend-node');p.add_argument('--backend-node');p.add_argument('--no-open',action='store_true');p.add_argument('--test-seconds',type=int);a=p.parse_args()
root=Path(__file__).resolve().parent
class VisibleLog:
    def __init__(self,console,log):self.console=console;self.log=log
    def write(self,value):
        self.console.write(value);self.console.flush();self.log.write(value);self.log.flush();return len(value)
    def flush(self):self.console.flush();self.log.flush()
    def isatty(self):return self.console.isatty()
launch_log=(root/'WINDOWS_PREVIEW_LAUNCH.log').open('a',encoding='utf-8')
sys.stdout=VisibleLog(sys.stdout,launch_log);sys.stderr=VisibleLog(sys.stderr,launch_log)
print('\nStarting local preview preparation. Progress will appear below.',flush=True)
results=root/'PREVIEW_LOGS';results.mkdir(exist_ok=True)
run=results/(time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8]);run.mkdir()
meta=json.loads((root/'OPERATOR_MANIFEST.json').read_text());archive=root/meta['source_file']
stage=None;children=[];handles=[];status='FAIL';stop=threading.Event()
def requested_stop(*_):stop.set()
signal.signal(signal.SIGTERM,requested_stop);signal.signal(signal.SIGINT,requested_stop)
if hasattr(signal,'SIGHUP'):signal.signal(signal.SIGHUP,requested_stop)
def stop_child(child):
    if child.poll() is None:
        try:os.killpg(child.pid,signal.SIGTERM)
        except ProcessLookupError:pass
    try:child.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:os.killpg(child.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        child.wait()
def execute(name,cmd,cwd,env,timeout=300):
    print(name+'...',flush=True)
    begin=time.monotonic();notice=begin+15
    with (run/(name+'.log')).open('w') as f:
        child=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);children.append(child)
        while child.poll() is None:
            elapsed=time.monotonic()-begin
            if stop.is_set():stop_child(child);raise RuntimeError('Preview preparation was stopped; logs are saved.')
            if elapsed>=timeout:stop_child(child);raise RuntimeError(name+' exceeded its time limit; logs are saved for diagnosis.')
            if time.monotonic()>=notice:
                print(name+' is still running ('+str(int(elapsed))+' seconds).',flush=True);notice=time.monotonic()+15
            stop.wait(.2)
        rc=child.returncode;children.remove(child)
    if rc:raise RuntimeError(name+' failed. The saved logs will let me diagnose it.')
    print(name+' completed ('+str(int(time.monotonic()-begin))+' seconds).',flush=True)
def get_node(version,override=None):
    print('Preparing Node '+version+'...',flush=True)
    existing=override or shutil.which('node')
    if existing and subprocess.check_output([existing,'-p','process.versions.node'],text=True,timeout=10).strip()==version:
        print('Reusing existing Node '+version+'.',flush=True);return Path(existing).resolve()
    if override:raise RuntimeError('Specified Node runtime has the wrong version')
    arch={'x86_64':'x64','aarch64':'arm64'}.get(platform.machine())
    if not arch:raise RuntimeError('Unsupported Linux CPU architecture')
    name=f'node-v{version}-linux-{arch}.tar.xz';base=f'https://nodejs.org/dist/v{version}/'
    with urllib.request.urlopen(base+'SHASUMS256.txt',timeout=45) as r:sums=r.read().decode()
    expected=next(x.split()[0] for x in sums.splitlines() if x.endswith('  '+name))
    downloaded=stage/name
    print('Downloading verified Node '+version+' runtime...',flush=True)
    begin=time.monotonic();notice=begin+10;downloaded_bytes=0
    with urllib.request.urlopen(base+name,timeout=20) as r,downloaded.open('wb') as f:
        while True:
            if stop.is_set():raise RuntimeError('Runtime download stopped; logs are saved.')
            if time.monotonic()-begin>180:raise RuntimeError('Node runtime download exceeded three minutes; logs are saved.')
            chunk=r.read(256*1024)
            if not chunk:break
            f.write(chunk);downloaded_bytes+=len(chunk)
            if time.monotonic()>=notice:
                print('Node '+version+': '+str(downloaded_bytes//1048576)+' MB downloaded.',flush=True);notice=time.monotonic()+10
    if hashlib.sha256(downloaded.read_bytes()).hexdigest()!=expected:raise RuntimeError('Official Node download integrity mismatch')
    with tarfile.open(downloaded) as t:
        if hasattr(tarfile,'data_filter'):t.extractall(stage,filter='data')
        else:
            # Preserve safe extraction on the owner's older Ubuntu Python as well.
            for m in t.getmembers():
                n=PurePosixPath(m.name)
                if n.is_absolute() or '..' in n.parts or not (m.isfile() or m.isdir() or m.issym() or m.islnk()):raise RuntimeError('Unsafe Node archive entry')
                if m.issym() or m.islnk():
                    link=posixpath.normpath(posixpath.join(posixpath.dirname(m.name) if m.issym() else '',m.linkname))
                    if link.startswith('/') or link=='..' or link.startswith('../'):raise RuntimeError('Unsafe Node archive link')
            t.extractall(stage)
    return stage/name[:-len('.tar.xz')]/'bin/node'
try:
    if hashlib.sha256(archive.read_bytes()).hexdigest()!=meta['source_sha256']:raise RuntimeError('Sealed source archive checksum mismatch')
    for port in [4388,4399,4400]:
        with socket.socket() as s:
            s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
            try:s.bind(('127.0.0.1',port))
            except OSError:raise RuntimeError(f'Preview port {port} is occupied. No existing application was stopped.')
    stage=Path(tempfile.mkdtemp(prefix='idigitalroot-preview-',dir='/tmp'));source=stage/'source'
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:raise RuntimeError('Source ZIP CRC failure')
        for n in z.namelist():
            path=PurePosixPath(n)
            if path.is_absolute() or '..' in path.parts:raise RuntimeError('Unsafe source archive path')
        z.extractall(source)
    node=get_node('22.19.0',a.frontend_node);backend=get_node('22.16.0',a.backend_node);npm=str(backend.parent/'npm')
    original=os.environ.copy()
    env={**original,'PATH':str(node.parent)+os.pathsep+str(source/'node_modules/.bin')+os.pathsep+original['PATH'],'ASTRO_TELEMETRY_DISABLED':'1','WRANGLER_SEND_METRICS':'false','npm_config_cache':str(stage/'npm-cache')}
    execute('Verifying source files',['sha256sum','--check','SHA256SUMS.txt'],source,env)
    execute('Installing pinned dependencies',[npm,'ci','--engine-strict','--no-audit','--no-fund','--fetch-retries=1','--fetch-timeout=30000'],source,env,timeout=420)
    # Reuse the existing owner authentication read-only before building/testing.
    connection='UNVERIFIED'
    print('Checking existing Cloudflare identity read-only (up to 45 seconds)...',flush=True)
    try:
        identity=subprocess.run([str(node),str(source/'node_modules/wrangler/bin/wrangler.js'),'whoami'],cwd=source,env={**original,'PATH':str(node.parent)+os.pathsep+original['PATH'],'WRANGLER_SEND_METRICS':'false'},capture_output=True,text=True,timeout=45)
        text=identity.stdout+identity.stderr
        connection='UNAUTHENTICATED' if 'not authenticated' in text else 'AUTHENTICATED' if ('logged in' in text.lower() or 'account name' in text.lower()) else 'UNVERIFIED'
    except (OSError,subprocess.TimeoutExpired):pass
    print('Read-only identity check finished. Local preview preparation continues.',flush=True)
    (run/'cloudflare-read-only-status.json').write_text(json.dumps({'status':connection,'operation':'wrangler whoami only','login_performed':False,'provider_mutation_performed':False},indent=2)+'\n')
    env.update(XDG_CONFIG_HOME=str(stage/'config'),XDG_CACHE_HOME=str(stage/'cache'))
    (source/'.dev.vars').write_text('IDR_PUBLIC_API_BASE_URL="http://127.0.0.1:4388"\nIDR_PUBLIC_SITE_ORIGIN="http://127.0.0.1:4400"\n')
    execute('Checking the website',[npm,'run','check'],source,env)
    execute('Building the local website',[npm,'run','build'],source,env)
    execute('Checking frontend boundaries',[sys.executable,'scripts/check_worker_bindings.py'],source,env)
    be=source/'tests/authority/be01';beenv={**env,'PATH':str(backend.parent)+os.pathsep+str(source/'node_modules/.bin')+os.pathsep+original['PATH']}
    execute('Preparing local content service',[npm,'ci','--ignore-scripts','--no-audit','--no-fund','--fetch-retries=1','--fetch-timeout=30000'],be,beenv,timeout=120)
    execute('Verifying backend toolchain',[npm,'run','install:verify'],be,beenv)
    execute('Building local content service',[npm,'run','build'],be,beenv)
    execute('Preparing preview',[str(node),str(source/'node_modules/typescript/bin/tsc'),'-p','tsconfig.fe02.json'],source,env)
    # Only the synthetic preview fixture is extended. Sealed application source is unchanged.
    fixture=(source/'tests/integration-server.mjs').read_text();seed=(root/'preview_seed.mjs').read_text()
    marker='let failApi=false;';assert marker in fixture
    (source/'preview-fixture.mjs').write_text(fixture.replace(marker,seed+'\n'+marker))
    execute('Rechecking sealed source',['sha256sum','--check','SHA256SUMS.txt'],source,env)
    print('Starting the local website...',flush=True)
    for name,cmd,process_env in [('content',[str(backend),'preview-fixture.mjs'],beenv),('website',[str(node),'node_modules/.bin/astro','preview','--ignore-lock','--host','127.0.0.1','--port','4400'],env)]:
        log=(run/(name+'.log')).open('w');handles.append(log);children.append(subprocess.Popen(cmd,cwd=source,env=process_env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True))
    deadline=time.monotonic()+45
    while time.monotonic()<deadline and not stop.is_set():
        if any(c.poll() is not None for c in children):raise RuntimeError('A local preview service stopped')
        try:
            with urllib.request.urlopen('http://127.0.0.1:4400/',timeout=2) as r:body=r.read().decode();assert r.status==200 and 'Your ambition deserves' in body
            with urllib.request.urlopen('http://127.0.0.1:4400/ar',timeout=2) as r:body=r.read().decode();assert r.status==200 and 'dir="rtl"' in body
            break
        except Exception:time.sleep(.2)
    else:raise RuntimeError('Website preview did not become ready')
    status='PASS'
    (run/'READY.json').write_text(json.dumps({'status':'PASS','source_sha256':meta['source_sha256'],'fixture_profile':'Synthetic publications using approved code-owned presentation copy; not production content','deployment_performed':False,'provider_mutation_performed':False,'launcher_pid':os.getpid()},indent=2)+'\n')
    print('PREVIEW READY. The website is opening in your browser. Keep this window open.',flush=True)
    print('Sample content is used. Live inquiry submission and analytics are still unfinished.',flush=True)
    if not a.no_open:
        cmd=shutil.which('cmd.exe') or ('/mnt/c/Windows/System32/cmd.exe' if Path('/mnt/c/Windows/System32/cmd.exe').exists() else None)
        if cmd:
            try:
                opened=subprocess.run([cmd,'/c','start','','http://127.0.0.1:4400'],capture_output=True,timeout=15)
                if opened.returncode:print('Browser opening failed. The preview remains running; enter the local address below in your browser.',flush=True)
            except (OSError,subprocess.TimeoutExpired):print('Browser opening did not complete. The preview remains running; enter the local address below in your browser.',flush=True)
        else:print('See the installation guide for the local browser address.',flush=True)
    print('Local browser address: http://127.0.0.1:4400',flush=True)
    print(f'Preview launcher PID: {os.getpid()}. Press Enter here to stop the preview.',flush=True)
    if a.test_seconds is not None:stop.wait(a.test_seconds)
    else:
        def enter_to_stop():
            try:input();stop.set()
            except EOFError:pass
        threading.Thread(target=enter_to_stop,daemon=True).start()
        while not stop.wait(1):
            if any(c.poll() is not None for c in children):raise RuntimeError('A preview service stopped')
except Exception as e:
    status='FAIL';(run/'error.txt').write_text(str(e)+'\n');print('Preview could not start. Send PREVIEW_LOGS.zip so I can diagnose it; no debugging is needed from you.',flush=True)
finally:
    for c in reversed(children):stop_child(c)
    for f in handles:f.close()
    (run/'RESULT.json').write_text(json.dumps({'status':status,'source_sha256':meta['source_sha256'],'deployment_performed':False,'provider_mutation_performed':False},indent=2)+'\n')
    with zipfile.ZipFile(root/'PREVIEW_LOGS.zip','w',zipfile.ZIP_DEFLATED) as z:
        for f in run.rglob('*'):
            if f.is_file():z.write(f,f.relative_to(run))
    if stage:shutil.rmtree(stage)
    print('Preview stopped. Logs saved in PREVIEW_LOGS.zip.',flush=True)
sys.exit(0 if status=='PASS' else 1)
