# P1-FE-02 Changelog

Baseline: exact accepted FE-01 source SHA-256 `b2e65d6aff1a7b9799fd98b8fa61b39cc534be1fa63e16d11e8b6f29a6c09823`.

Sealed candidate: `56a0f1ed833676aa7f10a3f08a7774b81be119a45e0e69da79c3886e03c6f191`.

## Added

- `src/runtime-public.ts`: typed published-public API loader, publication validation, localization/SEO/ETag model, public navigation/footer/Knowledge/legal/inquiry-definition binding and safe text/URL rendering.
- `src/edge-worker.ts`: request-time public renderer with injected API/site origins, controlled 404/503 behavior and published validators.
- `tsconfig.fe02.json`: isolated deterministic TypeScript verification for the new request-time seam.
- deterministic BE-01 local integration authority under `tests/authority/be01`.
- `tests/integration-server.mjs`: accepted BE-01 + local SQLite publication integration server and update/draft/failure controls.
- `tests/browser_parity.py`: real-Chromium published-response regression checks.
- `scripts/verify_source.py` and `scripts/verify_candidate.py`.
- `P1-FE-02_READING_CHECKPOINT.md`.

## Changed

- `src/scripts/client.ts`: published-model overlay and locale/path hydration support while retaining the v4.3 interaction renderer; no browser API fetch, inquiry POST or analytics ingest added.
- `src/content/route-registry.ts`: NodeNext-compatible local import extension only.
- `README.md`: FE-02 scope and boundaries.

## Deliberately unchanged

- FE-01 `package.json`, `package-lock.json` and `.nvmrc` remain byte-identical to the accepted baseline.
- No schema migration was added or modified.
- No CMS UI/backend/provider resource was modified.

## Release limitation

This candidate is intentionally not declared ready because the official Astro Cloudflare on-demand adapter and clean Astro build cannot be verified in the current sandbox, and public media byte delivery is not defined by the supplied BE-01 boundary.
