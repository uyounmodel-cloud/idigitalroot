# P1-FE-02 Security, Cache and SEO Matrix

Sealed source SHA-256: `56a0f1ed833676aa7f10a3f08a7774b81be119a45e0e69da79c3886e03c6f191`.

| Area | Candidate state | Evidence / limitation |
|---|---|---|
| Public data boundary | PASS | `/api/public/v1` only; no CMS API and no frontend SQL/D1. |
| API origin configuration | PASS | `PUBLIC_API_BASE_URL` and `PUBLIC_SITE_ORIGIN` injected. |
| Draft/private fallback | PASS | Missing/unpublished/public-service failure fails closed. |
| Unknown components | PASS | Code-owned allowlist; unknown component rejects publication. |
| Text/attribute safety | PASS | Context encoding; no arbitrary raw HTML/JSON-LD execution. |
| URL safety | PASS | Relative or HTTPS allowlist; protocol-relative unsafe values rejected. |
| Path traversal | PASS | Rejects traversal, backslash, NUL and double-decode ambiguity. |
| ETag | PASS | Published revision/hash identity drives validator and 304. |
| Draft cache isolation | PASS | Public path never reads preview/draft data; failures are `no-store`. |
| SEO title/description | PASS | Typed published values only. |
| Canonical | PASS | Derived from injected public site origin + published route. |
| hreflang | PASS | Emitted only after independent route publication resolution. |
| Missing/private route | PASS | Controlled 404/noindex. |
| Live inquiry POST | PASS (absent) | Deliberately deferred to FE-03. |
| Browser analytics ingest | PASS (absent) | Deliberately deferred to FE-03. |
| Public media bytes | **OPEN** | No accepted BE-01 public delivery URL; direct R2 construction is prohibited. |
| Official Astro Cloudflare SSR | **OPEN** | `@astrojs/cloudflare` could not be installed/verified in this sandbox. |
| Provider mutation/deploy/spend | PASS (none) | No provider state was changed. |
