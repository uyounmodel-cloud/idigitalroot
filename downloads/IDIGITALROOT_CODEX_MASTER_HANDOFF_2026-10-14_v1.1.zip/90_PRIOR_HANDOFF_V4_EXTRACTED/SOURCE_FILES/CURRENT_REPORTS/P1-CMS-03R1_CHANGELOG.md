# P1-CMS-03R1 Changelog

## Scope rule

Bounded repair only: Headquarters F1–F4 plus directly affected contracts, tests, verifiers, generated build output, package metadata and internal checksums. No P1-CMS-03 UI wiring/redesign and no unrelated feature expansion.

## Returned version transitions

- CMS: P1-CMS-02 full CMS source `v1.4` candidate → repaired `v1.4.1`.
- Public backend: `v1.1` candidate → repaired `v1.1.1`.
- DATA-03: `v1.0` candidate → repaired `v1.1`.

## F1 — site design profile

CMS changes:

- `src/site-profile/idigitalroot/registry.ts`: added explicit registered IDs/token allowlists and exact semantic registry values used by validation/contracts.
- `src/core/approved-scope.ts`: strict nested design-profile schema/token validation; unsafe CSS/url/import/remote/script/event/expression patterns denied.
- Corresponding compiled `dist/` outputs rebuilt from those source edits.
- `tests/p1-cms-03.test.mjs`: exact HQ invalid payloads plus expanded allowlist/fail-closed cases and valid owner-profile acceptance.

## F2 — semantic product keys

CMS changes:

- `src/site-profile/idigitalroot/registry.ts`: exact ordered 9/12/3/5 semantic stable-key arrays.
- `src/core/approved-scope.ts`: product-presentation entitlement/functionality denial made recursive/fail-closed for nested mutation attempts.
- `tests/p1-cms-03.test.mjs`: exact key/order/uniqueness and `ensureProductRecords` coverage strengthened.

## F3 — external redirect policy

CMS changes:

- `src/site-profile/idigitalroot/registry.ts`: explicit empty external-host policy.
- `src/core/approved-scope.ts`: create/update share the strict external HTTPS host validation; internal PATH semantics preserved.
- `tests/p1-cms-03.test.mjs`: evil/unapproved external create/update rejection plus PATH status/loop/collision regression coverage.

Backend changes:

- `src/site-profile/config.ts`: explicit empty external redirect host list.
- `src/services/public-content.ts`: defense-in-depth external-host recheck before emitting `Location`.
- `tests/backend.test.mjs`: direct injected unapproved external redirect row must resolve fail-closed (404/no Location).
- Corresponding compiled `dist/` outputs rebuilt.

## F4 — D1 component registry parity

CMS/BE/DATA:

- Corrected `0016_http_redirect_and_final_registry_closure.sql` replaces the unaccepted candidate `0016` and is byte-identical across all three packages.
- Corrected 0016 SHA-256: `c503555f67999744331f509e2e7ce54b077b25033117e5623f5a2ca913690d48`.
- Adds active compatibility truth for `rich_text` and `cards`; keeps `retired_legacy` non-active/non-usable.
- No `0017+` migration added.

DATA changes:

- `tests/test_p1_cms03_integration.py`: exact active-set parity, `rich_text`, `cards`, and `retired_legacy` assertions strengthened.
- `SOURCE_MANIFEST.json` and `README.md`: repaired lineage/version/task metadata updated.

## Direct verifier/metadata updates

CMS:

- `scripts/verify_schema.py`
- `scripts/verify_source.py`
- `scripts/verify_all.py`
- `package.json`
- `package-lock.json`
- `README.md`
- `SHA256SUMS.txt` regenerated for final package bytes.

BE:

- `package.json`
- `package-lock.json`
- `README.md`
- `SHA256SUMS.txt` regenerated.

DATA:

- `README.md`
- `SOURCE_MANIFEST.json`
- `SHA256SUMS.txt` regenerated.

## Exact changed-path inventory versus untouched candidates

### CMS — 13 paths

1. `README.md`
2. `SHA256SUMS.txt`
3. `dist/core/approved-scope.js`
4. `dist/site-profile/idigitalroot/registry.js`
5. `package-lock.json`
6. `package.json`
7. `schema/core/migrations/0016_http_redirect_and_final_registry_closure.sql`
8. `scripts/verify_all.py`
9. `scripts/verify_schema.py`
10. `scripts/verify_source.py`
11. `src/core/approved-scope.ts`
12. `src/site-profile/idigitalroot/registry.ts`
13. `tests/p1-cms-03.test.mjs`

### BE — 10 paths

1. `README.md`
2. `SHA256SUMS.txt`
3. `dist/services/public-content.js`
4. `dist/site-profile/config.js`
5. `package-lock.json`
6. `package.json`
7. `schema/core/migrations/0016_http_redirect_and_final_registry_closure.sql`
8. `src/services/public-content.ts`
9. `src/site-profile/config.ts`
10. `tests/backend.test.mjs`

### DATA — 5 paths

1. `README.md`
2. `SHA256SUMS.txt`
3. `SOURCE_MANIFEST.json`
4. `core/migrations/0016_http_redirect_and_final_registry_closure.sql`
5. `tests/test_p1_cms03_integration.py`

## Explicitly unchanged

- Core `0001–0015`: byte-identical.
- Analytics `0001–0002`: byte-identical.
- CMS frozen UI files: byte-identical; no owner-approved v4.1 UI wiring or redesign.
- G-10 Vimeo/future providers: FUTURE_DEFERRED.
- G-14 role-bundle designer: POLICY_GATE.
- G-21 Root Check live scanner/scoring: FUTURE_DEFERRED.
- G-22 final legal/privacy/cookie override: POLICY_GATE.
- G-23 Lead/account schema editing via inquiry builder: POLICY_GATE.
- No deployment, provider-resource, credential or spend mutation.

## Final sealed hashes

- `IDIGITALROOT_P1-CMS-02_FULL_CMS_SOURCE_v1.4.1.zip` — `9da0b0174c6c5ce57b1ec8705ed0ca8119f57e7b269b145efffc242b03922239`
- `IDIGITALROOT_P1-BE-01_PUBLIC_BACKEND_SOURCE_v1.1.1.zip` — `781aa26489e39c2ce32096da18268bcdc5a763a601724ca7bb15e1d4f8f35ee9`
- `IDIGITALROOT_P1-DATA-03_CMS_INTEGRATION_SCHEMA_SOURCE_v1.1.zip` — `bc0e19b9a9240741b04e1085819164e3a6b6e75f91c059a77070c5c3be9068b6`

Full exact-sealed regression outcomes and R01–R50 evidence are recorded in the Result Report and Test Matrix.
