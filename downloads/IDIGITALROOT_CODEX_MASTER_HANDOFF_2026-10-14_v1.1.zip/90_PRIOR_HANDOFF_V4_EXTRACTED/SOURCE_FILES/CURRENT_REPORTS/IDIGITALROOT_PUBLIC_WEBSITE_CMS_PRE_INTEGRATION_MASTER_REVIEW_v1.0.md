# iDigitalRoot — Public Website CMS Pre-Integration Master Review v1.0

**Date:** 2026-10-02  
**Purpose:** exhaustive product/UI/architecture reconciliation before implementing the final CMS frontend and connecting it to the accepted backend, D1/R2, authentication, publishing and analytics cores.

## Executive decision

**Do not begin final CMS frontend ↔ backend/database integration until the owner approves the complete CMS UI/UX.**

The technically accepted CMS v1.3 remains useful as the service/security/data foundation, but its existing owner-facing UI was explicitly rejected. The correct path is therefore:

1. freeze the complete owner-approved CMS UI/UX;
2. create exact UI action → service/API → physical storage → permission/scope → audit → test traceability;
3. identify any real backend/schema gaps;
4. repair those gaps additively without rewriting accepted migrations;
5. implement the real CMS frontend on the accepted technical foundation;
6. connect it to Core D1/R2/Auth/Analytics;
7. run EN/AR/RTL/responsive/security/browser acceptance;
8. give the owner a second review of the real connected CMS;
9. only then proceed to later integrated Phase-1 release gates.

---

# 1. Sources reviewed

This review reconciled the following project sources instead of relying on the simplified prior prototype:

- owner-approved Public Website UI v4.3;
- P1-ARCH-01 Public Content and CMS contract;
- P1-AUTH-01 identity/session/authorization contract;
- P1-DATA-01R1 and P1-DATA-02 schema contracts;
- P1-EXT-01 advanced CMS / analytics / media-provider / reusable-core contract;
- P1-BE-01 public backend contract;
- P1-AN-01 first-party analytics contract;
- CMS technical implementation lineage through v1.3;
- Public Website Product & Technical Blueprint v1.0 Candidate;
- Public Website Lead / Inquiry Extension v1.1;
- Admin & Operations Dashboard Final Technical Blueprint v1.0;
- Cross-Platform Admin Control, Localization & Rich Media Extension v1.0;
- Full Solution Technical Architecture & Developer Blueprint Requirements v0.1;
- `cms blueprint v1.docx` for advanced DXP concepts, reviewed separately as older/generic input rather than current Phase-1 authority.

## Precedence rule

Later explicit iDigitalRoot decisions override older candidate implementation choices. The current Phase-1 authority is Cloudflare-first Astro/TypeScript + Workers/D1/R2, separate Public Website CMS, isolated future client CMS deployments, no public self-signup, no Git-based owner release workflow, no arbitrary executable CMS content, and no unapproved provider/spend/deployment assumptions.

---

# 2. Frozen Public Website the CMS must actually control

## Current primary Personal / Student routes

- `/`
- `/personal`
- `/students`
- `/student/toolbox`
- `/student/workspace`
- `/student/majors`
- `/not-a-student`

## Supporting route family

- `/why-idigitalroot`
- `/what-you-get`
- `/services`
- generated approved `/services/{slug}`
- `/how-we-build`
- `/knowledge`
- `/knowledge/insights`
- `/knowledge/guides`
- `/knowledge/digital-future`
- `/knowledge/research`
- `/knowledge/stories`
- `/knowledge/news`
- generated approved `/knowledge/{slug}`
- `/company/about`
- `/company/trust`
- `/contact`
- `/pricing`
- `/legal/terms`
- `/legal/privacy`
- `/legal/cookies`
- `/search`
- `/root-check`
- `/root-check/methodology`
- `/inquiry`
- generated eight inquiry-step routes
- `/inquiry/received`
- `/client-login`

Historical broad `/solutions/*` and `/blueprints/*` routes remain compatibility policy only. They must not allow the CMS to reintroduce the former broad Business/industry product direction as current Phase-1 offerings.

---

# 3. Exact frozen homepage composition

The CMS needs a dedicated Homepage Chapters workspace because the approved homepage is not a generic blank-canvas page.

The current code/profile-owned section IDs are:

1. `hero`
2. `student-problem`
3. `student-foundation`
4. `story`
5. `human-stories`
6. `three-experiences`
7. `roots`
8. `toolbox`
9. `student-workspace`
10. `student-benefits`
11. `my-dream`
12. `major-personalization`
13. `project-to-career`
14. `human-built`
15. `knowledge`
16. `not-student`
17. `proof`
18. `faq`
19. `final-cta`
20. `footer`

Additional registered visual/story blocks include the signature ticker, illustrative people stories and the brand manifesto.

Editors may change allowed localized copy, media, typed child records, approved variants, visibility and ordering only where the registered site profile allows it. They do not gain application-code editing.

---

# 4. Frozen structured product/content registries

## Personal Root

- Website
- Portfolio
- CV
- Digital Card
- QR Codes
- Links
- Achievements
- Contact
- Root Health

## Root Toolbox — 12 registered tools

1. CV Studio
2. Portfolio Builder
3. Digital Card
4. QR Studio
5. Link Hub
6. Achievement Kit
7. Career Kit
8. Email Signature
9. Project Share
10. Personal Brand Kit
11. Contact Card
12. Root Export

## Student Workspace

- University Life
- My Future
- Personal Growth

## Major presentation

- Architecture & Design
- Computer Science & Engineering
- Medicine & Health Sciences
- Business, Law & Humanities
- Every Other Major

Major changes presentation/emphasis, not product entitlement.

## Current managed-service records

- Professionally built website
- Your own domain
- Professional email
- Search & AI readiness
- Protection & monitoring
- Connected digital world
- Room to grow

The CMS edits approved public copy/status/relationships without changing stable technical meaning or inventing commercial promises.

---

# 5. Required final Public Website CMS workspaces

The final owner-facing CMS needs all of these workspaces or clearly equivalent navigation.

## Overview

1. Dashboard
2. Approved Scope / Coverage & Traceability
3. Frozen Website Map

## Website

4. Visual Website Editor
5. Homepage Chapters
6. Pages & Hierarchy
7. Sections & Components
8. Product Registries
9. Navigation & Footer
10. Typography & Appearance

## Content

11. Localization
12. Services & Pricing
13. Knowledge Center
14. SEO & Discovery
15. Public Search
16. Root Check
17. Inquiry Wizard
18. Legal & System Pages

## Media

19. Media Library
20. Imports & Embeds

## Publish & Measure

21. Publishing & Versions
22. Analytics
23. History & Audit

## Security & System

24. Users & Roles
25. Sessions & Security
26. Operations & Health
27. Site Settings

---

# 6. Required CMS capability inventory

## 6.1 Operator shell and UX

- professional contextual dashboard;
- full English CMS UI;
- full Arabic CMS UI;
- true RTL mirroring of the CMS itself;
- readable typography, not 7–10px engineering labels;
- permission-aware navigation;
- useful global/record search patterns;
- visible environment and publication status;
- human-readable conflicts/errors with recovery actions;
- responsive desktop/tablet/mobile CMS;
- keyboard/focus/accessibility support.

### Readability baseline for owner-facing UI

The final prototype increases the normal CMS UI scale to approximately:

- normal body/UI: 14–16px;
- navigation: 14–15px;
- form fields: 14px;
- labels: 12–13px;
- buttons: 13–14px;
- tables: 13–14px;
- module/page headings: 20–28px.

Arabic receives comparable or slightly larger typography where appropriate.

## 6.2 Visual editing of the frozen site

- actual public-site preview in the CMS;
- current page tree;
- desktop/tablet/mobile preview;
- EN/AR and future locale preview;
- click a visible section to edit it;
- show registered section/component identity;
- edit localized text and CTA labels;
- safe destination/reference picker;
- approved media picker;
- typed child-collection editing;
- approved visual variant selection;
- allowed show/hide/reorder;
- draft/save/conflict recovery;
- clean exact-revision preview;
- visible publication/revision state;
- direct version/history access.

## 6.3 Page/hierarchy lifecycle

Supported page classes include the frozen specialized routes plus safe generic supporting pages, landing pages, service pages, Knowledge pages, legal pages, system/error/maintenance content and approved custom marketing pages.

Actions:

- create;
- rename/internal title;
- duplicate;
- move parent;
- sibling reorder;
- localized title and slug/path;
- hide from navigation;
- preview;
- publish/unpublish;
- schedule;
- archive/restore;
- safe redirect-impact analysis;
- optimistic concurrency;
- search/filter/sort;
- registered bulk operations.

## 6.4 Section/component builder

General approved component families include:

- Hero;
- text block;
- rich HTML block;
- image;
- gallery;
- video/embed;
- CTA;
- feature cards;
- audience cards;
- service cards;
- registered presentation/card grids;
- pricing/comparison blocks;
- FAQ;
- testimonial only with truthful evidence;
- case study;
- statistic/metric only with evidence;
- process/timeline;
- downloadable resource;
- article/research feeds;
- contact block;
- approved custom block.

Current iDigitalRoot-specific registered families also include the Personal Root atlas, Root Toolbox, Student Workspace, Major Explorer, root-convergence/before-after composition, human stories, brand manifesto, managed-services presentation, Knowledge preview and final CTA/footer structures.

## 6.5 Rich text / source HTML

Required editing modes:

1. normal WYSIWYG/rich text;
2. source HTML for authorized content users;
3. trusted embed/HTML block under separate permission.

Security remains mandatory:

- server sanitizer;
- element allowlist;
- attribute allowlist;
- URL protocol allowlist;
- approved iframe/provider validation;
- CSP alignment;
- no `<script>`;
- no inline event handlers;
- no arbitrary executable CSS/JS;
- no application/server source editor.

## 6.6 Typography and font control

The owner previously required CMS control over website content, images and fonts, while production fonts remain licensed/self-hosted.

The final UI therefore includes a registered typography/design-profile workspace for:

- Latin UI/body font role;
- Latin serif/accent role;
- Arabic UI/body role;
- Arabic Kufi/display role;
- Arabic Naskh/editorial role;
- fallback stack;
- allowed weights;
- body size/line-height preset;
- heading scale;
- navigation size;
- EN/AR preview.

This is not arbitrary CSS editing. Layout algorithms, responsive behavior, motion and security-sensitive design tokens remain code-owned.

## 6.7 Header/navigation/mobile/footer

Manage independently where required:

- desktop primary navigation;
- Personal grouped menu;
- mobile navigation presentation;
- utility links;
- primary CTA;
- footer groups;
- legal links;
- localized labels;
- internal route refs;
- validated external HTTPS refs;
- order/nesting;
- optional dates/visibility;
- dangling-reference validation.

## 6.8 Localization

Architecture supports Admin-managed future locales without application redesign.

Launch locales:

- English LTR;
- Arabic RTL.

Locale registry:

- locale code;
- display/native name;
- direction;
- fallback;
- enabled surfaces;
- date/number/currency-format configuration where applicable;
- status/launch readiness.

Translation states:

- MISSING;
- DRAFT;
- NEEDS REVIEW;
- READY;
- PUBLISHED;
- OUTDATED;
- ARCHIVED.

Workspace requirements:

- source/target side by side;
- field-level status;
- missing/outdated filters;
- translation notes;
- copy-source starting point;
- direction-aware editing;
- locale preview;
- version history;
- per-locale publication;
- fallback visibility.

The CMS shell itself must also have a complete Arabic UI and true RTL mirroring. Arabic public-preview mode is not enough.

## 6.9 Services/pricing copy

A dedicated content workspace must cover the current registered public service records and pricing/scope explanatory copy.

No invented fixed price, unsupported free promise, guaranteed outcome or stale commercial classification may be inferred from empty CMS fields.

## 6.10 Knowledge Center

Content kinds:

- Insights;
- Guides;
- Digital Future;
- Research;
- Stories / Case Studies;
- News;
- FAQs.

Fields/relations include:

- title/summary;
- rich content / HTML;
- structured sections;
- truthful author/byline;
- source links;
- publication date;
- categories/tags;
- related audience;
- related service;
- relevant current product references;
- media/embed;
- downloadable files;
- SEO;
- locale variants;
- homepage feature flag;
- schedule;
- revision/history;
- archive/restore.

The CMS must not invent testimonials, research results, case-study outcomes, rankings, certifications or customer numbers.

## 6.11 SEO/discovery/redirects

Per page/locale:

- SEO title;
- description;
- canonical;
- robots/index state;
- follow/nofollow where allowed;
- Open Graph title/description/image;
- social preview;
- breadcrumb metadata;
- sitemap inclusion;
- approved structured-data configuration;
- hreflang consistency;
- preview.

Redirect manager:

- 301;
- controlled temporary redirects;
- source/destination;
- locale;
- active dates;
- loop/conflict detection;
- optional hit count;
- slug-change redirect prompt.

Editors do not paste arbitrary executable JSON-LD.

## 6.12 Public search

The current website includes `/search`.

Operator/CMS surfaces need:

- published-only indexed content families;
- locale coverage;
- search-index health;
- exclusions;
- error status;
- privacy-safe internal-search analytics.

Accepted Analytics does not retain raw internal visitor search text; it may use bounded classes and a keyed grouping token.

## 6.13 Root Check

Current Phase 1 permits the public concept/methodology surface but does not authorize pretending a live scanner exists.

CMS manages:

- Root Check public copy;
- methodology content;
- category labels/explanations;
- CTA;
- privacy explanation;
- example-result disclaimer;
- SEO/localization;
- capability status.

A future live scanner/scoring engine requires a separately accepted backend and methodology. No fake score.

## 6.14 Inquiry Wizard

Current public Lead flow is eight protected steps.

CMS-manageable presentation includes:

- wizard title/introduction;
- step labels;
- question labels;
- help text;
- registered option labels;
- validation-display copy;
- consent copy;
- review labels;
- confirmation copy;
- locale variants;
- contextual CTA labels;
- effective version metadata where allowed.

System-owned invariants include stable step/field IDs, protected current step sequence, backend validation, Lead state, idempotency/anti-abuse, no public self-signup and prohibition on credential/password harvesting.

## 6.15 Legal/system/error pages

Legal:

- Terms;
- Privacy;
- Cookies;
- versions/history;
- approval state;
- locale variants;
- publication gate.

System/error content:

- 404;
- public failure/500-safe content;
- maintenance;
- service unavailable;
- form failure;
- Root Check unavailable/timeout concept states where applicable.

## 6.16 Media manager

Supported classes include images, controlled SVG, PDFs/documents where approved, infographics and provider references/embeds.

Lifecycle:

- private intake;
- quarantine;
- validation;
- approved public state;
- rejected;
- archived.

Metadata includes title, localized title, alt, caption, credit/source, rights/license note, locale, tags/collection, dimensions/aspect ratio, size/MIME, source/provider, provenance, creator/time and usage/dependency map.

Actions include search/filter, managed upload, validation, replacement, archive and usage-map review. Current published dependencies must not be invalidated silently.

## 6.17 Providers/imports/embeds

Current approved model includes:

- Google Drive managed import;
- YouTube normalized/privacy-enhanced external embed;
- future registered providers such as Vimeo;
- controlled generic approved provider mode.

Provider registry surfaces name, mode, allowlisted hosts/patterns, sandbox, referrer policy, privacy mode, features/autoplay, CSP needs, active state and non-secret configuration.

No arbitrary browser-controlled outbound host/header fetch, provider password storage or raw access-token UI.

## 6.18 Publishing/versioning/preview/schedule/rollback

States:

- DRAFT;
- NEEDS REVIEW / REVIEW;
- SCHEDULED;
- PUBLISHED;
- UNPUBLISHED;
- ARCHIVED.

Actions:

- immutable revisions;
- compare;
- restore/rollback through new immutable event;
- exact revision/locale preview;
- publish selected locale;
- publish all ready locales;
- schedule publish;
- schedule unpublish where allowed;
- cancel schedule;
- unpublish;
- publication note/reason;
- audit;
- optimistic concurrency.

Publish revalidation includes route state, content schema, required localized content, media/provider state, SEO/canonical, legal/inquiry dependencies, concurrency, authorization and fresh-auth policy.

## 6.19 First-party analytics

The final CMS must surface all 11 accepted report families:

1. Overview
2. Content / routes
3. Acquisition
4. Audience technology
5. Coarse geography
6. Engagement / custom
7. Internal search
8. Inquiry funnel
9. Performance / Web Vitals
10. Public runtime health
11. Bot / abuse

Controls include date range, comparison, locale, route/content, referrer/campaign, device/browser/OS, language, viewport, coarse geography and permitted event/funnel dimensions.

Privacy/authorization boundaries:

- OFF / COOKIELESS / CONSENTED collection modes exist in core;
- final production policy mode remains an external legal/privacy gate;
- no raw IP;
- no full User-Agent;
- no precise location;
- no fingerprint;
- no Lead PII in Analytics;
- aggregate/raw/export/config permissions remain separate;
- raw/export access is audited.

## 6.20 Users/roles/permissions/scopes/sessions

CMS security/admin UI includes:

- actor state;
- invitations;
- activation/deactivation;
- external identity binding status;
- roles/permission bundles;
- global/locale/content scope;
- analytics permission separation;
- active sessions;
- revoke/logout-all;
- reauth/fresh-auth indicators;
- Access perimeter/session health;
- safe security/audit visibility.

Frontend visibility never replaces backend authorization.

## 6.21 Audit/history

Read-only permissioned history should cover editorial, translation, media, provider/import, publication, identity/roles, sessions/security, privileged analytics and system/config actions.

Important fields include actor, time, action, object/reference, request/correlation ID, safe before/after context and redacted evidence.

## 6.22 Operations/health

Operator UI should surface publication failures/blockers, scheduled jobs, provider/import jobs, media validation failures, analytics lag/health, sanitized runtime errors, bot/abuse aggregates and current release/build identity where safe.

It is not a secret-management or raw infrastructure console.

## 6.23 Reusable core/site-profile seam

The current CMS preserves the permanent design rule:

- generic CMS/backend core;
- iDigitalRoot site profile;
- registered components;
- locale registry;
- media/provider adapters;
- analytics registry;
- identity/storage seams.

Future client website CMS extraction uses independent deployments/data/media/security/config. The current CMS UI must not imply a shared tenant selector or unsafe multi-tenant runtime.

---

# 7. Older generic DXP ideas reviewed and deliberately not lost

The older `cms blueprint v1.docx` contained additional enterprise/DXP ideas. They were reviewed and are not forgotten, but they are **not silently promoted to current Phase-1 requirements** because they conflict with later architecture, introduce unapproved provider/cost dependencies, or were never explicitly adopted for the current product.

Deferred/future unless separately approved:

- CRDT real-time multiplayer editing;
- content-blueprint/template authoring beyond current registered page/component profiles;
- voice dictation;
- LLM rewrite/polish;
- smartwatch/AR/VR preview modes;
- AI media auto-tagging;
- perceptual-hash duplicate detection;
- native HLS/DASH streaming;
- asset-license expiry automation;
- AI taxonomy/topic clustering;
- automated external broken-link crawler;
- vector embedding/search dependencies;
- LLM search-intent classification;
- Google Search Console two-way sync;
- click/scroll heatmaps;
- anomaly detection/SMS alerts;
- native newsletter/email marketing engine;
- A/B personalization engine;
- translation memory/automatic translation;
- broad shared multi-tenant CMS runtime.

Explicitly superseded in the current iDigitalRoot architecture:

- PostgreSQL/Redis mandate for Phase 1;
- shared multi-tenant CMS runtime;
- Git-backed owner release workflow.

If any deferred capability is later wanted, it should receive an explicit owner decision, architecture/security/cost review, schema/service contract and test gate.

---

# 8. Why the previous CMS prototypes were insufficient

The earlier prototypes did not faithfully represent enough of the already-approved product and CMS contract. Missing or underrepresented areas included:

- full Arabic CMS chrome and true RTL mirroring;
- readable UI font sizes;
- frozen public route map;
- exact 20 homepage chapters;
- Personal Root / Toolbox / Workspace / Major registries;
- typography/font management;
- services/pricing content;
- public-search management;
- Root Check concept/methodology gating;
- legal/system/error-page management;
- complete translation states/workflow;
- deeper mobile/header/footer navigation management;
- explicit source-HTML safety UI;
- media rights/provenance/usage/dependency view;
- full provider-registry visibility;
- complete publication/unpublish/schedule/compare/rollback flow;
- all 11 analytics report families and privacy boundary;
- roles/scopes/sessions security surfaces;
- operations/health;
- explicit scope traceability;
- explicit record of advanced DXP ideas that are deferred/superseded rather than forgotten.

The final v4 owner-review prototype is built to correct these omissions before implementation work resumes.

---

# 9. Pre-integration traceability gate

Once the owner approves the final UI, Headquarters must produce a 1:1 matrix for **every visible action**:

**UI screen/action → service/API method → Core D1 / Analytics D1 / R2 physical record → permission → scope → validation/security → concurrency/idempotency → audit event → test evidence.**

For every action answer:

1. Which service owns it?
2. Which endpoint/service method executes it?
3. Which current physical table/object stores it?
4. Which permission is required?
5. Which scope is evaluated?
6. Which concurrency/idempotency rule applies?
7. Which audit event is written?
8. Which security validation applies?
9. Which integration/browser test proves it?
10. Is it already implemented physically, or does it require an additive repair/migration?

No visible button should be connected to a guessed backend.

---

# 10. Database rule before connection

The accepted schema history must not be discarded or rewritten.

- Core migrations `0001–0015` remain immutable.
- Analytics migrations `0001–0002` remain immutable.
- Compare the final approved CMS UI/action model against the current physical schema.
- Add migration(s) only for proven missing physical requirements.
- Any additive migration must pass fresh apply, exact upgrade, rerun/idempotency where applicable, FK/integrity checks and stable-ID regression.

This is not “build the database again.” It is a controlled physical-alignment pass after the complete UI is frozen.

---

# 11. Backend/service rule before connection

The accepted Auth, Backend, Analytics and CMS service cores remain the starting point.

Before wiring the final UI:

- inventory every current service/API method;
- map it to the approved UI;
- identify missing methods/endpoints;
- repair only real gaps;
- preserve accepted session/CSRF/RBAC/publication/media/privacy boundaries;
- use production-shaped D1/R2 paths in tests;
- never rely on MemoryStore-only success for production authority.

---

# 12. Owner approval gate

The owner must review the final CMS in both:

- **English UI**
- **Arabic UI with true RTL**

The review should cover all 27 workspaces listed above, especially visual editing, homepage chapters, frozen routes, fonts/typography, localization, media/providers, publishing, analytics and security.

Decision tokens:

- `OWNER_APPROVED_FOR_IMPLEMENTATION`
- `CHANGES_REQUIRED`

Only `OWNER_APPROVED_FOR_IMPLEMENTATION` unlocks final CMS frontend implementation/integration.

---

# 13. Recommended next sequence after owner approval

1. Freeze owner-approved CMS UI/UX HTML and this scope review.
2. Generate the exact UI/API/data/permission/audit/test matrix.
3. Run backend/schema physical-gap analysis.
4. Add only required additive migrations/service repairs.
5. Implement the real owner-approved CMS frontend.
6. Connect to Core D1, R2, Auth, Publication and Analytics.
7. Execute real-browser EN/AR/RTL/responsive/accessibility acceptance.
8. Execute authorization, CSRF, XSS, HTML/embed/media, IDOR, SSRF, audit and data-leakage tests.
9. Owner reviews the real connected CMS.
10. Continue the remaining public frontend/inquiry/analytics integration and Phase-1 release gates.

**Headquarters conclusion:** the product is not ready to begin final CMS UI/backend/database integration until the owner approves the complete final CMS UI. This deliberate stop prevents another implementation cycle built against an incomplete interface model.
