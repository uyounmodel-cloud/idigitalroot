# P1-FE-02 Browser Parity Report

Sealed source SHA-256: `56a0f1ed833676aa7f10a3f08a7774b81be119a45e0e69da79c3886e03c6f191`.

## Real Chromium candidate run

System Chromium (`/usr/bin/chromium`) executed the actual FE-01 HTML/CSS/client renderer populated from real local responses produced by the accepted BE-01 implementation. Because this sandbox blocks Chromium's direct localhost navigation, the harness obtains the exact local server HTML with the host process and injects that server response into Chromium; it does not replace page publication data with browser fixtures.

PASS evidence from the fresh candidate run:

- EN published home response and LTR.
- AR independently published response and RTL.
- Personal menu target integrity, open, Escape close and focus restoration.
- No core horizontal overflow at 1440, 768 and 390 on `/`, `/personal`, `/students`, `/student/toolbox`, `/student/workspace`, `/student/majors`; AR home also passes each width.
- `/client-login` remains truthful and has no password input/self-signup behavior.
- New published revision becomes visible in Chromium without frontend rebuild and changes ETag.
- Draft-only revision remains invisible and does not change ETag.
- Disabled Arabic publication returns controlled 404 without EN fallback.
- Backend unavailability yields controlled 503 state, not stale fixture content.
- zero uncaught Chromium runtime exceptions on the representative run.

## Not yet claimable

The full accepted FE-01 **built Astro preview** suite was not rerun on the sealed candidate because clean `npm ci` and Astro build cannot complete in this sandbox. Reduced-motion, the dedicated root before/after CTA geometry assertion and dedicated Arabic toolbox overlap assertion therefore remain explicit open gates rather than inferred PASSes.
