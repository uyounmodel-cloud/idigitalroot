# P1-CMS-04 EN / AR / RTL / Accessibility Report

## Result

**PASS**

## English UI
- Document language/direction switches to `lang=en`, `dir=ltr`.
- CMS sidebar is on the left.
- Visual editor uses tree-left / canvas-center / inspector-right.
- Real Chromium workflow PASS.

## Arabic UI
- Document switches to `lang=ar`, `dir=rtl`.
- Entire CMS shell mirrors RTL.
- CMS navigation sidebar is on the RIGHT.
- Visual-editor page tree is on the RIGHT.
- Visual-editor inspector is on the LEFT.
- Main forms, tables, action rows, dialogs and status presentation use logical RTL flow.
- CMS language is independent of the public preview locale.
- Representative Arabic dashboard/editor/localization/publishing workspaces pass 1440px no-overflow checks.

## Responsive verification
Representative heavy workspaces were checked in real Chromium at 1440, 1024, 768 and 390 pixels:
Dashboard, Visual Editor, Pages, Localization, Media, Publishing, Analytics and Users.

All passed the core horizontal-overflow gate.

## Accessibility implementation
- skip link;
- semantic main/sidebar/header structure;
- explicit labels;
- table column headers;
- visible `:focus-visible` styling;
- `aria-live=polite` async status region;
- modal `role=dialog`, `aria-modal=true`, labelled title;
- modal initial focus, Tab/Shift+Tab focus containment, Escape close and return-focus behavior;
- logical direction-aware focus flow;
- no browser runtime exceptions in Chromium acceptance.

## Typography
The rejected tiny engineering-shell typography was not retained. The connected CMS uses the owner-approved readable UI scale (general body/navigation/forms/tables materially larger than the prior 7–10px shell).

## Frozen owner requirement
Owner requirement “Arabic CMS panel on the right; full site right-to-left” is implemented and browser-verified.
