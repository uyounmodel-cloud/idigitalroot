# iDigitalRoot Public Website CMS — Owner Final UI Review Checklist

Open `IDIGITALROOT_PUBLIC_WEBSITE_CMS_FINAL_OWNER_REVIEW_v4.html`.

## Required review modes

1. Review the complete CMS in **English UI**.
2. Click **ع** in the top bar and review the complete **Arabic CMS UI**.
3. Confirm the sidebar moves to the right and normal forms/tables/text align naturally in RTL.
4. Open **Visual website editor**, then separately toggle the public-site preview between EN and AR.
5. Review Desktop / Tablet / Mobile preview modes.

## Workspaces to review

- Dashboard
- Approved scope map
- Frozen website map
- Visual website editor
- Homepage chapters
- Pages & structure
- Section builder
- Product registries
- Typography & appearance
- Localization
- Navigation & footer
- Services & pricing
- Knowledge Center
- SEO & discovery
- Public search
- Root Check
- Inquiry builder
- Legal & system pages
- Media library
- Imports & embeds
- Publishing & releases
- Analytics — all 11 report tabs
- History & audit
- Users & roles
- Sessions & security
- Operations & health
- Site settings

## Owner decision

Use exactly one:

`OWNER_APPROVED_FOR_IMPLEMENTATION`

or

`CHANGES_REQUIRED`

If changes are required, list them by workspace. We will modify the prototype before connecting any of this UI to the accepted backend/database.
