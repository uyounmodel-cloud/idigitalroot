# P1-CMS-03R1 Schema and Lineage Report

## Result

Schema/lineage closure: **PASS** for the bounded F4 correction and all immutable-lineage requirements.

## Candidate lineage pins

- Untouched CMS v1.4 candidate SHA-256: `5e0efeba09622f369ef9e4f0c1bed88f8df1fde332f626e5f41c9f555eaa5ac1`
- Untouched BE v1.1 candidate SHA-256: `08f6d53a399fdf719a935f68ae92c13660b25bc2682a7afd024ebfb73c74a214`
- Untouched DATA-03 v1.0 candidate SHA-256: `34b400711e1652d5987a15d1a04e0f2910913e34756c61b441ac9f05a712a4d6`

All three pins were verified before editing and F1–F4 were reproduced against those untouched bytes.

## Immutable migrations

Core migrations `0001–0015` remain byte-identical to the candidate lineage. Analytics migrations `0001–0002` remain byte-identical where present. A frozen pre-edit hash snapshot covered 52 immutable surfaces total:

- CMS: 15 Core migrations + 2 Analytics migrations + 3 frozen CMS UI files = 20 preserved surfaces.
- BE: 15 Core migrations = 15 preserved surfaces.
- DATA: 15 Core migrations + 2 Analytics migrations = 17 preserved surfaces.

Post-repair byte comparison: **52/52 identical**. The explicitly replaceable candidate `0016` is excluded from this immutable set by task authority.

## Corrected forward migration

`0016_http_redirect_and_final_registry_closure.sql` is the sole forward candidate migration. No migration `0017` or higher exists in any returned source package.

The corrected `0016` is byte-identical across CMS, BE and DATA:

`SHA-256 c503555f67999744331f509e2e7ce54b077b25033117e5623f5a2ca913690d48`

The existing redirect schema/trigger contract remains in place. The bounded F4 correction adds only the registry compatibility truth needed for exact active parity:

- `rich_text`: `code_registered=1`, active compatibility row, production D1 revision creation verified.
- `cards`: `code_registered=1`, active compatibility row.
- `retired_legacy`: `code_registered=0`, retained as non-active/non-usable compatibility marker.

## Active registry parity

Pre-repair reproduction:

- Active code keys: 46.
- Active D1 `code_registered=1` keys: 44.
- Code-only: exactly `cards`, `rich_text`.
- D1-only: none.

Post-repair fresh migration:

- Active code keys exactly equal active D1 `code_registered=1` keys.
- No unknown active D1 key exists.
- `rich_text` production D1 revision creation succeeds.
- `cards` is present as active parity truth.
- `retired_legacy` remains unusable/non-active.

## Migration verification

Exact sealed CMS fresh extraction reports:

- `CORE_FRESH_SCHEMA_PASS 16`
- `CORE_UPGRADE_0016_PASS`
- `ANALYTICS_SCHEMA_PASS 2`
- source-static verification of accepted migration hashes/closure guards PASS.

Exact sealed DATA fresh extraction reports **50/50 tests PASS**, including the strengthened P1-CMS-03 integration parity assertions.

## Returned schema-bearing package hashes

- CMS v1.4.1: `9da0b0174c6c5ce57b1ec8705ed0ca8119f57e7b269b145efffc242b03922239`
- BE v1.1.1: `781aa26489e39c2ce32096da18268bcdc5a763a601724ca7bb15e1d4f8f35ee9`
- DATA-03 v1.1: `bc0e19b9a9240741b04e1085819164e3a6b6e75f91c059a77070c5c3be9068b6`

All three returned ZIPs pass CRC/path safety, exact internal file-set validation, and internal `SHA256SUMS.txt` verification. No live D1/provider resource was mutated; all migration execution was local test/verification authority only.
