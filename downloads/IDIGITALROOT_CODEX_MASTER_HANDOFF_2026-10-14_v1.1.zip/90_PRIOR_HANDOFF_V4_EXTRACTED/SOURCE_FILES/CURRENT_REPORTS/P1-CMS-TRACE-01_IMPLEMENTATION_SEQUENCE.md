# P1-CMS-TRACE-01 — Implementation Sequence

**Planning only; this task performed no source/schema/provider/deployment mutation.**

## 0 — Preserve sealed baseline

Pin CMS v1.3, BE v1.0, AN v1.0, DATA-02, ARCH-01, EXT-01, AUTH-01 and owner-approved v4.1. Keep Core 0001–0015 and Analytics 0001–0002 byte-immutable. Preserve dedicated Public CMS separation and generic-core/site-profile split.

## 1 — Close code/profile registry mismatches

Additively register the owner-approved v4.1 component families and iDigitalRoot-only Personal Root/Toolbox/Workspace/Majors/homepage presentation records. Do not add executable authoring or alter public entitlement.

## 2 — Close existing-schema service gaps

Add bounded services over already accepted truth: bulk page operations, translator-authorized locale mutation, locale registry control, validated footer management, taxonomy term creation, inquiry-definition draft/version management, global publication queue/health reads, global settings mapping, service-record management, server-side audit filtering.

## 3 — Close schema-required gaps

Add new migrations after Core 0015 only for durable redirect semantics and a versioned site-wide design/typography profile if the final service design cannot safely use an existing versioned content/config model. Never edit migrations 0001–0015.

## 4 — Close public search

Implement published-only search/read/index behavior over accepted public entities, Knowledge and services; connect privacy-safe internal_search analytics without retaining raw visitor search text.

## 5 — Bind analytics production adapter

Implement the narrow CMS AnalyticsAdapter bridge to accepted P1-AN query/export/config functions using Analytics D1 + trusted Core D1 authorization/audit context. Do not expose raw analytics publicly.

## 6 — Wire frozen v4.1 UI

Replace prototype-only controls with the accepted APIs and newly closed additive services. Preserve EN LTR and full AR RTL: CMS nav panel right in Arabic, mirrored topbar/main flow, page tree right/inspector left, independent RTL public preview.

## 7 — Re-run security/concurrency acceptance

For each mutation: Access + local session + exact Origin + X-CSRF-Token; fresh auth where Tier-A/privileged contract requires; permission + object/locale scope; optimistic CAS/idempotency; audit evidence; negative tests.

## 8 — Keep gates truthful

Do not activate Vimeo/future providers without registered adapter/CSP approval; do not expose live Root Check scanner/scoring; do not self-open legal/privacy/cookie gates; do not permit role-bundle redesign unless a new authority explicitly changes the frozen system-managed role model.

## 9 — Final end-to-end closure

Execute browser EN/AR LTR/RTL coverage, all CMS/BE/AN/DATA suites, public published-only verification, media/R2 failure compensation, schedule/rollback/idempotency, analytics privacy tests, and exact visible-action trace recheck before deployment authority is considered.

