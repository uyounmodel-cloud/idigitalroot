# P1-CMS-04 Changelog

## v1.5 connected CMS frontend

- Replaced the accepted v1.4.1 engineering CMS shell with the complete owner-approved v4.1 connected CMS experience.
- Added modular frontend state, i18n, API client, error mapping, data layer and workspace modules.
- Added complete EN/AR CMS chrome and explicit full RTL mirror.
- Added real visual website editor backed by content/revision/preview services.
- Added real connected content/page/product/navigation/footer/localization/service/Knowledge/SEO/redirect/inquiry/settings actions.
- Added real connected media/provider/import actions.
- Added real publication/version/analytics/identity/security/audit/health actions.
- Added production session-establishment browser flow and LOCAL REVIEW protected fixture flow.
- Added memory-only CSRF handling and same-origin credentialed API client.
- Added human-readable service error mapping and service-first success behavior.
- Added local production-shaped Core D1, Analytics D1 and R2-compatible owner-review environment.
- Added accepted BE v1.1.1 and AN v1.0 compiled local-review adapters pinned inside the source package for offline owner review.
- Added P1-CMS-04 integration/static/browser acceptance tests.
- Added one-click Windows/WSL connected owner-review package.
- Changed owner-review bootstrap so the visual editor selects Home by default when present.

## Frozen technical authority preserved
- CMS backend/service source remains byte-identical to accepted v1.4.1 authority.
- Core migrations 0001–0016 unchanged.
- Analytics migrations 0001–0002 unchanged.
- BE v1.1.1 / DATA-03 v1.1 / AN v1.0 are not modified.
- No 0017+ migration.
- No deployment/provider/credential/spend mutation.
