# P1-CMS-03 API and Service Contract

## Common protected-CMS contract
All protected routes continue to require a validated Access principal, active matching D1 session/actor state and current D1 RBAC/scope. Mutations inherit exact Origin + `X-CSRF-Token` enforcement. Existing privileged/Tier-A fresh-auth rules remain; new global locale/settings/inquiry mutations explicitly require fresh auth. Generic error envelopes remain fail-closed.

## New/extended CMS surfaces
| Surface | Contract |
|---|---|
| `POST /api/cms/v1/bulk/pages` | Bounded 1–50 archive/restore targets; each target independently authorized and CAS checked; per-item result/audit. |
| content revision mutation | `translations.edit` may edit within matching locale/content scope without granting publication authority. |
| `GET/POST /api/cms/v1/locales`, `PATCH .../:locale` | Controlled locale metadata. New locale defaults public/cms/inquiry/publication flags off. |
| `POST /api/cms/v1/footer/:entityId` | Typed groups/links; active internal route validation + safe HTTPS/mailto validation; immutable revision/CAS/audit. |
| `POST /api/cms/v1/taxonomy` | Stable term creation with vocabulary, hierarchy/localization/slug validation; no destructive-delete API. |
| SEO mutation | Validated locale + `seo.edit` scope + expected row version; immutable revision. |
| `GET/POST /api/cms/v1/redirects`, `PATCH .../:id` | Locale/source/destination/status/active-window/row-version redirect management with conflict/loop guards and audit. |
| `POST /api/cms/v1/inquiry-definition/drafts` | Clones the accepted eight-step definition into a DRAFT and overlays only already-modeled step/field/option presentation keys. |
| `GET /api/cms/v1/publication/queue` | <=200 rows; actor content/locale scope constrained; schedule/state/validation/next-due evidence only. |
| analytics query/export/config | Production adapter bridge delegates accepted P1-AN query/export/config contracts; aggregate/raw/export/config permissions stay separate; worker writes Core audit for privileged raw/export/config operations. |
| `GET /api/cms/v1/audit` | Server-side allowlisted actor/action/target/date/correlation/order filters; <=500. |
| `GET /api/cms/v1/operations/publication-health` | Sanitized schedule + media/import blocker aggregation. |
| global copy/runtime config | Only `site-brand-contact-social`, `site-design-profile` and code-declared non-secret boolean runtime keys. |
| product presentation | Exactly 9 Personal Root, 12 Toolbox, 3 Student Workspace and 5 Major stable records; presentation only, no entitlement/functionality mutation. |
| services | Typed list/read/create/update/archive over `SERVICE` + `service_records`; no default price or guaranteed outcome. |

## Public backend additions
`GET /api/public/v1/search` normalizes and bounds the locale-aware query, reads only publication-pointer-authoritative public PAGE/KNOWLEDGE_ARTICLE and AVAILABLE SERVICE truth, returns deterministic safe fields, and performs no search-query write. Only privacy-safe result-count/query-length classes are exposed for the accepted `internal_search` analytics event contract.

`GET /api/public/v1/route` retains canonical resolution and, on canonical miss, may emit a real 301/302/307/308 response from active `http_redirects`. Internal redirect destinations resolve only when the final canonical content is currently published; invalid/unpublished/looped chains fail closed.

## Deliberately unavailable
Vimeo/future providers (G-10), role-bundle redesign (G-14), Root Check live scanning/scoring (G-21), ordinary-CMS legal gate override (G-22), and Lead/account schema editing (G-23) remain unavailable.
