# FAILURES, CORRECTIONS AND LESSONS

## 1. Do not confuse technical acceptance with owner-facing UX acceptance
The original CMS could pass service/browser tests and still fail as a usable CMS. The owner explicitly rejected the engineering shell. The correction was a separate visual owner-approval gate before final wiring.

## 2. Packaged tests are not sufficient proof by themselves
P1-CMS-03 reported 105/105 PASS, but Headquarters independently found four real defects. Later work must include negative/adversarial/source-level review beyond merely rerunning the candidate's own verifier.

## 3. Semantic equality matters, not count-only checks
The product registry bug passed because tests only checked counts 9/12/3/5. Repairs now assert exact stable semantic keys matching owner-approved product records.

## 4. Security/content configuration must use strict registered tokens
Design-profile fields initially accepted arbitrary values/CSS-like fallback strings. The repair established strict code-owned allowlists.

## 5. Redirects need a destination trust policy
HTTPS alone did not make an external redirect safe. Current external redirect allowlist is fail-closed/empty unless explicit authority adds a trusted host.

## 6. Code/database registry parity must be exact
`rich_text` and `cards` existed in active code but not D1 registry. Compatibility rows were added and exact parity tests were created.

## 7. Owner should not be the debug operator
Several local launcher rounds exposed environment/path/Node-shell issues. Future owner packages should be self-contained, one-click/bounded and repaired by Headquarters if they fail.

## 8. Avoid using fresh chats as a technical courier workflow
A P1-CMS-04 execution chat was blocked by a generic cybersecurity safety UI after long processing. Headquarters then took over the task directly. This is now a workflow rule: use fresh chats only when genuinely necessary, not as routine orchestration.

## 9. Keep policy/future gates truthful
Root Check live scoring, role-bundle redesign, future providers, final legal copy and protected Lead/account internals must remain visibly gated rather than simulated.

## 10. Do not rebuild accepted migrations casually
Core 0001–0015 and Analytics 0001–0002 remained immutable; corrected 0016 was accepted before UI wiring. Later work should add only explicitly authorized additive migrations.

## 11. Public frontend work is not complete merely because CMS is advanced
FE-02 still has real build/adapter/media-delivery/visual-regression blockers. CMS progress must not be used to claim the public frontend is finished.
