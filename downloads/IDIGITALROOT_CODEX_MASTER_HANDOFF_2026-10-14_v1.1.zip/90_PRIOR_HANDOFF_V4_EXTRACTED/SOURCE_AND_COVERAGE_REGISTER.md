# SOURCE AND COVERAGE REGISTER

## Classification legend
- **DIRECT_FULL_READ** — content directly read in this handoff build.
- **DIRECT_EXECUTED** — exact artifact was executed/verified in this handoff build.
- **PRESERVED_CURRENT** — copied byte-for-byte and hash-verified; not every nested file was re-read in this pass.
- **INHERITED_PRIOR_READ** — prior handoff documented direct inspection; preserved here, not fully re-read now.
- **RECONSTRUCTED** — narrative reconstructed from accessible conversation/artifacts; not verbatim.
- **MISSING/INACCESSIBLE** — mentioned but original bytes/transcript unavailable.

## Direct current evidence
- `P1-CMS-04_RESULT_REPORT.md` — DIRECT_FULL_READ.
- `P1-CMS-04_CHANGELOG.md` — DIRECT_FULL_READ.
- `P1-CMS-04_EN_AR_RTL_ACCESSIBILITY_REPORT.md` — DIRECT_FULL_READ.
- `P1-CMS-04_VISUAL_AND_WORKFLOW_ACCEPTANCE.md` — DIRECT_FULL_READ.
- `IDIGITALROOT_P1-CMS_FINAL_CONNECTED_SOURCE_v1.5.zip` — PRESERVED_CURRENT + DIRECT_EXECUTED via fresh `python scripts/verify_all.py`.
- `IDIGITALROOT_P1-CMS_OWNER_REVIEW_CONNECTED_v1.0.zip` — PRESERVED_CURRENT; archive listing/README inspected.
- `P1-FE-02_RESULT_REPORT.md` — DIRECT_FULL_READ.
- `P1-FE-02_SECURITY_CACHE_AND_SEO_MATRIX.md` — DIRECT_FULL_READ.
- `P1-FE-02_BROWSER_PARITY_REPORT.md` — DIRECT_FULL_READ.
- `P1-CMS-03R1_RESULT_REPORT.md` and schema evidence — DIRECT/accessible current evidence; preserved.
- latest handoff request — exact uploaded text preserved.

## Prior handoff and foundational sources
The entire 2026-09-28 handoff ZIP is preserved intact. Its README/Master/Current/Requirements/Decisions/Chronology/Failures/Open Items/Source Register/Conflicts/Verification/Product/CMS brief/visual acceptance were directly read during this handoff build via the archive.

Key technical blueprints are extracted again under `SOURCE_FILES/FOUNDATIONAL_FROM_PRIOR_HANDOFF/` for convenient access. Their current classification is **INHERITED_PRIOR_READ / PRESERVED**, because this handoff build did not fully re-read every line of every older blueprint; the prior handoff documents its own inspection boundary.

## Current accepted/sealed source packages included but not fully re-read here
- ARCH-01, AUTH-01, DATA-01R1, DATA-02, EXT-01, BE v1.1.1, AN v1.0, DATA-03 v1.1, CMS backend v1.4.1, TRACE result — PRESERVED_CURRENT.
- FE-01 v1.1 source — PRESERVED_CURRENT.
- FE-02 candidate/task — PRESERVED_CURRENT; main result evidence directly read.

## Reconstructed conversation records
- Prior reconstructed record from 2026-09-28 handoff — inherited reconstruction.
- `CURRENT_PROJECT_RECONSTRUCTED_RECORD_2026-09-28_TO_2026-10-06.md` — RECONSTRUCTED.

## Missing/inaccessible material
- Complete all-chat verbatim export — MISSING.
- Original binary `IDIGITALROOT_FULL_HANDOFF_RELEASE_2026-09-23_POST_STAGE9C_v2.0.zip` — historically inaccessible; textual recovery preserved in prior handoff.

## Governing precedence
Later explicit owner decisions and accepted repairs supersede earlier drafts. Exact current source hashes and owner-approved UI artifacts govern implementation. Prior handoff/blueprints remain historical and requirements authority only where not superseded.
