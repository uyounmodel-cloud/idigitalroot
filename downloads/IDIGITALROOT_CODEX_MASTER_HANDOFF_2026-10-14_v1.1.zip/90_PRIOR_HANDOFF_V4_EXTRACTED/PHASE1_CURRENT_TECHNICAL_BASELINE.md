# PHASE 1 CURRENT TECHNICAL BASELINE

## Governing UI hashes
- Public website v4.3: `d10b1cff47d5912fecb49d88579971f3e21bb19a33b179e29356ea0eac5646fd`.
- CMS UI v4.1: `7f7e099e3c525b27dd8ee285410ad0a9ce71c5055d845219c40a8501f8ee60cf`.

## Current service/data sources
- CMS backend v1.4.1: `9da0b0174c6c5ce57b1ec8705ed0ca8119f57e7b269b145efffc242b03922239`.
- BE v1.1.1: `781aa26489e39c2ce32096da18268bcdc5a763a601724ca7bb15e1d4f8f35ee9`.
- DATA-03 v1.1: `bc0e19b9a9240741b04e1085819164e3a6b6e75f91c059a77070c5c3be9068b6`.
- AN v1.0: `22d144914828c9e6503b03d0bac63c3b13aadd970ffe5dde4727943787cea86a`.

## Current connected CMS candidate
- Connected source v1.5: `f5ddf328ce38613ed5fa7a59b638ba7a8057d66a41f7e436f979507ec27e96e9`.
- Connected owner-review v1.0: `a960e886c11ac9391659fabcbc7b03e338138d37e81080cf72cc8e46d513ae62`.

## Stack
- Public frontend: Astro + TypeScript; official Cloudflare adapter still needs FE-02 closure.
- CMS/backend: Cloudflare Worker-oriented TypeScript service layer.
- Core D1: migrations 0001–0016.
- Analytics D1: migrations 0001–0002.
- R2: managed media object storage model.
- Cloudflare Access: perimeter identity assertion for protected CMS; app-owned D1 actor/session/RBAC remains authoritative.
- EN LTR / AR RTL.

## CMS connected local-review boundary
P1-CMS-04 local review uses production-shaped local Core D1, separate local Analytics D1, local R2-compatible media fixture, accepted CMS logic, accepted BE public search/inquiry, accepted AN report/query/export/config, deterministic local Drive adapter and local protected-login fixture only in LOCAL REVIEW MODE.

## Frozen security rules
- same-origin mutation protections;
- exact CSRF header contract;
- memory-only frontend CSRF;
- no browser persistence of session/CSRF/provider secrets;
- no arbitrary provider host/iframe/HTML/script/CSS/SQL;
- media private intake/quarantine before approval;
- strict component registry;
- strict design-profile token allowlists;
- external redirect host policy fail-closed unless explicitly approved;
- audit and immutable publication/versioning rules.

## Migration rule
Do not edit accepted migrations retroactively. P1-CMS-03R1 accepted corrected 0016 as current lineage. No 0017+ exists in current connected source. Any future schema need requires a separately authorized additive migration.
