# OPEN ITEMS AND NEXT STEPS

## Immediate — do this first
### 1. Independent Headquarters adjudication of P1-CMS-04
Use the exact connected source v1.5 and current reports. Verify more than the candidate's own test suite. At minimum confirm:
- backend/service source and migration lineage truly unchanged;
- frontend action coverage is real and no fake-success/dead mutation paths exist;
- EN/AR direction and Arabic panel placement are correct;
- connected local fixtures exercise production-shaped boundaries;
- owner-review package is pinned to exact source bytes;
- no hidden production/provider mutation authority was introduced.

Possible HQ result: PASS or bounded repair required.

### 2. Owner connected CMS review if HQ passes
Use:
`SOURCE_FILES/CURRENT_CONNECTED_CMS/IDIGITALROOT_P1-CMS_OWNER_REVIEW_CONNECTED_v1.0.zip`

Owner workflow:
1. extract to Windows folder;
2. double-click `START_CONNECTED_CMS_REVIEW.cmd`;
3. keep terminal open;
4. browser opens `http://127.0.0.1:4177/`;
5. click **Sign in with local protected fixture**;
6. inspect EN and AR CMS, especially Visual Website Editor;
7. return one decision: `OWNER_APPROVED_CONNECTED_CMS`, `CHANGES_REQUIRED`, or `BLOCKED_LOCAL_REVIEW`.

If launcher fails, Headquarters repairs it; do not make owner debug.

## After connected CMS owner approval
3. Freeze the approved connected CMS source and owner-review evidence.
4. Resume P1-FE-02 bounded repair from exact candidate v1.0.
5. Close official Astro Cloudflare adapter, public media delivery seam, clean build and full built-preview regression.
6. Implement/close FE-03 live inquiry submission and browser analytics according to accepted contracts.
7. Run integrated security review P1-SEC-01.
8. Run integrated QA P1-QA-01.
9. Prepare staging/release P1-REL-01.
10. Obtain explicit staging/production/provider/credential/spend authority before mutations.
11. Deploy and verify staging; then production only after explicit owner release approval.

## Later phases after Phase 1 is actually closed
- Phase 2 Admin & Operations Dashboard.
- Phase 3 Personal Client Portal.
- Phase 4 independent reusable client Website CMS template.
