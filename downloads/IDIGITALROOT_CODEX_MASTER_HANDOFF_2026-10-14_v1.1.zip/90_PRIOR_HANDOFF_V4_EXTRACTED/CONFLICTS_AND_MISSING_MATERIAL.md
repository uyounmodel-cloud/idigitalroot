# CONFLICTS AND MISSING MATERIAL

## Historical binary gap
The prior handoff documents a historical artifact:
`IDIGITALROOT_FULL_HANDOFF_RELEASE_2026-09-23_POST_STAGE9C_v2.0.zip`.
Its original binary bytes were not available in the current runtime. The preserved 2026-09-28 handoff includes textual recovery and explicitly does not claim byte-level inspection of its nested archives.

## Conversation export gap
No complete verbatim export of all iDigitalRoot chats was available. The current release includes:
- exact uploaded latest handoff request;
- preserved prior handoff conversation reconstruction;
- a new current-project reconstructed record.

The reconstructed record is evidence-linked narrative, not a verbatim transcript.

## P1-CMS-04 formal verdict gap
The exact connected source v1.5 verifier was rerun successfully during this handoff build. Nevertheless, the conversation has not yet recorded a separate formal Headquarters acceptance verdict after an independent source-level/adversarial adjudication of P1-CMS-04. Treat it as **READY FOR HQ REVIEW**, not accepted/deployed.

## Connected owner-review gap
The owner has not yet personally reviewed the real connected CMS package v1.0. Owner product/visual acceptance of the connected implementation is therefore open.

## FE-02 open technical gaps
FE-02 remains NOT READY. Current documented blockers:
1. clean dependency install/Astro build reproducibility;
2. official `@astrojs/cloudflare` on-demand/SSR adapter closure;
3. accepted public media-delivery seam without frontend direct R2 construction;
4. full built-Astro visual regression on exact sealed bytes.

## Production policy gaps
Still separate/open:
- final Terms/Privacy/Cookies legal approval;
- numeric retention/legal-basis/deletion-exception decisions;
- production analytics/privacy mode;
- production provider credentials/resources;
- production Access/D1/R2/Worker bindings/secrets;
- spend/plan/entitlement authorization;
- final production release authority.

## Older blueprint conflicts / superseded assumptions
Older generic sources contained architecture/product ideas that later current authority superseded or deferred, including broad Business/industry product scope, some earlier stack assumptions, Git-oriented workflows and generic advanced DXP concepts. Later owner-approved Personal/Student scope and accepted Phase 1B contracts govern when they conflict.
