# PUBLIC WEBSITE AND FRONTEND STATUS

## Owner-approved public presentation
Current approved UI/content direction is v4.3, SHA-256 `d10b1cff47d5912fecb49d88579971f3e21bb19a33b179e29356ea0eac5646fd`.

## FE-01
Accepted Astro/TypeScript presentation foundation v1.1. Current preserved source in this handoff:
`SOURCE_FILES/FE_CURRENT/IDIGITALROOT_P1-FE-01_ASTRO_SOURCE_v1.1_LOCAL_CANDIDATE.zip`
SHA-256 `b2e65d6aff1a7b9799fd98b8fa61b39cc534be1fa63e16d11e8b6f29a6c09823`.

## FE-02
Current candidate:
`IDIGITALROOT_P1-FE-02_PUBLIC_FRONTEND_SOURCE_v1.0.zip`
SHA-256 `56a0f1ed833676aa7f10a3f08a7774b81be119a45e0e69da79c3886e03c6f191`.

Formal candidate status: **NOT READY FOR HQ REVIEW**.

What the candidate proves:
- public data comes through `/api/public/v1` only;
- no CMS API or frontend SQL/D1 access;
- EN/AR publication behavior demonstrated through accepted BE local responses;
- draft invisibility and ETag behavior demonstrated;
- controlled 404/503 behavior;
- representative Chromium parity and menu/accessibility behavior;
- live inquiry POST and browser analytics deliberately deferred.

Open blockers:
1. fresh `npm ci` / Astro build could not be proven in the prior sandbox because required package cache/network was unavailable;
2. official `@astrojs/cloudflare` SSR/on-demand adapter not installed/verified;
3. public media byte delivery seam not accepted/available without direct frontend R2 construction;
4. full built-Astro visual regression on exact sealed candidate bytes remains open.

## FE-03
Not completed. Intended later scope includes live public inquiry submission and browser analytics ingest under accepted contracts.

## Deployment
No production public-site deployment has been performed or authorized by the current handoff.
