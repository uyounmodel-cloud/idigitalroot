# REQUIREMENTS AND USER RULES

## Product and quality
- Deliver a complete working solution, not a design-only release presented as finished software.
- Public website should feel like a serious global digital company, not a cheap student portal.
- Students are the first commercial audience, not the only future Personal audience.
- All students receive the same complete root/toolbox; major affects presentation, not entitlement.
- Keep a non-student inquiry door open without publishing internal roadmap language.
- Business iDigitalRoot is a separate future product.
- Do not attack LinkedIn or promise jobs/scholarships/rankings/outcomes.
- No public self-signup; inquiry remains human-reviewed Lead intake.

## Architecture and execution
- Phase order: Public Website + dedicated CMS → Admin Dashboard → Client Portal → reusable client Website CMS template.
- Dedicated Public Website CMS stays separate from future Admin.
- Generic reusable CMS/backend core + iDigitalRoot site profile.
- Later client websites use isolated deployments/data/media/security/config, not unsafe shared multitenancy.
- Cloudflare-first stack: Astro/TypeScript frontend, Workers, D1, R2 unless later explicit authority supersedes.
- No Git in owner release workflow.
- No plugins.
- Use immutable ZIP/SHA-256 packages and fail-closed tests.

## Language/UI
- English LTR.
- Arabic must be native-quality RTL.
- CMS Arabic mode mirrors the entire shell; sidebar on the right.
- Arabic visual editor page tree right, inspector left.
- CMS language and public-preview language independent.
- Production fonts licensed/approved/self-hosted.
- Avoid tiny engineering-shell typography.

## CMS/security/content
- No arbitrary executable script/CSS/SQL/unsafe embeds.
- Sanitize rich HTML.
- Registered provider allowlists/CSP.
- Permission-aware publishing and server-side authorization.
- Stable IDs; visible labels are not authority keys.
- Media quarantine/validation/finalization.
- Exact-version preview, publication history, rollback and audit where approved.
- Do not invent analytics numbers, pricing, testimonials, certifications or scores to fill empty UI.

## Owner workflow preference
- Headquarters should do the technical work.
- Owner should mainly review/approve or run one bounded local launcher when genuinely needed.
- Do not make the owner debug assistant mistakes.
- Do not repeatedly send the owner to fresh chats as a courier.
- If a launcher fails, repair it rather than asking the owner to troubleshoot.
- Instructions should be simple and exact.

## Approval boundaries
- Do not claim deployed/accepted/production unless evidence proves it.
- Production provider/Cloudflare mutations, credentials, spend/plan changes and final release require explicit authority.
- Legal/privacy/retention/production analytics mode remain separate policy gates until explicitly closed.
