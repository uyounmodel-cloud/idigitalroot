# Package Index

- `00_START_HERE/` — governing transfer instructions, current ledger and master Codex prompt.
- `01_CURRENT_IMPLEMENTATIONS/` — newest exact source/review/test packages and owner-approved UI authorities.
- `02_FOUNDATIONAL_BLUEPRINTS/` — prior product/technical blueprints for the full solution.
- `03_SYSTEM_DEFINITIONS/` — consolidated definitions of all six systems and cross-system boundaries.
- `04_SECURITY/` — mandatory high-assurance security baseline, threat model method, gates and matrix.
- `05_DELIVERY_ROADMAP/` — current-to-future execution sequence and release definitions.
- `06_CODEX_TASK_PROMPTS/` — ready-to-use Codex prompts per phase/system.
- `07_REFERENCE_EVIDENCE/` — screenshots showing the professional CMS presentation reached during repair.
- `90_PRIOR_HANDOFF_V4_EXTRACTED/` — full extracted prior handoff evidence as of 2026-10-06.
- `91_ORIGINAL_HANDOFF_ARCHIVE/` — immutable prior handoff ZIP + continuation prompt.

The files under `00_START_HERE` through `06_CODEX_TASK_PROMPTS` supersede the prior handoff only where they explicitly record post-2026-10-06 decisions/current artifacts. Otherwise use the prior handoff for chronology and accepted evidence.
