# Codex Task Prompt — Continue P1-FE-02

Use only after the master read checkpoint.

> Continue iDigitalRoot Phase 1 from the exact `IDIGITALROOT_P1-FE-02_PUBLIC_FRONTEND_SOURCE_v1.1.1_CANDIDATE.zip`. First independently verify the source, accepted UI authority and backend contracts. Treat `IDIGITALROOT_P1-FE-02R1_LOCAL_CLOSURE_v1.7.zip` as a test operator/evidence source, not as automatic proof of PASS. Reproduce the clean install/build under a Linux environment with network access, run the official Cloudflare adapter/workerd path, run the real browser acceptance, diagnose any failure yourself, and make only bounded repairs that preserve the approved v4.3 public UI/content direction and frozen backend/data authority. Do not deploy. Return a sealed candidate + hash + manifest + test/security matrices + exact PASS/FAIL verdict. Only claim `PUBLISHED_FRONTEND_BINDING_READY_FOR_HQ_REVIEW` if every required gate passes again from a fresh extraction of the exact sealed bytes.
