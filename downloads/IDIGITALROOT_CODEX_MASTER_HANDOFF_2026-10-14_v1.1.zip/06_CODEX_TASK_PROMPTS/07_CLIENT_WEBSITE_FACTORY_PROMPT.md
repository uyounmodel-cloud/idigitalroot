# Codex Master Prompt — Create a New Client Public Website

Use this only after the reusable Client Website CMS and generic public runtime are accepted.

> You are creating one new iDigitalRoot-managed client website using the approved Client Website CMS/runtime. First read the capability catalog, site-profile schema, security baseline and deployment template. Then ask for only the missing client-specific inputs: business/site identity, target audiences, goals/conversion actions, required pages, languages, brand assets/style, content availability, supported modules/functions, provider integrations, legal/privacy needs and SEO requirements. Do not invent unsupported capabilities.
>
> Produce and obtain approval for a concise site product brief and IA before implementation. Create the site profile, CMS content schemas, allowed components/design tokens, localized routing and public renderer configuration. Do not add arbitrary JS/CSS/embed/provider behavior. Keep the client site's deployment, data, media, secrets, auth, audit and backups isolated from every other client site.
>
> Build a professional responsive accessible website connected only through the supported CMS/public contracts. Run threat-model/security gates, EN/AR or requested locale tests, RTL where applicable, accessibility, responsive/browser, SEO/schema, performance, media, form/integration abuse tests and exact-version publish/preview tests. Produce a bounded owner review. After approval, seal immutable source + site profile + CMS package + manifest/checksums + SBOM/provenance + deployment/config checklist. Never deploy without explicit authority for that exact client/environment.
