from pathlib import Path
import tempfile,json,sqlite3,hashlib
from review_data import adopt_previous,schemas
import argparse
p=argparse.ArgumentParser();p.add_argument('--source',required=True);args=p.parse_args();b=Path(tempfile.gettempdir());source=Path(args.source).resolve();oldsha='6e409c00e4e4122343276b44dae9b838967cf1050a054b74caccf5f3960b3811';meta={'previousReviewSourceSha256':oldsha};checks=[]
def check(name,fn):
 fn();checks.append({'name':name,'status':'PASS'})
def digest(folder):return {str(p.relative_to(folder)):hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.rglob('*') if p.is_file()}
with tempfile.TemporaryDirectory(dir=b,prefix='inheritance-test-') as temp:
 state=Path(temp);data=state/'new/review-data';data.mkdir(parents=True);old=state/oldsha[:20]/'review-data';old.mkdir(parents=True)
 check('No previous data is created or reset',lambda:None if adopt_previous(state,source,data,meta)['status']=='NO_PREVIOUS_REVIEW_DATA' else (_ for _ in []).throw(AssertionError()))
 (old/'BOOTSTRAP.json').write_text(json.dumps({'schemas':schemas(source)}));(old/'state').mkdir();db=sqlite3.connect(old/'state/test.sqlite');db.execute('CREATE TABLE preserved(value TEXT)');db.execute("INSERT INTO preserved VALUES('Earlier private draft')");db.commit();db.close();(old/'state/private-media.txt').write_text('Local media bytes');before=digest(old)
 result=adopt_previous(state,source,data,meta,lambda _:None);assert result['status']=='COPIED_COMPATIBLE_REVIEW_DATA';db=sqlite3.connect(data/'state/test.sqlite');assert db.execute('SELECT value FROM preserved').fetchone()[0]=='Earlier private draft';db.execute("UPDATE preserved SET value='New candidate edit'");db.commit();db.close();assert digest(old)==before
 check('Compatible SQLite/media copied; original byte inventory stays unchanged',lambda:None)
 before_new=digest(data);assert adopt_previous(state,source,data,meta)['status']=='EXISTING_CURRENT_DATA_KEPT' and digest(data)==before_new;check('Restart preserves current candidate edits',lambda:None)
 other=state/'mismatch/review-data';other.mkdir(parents=True);(old/'BOOTSTRAP.json').write_text(json.dumps({'schemas':{'different':{}}}))
 try:adopt_previous(state,source,other,meta);raise AssertionError('Mismatch accepted')
 except RuntimeError:pass
 assert not any(other.iterdir());check('Schema mismatch fails without touching destination',lambda:None)
 (old/'BOOTSTRAP.json').write_text(json.dumps({'schemas':schemas(source)}));(old/'unsafe-link').symlink_to('/tmp')
 try:adopt_previous(state,source,other,meta);raise AssertionError('Symlink accepted')
 except RuntimeError:pass
 assert not any(other.iterdir());check('Symbolic links rejected without copying',lambda:None)
 (other/'KEEP.txt').write_text('Existing user data');assert adopt_previous(state,source,other,meta)['status']=='NONEMPTY_CURRENT_DATA_KEPT';assert (other/'KEEP.txt').read_text()=='Existing user data';check('Nonempty new data is never overwritten',lambda:None)
 (old/'unsafe-link').unlink()
 wal=sqlite3.connect(old/'state/wal.sqlite');wal.execute('PRAGMA journal_mode=WAL');wal.execute('CREATE TABLE latest(value TEXT)');wal.execute("INSERT INTO latest VALUES('Committed WAL draft')");wal.commit()
 wal_before=digest(old);wal_dest=state/'wal-copy/review-data';wal_dest.mkdir(parents=True);adopt_previous(state,source,wal_dest,meta,lambda _:None)
 copied=sqlite3.connect(wal_dest/'state/wal.sqlite');assert copied.execute('SELECT value FROM latest').fetchone()[0]=='Committed WAL draft';copied.close();assert digest(old)==wal_before;wal.close();check('Committed WAL copied without opening or changing any original sidecar bytes',lambda:None)
with tempfile.TemporaryDirectory(dir=b,prefix='inheritance-priority-') as temp:
 state=Path(temp);latestsha='3d6f8d50510dbe0502c677995f87cf074412a3524528bba07cc81036d3aeb463';candidates={'previousReviewSourceSha256':latestsha,'previousReviewFallbackSha256':[oldsha]}
 for sha,label in [(oldsha,'older'),(latestsha,'latest')]:
  folder=state/sha[:20]/'review-data';folder.mkdir(parents=True);(folder/'BOOTSTRAP.json').write_text(json.dumps({'schemas':schemas(source)}));(folder/'content.txt').write_text(label)
 data=state/'new/review-data';data.mkdir(parents=True);adopt_previous(state,source,data,candidates,lambda _:None);assert (data/'content.txt').read_text()=='latest';check('Latest release data takes priority; separate older edits are not merged',lambda:None)
 fallback=state/'fallback/review-data';fallback.mkdir(parents=True);candidates['previousReviewSourceSha256']='0'*64;adopt_previous(state,source,fallback,candidates,lambda _:None);assert (fallback/'content.txt').read_text()=='older';check('Known older release fallback works when latest review data is absent',lambda:None)
with tempfile.TemporaryDirectory(dir=b,prefix='horizon-lineage-') as temp:
 state=Path(temp);lineage=['3d6f8d50510dbe0502c677995f87cf074412a3524528bba07cc81036d3aeb463','f3d374b3e2922ffa355d21b0bbb3432302221d0481415be82cf4a2d0a4b46bdf',oldsha]
 meta={'previousReviewSourceSha256':lineage[0],'previousReviewFallbackSha256':lineage[1:]}
 for index,sha in enumerate(lineage):
  folder=state/sha[:20]/'review-data';folder.mkdir(parents=True);(folder/'BOOTSTRAP.json').write_text(json.dumps({'schemas':schemas(source)}));(folder/'draft.txt').write_text(str(index))
 for index in range(3):
  dest=state/('target-'+str(index))/'review-data';dest.mkdir(parents=True);result=adopt_previous(state,source,dest,meta,lambda _:None);assert result['previousSourceSha256']==lineage[index] and (dest/'draft.txt').read_text()==str(index);(state/lineage[index][:20]/'review-data'/'BOOTSTRAP.json').unlink()
 check('Actual Clarity then Studio then rc9 lineage priority and both fallbacks preserve the correct edits',lambda:None)
report={'status':'PASS','checks':checks,'providerMutation':False,'deployment':False};print(json.dumps(report,indent=2))
