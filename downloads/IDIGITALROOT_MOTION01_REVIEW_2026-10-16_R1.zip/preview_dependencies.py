"""Verify and install sealed preview dependencies without registry access."""
from pathlib import Path, PurePosixPath
import hashlib,json,os,posixpath,shutil,stat,tarfile,tempfile,time,uuid

def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()

def ready_install(source,lockhash):
 try:
  stamp=json.loads((source.parent/'DEPENDENCIES.json').read_text())
 except (OSError,ValueError):return False
 if stamp.get('lockSha256')!=lockhash or stamp.get('npm')!='10.9.2':return False
 needed=['typescript/bin/tsc','astro/bin/astro.mjs','wrangler/bin/wrangler.js','esbuild/bin/esbuild']
 return all((source/'website/node_modules'/p).is_file() for p in needed)

def relative(name):
 p=PurePosixPath(name)
 if p.is_absolute() or '..' in p.parts or '\\' in name or not p.parts or p.parts[0]!='node_modules':raise RuntimeError('Unsafe dependency archive path')
 return p

def inside_link(name,target,hard=False):
 if not target or target.startswith('/') or '\\' in target:raise RuntimeError('Unsafe dependency archive link')
 value=posixpath.normpath(target if hard else posixpath.join(posixpath.dirname(name),target))
 relative(value)
 return value

def verify_tree(root,manifest,stop,progress):
 expected=set();notice=time.monotonic()+15
 for item in manifest['files']:
  p=relative(item['path']);expected.add(p.as_posix());file=root.joinpath(*p.parts)
  if stop.is_set():raise RuntimeError('Dependency preparation stopped')
  if item['type']=='symlink':
   if not file.is_symlink() or os.readlink(file)!=item['target']:raise RuntimeError('Dependency link verification failed: '+item['path'])
  elif item['type']=='file':
   if file.is_symlink() or not file.is_file() or file.stat().st_size!=item['bytes'] or digest(file)!=item['sha256']:raise RuntimeError('Dependency file verification failed: '+item['path'])
   if item.get('executable') and not os.access(file,os.X_OK):raise RuntimeError('Dependency executable permissions are missing: '+item['path'])
  else:raise RuntimeError('Unknown dependency manifest entry')
  if time.monotonic()>=notice:progress('Verifying bundled dependency files...');notice=time.monotonic()+15
 actual=set()
 for folder,dirs,files in os.walk(root/'node_modules',followlinks=False):
  for name in files+dirs:
   p=Path(folder)/name
   if p.is_file() or p.is_symlink():actual.add(p.relative_to(root).as_posix())
 if actual!=expected:raise RuntimeError('Dependency archive file inventory differs from its manifest')
 return len(expected)

def install_bundle(root,source,meta,stop,progress):
 bundle=meta['offlineDependencies'];archive=root/bundle['file'];index=root/bundle['manifest']
 if digest(source/'website/package-lock.json')!=bundle['lockSha256'] or digest(source/'website/package.json')!=bundle['packageSha256']:raise RuntimeError('Offline dependencies do not match the sealed source lock')
 progress('Verifying bundled dependency archive (no npm registry download)...')
 if not archive.is_file() or digest(archive)!=bundle['sha256']:raise RuntimeError('Bundled dependency archive checksum failed; extract the complete recovery ZIP')
 if digest(index)!=bundle['manifestSha256']:raise RuntimeError('Bundled dependency manifest checksum failed')
 manifest=json.loads(index.read_text())
 if manifest['lockSha256']!=bundle['lockSha256']:raise RuntimeError('Dependency manifest lock binding is invalid')
 if shutil.disk_usage(source.parent).free<bundle['expandedBytes']+64*1024*1024:raise RuntimeError('Not enough free native WSL space to stage the verified dependencies')
 with tempfile.TemporaryDirectory(prefix='dependency-stage-',dir=source.parent) as temp:
  stage=Path(temp)
  with tarfile.open(archive,mode='r:xz') as t:
   members=t.getmembers()
   if len(members)>50000 or sum(m.size for m in members)>750*1024*1024:raise RuntimeError('Dependency archive exceeds release limits')
   seen={};symlinks=set()
   for m in members:
    name=relative(m.name).as_posix()
    if name in seen:raise RuntimeError('Duplicate dependency archive path')
    if not (m.isfile() or m.isdir() or m.issym() or m.islnk()):raise RuntimeError('Unsupported dependency archive entry')
    if m.issym():inside_link(name,m.linkname);symlinks.add(name)
    if m.islnk():
     target=inside_link(name,m.linkname,True)
     if target not in seen or not seen[target].isfile():raise RuntimeError('Dependency hard link does not reference an earlier regular file')
    seen[name]=m
   for name in seen:
    if any(p.as_posix() in symlinks for p in PurePosixPath(name).parents):raise RuntimeError('Dependency archive traverses a symbolic-link directory')
   progress('Extracting verified dependencies into native WSL storage...')
   if hasattr(tarfile,'data_filter'):t.extractall(stage,filter='data')
   else:t.extractall(stage)
  count=verify_tree(stage,manifest,stop,progress)
  target=source/'website/node_modules';backup=None
  if target.exists() or target.is_symlink():
   backups=source.parent/'dependency-backups';backups.mkdir(exist_ok=True);backup=backups/(time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8]);target.rename(backup)
  try:(stage/'node_modules').rename(target)
  except BaseException:
   if backup and not target.exists():backup.rename(target)
   raise
 result={'strategy':'SEALED_LINUX_X64_DEPENDENCIES','registryDownloadRequired':False,'archiveSha256':bundle['sha256'],'manifestSha256':bundle['manifestSha256'],'verifiedFiles':count,'previousInstallPreserved':backup is not None,'lockSha256':bundle['lockSha256'],'npm':'10.9.2'}
 stamp=source.parent/'DEPENDENCIES.json';temp=stamp.with_name(stamp.name+'.'+uuid.uuid4().hex+'.tmp');temp.write_text(json.dumps(result,indent=2)+'\n');temp.replace(stamp)
 progress('Pinned dependencies ready; npm registry download was not needed.')
 return result
