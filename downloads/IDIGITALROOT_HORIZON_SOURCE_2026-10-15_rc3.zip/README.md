# iDigitalRoot / Horizon 01 review source

Current owner direction: a visibly new enterprise futuristic public website and a much simpler CMS, preserving content/distribution and domain capabilities. Clarity was not accepted. Read docs/HORIZON_OWNER_GUIDE.md, HORIZON_CHANGE_REPORT.md, HORIZON_SECURITY_REVIEW.md and HORIZON_READING_CHECKPOINT.md first. Earlier restoration-only instructions are historical. Original approvals remain preserved in docs/AUTHORITY_REGISTER.md; they do not approve these changed bytes.

This is an unaccepted Phase 1 local review candidate, not deployed or production-ready. Production is Cloudflare Workers with server-side D1/private R2. Owner Windows+Ubuntu/WSL remains frozen. Core0001–0016 and Analytics0001–0002 are unchanged. No provider mutation/spend is authorized. Admin/Client phases remain unopened; Toolbox/Workspace demos are not operational services.

For technical acceptance use a new extraction and fresh isolated test data: scripts/run-native.py --frontend-node <Node22.19.0> --backend-node <Node22.16.0> --data-dir <NEW_EMPTY_DATA> --evidence-dir <NEW_EVIDENCE> --install --verify --full-browser. Exact pins/lock, reproduction and open external/manual/independent gates remain in docs/REPRODUCTION.md and security matrices. Never reset owner review data for testing. Owner-friendly installation is in the outer review package.
