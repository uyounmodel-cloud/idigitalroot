import {boundedBytes} from './bounded-response.js';
import {PHASE1B_ROUTES} from './content/route-registry.js';
import { renderLiveInquiry } from './live-inquiry.js';
import { EDITOR_COMPONENTS, COMPONENT_ALIASES, renderPublishedSection } from './published-components.js';
import { bindEditorialFields, bindSectionMedia, bindPublishedRecords, composePublishedHome, localizePublishedLinks, replacePublishedRegion, sanitizePublishedProse } from './published-markup.js';
export type Locale='en'|'ar';
export interface PublicEnvelope<T>{ok:true;data:T;requestId:string}
export interface PublicRoute{routeId:string;path:string;entityId:string;locale:Locale}
export interface PublicSection{id:string;component:string;ordinal:number;variant?:string|null;config:Record<string,unknown>;content:Record<string,unknown>}
export interface PublicMedia{media_id:string;media_kind:string;source_class:string;detected_mime?:string;width_px?:number;height_px?:number;title?:string;alt_text?:string;usage_role?:string}
export interface PublicEntity{entity:{id:string;type:string;key:string;locale:Locale;revisionNumber:number;availability?:string;content:Record<string,unknown>};sections:PublicSection[];media:PublicMedia[];version:{pointer:number;contentHash:string;publishedAt:string}}
export interface PublishedPageModel{locale:Locale;path:string;route:PublicRoute;page:PublicEntity;navigation?:PublicEntity;footer?:PublicEntity;knowledge?:unknown;knowledgeIndex?:unknown;legal?:PublicEntity;inquiryDefinition?:unknown;presentation?:{features?:{inquiry:boolean;knowledge:boolean;search:boolean};records:{key:string;type:string;content:Record<string,unknown>;version:unknown}[]};etag:string;canonical:string;alternates:{locale:Locale;href:string}[]}

const COMPONENTS=new Set([...EDITOR_COMPONENTS,'hero','student-problem','student-foundation','story','human-stories','three-experiences','roots','student-benefits','toolbox','student-workspace','my-dream','major-personalization','project-to-career','human-built','knowledge','not-student','proof','faq','final-cta','footer','signature-ticker','illustrative-people-stories','brand-manifesto','route-hero','content','service-list','knowledge-list','knowledge-detail','legal-document','inquiry-wizard']);
const SAFE_URL=/^(?:\/|https:\/\/)/i;
export function safeText(v:unknown,max=8000){return typeof v==='string'?v.slice(0,max):''}
export function safeUrl(v:unknown){const s=safeText(v,2048);if(!s||/[\x00-\x20\\]/.test(s)||s.startsWith('//'))return '';if(/^mailto:[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s))return s;try{const u=new URL(s,'https://public.invalid');return ['https:'].includes(u.protocol)&&!u.username&&!u.password?s:''}catch{return ''}}
function sanitizePublicMedia(media:unknown):PublicMedia[]{
 if(!Array.isArray(media))return [];
 return media.map((raw:any)=>({
  media_id:safeText(raw?.media_id,160),media_kind:safeText(raw?.media_kind,40),source_class:safeText(raw?.source_class,40),
  detected_mime:safeText(raw?.detected_mime,120)||undefined,width_px:Number.isFinite(Number(raw?.width_px))?Number(raw.width_px):undefined,height_px:Number.isFinite(Number(raw?.height_px))?Number(raw.height_px):undefined,
  title:safeText(raw?.title,500)||undefined,alt_text:safeText(raw?.alt_text,500)||undefined,usage_role:safeText(raw?.usage_role,120)||undefined
 })).filter(m=>!!m.media_id);
}
export function sanitizePublishedEntity(entity:PublicEntity):PublicEntity{
 return {...entity,media:sanitizePublicMedia(entity?.media)};
}
export function validatePublishedEntity(entity:PublicEntity){
 if(!entity?.entity?.id||!entity?.version?.contentHash)throw Object.assign(new Error('PUBLIC_CONTENT_INVALID'),{status:404});
 let last=-1;
 for(const s of entity.sections||[]){if(!COMPONENTS.has(s.component))throw Object.assign(new Error('UNKNOWN_COMPONENT'),{status:404});if(!Number.isInteger(s.ordinal)||s.ordinal<last)throw Object.assign(new Error('SECTION_ORDER_INVALID'),{status:404});last=s.ordinal;}
 for(const m of entity.media||[]){if(m.source_class==='LOCAL_UPLOAD'&&!m.media_id)throw Object.assign(new Error('PUBLIC_MEDIA_INVALID'),{status:404});}
 return entity;
}
export interface ApiTransport{fetch(input:Request|string,init?:RequestInit):Promise<Response>}
export function httpTransport():ApiTransport{return {fetch:(input,init)=>fetch(input,init)}}
export async function apiJson<T>(transport:ApiTransport,base:string,path:string,init?:RequestInit):Promise<{data:T;etag:string}>{
 const root=base.replace(/\/$/,'');const url=`${root}${path}`;const ctrl=new AbortController();const timer=setTimeout(()=>ctrl.abort(),4000);
 try{const r=await transport.fetch(url,{...init,signal:ctrl.signal,headers:{accept:'application/json',...(init?.headers||{})}});if(!r.ok)throw Object.assign(new Error(r.status===404?'NOT_FOUND':'PUBLIC_API_UNAVAILABLE'),{status:r.status});const body=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(await boundedBytes(r,1048576))) as PublicEnvelope<T>;if(!body||body.ok!==true)throw new Error('PUBLIC_API_INVALID');return {data:body.data,etag:r.headers.get('etag')||''};}finally{clearTimeout(timer)}
}
function localePath(path:string,locale:Locale){const clean=path.startsWith('/')?path:`/${path}`;if(locale==='ar')return clean==='/'?'/ar':`/ar${clean}`;return clean}
export async function loadPublishedPage(transport:ApiTransport,base:string,path:string,locale:Locale,origin:string):Promise<PublishedPageModel>{
 const q=encodeURIComponent(path);const route=(await apiJson<PublicRoute>(transport,base,`/api/public/v1/route?locale=${locale}&path=${q}`)).data;
 const content=await apiJson<PublicEntity>(transport,base,`/api/public/v1/content/${encodeURIComponent(route.entityId)}?locale=${locale}`);const page=sanitizePublishedEntity(content.data);validatePublishedEntity(page);
 if(path==='/'){
  const home=new Set([...COMPONENTS].filter(k=>!['route-hero','content','service-list','knowledge-list','knowledge-detail','legal-document','inquiry-wizard'].includes(k)));
  const seen=new Set<string>();for(const section of page.sections||[]){if(!home.has(section.component)||seen.has(COMPONENT_ALIASES[section.component]||section.component))throw Object.assign(new Error('PUBLIC_COMPONENT_MAPPING_INVALID'),{status:404});seen.add(COMPONENT_ALIASES[section.component]||section.component);}
  if(!seen.has('hero'))throw Object.assign(new Error('PUBLIC_COMPONENT_MAPPING_INVALID'),{status:404});
 }
 const model:PublishedPageModel={locale,path:route.path,route,page,etag:content.etag||`"${page.version.contentHash}-${page.version.pointer}"`,canonical:new URL(localePath(route.path,locale),origin).href,alternates:[]};
 for(const alt of ['en','ar'] as Locale[]){try{await apiJson<PublicRoute>(transport,base,`/api/public/v1/route?locale=${alt}&path=${q}`);model.alternates.push({locale:alt,href:new URL(localePath(route.path,alt),origin).href});}catch{}}
 model.presentation=(await apiJson<NonNullable<PublishedPageModel['presentation']>>(transport,base,`/api/public/v1/presentation?locale=${locale}`)).data;
 model.navigation=sanitizePublishedEntity((await apiJson<PublicEntity>(transport,base,`/api/public/v1/navigation/primary?locale=${locale}`)).data);validatePublishedEntity(model.navigation);
 model.footer=sanitizePublishedEntity((await apiJson<PublicEntity>(transport,base,`/api/public/v1/footer/primary?locale=${locale}`)).data);validatePublishedEntity(model.footer);
 if(model.presentation?.features?.knowledge!==false&&(route.path==='/'||route.path==='/knowledge'||(route.path.startsWith('/knowledge/')&&page.entity.type!=='KNOWLEDGE_ARTICLE'))){model.knowledge=(await apiJson(transport,base,`/api/public/v1/knowledge?locale=${locale}&limit=20&offset=0`)).data}
 if((route.path.startsWith('/knowledge')&&model.presentation?.features?.knowledge===false)||(route.path.startsWith('/inquiry')&&model.presentation?.features?.inquiry===false)||(route.path==='/search'&&model.presentation?.features?.search===false))throw Object.assign(new Error('FEATURE_UNAVAILABLE'),{status:503});
 if(page.entity.type==='KNOWLEDGE_ARTICLE'){const key=route.path.split('/')[2];model.knowledge=(await apiJson(transport,base,`/api/public/v1/knowledge/${encodeURIComponent(key)}?locale=${locale}`)).data;model.knowledgeIndex=(await apiJson(transport,base,`/api/public/v1/knowledge?locale=${locale}&limit=20&offset=0`)).data}
 if(route.path.startsWith('/legal/')){model.legal=sanitizePublishedEntity((await apiJson<PublicEntity>(transport,base,`/api/public/v1/legal/${encodeURIComponent(route.path.split('/')[2])}?locale=${locale}`)).data);validatePublishedEntity(model.legal)}
 if(route.path==='/inquiry'||route.path.startsWith('/inquiry/')){model.inquiryDefinition=(await apiJson(transport,base,`/api/public/v1/inquiry-definition?locale=${locale}`)).data}
  const canonical=(page.entity.content.seo as any)?.canonical;if(typeof canonical==='string'&&canonical!==route.path){await apiJson<PublicRoute>(transport,base,`/api/public/v1/route?locale=${locale}&path=${encodeURIComponent(canonical)}`);model.canonical=new URL(localePath(canonical,locale),origin).href;}
 const identity = JSON.stringify({presentation:model.presentation,locale,path:model.path,page:model.page,navigation:model.navigation,footer:model.footer,knowledge:model.knowledge,knowledgeIndex:model.knowledgeIndex,legal:model.legal,inquiryDefinition:model.inquiryDefinition,alternates:model.alternates});
 const hash=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(identity));
 model.etag='"'+Array.from(new Uint8Array(hash),b=>b.toString(16).padStart(2,'0')).join('')+'"';
 return model;
}
export function escapeHtml(v:unknown){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!))}
export function publishedKnowledgeCards(items:any[],locale:Locale){if(!items.length)return `<p class="tiny" role="status">${locale==='ar'?'لا توجد مقالات منشورة في هذا التصنيف.':'No published articles in this category.'}</p>`;return items.slice(0,20).map(x=>{const c=x?.content||{},title=safeText(c.title||c.heading,240),summary=safeText(c.summary||c.description,800),key=safeText(x?.key,160);if(!title||!key)return '';return `<article class="knowledge-card" data-published-article="${escapeHtml(key)}"><span class="tag">${locale==='ar'?'المعرفة':'Knowledge'}</span><h3>${escapeHtml(title)}</h3><p>${escapeHtml(summary)}</p><a href="${locale==='ar'?'/ar':''}/knowledge/${encodeURIComponent(key)}">${locale==='ar'?'اقرأ المقال':'Read article'}</a></article>`}).join('')}
function bindPublishedEditorial(html:string,model:PublishedPageModel){
 if(model.path==='/knowledge'||(model.path.startsWith('/knowledge/')&&model.page.entity.type!=='KNOWLEDGE_ARTICLE')){
  const items=(model.knowledge as any)?.items;if(!Array.isArray(items))throw Object.assign(new Error('PUBLIC_CONTENT_INVALID'),{status:404});
  const kinds:Record<string,string>={guides:'GUIDE',insights:'INSIGHT','digital-future':'DIGITAL_FUTURE',research:'RESEARCH',stories:'STORY',news:'NEWS'};const kind=kinds[model.path.split('/')[2]];html=replacePublishedRegion(html,'id','knowledge-list',publishedKnowledgeCards(kind?items.filter((x:any)=>x.kind===kind):items,model.locale));
  const links=items.slice(0,3).map((x:any)=>`<a href="/knowledge/${encodeURIComponent(safeText(x.key,160))}"><span>${escapeHtml(safeText(x.content?.title,240))}</span></a>`).join('');
  html=replacePublishedRegion(html,'class','knowledge-discovery',`<div class="knowledge-shelf"><h3>${model.locale==='ar'?'من المكتبة':'From the library'}</h3>${links}</div>`);
 }
 if(model.page.entity.type==='KNOWLEDGE_ARTICLE'){
  const c=model.page.entity.content;const prose=sanitizePublishedProse(safeText(c.body||c.summary||c.description,12000));
  html=replacePublishedRegion(html,'class','editorial-long',`<div data-public-binding="knowledge-detail">${prose}</div>`);
  const items=((model.knowledgeIndex as any)?.items||[]).filter((x:any)=>x.entityId!==model.page.entity.id).slice(0,3);
  html=replacePublishedRegion(html,'class','article-aside',`<section class="knowledge-shelf"><h3>${model.locale==='ar'?'قراءات أخرى':'Read next'}</h3>${publishedKnowledgeCards(items,model.locale)}<a href="/knowledge">${model.locale==='ar'?'مكتبة المعرفة':'Knowledge library'}</a></section>`);
 }
 if(model.legal){const c=model.legal.entity.content;html=replacePublishedRegion(html,'class','editorial-long',`<div data-public-binding="legal">${sanitizePublishedProse(safeText(c.body||c.summary,12000))}</div>`);}
 return html;
}
function patchFirst(html:string,re:RegExp,value:string){return value?html.replace(re,(m,p1,p2)=>`${p1}${escapeHtml(value)}${p2}`):html}
function publishedItems(entity?:PublicEntity){const c=entity?.entity?.content as Record<string,unknown>|undefined;return Array.isArray(c?.items)?c!.items.filter(x=>x&&typeof x==='object') as Record<string,unknown>[]:[]}
function patchLinks(html:string,items:Record<string,unknown>[]){for(const item of items){const href=safeUrl(item.href);const label=safeText(item.label,180);if(!href||!label)continue;const escaped=href.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');const re=new RegExp(`(<a[^>]+href=["']${escaped}["'][^>]*>)([\\s\\S]*?)(<\\/a>)`,'i');html=html.replace(re,(m,a,_old,z)=>/class=["'][^"']*\bbrand\b/.test(a)?m:`${a}${escapeHtml(label)}${z}`)}return html}
export function overlayPublishedHtml(html:string,model:PublishedPageModel){
 if(model.page.entity.type==='SERVICE'){const c=model.page.entity.content,available=model.page.entity.availability==='AVAILABLE';return localizePublishedLinks(`<section class="section-space"><div class="shell"><span class="eyebrow">${model.locale==='ar'?'خدمات iDigitalRoot':'iDigitalRoot SERVICES'}</span><h1 class="section-title">${escapeHtml(safeText(c.title,240))}</h1><p class="section-lead">${escapeHtml(safeText(c.description,8000))}</p>${available?`<a class="btn primary" href="/inquiry">${model.locale==='ar'?'ناقش هذه الخدمة معنا':'Discuss this service'}</a>`:`<p role="status">${model.locale==='ar'?'هذه الخدمة غير متاحة حالياً.':'This service is currently unavailable.'}</p>`}</div></section>`,model.locale)}
 if(model.inquiryDefinition)return localizePublishedLinks(renderLiveInquiry(model),model.locale);
 if(model.path==='/')html=composePublishedHome(html,(model.page.sections||[]).filter(s=>model.presentation?.features?.knowledge!==false||!['knowledge','knowledge-preview','article-research-feed'].includes(s.component)),s=>renderPublishedSection(s as PublicSection,model.page),COMPONENT_ALIASES,safeUrl);else if(!(PHASE1B_ROUTES as readonly string[]).includes(model.path)&&(model.page.sections||[]).length)html=`<section class="section-space"><div class="shell"><h1 class="section-title">${escapeHtml(safeText(model.page.entity.content.title||model.page.entity.content.heading,240))}</h1></div></section>`+model.page.sections.filter(s=>s.component!=='footer').map(s=>renderPublishedSection(s,model.page)).join('');
 if(model.path!=='/'&&(PHASE1B_ROUTES as readonly string[]).includes(model.path)&&model.page.sections?.length)html+=model.page.sections.filter(s=>s.component!=='footer').map(s=>renderPublishedSection(s,model.page)).join('');
 if(model.path==='/'&&model.knowledge){const items=(model.knowledge as any).items||[];if(html.includes('knowledge-grid'))html=replacePublishedRegion(html,'class','knowledge-grid',publishedKnowledgeCards(items.slice(0,3),model.locale));}
 html=bindEditorialFields(html,model.page.entity.content.fields);html=bindPublishedEditorial(html,model);if(model.path==='/services'){const services=(model.presentation?.records||[]).filter(x=>x.type==='SERVICE');if(services.length)html=replacePublishedRegion(html,'class','service-list',services.map((x:any)=>`<a href="/services/${encodeURIComponent(x.key.replace(/^service-/,''))}"><h3>${escapeHtml(safeText(x.content.title,240))}</h3><p>${escapeHtml(safeText(x.content.description,8000))}</p>${x.availability==='UNAVAILABLE'?`<span>${model.locale==='ar'?'غير متاحة حالياً':'Currently unavailable'}</span>`:''}</a>`).join(''));}
 const c=model.page.entity.content||{};const presentation=(c.presentation&&typeof c.presentation==='object'?c.presentation:c) as Record<string,unknown>;
 if(!Array.isArray(c.fields)&&!model.page.sections.some(s=>s.component==='hero'&&Array.isArray(s.config.fields)))html=patchFirst(html,/(<h1[^>]*>)[\s\S]*?(<\/h1>)/i,safeText(presentation.heading||presentation.title));
 if(!Array.isArray(c.fields)&&!model.page.sections.some(s=>s.component==='hero'&&Array.isArray(s.config.fields)))html=patchFirst(html,/(<p class="(?:lead|section-lead)"[^>]*>)[\s\S]*?(<\/p>)/i,safeText(presentation.lead||presentation.description||presentation.summary));
 for(const s of model.page.sections||[]){if(Array.isArray(s.config.fields))continue;const fields={...s.config,...s.content};const heading=safeText(fields.heading||fields.title);const lead=safeText(fields.lead||fields.description||fields.summary||fields.body);if(!heading&&!lead)continue;const escComp=s.component.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');const block=new RegExp(`(<[^>]+data-cms-section="${escComp}"[^>]*>)([\\s\\S]*?)(<\\/section>)`,'i');html=html.replace(block,(all,start,body,end)=>{let b=body;if(heading)b=patchFirst(b,s.component==='hero'?/(<h1[^>]*>)[\s\S]*?(<\/h1>)/i:/(<h[23][^>]*>)[\s\S]*?(<\/h[23]>)/i,heading);if(lead)b=patchFirst(b,/(<p[^>]*>)[\s\S]*?(<\/p>)/i,lead);return start+b+end});}
 html=bindSectionMedia(html,model.page.sections||[],model.page.media||[]);
 return localizePublishedLinks(bindPresentation(html,model),model.locale);
}
export function overlayPublishedShell(header:string,footer:string,model:PublishedPageModel){
 const link=(x:any)=>{const u=safeUrl(x?.href),label=safeText(x?.label,180);return u&&label?`<a class="nav-anchor" href="${escapeHtml(u)}">${escapeHtml(label)}</a>`:''};
 const megaOpen=header.includes('id="personal-mega"')&&!/id="personal-mega"[^>]*\bhidden\b/.test(header);const item=(x:any,mobile=false)=>{const children=Array.isArray(x?.children)?x.children.slice(0,24):[];if(!mobile&&x?.href==='/personal'&&children.length)return `<button class="nav-menu-trigger" type="button" data-action="mega" data-section="personal" aria-haspopup="true" aria-controls="personal-mega" aria-expanded="${megaOpen}">${escapeHtml(safeText(x.label,180))} <span aria-hidden="true">⌄</span></button>`;return children.length?`<div class="published-nav-group"><details><summary>${escapeHtml(safeText(x.label,180))}</summary><div class="published-nav-children">${link(x)}${children.map(link).join('')}</div></details></div>`:link(x)};
 const items=publishedItems(model.navigation).slice(0,32).filter(x=>model.presentation?.features?.knowledge!==false||!String(x.href).startsWith('/knowledge'));
 if(header){const personal=items.find(x=>x.href==='/personal');if(personal&&Array.isArray(personal.children)&&header.includes('personal-mega-grid'))header=replacePublishedRegion(header,'class','personal-mega-grid',`<div class="personal-mega-intro"><span class="personal-mega-kicker">PERSONAL iDIGITALROOT</span><h3>${model.locale==='ar'?'مساحتك الخاصة لكل خطوة نحو مستقبلك.':'One home for everything you are becoming.'}</h3>${link(personal)}</div><div class="personal-mega-group"><span class="personal-mega-label">${escapeHtml(safeText(personal.label,180))}</span>${personal.children.map(link).join('')}</div>`);if((!personal||!Array.isArray(personal.children)||!personal.children.length)&&header.includes('id="personal-mega"'))header=replacePublishedRegion(header,'id','personal-mega','');header=replacePublishedRegion(header,'class','desktop-nav',items.map(x=>item(x)).join(''));if(header.includes('mobile-site-links'))header=replacePublishedRegion(header,'class','mobile-site-links',items.map(x=>item(x,true)).join(''));}
 const c:any=model.footer?.entity?.content||{};
 if(footer&&Array.isArray(c.groups)){
  const groups=c.groups.slice(0,12).map((g:any)=>`<nav class="footer-nav-group" aria-label="${escapeHtml(safeText(g.label,180))}"><h3>${escapeHtml(safeText(g.label,180))}</h3>${(Array.isArray(g.links)?g.links:[]).slice(0,24).map(link).join('')}</nav>`).join('');
  footer=footer.replace(/<nav class="footer-nav-group"[\s\S]*?<\/nav>/g,'');
  footer=footer.replace(/(<div class="footer-main">)/,`<div class="footer-main published-footer" style="--footer-group-count:${Math.min(c.groups.length,4)}">${groups}`);
 }else footer=patchLinks(footer,publishedItems(model.footer));
 if(model.presentation?.features?.search===false)header=header.replace(/(<button[^>]*data-action="search"[^>]*)>/g,'$1 disabled>');
 return {header:localizePublishedLinks(bindPresentation(header,model),model.locale),footer:localizePublishedLinks(bindPresentation(footer,model),model.locale)};
}
function bindPresentation(html:string,model:PublishedPageModel){return bindPublishedRecords(html,model.presentation?.records||[])}
export function publicDesign(model:PublishedPageModel){const c=model.presentation?.records.find(x=>x.key==='site-design-profile')?.content||{};const body=[16,17,18].includes(Number(c.body))?Number(c.body):16;const line=[1.6,1.7].includes(Number(c.lineHeight))?Number(c.lineHeight):1.6;const nav=[15,16].includes(Number(c.nav))?Number(c.nav):15;return `--published-body:${body}px;--published-line:${line};--published-nav:${nav}px;`}
export function seoFrom(model:PublishedPageModel){const c=model.page.entity.content||{};const seo=(c.seo&&typeof c.seo==='object'?c.seo:{}) as Record<string,unknown>;const p=(c.presentation&&typeof c.presentation==='object'?c.presentation:c) as Record<string,unknown>;return {title:safeText(seo.title||p.title||p.heading,180)||'iDigitalRoot Personal · Student Edition',description:safeText(seo.description||p.description||p.lead||model.presentation?.records.find(x=>x.key==='site-brand-contact-social')?.content.defaultDescription,320)||'iDigitalRoot Personal',robots:safeText(seo.robots,80)||'index,follow'};}

export function publicHeadingStyle(model:PublishedPageModel){return model.presentation?.records.find(x=>x.key==='site-design-profile')?.content?.headings==='balanced'?'balanced':'signature-large'}
