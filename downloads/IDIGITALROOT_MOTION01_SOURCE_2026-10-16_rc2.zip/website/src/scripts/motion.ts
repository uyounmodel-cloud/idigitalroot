/** Decorative motion only. No tracking, remote resources, navigation interception or content mutation. */
if (typeof document !== 'undefined') {
 const root=document.documentElement;
 const preference=window.matchMedia('(prefers-reduced-motion: reduce)');
 const finePointer=window.matchMedia('(hover: hover) and (pointer: fine)');
 const toggles=[...document.querySelectorAll<HTMLButtonElement>('[data-motion-toggle]')];
 const sculptures=[...document.querySelectorAll<HTMLElement>('.m-sculpture')];
 const running=new Set<Animation>();
 let chosen:string|null=null,enabled=false,frame=0;
 try{chosen=localStorage.getItem('idr-motion-preference')}catch{/* Storage is optional. */}
 const update=()=>{
  // An OS preference is a hard ceiling; turning motion on requires changing that preference.
  enabled=!preference.matches&&chosen!=='off';root.dataset.motion=enabled?'on':'off';
  for(const toggle of toggles){toggle.hidden=false;toggle.setAttribute('aria-pressed',String(!enabled));toggle.setAttribute('aria-label',root.lang==='ar'?(enabled?'إيقاف الحركة الزخرفية':'تشغيل الحركة الزخرفية'):(enabled?'Pause decorative motion':'Enable decorative motion'));toggle.setAttribute('aria-disabled',String(preference.matches));if(preference.matches)toggle.setAttribute('aria-label',root.lang==='ar'?'الحركة متوقفة وفق إعداد جهازك':'Motion is paused by your device setting');toggle.title=preference.matches?(root.lang==='ar'?'تفضيل تقليل الحركة في الجهاز مفعّل':'Your device prefers reduced motion'):(toggle.getAttribute('aria-label')||'');toggle.querySelector('.m-motion-symbol')!.textContent=enabled?'Ⅱ':'▷';}
  if(!enabled){for(const animation of running)animation.cancel();running.clear();for(const el of sculptures){el.style.removeProperty('--tilt-x');el.style.removeProperty('--tilt-y')}}
 };
 for(const toggle of toggles)toggle.addEventListener('click',()=>{if(preference.matches)return;chosen=enabled?'off':'on';try{localStorage.setItem('idr-motion-preference',chosen)}catch{}update()});
 preference.addEventListener('change',update);update();
 // Content is visible by default. Animation failure and missing JS cannot hide a section.
 if('IntersectionObserver' in window){
  const reveals=new IntersectionObserver(entries=>{for(const entry of entries){if(!entry.isIntersecting)continue;const el=entry.target as HTMLElement;el.dataset.motionEntered='true';reveals.unobserve(el);if(enabled){const animation=el.animate([{opacity:.35,transform:'translateY(26px)'},{opacity:1,transform:'translateY(0)'}],{duration:700,easing:'cubic-bezier(.2,.8,.2,1)'});running.add(animation);animation.finished.catch(()=>{}).finally(()=>running.delete(animation))}}},{threshold:.12});
  document.querySelectorAll('.u-section h2,.u-audience-card,.u-grid>.u-card,.u-account-map,.u-faq-grid details').forEach(el=>reveals.observe(el));
  const visibility=new IntersectionObserver(entries=>{for(const entry of entries)(entry.target as HTMLElement).dataset.motionOffscreen=String(!entry.isIntersecting)},{rootMargin:'80px'});sculptures.forEach(el=>visibility.observe(el));
 }
 for(const el of sculptures){
  let pointerFrame=0;
  el.addEventListener('pointermove',event=>{if(!enabled||!finePointer.matches||event.pointerType==='touch'||pointerFrame)return;pointerFrame=requestAnimationFrame(()=>{pointerFrame=0;if(!enabled)return;const box=el.getBoundingClientRect();el.style.setProperty('--tilt-x',`${((event.clientX-box.left)/box.width-.5)*10}deg`);el.style.setProperty('--tilt-y',`${-((event.clientY-box.top)/box.height-.5)*8}deg`);})},{passive:true});
  el.addEventListener('pointerleave',()=>{cancelAnimationFrame(pointerFrame);pointerFrame=0;el.style.removeProperty('--tilt-x');el.style.removeProperty('--tilt-y')});
 }
 const header=document.querySelector<HTMLElement>('.u-header'),progress=document.getElementById('scroll-progress');
 const scroll=()=>{if(frame)return;frame=requestAnimationFrame(()=>{frame=0;if(header)header.dataset.scrolled=String(scrollY>24);const length=document.documentElement.scrollHeight-innerHeight;if(progress)progress.style.transform=`scaleX(${length>0?Math.min(1,Math.max(0,scrollY/length)):0})`;})};
 addEventListener('scroll',scroll,{passive:true});addEventListener('resize',scroll,{passive:true});scroll();
 addEventListener('pagehide',()=>{cancelAnimationFrame(frame);for(const animation of running)animation.cancel()},{once:true});
}
