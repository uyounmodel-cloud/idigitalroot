import fs from 'node:fs';
import assert from 'node:assert/strict';
import puppeteer from '../website/node_modules/puppeteer-core/lib/puppeteer/puppeteer-core.js';
const dir='evidence/motion';fs.mkdirSync(dir,{recursive:true});
const browser=await puppeteer.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
const checks=[],errors=[];const p=await browser.newPage();await p.setCacheEnabled(false);
p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
const base='http://127.0.0.1:4400';
async function check(name,fn){try{await fn();checks.push({name,status:'PASS'});console.log('PASS '+name)}catch(e){checks.push({name,status:'FAIL',error:String(e)});throw e}}
const wait=ms=>new Promise(r=>setTimeout(r,ms));
try{
 await check('Real decorative animation advances; visible pause stops it and persists through navigation',async()=>{
  await p.setViewport({width:1440,height:1000});await p.emulateMediaFeatures([{name:'prefers-reduced-motion',value:'no-preference'}]);await p.goto(base,{waitUntil:'networkidle0'});
  assert.equal(await p.$eval('html',x=>x.dataset.motion),'on');
  const before=await p.$eval('.m-rotor',x=>getComputedStyle(x).transform);await wait(250);const after=await p.$eval('.m-rotor',x=>getComputedStyle(x).transform);assert.notEqual(before,after);
  await p.click('[data-motion-toggle]');assert.equal(await p.$eval('[data-motion-toggle]',x=>x.getAttribute('aria-pressed')),'true');
  assert.equal(await p.$eval('.m-rotor',x=>getComputedStyle(x).animationName),'none');
  await p.goto(base+'/students',{waitUntil:'networkidle0'});assert.equal(await p.$eval('html',x=>x.dataset.motion),'off');
  await p.click('[data-motion-toggle]');assert.equal(await p.$eval('html',x=>x.dataset.motion),'on');
 });
 await check('Live reduced-motion preference overrides saved animation and exposes all content',async()=>{
  await p.emulateMediaFeatures([{name:'prefers-reduced-motion',value:'reduce'}]);await p.waitForFunction(()=>document.documentElement.dataset.motion==='off');
  assert.equal(await p.$eval('.m-rotor',x=>getComputedStyle(x).animationName),'none');await p.click('[data-motion-toggle]');assert.equal(await p.$eval('html',x=>x.dataset.motion),'off');
  await p.evaluate(()=>scrollTo(0,document.documentElement.scrollHeight));await wait(100);assert.equal(await p.$$eval('.u-section h2',xs=>xs.every(x=>getComputedStyle(x).opacity==='1')),true);
 });
 await check('Responsive motion composition and all four audience journeys remain visible in EN/LTR and AR/RTL',async()=>{
  for(const width of [320,390,768,1090,1440])for(const lc of ['en','ar'])for(const path of ['','/students','/professionals','/entrepreneurs','/businesses']){
   await p.setViewport({width,height:900});const url=base+(lc==='ar'?'/ar':'')+path;const r=await p.goto(url,{waitUntil:'domcontentloaded'});assert.equal(r.status(),200,url);
   const facts=await p.evaluate(()=>({overflow:document.documentElement.scrollWidth-innerWidth,h1:document.querySelectorAll('h1').length,dir:document.documentElement.dir,hero:document.querySelector('.m-sculpture')?.getBoundingClientRect().width,body:getComputedStyle(document.body).visibility}));assert.ok(facts.overflow<=0,JSON.stringify({url,width,...facts}));assert.equal(facts.h1,1);assert.equal(facts.dir,lc==='ar'?'rtl':'ltr');assert.ok(facts.hero>200);assert.equal(facts.body,'visible');
  }
 });
 await check('Keyboard pause and native phone menu work without pointer-only controls or blocked scrolling',async()=>{
  await p.emulateMediaFeatures([{name:'prefers-reduced-motion',value:'no-preference'}]);await p.setViewport({width:390,height:900});await p.goto(base,{waitUntil:'networkidle0'});await p.focus('[data-motion-toggle]');await p.keyboard.press('Enter');assert.equal(await p.$eval('[data-motion-toggle]',x=>x.getAttribute('aria-pressed')),'true');
  await p.focus('.u-mobile-menu>summary');await p.keyboard.press('Enter');assert.equal(await p.$eval('.u-mobile-menu',x=>x.open),true);await p.keyboard.press('Escape');assert.equal(await p.$eval('.u-mobile-menu',x=>x.open),false);
  await p.evaluate(()=>scrollTo(0,600));await wait(100);assert.ok(await p.evaluate(()=>scrollY>400));
 });
 await check('Script-free fallback retains headings, audience links, native menus and a static visual',async()=>{
  const q=await browser.newPage();try{await q.setJavaScriptEnabled(false);await q.setViewport({width:390,height:900});await q.goto(base,{waitUntil:'networkidle0'});assert.ok(await q.$('h1'));assert.equal(await q.$eval('.m-rotor',x=>getComputedStyle(x).animationName),'none');await q.click('.u-mobile-menu>summary');assert.equal(await q.$eval('.u-mobile-menu',x=>x.open),true);assert.equal(await q.$$eval('.u-audience-card',x=>x.length),4);assert.equal(await q.$eval('[data-motion-toggle]',x=>getComputedStyle(x).display),'none')}finally{await q.close()}
 });
 await check('Normal-CSP motion uses no third-party assets or new browser CMS/storage access',async()=>{
  const remote=[],forbidden=[];const listener=r=>{const u=new URL(r.url());if(u.protocol==='http:'||u.protocol==='https:'){if(u.origin!==base)remote.push(u.origin);if(/\/api\/cms|cloudflarestorage|\/d1\//.test(u.href))forbidden.push(u.pathname)}};p.on('request',listener);await p.goto(base,{waitUntil:'networkidle0'});await p.evaluate(()=>scrollTo(0,1500));await wait(800);p.off('request',listener);assert.deepEqual(remote,[]);assert.deepEqual(forbidden,[]);assert.deepEqual(errors,[])
 });
}finally{await browser.close();fs.writeFileSync(dir+'/checks.json',JSON.stringify({status:checks.some(x=>x.status==='FAIL')?'FAIL':'PASS',checks,errors,scope:'Real Chromium, normal CSP, local built Workers source. Motion is decoration, not an operational product capability.'},null,2))}
